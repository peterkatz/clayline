; CLAYLINE_HEADER_BEGIN
; clayline_version=0.1.0.dev0
; generated_utc=reproducible
; job_id=weave-slice-2df0ff8f08b9ef8d88c1
; prepared_trace_sha256=7ce2a9700865d2773f6d06fbe11e61f65899a3433c68576180fc7cff9793a04b
; body_sha256=e1f5795d4a4fc9b705abf6f89d635a6b797d92707bdbb2005c97d8a1782c1c80
; profile_name=potterbot-xl
; profile_version=1.3.0
; profile_verified=true
; profile_flavor=marlin
; extrusion_mode=absolute
; bead_width_mm=5
; layer_height_mm=2
; flow_multiplier=1
; wet_density_g_cm3=1.8
; prime_mm=0
; end_early_mm=0
; first_layer_z_mm=2
; speed_default_mm_s=40
; speed_first_layer_mm_s=30
; speed_travel_mm_s=40
; virtual_filament_diameter_mm=1.75
; work_bounds=17,398,12,393,0,710
; machine_envelope=0,490,0,490,0,710
; stats.motion_count=1919
; stats.print_motion_count=1902
; stats.travel_motion_count=17
; stats.stroke_count=6
; stats.page_count=1
; stats.print_path_mm=3067.687508
; stats.deposited_path_mm=3067.687508
; stats.travel_path_mm=147.343478
; stats.total_motion_path_mm=3215.030986
; stats.motion_time_seconds=86.212505
; stats.pause_time_seconds=0
; stats.pressure_time_seconds=0
; stats.estimated_print_time_seconds=86.212505
; stats.body_volume_mm3=31377.28273
; stats.wet_weight_g=56.479109
; stats.body_e=13045.158262
; stats.pressure_e_excluded=0
; stats.warning_count=1
; nominal_label=Weave mesh — teapot-lid.obj
; stats.warning_count.overhang=1
; parameter.bottom_layers=0
; parameter.first_layer_flow_factor=1.1
; parameter.first_layer_height_mm=2.0
; parameter.interior=solid
; parameter.layer_count=6
; parameter.layer_range_from=1
; parameter.layer_range_semantics=one_based_inclusive
; parameter.layer_range_to=6
; parameter.layer_range_total=6
; parameter.level_rim=true
; parameter.mode=weave
; parameter.pattern_part_0001={"extrusion":[{"u":0.0,"value":1.0},{"u":0.5,"value":1.0}],"interpolation":"monotone_cubic_periodic","name":"sine","schema":"cla
; parameter.pattern_part_0002=yline.weave-pattern","seed":null,"settings":{"amplitude":0.6,"bottom_layers":0,"extrusion_phase_offset":0.0,"infill_angle_deg":4
; parameter.pattern_part_0003=5.0,"infill_base_layers":0,"infill_cap_layers":0,"infill_pattern":"lines","infill_ramp_layers":3,"infill_spacing_beads":3.0,"int
; parameter.pattern_part_0004=erior":"solid","level_rim":true,"overlap_fraction":0.2,"pinned_seam_angle":0.0,"seam":"chained","solid_pattern":"crossing","twis
; parameter.pattern_part_0005=t":0.0,"wavelength":12.0,"z_blend":false},"version":1,"wave":[{"u":0.0,"value":0.0},{"u":0.0625,"value":0.3826834323650898},{"u"
; parameter.pattern_part_0006=:0.125,"value":0.7071067811865475},{"u":0.1875,"value":0.9238795325112867},{"u":0.25,"value":1.0},{"u":0.3125,"value":0.92387953
; parameter.pattern_part_0007=25112867},{"u":0.375,"value":0.7071067811865476},{"u":0.4375,"value":0.3826834323650899},{"u":0.5,"value":1.2246467991473532e-16
; parameter.pattern_part_0008=},{"u":0.5625,"value":-0.38268343236508967},{"u":0.625,"value":-0.7071067811865475},{"u":0.6875,"value":-0.9238795325112865},{"u
; parameter.pattern_part_0009=":0.75,"value":-1.0},{"u":0.8125,"value":-0.9238795325112866},{"u":0.875,"value":-0.7071067811865477},{"u":0.9375,"value":-0.382
; parameter.pattern_part_0010=6834323650904}]}
; parameter.pattern_part_count=10
; parameter.print_range=printing layers 1–6 of 6, rebased to the bed
; parameter.range_rebased_to_bed=true
; parameter.reproducible=true
; parameter.restore_capsule_v1_b64_part_0001=eyJlbWlzc2lvbiI6eyJlbmRfZWFybHlfbW1faGV4IjoiMHgwLjBwKzAiLCJmbG93X211bHRpcGxpZXJfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzAiLCJwcmltZV9t
; parameter.restore_capsule_v1_b64_part_0002=bV9oZXgiOiIweDAuMHArMCIsInJlcHJvZHVjaWJsZSI6dHJ1ZSwid2V0X2RlbnNpdHlfZ19jbTNfaGV4IjoiMHgxLmNjY2NjY2NjY2NjY2RwKzAifSwiam9iX2lkIjp7
; parameter.restore_capsule_v1_b64_part_0003=ImVuY29kaW5nIjoidXRmLTgvYmFzZTY0IiwicHJlc2VudCI6dHJ1ZSwidXRmOF9iNjQiOiJkMlZoZG1VdGMyeHBZMlV0TW1SbU1HWm1PR1l3T0dJNVpXWTRaRGc0WXpF
; parameter.restore_capsule_v1_b64_part_0004=PSJ9LCJwYXR0ZXJuX2pzb25fdXRmOF9iNjQiOiJleUpsZUhSeWRYTnBiMjRpT2x0N0luVWlPakF1TUN3aWRtRnNkV1VpT2pFdU1IMHNleUoxSWpvd0xqVXNJblpoYkhW
; parameter.restore_capsule_v1_b64_part_0005=bElqb3hMakI5WFN3aWFXNTBaWEp3YjJ4aGRHbHZiaUk2SW0xdmJtOTBiMjVsWDJOMVltbGpYM0JsY21sdlpHbGpJaXdpYm1GdFpTSTZJbk5wYm1VaUxDSnpZMmhsYldF
; parameter.restore_capsule_v1_b64_part_0006=aU9pSmpiR0Y1YkdsdVpTNTNaV0YyWlMxd1lYUjBaWEp1SWl3aWMyVmxaQ0k2Ym5Wc2JDd2ljMlYwZEdsdVozTWlPbnNpWVcxd2JHbDBkV1JsSWpvd0xqWXNJbUp2ZEhS
; parameter.restore_capsule_v1_b64_part_0007=dmJWOXNZWGxsY25NaU9qQXNJbVY0ZEhKMWMybHZibDl3YUdGelpWOXZabVp6WlhRaU9qQXVNQ3dpYVc1bWFXeHNYMkZ1WjJ4bFgyUmxaeUk2TkRVdU1Dd2lhVzVtYVd4
; parameter.restore_capsule_v1_b64_part_0008=c1gySmhjMlZmYkdGNVpYSnpJam93TENKcGJtWnBiR3hmWTJGd1gyeGhlV1Z5Y3lJNk1Dd2lhVzVtYVd4c1gzQmhkSFJsY200aU9pSnNhVzVsY3lJc0ltbHVabWxzYkY5
; parameter.restore_capsule_v1_b64_part_0009=eVlXMXdYMnhoZVdWeWN5STZNeXdpYVc1bWFXeHNYM053WVdOcGJtZGZZbVZoWkhNaU9qTXVNQ3dpYVc1MFpYSnBiM0lpT2lKemIyeHBaQ0lzSW14bGRtVnNYM0pwYlNJ
; parameter.restore_capsule_v1_b64_part_0010=NmRISjFaU3dpYjNabGNteGhjRjltY21GamRHbHZiaUk2TUM0eUxDSndhVzV1WldSZmMyVmhiVjloYm1kc1pTSTZNQzR3TENKelpXRnRJam9pWTJoaGFXNWxaQ0lzSW5O
; parameter.restore_capsule_v1_b64_part_0011=dmJHbGtYM0JoZEhSbGNtNGlPaUpqY205emMybHVaeUlzSW5SM2FYTjBJam93TGpBc0luZGhkbVZzWlc1bmRHZ2lPakV5TGpBc0lucGZZbXhsYm1RaU9tWmhiSE5sZlN3
; parameter.restore_capsule_v1_b64_part_0012=aWRtVnljMmx2YmlJNk1Td2lkMkYyWlNJNlczc2lkU0k2TUM0d0xDSjJZV3gxWlNJNk1DNHdmU3g3SW5VaU9qQXVNRFl5TlN3aWRtRnNkV1VpT2pBdU16Z3lOamd6TkRN
; parameter.restore_capsule_v1_b64_part_0013=eU16WTFNRGc1T0gwc2V5SjFJam93TGpFeU5Td2lkbUZzZFdVaU9qQXVOekEzTVRBMk56Z3hNVGcyTlRRM05YMHNleUoxSWpvd0xqRTROelVzSW5aaGJIVmxJam93TGpr
; parameter.restore_capsule_v1_b64_part_0014=eU16ZzNPVFV6TWpVeE1USTROamQ5TEhzaWRTSTZNQzR5TlN3aWRtRnNkV1VpT2pFdU1IMHNleUoxSWpvd0xqTXhNalVzSW5aaGJIVmxJam93TGpreU16ZzNPVFV6TWpV
; parameter.restore_capsule_v1_b64_part_0015=eE1USTROamQ5TEhzaWRTSTZNQzR6TnpVc0luWmhiSFZsSWpvd0xqY3dOekV3TmpjNE1URTROalUwTnpaOUxIc2lkU0k2TUM0ME16YzFMQ0oyWVd4MVpTSTZNQzR6T0RJ
; parameter.restore_capsule_v1_b64_part_0016=Mk9ETTBNekl6TmpVd09EazVmU3g3SW5VaU9qQXVOU3dpZG1Gc2RXVWlPakV1TWpJME5qUTJOems1TVRRM016VXpNbVV0TVRaOUxIc2lkU0k2TUM0MU5qSTFMQ0oyWVd4
; parameter.restore_capsule_v1_b64_part_0017=MVpTSTZMVEF1TXpneU5qZ3pORE15TXpZMU1EZzVOamQ5TEhzaWRTSTZNQzQyTWpVc0luWmhiSFZsSWpvdE1DNDNNRGN4TURZM09ERXhPRFkxTkRjMWZTeDdJblVpT2pB
; parameter.restore_capsule_v1_b64_part_0018=dU5qZzNOU3dpZG1Gc2RXVWlPaTB3TGpreU16ZzNPVFV6TWpVeE1USTROalY5TEhzaWRTSTZNQzQzTlN3aWRtRnNkV1VpT2kweExqQjlMSHNpZFNJNk1DNDRNVEkxTENK
; parameter.restore_capsule_v1_b64_part_0019=MllXeDFaU0k2TFRBdU9USXpPRGM1TlRNeU5URXhNamcyTm4wc2V5SjFJam93TGpnM05Td2lkbUZzZFdVaU9pMHdMamN3TnpFd05qYzRNVEU0TmpVME56ZDlMSHNpZFNJ
; parameter.restore_capsule_v1_b64_part_0020=Nk1DNDVNemMxTENKMllXeDFaU0k2TFRBdU16Z3lOamd6TkRNeU16WTFNRGt3TkgxZGZRPT0iLCJwcm9maWxlIjp7ImNlbnRlciI6eyJ4IjoiMHgxLjlmMDAwMDAwMDAw
; parameter.restore_capsule_v1_b64_part_0021=MDBwKzciLCJ5IjoiMHgxLjk1MDAwMDAwMDAwMDBwKzcifSwiZGVmYXVsdF9ub3p6bGVfZGlhbWV0ZXJfaGV4IjoiMHgxLjQwMDAwMDAwMDAwMDBwKzIiLCJkZXNjcmlw
; parameter.restore_capsule_v1_b64_part_0022=dGlvbiI6IlZlcmlmaWVkIGZyb20gUGV0ZSdzIHN1Y2Nlc3NmdWwgSmFudWFyeSAyMDI2IFBvdHRlckJvdCAxMCBYTCBwcmludC4gMTAgbW0gbm96emxlIGFkZGVkIHBl
; parameter.restore_capsule_v1_b64_part_0023=ciBQZXRlIDIwMjYtMDctMTUuIHYxLjIuMDogdHJhdmVsIHNwZWVkIGNvcnJlY3RlZCB0byBwcmludCBzcGVlZCBcdTIwMTQgdGhlIHJlZmVyZW5jZSBDdXJhIHByb2Zp
; parameter.restore_capsule_v1_b64_part_0024=bGUgb25seSB1c2VkIDEyMCBvdXRzaWRlIHNwaXJhbGl6ZSBtb2RlIGFuZCB0aGUgZmlyc3QgY2xheSBwcmludCAoMjAyNi0wNy0xNykgc2hvd2VkIGZhc3QgdHJhdmVs
; parameter.restore_capsule_v1_b64_part_0025=cyB0ZWFyIHRoZSB0aHJlYWQuIHYxLjMuMDogZW5kLW9mLWpvYiBkZXByZXNzdXJpemUgYW5kIG1hdGNoaW5nIHN0YXJ0IHByaW1lIHJlZHVjZWQgMzAwMC0+MTAwIFx1
; parameter.restore_capsule_v1_b64_part_0026=MjAxNCB0aGUgQ3VyYS1pbmhlcml0ZWQgZnVsbCBkZXByZXNzdXJpemUgbGVmdCBiYWNrLXRvLWJhY2sgam9icyBwcmludGluZyBkcnkgZm9yIDMwLTQwcyAoUGV0ZSwg
; parameter.restore_capsule_v1_b64_part_0027=MjAyNi0wOC0wMik7IDEwMCBpcyBlbm91Z2ggdG8gc3RvcCBvb3plIGR1cmluZyB0aGUgaG9taW5nIG1vdmVzIHdpdGhvdXQgZW1wdHlpbmcgdGhlIGJhcnJlbC4iLCJl
; parameter.restore_capsule_v1_b64_part_0028=bWlzc2lvbl9kZWZhdWx0cyI6eyJlbmRfZWFybHlfbW1faGV4IjoiMHgxLjQwMDAwMDAwMDAwMDBwKzIiLCJwcmltZV9tbV9oZXgiOiIweDEuZTAwMDAwMDAwMDAwMHAr
; parameter.restore_capsule_v1_b64_part_0029=MyJ9LCJlbmRfZ2NvZGUiOlsiTTgzIDtTZXQgdG8gUmVsYXRpdmUgRXh0cnVzaW9uIE1vZGUiLCJHOTEgO1NldCB0byBSZWxhdGl2ZSBQb3NpdGlvbmluZyIsIkcxIFox
; parameter.restore_capsule_v1_b64_part_0030=NTAgRS0xMDAgRjQwMDAwIDtNb3ZlIFogQXhpcyB1cCBhbmQgcmVsaWV2ZSBFeHRydWRlciBwcmVzc3VyZSAodjEuMy4wOiB3YXMgRS0zMDAwLCB3aGljaCBsZWZ0IHRo
; parameter.restore_capsule_v1_b64_part_0031=ZSBuZXh0IGpvYiBkcnkpIiwiRzkwIDtTZXQgdG8gQWJzb2x1dGUgUG9zaXRpb25pbmciLCJHMjggWiA7SG9tZSBaIiwiRzEgWDIwNy41IFkwIEY1MDAgO01vdmUgWCBh
; parameter.restore_capsule_v1_b64_part_0032=bmQgWSBzbG93IHRvIGhvbWUgcG9zaXRpb24iLCJNODIgO2Fic29sdXRlIGV4dHJ1c2lvbiBtb2RlIl0sImV4dHJ1c2lvbl9tb2RlIjoiYWJzb2x1dGUiLCJmbGF2b3Ii
; parameter.restore_capsule_v1_b64_part_0033=OiJtYXJsaW4iLCJnY29kZV93aGl0ZWxpc3QiOlsiRzAiLCJHMSIsIkc0IiwiRzIxIiwiRzI4IiwiRzkwIiwiRzkxIiwiRzkyIiwiTTgyIiwiTTgzIiwiTTEwNSIsIk0x
; parameter.restore_capsule_v1_b64_part_0034=MDciLCJNMTA5Il0sIm1hY2hpbmVfZW52ZWxvcGUiOnsibWF4X3giOiIweDEuZWEwMDAwMDAwMDAwMHArOCIsIm1heF95IjoiMHgxLmVhMDAwMDAwMDAwMDBwKzgiLCJt
; parameter.restore_capsule_v1_b64_part_0035=YXhfeiI6IjB4MS42MzAwMDAwMDAwMDAwcCs5IiwibWluX3giOiIweDAuMHArMCIsIm1pbl95IjoiMHgwLjBwKzAiLCJtaW5feiI6IjB4MC4wcCswIn0sIm5hbWUiOiJw
; parameter.restore_capsule_v1_b64_part_0036=b3R0ZXJib3QteGwiLCJub3p6bGVfZGlhbWV0ZXJzX2hleCI6WyIweDEuYzAwMDAwMDAwMDAwMHArMSIsIjB4MS4wODUxZWI4NTFlYjg1cCsyIiwiMHgxLjQwMDAwMDAw
; parameter.restore_capsule_v1_b64_part_0037=MDAwMDBwKzIiLCIweDEuOTk5OTk5OTk5OTk5YXArMiIsIjB4MS40MDAwMDAwMDAwMDAwcCszIl0sInNwZWVkX2RlZmF1bHRfaGV4IjoiMHgxLjQwMDAwMDAwMDAwMDBw
; parameter.restore_capsule_v1_b64_part_0038=KzUiLCJzcGVlZF9maXJzdF9sYXllcl9oZXgiOiIweDEuZTAwMDAwMDAwMDAwMHArNCIsInNwZWVkX3RyYXZlbF9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArNSIsInN0
; parameter.restore_capsule_v1_b64_part_0039=YXJ0X2djb2RlIjpbIk0xMDUiLCJNMTA5IFMwIiwiTTgyIDthYnNvbHV0ZSBleHRydXNpb24gbW9kZSIsIkcyOCA7SG9tZSIsIkcxIFgyMDcuNSBZMjAyLjUgWjIwIEYx
; parameter.restore_capsule_v1_b64_part_0040=MDAwMCA7TW92ZSBYIGFuZCBZIHRvIGNlbnRlciwgWiB0byAyMG1tIGhpZ2giLCJHOTIgRTAiLCJHMSBFMTAwIEY0MDAwMCA7IFByaW1lIEV4dHJ1ZGVyICh2MS4zLjA6
; parameter.restore_capsule_v1_b64_part_0041=IG1hdGNoZXMgdGhlIHJlZHVjZWQgZW5kLW9mLWpvYiBkZXByZXNzdXJpemUpIiwiRzkyIEUwIiwiRzkyIEUwIiwiRzkyIEUwIiwiTTEwNyJdLCJ0cmF2ZWxfcG9saWN5
; parameter.restore_capsule_v1_b64_part_0042=Ijp7ImR3ZWxsX3NlY29uZHNfaGV4IjoiMHgwLjBwKzAiLCJsaWZ0X2hleCI6IjB4MS4wMDAwMDAwMDAwMDAwcCsxIiwicGFnZV9wYXVzZV9jb21tYW5kIjoiRzQgU3tz
; parameter.restore_capsule_v1_b64_part_0043=ZWNvbmRzfSIsInJlcHJpbWVfZV9oZXgiOiIweDAuMHArMCJ9LCJ2ZXJpZmljYXRpb25fc291cmNlIjoiZG9jcy9yZWZlcmVuY2UvcG90dGVyYm90LTEweGwtcmVmZXJl
; parameter.restore_capsule_v1_b64_part_0044=bmNlLWhlYWRlci1mb290ZXIuZ2NvZGUiLCJ2ZXJpZmllZCI6dHJ1ZSwidmVyc2lvbiI6IjEuMy4wIiwidmlydHVhbF9maWxhbWVudF9kaWFtZXRlcl9oZXgiOiIweDEu
; parameter.restore_capsule_v1_b64_part_0045=YzAwMDAwMDAwMDAwMHArMCIsIndvcmtfYm91bmRzIjp7Im1heF94IjoiMHgxLjhlMDAwMDAwMDAwMDBwKzgiLCJtYXhfeSI6IjB4MS44OTAwMDAwMDAwMDAwcCs4Iiwi
; parameter.restore_capsule_v1_b64_part_0046=bWF4X3oiOiIweDEuNjMwMDAwMDAwMDAwMHArOSIsIm1pbl94IjoiMHgxLjEwMDAwMDAwMDAwMDBwKzQiLCJtaW5feSI6IjB4MS44MDAwMDAwMDAwMDAwcCszIiwibWlu
; parameter.restore_capsule_v1_b64_part_0047=X3oiOiIweDAuMHArMCJ9fSwic2NoZW1hIjoiY2xheWxpbmUud2VhdmUtcmVzdG9yZSIsInNsaWNlIjp7ImJlYWRfd2lkdGhfbW1faGV4IjoiMHgxLjQwMDAwMDAwMDAw
; parameter.restore_capsule_v1_b64_part_0048=MDBwKzIiLCJmaXJzdF9sYXllcl9oZWlnaHRfbW1faGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzEiLCJsYXllcl9oZWlnaHRfbW1faGV4IjoiMHgxLjAwMDAwMDAwMDAw
; parameter.restore_capsule_v1_b64_part_0049=MDBwKzEiLCJyYW5nZV9mcm9tIjoxLCJyYW5nZV90byI6Niwic2FtcGxlX3NwYWNpbmdfbW1faGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzAifSwic291cmNlIjp7Imxh
; parameter.restore_capsule_v1_b64_part_0050=eWVyX3RvdGFsIjo2LCJtZXNoX25hbWUiOiJ0ZWFwb3QtbGlkLm9iaiIsIm1lc2hfc2hhMjU2IjoiZGVhNzlkYjdiMDUzZTk1MjU1NDFmODhlZGZjNGQ4ZWE1NmFlYTNl
; parameter.restore_capsule_v1_b64_part_0051=OWQ4ZDQ5YmE4MTUxZDkyNzNhZDRlZGNiYiIsIm9mZnNldF94X21tX2hleCI6IjB4MC4wcCswIiwib2Zmc2V0X3lfbW1faGV4IjoiMHgwLjBwKzAiLCJzY2FsZV9oZXgi
; parameter.restore_capsule_v1_b64_part_0052=OiIweDEuMDAwMDAwMDAwMDAwMHArMCIsInVwX2F4aXMiOiJ6In0sInZlcnNpb24iOjF9
; parameter.restore_capsule_v1_b64_part_count=52
; parameter.sample_spacing_mm=1.0
; parameter.seam=chained
; parameter.solid_pattern=crossing
; parameter.source_mesh=teapot-lid.obj
; parameter.source_mesh_sha256=dea79db7b053e9525541f88edfc4d8ea56aea3e9d8d49ba8151d9273ad4edcbb
; parameter.source_offset_x_mm=0.0
; parameter.source_offset_y_mm=0.0
; parameter.source_scale=1.0
; parameter.source_up_axis=z
; parameter.z_blend=false
; pressure_management=profile and marked pressure blocks excluded from body volume
; thermal_policy=no heater or fan commands outside verbatim profile blocks
; CLAYLINE_HEADER_END
; CLAYLINE_PROFILE_START_BEGIN
M105
M109 S0
M82 ;absolute extrusion mode
G28 ;Home
G1 X207.5 Y202.5 Z20 F10000 ;Move X and Y to center, Z to 20mm high
G92 E0
G1 E100 F40000 ; Prime Extruder (v1.3.0: matches the reduced end-of-job depressurize)
G92 E0
G92 E0
G92 E0
M107
; CLAYLINE_PROFILE_START_END
; CLAYLINE_BODY_BEGIN
G21 ; clayline units: millimeters
G90 ; clayline absolute XYZ
M82 ; clayline absolute extrusion
G92 E0 ; clayline body extrusion origin
; CLAYLINE_PAGE index=0
; CLAYLINE_STROKE_BEGIN page=0 layer=0 id=weave-00000-band-000-layer-000-island-000
G0 X231.021627 Y204.83707 Z20 F2400 ; clayline kind=travel_xy page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=stroke start XY at safe Z
G0 X231.021627 Y204.83707 Z2 F2400 ; clayline kind=travel_approach page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=stroke start vertical approach
G1 X230.920516 Y205.395315 Z2 E2.594541 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X230.690437 Y206.021852 Z2 E5.646954 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X230.313726 Y206.762822 Z2 E9.448402 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.820457 Y207.621385 Z2 E13.976737 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.27691 Y208.598902 Z2 E19.091814 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X228.76531 Y209.701583 Z2 E24.651 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X228.371821 Y210.886491 Z2 E30.360889 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X228.113874 Y212.057392 Z2 E35.844133 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X227.94526 Y213.122848 Z2 E40.777384 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X227.788886 Y214.016126 Z2 E44.924708 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X227.593263 Y214.733951 Z2 E48.327234 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X227.345131 Y215.304834 Z2 E51.173988 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X227.026549 Y215.78336 Z2 E53.803048 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.597133 Y216.232096 Z2 E56.643493 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.007885 Y216.689062 Z2 E60.053663 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.233545 Y217.186288 Z2 E64.262155 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X224.310994 Y217.766591 Z2 E69.2465 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.335882 Y218.468767 Z2 E74.74184 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.411912 Y219.292601 Z2 E80.403136 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.600544 Y220.18846 Z2 E85.930703 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.910442 Y221.075348 Z2 E91.069909 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.315021 Y221.864409 Z2 E95.590611 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X219.784468 Y222.493725 Z2 E99.354958 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X219.305144 Y222.938868 Z2 E102.346529 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.828119 Y223.242792 Z2 E104.933246 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.283554 Y223.462658 Z2 E107.619015 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.597454 Y223.616105 Z2 E110.834253 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.734628 Y223.718515 Z2 E114.807883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.727315 Y223.799797 Z2 E119.429573 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.584567 Y223.916234 Z2 E124.682723 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.369331 Y224.158208 Z2 E130.349427 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X212.181375 Y224.537813 Z2 E136.052897 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.100039 Y225.009746 Z2 E141.448594 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.174979 Y225.45842 Z2 E146.150496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.376834 Y225.805169 Z2 E150.13021 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.69218 Y226.026904 Z2 E153.421434 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.099994 Y226.120194 Z2 E156.163055 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.52385 Y226.106257 Z2 E158.798689 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X206.899345 Y225.981876 Z2 E161.710811 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X206.157841 Y225.720006 Z2 E165.307169 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.264636 Y225.338987 Z2 E169.748168 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.231341 Y224.909082 Z2 E174.866381 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.077973 Y224.525802 Z2 E180.424664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.875624 Y224.267433 Z2 E186.04885 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.690174 Y224.130391 Z2 E191.506338 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X199.586404 Y224.078553 Z2 E196.559736 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.635763 Y224.034292 Z2 E200.911986 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.867675 Y223.942581 Z2 E204.449607 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.263962 Y223.781269 Z2 E207.30741 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.750959 Y223.538098 Z2 E209.90374 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.255087 Y223.182181 Z2 E212.695179 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X195.727191 Y222.667778 Z2 E216.066038 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X195.144431 Y221.986791 Z2 E220.165054 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.486085 Y221.174514 Z2 E224.94672 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.704707 Y220.289511 Z2 E230.345854 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.784537 Y219.444588 Z2 E236.058978 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.785155 Y218.716014 Z2 E241.715032 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X190.804627 Y218.129633 Z2 E246.939931 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.944572 Y217.634346 Z2 E251.478781 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.234928 Y217.1772 Z2 E255.339272 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.703198 Y216.745391 Z2 E258.471864 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.31855 Y216.306663 Z2 E261.140225 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.023164 Y215.81429 Z2 E263.766109 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X187.786882 Y215.191251 Z2 E266.813452 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X187.58336 Y214.376731 Z2 E270.652993 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X187.385141 Y213.392787 Z2 E275.243236 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X187.135515 Y212.274197 Z2 E280.484681 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X186.766024 Y211.11148 Z2 E286.064133 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X186.274015 Y209.984227 Z2 E291.689015 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.690591 Y208.948071 Z2 E297.127176 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.116885 Y208.044966 Z2 E302.020226 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.644028 Y207.269473 Z2 E306.17406 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.3207 Y206.614072 Z2 E309.516276 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.142806 Y206.038413 Z2 E312.271758 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.074427 Y205.468015 Z2 E314.899021 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.1089 Y204.835778 Z2 E317.794703 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.258059 Y204.07916 Z2 E321.321519 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.505388 Y203.185449 Z2 E325.562326 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X184.810907 Y202.144446 Z2 E330.52391 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.07241 Y200.965734 Z2 E336.045544 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.212633 Y199.725434 Z2 E341.753903 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.213386 Y198.506052 Z2 E347.330464 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.131832 Y197.402167 Z2 E352.392587 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.060848 Y196.441973 Z2 E356.795796 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.049916 Y195.634418 Z2 E360.489297 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.124314 Y194.985535 Z2 E363.476256 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.286792 Y194.435463 Z2 E366.099328 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.551733 Y193.913872 Z2 E368.774793 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X185.972043 Y193.347681 Z2 E371.999619 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X186.56298 Y192.696074 Z2 E376.022531 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X187.283777 Y191.951781 Z2 E380.760934 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.065104 Y191.083198 Z2 E386.103853 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.794284 Y190.096346 Z2 E391.715348 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.418671 Y189.034024 Z2 E397.35066 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.90916 Y187.971055 Z2 E402.704475 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X190.308694 Y187.021563 Z2 E407.415523 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X190.673159 Y186.234539 Z2 E411.382004 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.030923 Y185.637305 Z2 E414.565881 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.41305 Y185.190246 Z2 E417.2555 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.859857 Y184.826051 Z2 E419.891683 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.433773 Y184.504543 Z2 E422.900136 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.181131 Y184.200609 Z2 E426.589834 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.099055 Y183.894917 Z2 E431.014414 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X195.160174 Y183.531891 Z2 E436.143334 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.284177 Y183.046379 Z2 E441.742746 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.367309 Y182.42561 Z2 E447.452065 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.333437 Y181.727846 Z2 E452.902276 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X199.17069 Y181.048877 Z2 E457.83206 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X199.899997 Y180.469229 Z2 E462.092524 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.53441 Y180.041426 Z2 E465.591885 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.100714 Y179.766668 Z2 E468.470471 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.644753 Y179.61215 Z2 E471.056915 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.248804 Y179.558708 Z2 E473.83019 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.992955 Y179.60338 Z2 E477.239523 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.898493 Y179.737005 Z2 E481.425634 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.961119 Y179.910443 Z2 E486.349611 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X206.132157 Y180.034541 Z2 E491.735073 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.361949 Y180.05137 Z2 E497.359768 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.588095 Y179.928889 Z2 E502.995169 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.710129 Y179.718462 Z2 E508.215994 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.686269 Y179.516483 Z2 E512.774706 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.500841 Y179.390093 Z2 E516.544539 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X212.162341 Y179.372099 Z2 E519.570873 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X212.736268 Y179.455313 Z2 E522.223042 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.291681 Y179.641554 Z2 E524.902089 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.898766 Y179.965943 Z2 E528.049952 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.594097 Y180.442084 Z2 E531.903984 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.390507 Y181.049813 Z2 E536.485488 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.32709 Y181.727472 Z2 E541.772329 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.393782 Y182.357122 Z2 E547.437076 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.528439 Y182.864432 Z2 E553.12121 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X219.638759 Y183.232596 Z2 E558.47087 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.640988 Y183.523301 Z2 E563.24325 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.495838 Y183.794405 Z2 E567.344598 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.169756 Y184.078743 Z2 E570.689701 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.681683 Y184.393826 Z2 E573.438788 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.099679 Y184.773573 Z2 E576.021485 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.485674 Y185.276832 Z2 E578.922039 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.873758 Y185.95839 Z2 E582.508863 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X224.289337 Y186.821876 Z2 E586.89137 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X224.769262 Y187.810921 Z2 E591.918921 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.356667 Y188.850526 Z2 E597.379762 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.075592 Y189.862275 Z2 E603.055942 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.883827 Y190.769773 Z2 E608.613537 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X227.682724 Y191.546941 Z2 E613.710683 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X228.371109 Y192.208376 Z2 E618.076587 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X228.88999 Y192.787812 Z2 E621.633707 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.24849 Y193.319837 Z2 E624.567642 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.483927 Y193.845822 Z2 E627.203094 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.627493 Y194.431619 Z2 E629.961383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.688935 Y195.144337 Z2 E633.232924 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.673174 Y196.020906 Z2 E637.242355 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.622867 Y197.065394 Z2 E642.024619 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.617037 Y198.24924 Z2 E647.438728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.739726 Y199.491667 Z2 E653.148316 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X229.996502 Y200.688071 Z2 E658.744392 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X230.328622 Y201.78076 Z2 E663.96728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X230.65071 Y202.746208 Z2 E668.62176 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X230.891602 Y203.575484 Z2 E672.571031 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X231.014949 Y204.260325 Z2 E675.753386 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X231.021627 Y204.83707 Z2 E678.391175 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.988294 Y204.477555 Z2 E696.90982 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.794439 Y204.858858 Z2 E698.866047 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.338172 Y205.653016 Z2 E703.054686 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.709959 Y206.782797 Z2 E708.966523 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.04095 Y208.224751 Z2 E716.236156 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X224.510186 Y209.82303 Z2 E723.938016 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X224.181767 Y211.313829 Z2 E730.919315 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.999539 Y212.465315 Z2 E736.250904 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.880815 Y213.143516 Z2 E739.399669 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.834777 Y213.312447 Z2 E740.200411 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.697041 Y213.419262 Z2 E740.997533 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.087964 Y213.810369 Z2 E744.307834 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.075202 Y214.447416 Z2 E749.779563 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.829378 Y215.344532 Z2 E756.80053 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X219.590496 Y216.449149 Z2 E764.391339 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.535438 Y217.614075 Z2 E771.579088 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.73535 Y218.642311 Z2 E777.537354 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.187166 Y219.368773 Z2 E781.699412 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.93753 Y219.664878 Z2 E783.470611 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.923461 Y219.668025 Z2 E783.536543 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.337899 Y219.737527 Z2 E786.233274 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.363679 Y219.816138 Z2 E790.703124 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.989924 Y219.956113 Z2 E797.018201 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X212.366818 Y220.279301 Z2 E804.586824 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.768924 Y220.789899 Z2 E812.258437 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.426568 Y221.375751 Z2 E818.956585 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.504522 Y221.822963 Z2 E823.643164 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.960384 Y222.05936 Z2 E826.356351 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.878976 Y222.085726 Z2 E826.74769 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.610057 Y221.990754 Z2 E828.051971 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X206.817665 Y221.65274 Z2 E831.991725 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.632207 Y221.159527 Z2 E837.863649 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.132006 Y220.660989 Z2 E845.093383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.527001 Y220.316095 Z2 E852.601058 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.014052 Y220.141193 Z2 E859.566258 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X199.774055 Y220.082957 Z2 E865.243351 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.966331 Y220.04535 Z2 E868.941288 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.739735 Y220.018294 Z2 E869.984934 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.648512 Y219.929402 Z2 E870.567439 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.218283 Y219.426657 Z2 E873.593577 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.540457 Y218.590345 Z2 E878.516733 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.564497 Y217.484954 Z2 E885.260384 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X195.323503 Y216.345442 Z2 E892.965428 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.994416 Y215.376505 Z2 E900.487465 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.829349 Y214.679765 Z2 E906.695711 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.02705 Y214.217739 Z2 E910.929761 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.597463 Y213.941003 Z2 E913.266731 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.486387 Y213.496463 Z2 E915.362231 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.29816 Y212.562117 Z2 E919.72109 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.001071 Y211.230849 Z2 E925.959096 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X190.515205 Y209.701919 Z2 E933.295869 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.858939 Y208.198332 Z2 E940.798622 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.12391 Y206.892927 Z2 E947.649908 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.512936 Y205.931156 Z2 E952.860811 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.152223 Y205.339581 Z2 E956.029509 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.105313 Y205.244493 Z2 E956.514413 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.153367 Y205.000739 Z2 E957.650621 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.352227 Y204.282168 Z2 E961.060359 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X188.68686 Y203.141962 Z2 E966.494759 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.023309 Y201.625434 Z2 E973.598879 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.212494 Y199.952058 Z2 E981.300426 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.213477 Y198.359729 Z2 E988.582578 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.120961 Y197.107456 Z2 E994.325166 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.05885 Y196.267292 Z2 E998.177948 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.05397 Y195.906815 Z2 E999.826655 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.066851 Y195.889463 Z2 E999.925486 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X189.481972 Y195.431724 Z2 E1002.751496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X190.208403 Y194.681613 Z2 E1007.526935 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X191.167738 Y193.615142 Z2 E1014.087117 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.136247 Y192.304389 Z2 E1021.540402 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.967588 Y190.889957 Z2 E1029.043552 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.569656 Y189.58518 Z2 E1035.615275 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.968129 Y188.638209 Z2 E1040.313815 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.213659 Y188.108014 Z2 E1042.98592 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.220935 Y188.095868 Z2 E1043.050671 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.56795 Y187.954744 Z2 E1044.76388 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X195.3784 Y187.684844 Z2 E1048.670413 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.602843 Y187.265942 Z2 E1054.588758 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.077432 Y186.628994 Z2 E1061.934681 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X199.538778 Y185.791462 Z2 E1069.637606 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.766056 Y184.905088 Z2 E1076.561042 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.674895 Y184.168067 Z2 E1081.912331 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.266213 Y183.698091 Z2 E1085.366688 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.444786 Y183.577674 Z2 E1086.351683 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.580372 Y183.585813 Z2 E1086.972868 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.284322 Y183.689691 Z2 E1090.227081 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.427761 Y183.876319 Z2 E1095.525532 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.893522 Y184.03165 Z2 E1102.266386 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.533927 Y184.054098 Z2 E1109.769098 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.156588 Y183.892009 Z2 E1117.226895 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.484099 Y183.643046 Z2 E1123.403803 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.398616 Y183.453818 Z2 E1127.674728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.817144 Y183.388879 Z2 E1129.611673 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.819968 Y183.390387 Z2 E1129.626314 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X212.249279 Y183.684367 Z2 E1132.005872 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.004458 Y184.260632 Z2 E1136.350181 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.133291 Y185.077394 Z2 E1142.722244 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.554949 Y185.916573 Z2 E1150.272066 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.079003 Y186.597986 Z2 E1157.906909 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.451716 Y187.053154 Z2 E1164.520807 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X219.479058 Y187.351144 Z2 E1169.412772 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.110834 Y187.551503 Z2 E1172.443869 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.199093 Y187.588741 Z2 E1172.881959 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.329391 Y187.817571 Z2 E1174.086218 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.687832 Y188.562337 Z2 E1177.866175 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.225179 Y189.669719 Z2 E1183.495269 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.976035 Y190.998604 Z2 E1190.475637 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.942298 Y192.358432 Z2 E1198.104634 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X223.992006 Y193.53706 Z2 E1205.322655 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X224.902412 Y194.422705 Z2 E1211.131258 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.491432 Y194.988665 Z2 E1214.866962 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.678707 Y195.197796 Z2 E1216.150803 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.68584 Y195.28053 Z2 E1216.530573 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.674905 Y195.888704 Z2 E1219.312367 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.623341 Y196.959279 Z2 E1224.214067 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.616067 Y198.436434 Z2 E1230.969576 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X225.781318 Y200.109869 Z2 E1238.65987 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.120694 Y201.691135 Z2 E1246.0561 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.517163 Y202.995538 Z2 E1252.290951 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.83142 Y203.937511 Z2 E1256.832259 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X226.988294 Y204.477555 Z2 E1259.404114 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.655477 Y204.045065 Z2 E1279.317718 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.143007 Y204.966693 Z2 E1284.140344 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.316589 Y206.747919 Z2 E1293.120425 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.648552 Y208.759569 Z2 E1302.814256 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.24966 Y210.570265 Z2 E1311.293611 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X220.196949 Y210.903342 Z2 E1312.835819 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X219.839411 Y211.128241 Z2 E1314.767519 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.322874 Y212.220296 Z2 E1323.314111 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.76908 Y213.605697 Z2 E1332.834434 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.470331 Y215.03969 Z2 E1341.682364 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.840824 Y215.848702 Z2 E1346.370306 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.395282 Y215.995992 Z2 E1353.01539 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.364305 Y216.400394 Z2 E1362.485931 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.356474 Y217.041985 Z2 E1372.125687 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.790888 Y217.725262 Z2 E1379.937718 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.033073 Y217.409972 Z2 E1383.691398 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.186038 Y216.796177 Z2 E1392.592584 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.178378 Y216.364757 Z2 E1401.983747 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.337931 Y216.151995 Z2 E1410.45666 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.688287 Y216.121485 Z2 E1413.430932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.594829 Y216.006175 Z2 E1414.109729 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X199.424286 Y214.680397 Z2 E1422.197899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.862469 Y213.246297 Z2 E1431.894862 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.203676 Y212.036996 Z2 E1441.282883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X195.137012 Y211.399104 Z2 E1446.966779 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.866628 Y210.187501 Z2 E1452.644059 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.264386 Y208.292358 Z2 E1461.738153 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.443862 Y206.412437 Z2 E1471.118776 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.557228 Y204.837783 Z2 E1479.383189 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.420869 Y204.62313 Z2 E1480.546181 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.562813 Y204.139478 Z2 E1482.851345 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X192.974208 Y202.285134 Z2 E1491.537952 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.212355 Y200.178683 Z2 E1501.232687 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.213568 Y198.213406 Z2 E1510.22043 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X193.152704 Y197.389572 Z2 E1513.998311 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X194.270372 Y196.147087 Z2 E1521.641213 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X195.478211 Y194.512431 Z2 E1530.936288 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.516506 Y192.74589 Z2 E1540.307275 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.186517 Y191.293869 Z2 E1547.620619 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.045511 Y190.999993 Z2 E1551.772568 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X199.870688 Y190.211609 Z2 E1560.865001 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.710247 Y189.157314 Z2 E1570.561533 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.198674 Y188.08233 Z2 E1578.958194 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.561744 Y187.7879 Z2 E1581.095963 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.894404 Y187.842195 Z2 E1582.637437 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.654887 Y188.028759 Z2 E1590.733685 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.705904 Y188.056825 Z2 E1600.114413 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.725081 Y187.855128 Z2 E1609.394606 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.855643 Y187.643102 Z2 E1614.655109 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.939492 Y188.427315 Z2 E1620.773245 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.716117 Y189.476025 Z2 E1630.208142 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.629567 Y190.331539 Z2 E1639.793693 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.264673 Y190.873712 Z2 E1647.67183 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.379523 Y190.907025 Z2 E1648.218722 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.681097 Y191.528518 Z2 E1651.377921 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.595403 Y193.146682 Z2 E1659.877817 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X219.809003 Y194.854589 Z2 E1669.459631 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.100185 Y196.304348 Z2 E1678.338077 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.625629 Y196.815501 Z2 E1681.690533 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.623815 Y196.853163 Z2 E1681.86297 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.615097 Y198.623628 Z2 E1689.95988 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X221.82291 Y200.728072 Z2 E1699.630881 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.244886 Y202.694199 Z2 E1708.827264 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X222.655477 Y204.045065 Z2 E1715.284203 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.354321 Y203.628507 Z2 E1735.046581 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.592229 Y205.271087 Z2 E1743.327674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.786918 Y207.696108 Z2 E1755.013476 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.603356 Y208.529354 Z2 E1758.915502 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.81637 Y209.096061 Z2 E1763.350637 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.947664 Y210.762245 Z2 E1774.800474 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X212.792731 Y212.037446 Z2 E1782.668632 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.361792 Y212.521487 Z2 E1794.004216 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.944023 Y213.294071 Z2 E1805.612115 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.679256 Y213.409625 Z2 E1806.933261 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X206.240071 Y212.931364 Z2 E1813.868949 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.829754 Y212.413419 Z2 E1825.143601 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.636964 Y212.275528 Z2 E1830.63488 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.284076 Y211.87584 Z2 E1833.073255 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.401436 Y210.147152 Z2 E1844.762138 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.643705 Y208.865723 Z2 E1854.710101 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.013567 Y206.882797 Z2 E1864.225433 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.028786 Y204.626542 Z2 E1875.483927 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.68677 Y204.019126 Z2 E1878.671888 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X196.925107 Y202.944834 Z2 E1883.704371 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.212216 Y200.405308 Z2 E1895.392293 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.213172 Y198.856715 Z2 E1902.474424 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X197.373006 Y198.679031 Z2 E1903.567411 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X198.820174 Y196.720474 Z2 E1914.704276 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.065424 Y194.601824 Z2 E1925.943102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.13292 Y194.455548 Z2 E1926.679842 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.663943 Y193.794224 Z2 E1934.306898 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.881716 Y192.523166 Z2 E1945.997037 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.678524 Y191.947689 Z2 E1950.492068 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.416253 Y192.025868 Z2 E1953.884791 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.877882 Y192.059553 Z2 E1965.143536 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.884411 Y191.85912 Z2 E1974.365601 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.877284 Y193.035477 Z2 E1984.9489 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.180132 Y194.065092 Z2 E1996.48516 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.598326 Y194.203758 Z2 E1998.500069 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X215.214771 Y195.29476 Z2 E2004.230887 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X216.675708 Y197.350747 Z2 E2015.765519 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.616117 Y198.406652 Z2 E2022.23197 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.614126 Y198.810822 Z2 E2024.080372 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X217.864501 Y201.346275 Z2 E2035.732078 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X218.354321 Y203.628507 Z2 E2046.407017 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.162508 Y203.159202 Z2 E2065.697072 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.867869 Y203.794255 Z2 E2068.898704 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.07527 Y206.180997 Z2 E2080.400045 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.126248 Y207.918793 Z2 E2092.341985 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.715257 Y208.372582 Z2 E2095.141925 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.359279 Y208.64258 Z2 E2101.464914 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.65606 Y209.186834 Z2 E2109.642204 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.294103 Y209.066551 Z2 E2111.386535 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.481131 Y208.462081 Z2 E2124.544677 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.480305 Y208.461985 Z2 E2124.548479 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.940402 Y207.048006 Z2 E2134.109388 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.058982 Y206.40543 Z2 E2139.097825 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.762748 Y205.473236 Z2 E2143.571079 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X200.890637 Y203.475123 Z2 E2153.541472 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.212077 Y200.631932 Z2 E2166.62698 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X201.212335 Y200.213953 Z2 E2168.538513 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.162137 Y198.928516 Z2 E2175.847837 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X202.943804 Y197.598599 Z2 E2182.902662 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X203.457199 Y197.376839 Z2 E2185.460224 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.804482 Y196.031555 Z2 E2197.833031 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.049859 Y196.062281 Z2 E2208.102705 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.978876 Y195.969481 Z2 E2212.372494 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X210.038451 Y196.594929 Z2 E2217.999445 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.800083 Y197.382563 Z2 E2226.824448 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X211.83414 Y197.442838 Z2 E2227.141057 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.542414 Y199.846904 Z2 E2240.628507 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.716259 Y200.042101 Z2 E2241.823905 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X213.906093 Y201.964478 Z2 E2250.658214 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X214.162508 Y203.159202 Z2 E2256.246429 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.989979 Y202.779744 Z2 E2275.407272 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.615826 Y203.906426 Z2 E2280.836579 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.739955 Y204.687374 Z2 E2286.203164 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.356766 Y204.763673 Z2 E2287.989995 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X207.533611 Y205.026708 Z2 E2291.942027 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X206.384219 Y204.779718 Z2 E2297.318496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.479368 Y203.948861 Z2 E2302.936511 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.453625 Y203.930094 Z2 E2303.082204 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X204.985848 Y202.858359 Z2 E2308.430055 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.122052 Y201.653613 Z2 E2313.974782 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.5041 Y201.136559 Z2 E2316.914885 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X205.789917 Y200.650275 Z2 E2319.49448 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X206.844001 Y200.046155 Z2 E2325.050682 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.044092 Y200.062576 Z2 E2330.539535 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X208.199619 Y200.154381 Z2 E2331.36547 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.158547 Y200.583123 Z2 E2336.169279 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.845727 Y201.550196 Z2 E2341.59482 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.947685 Y202.582681 Z2 E2346.339614 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X209.989979 Y202.779744 Z2 E2347.26136 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=interior 1 of 6 · island 1 of 1
G1 X233.037766 Y202.001643 Z2 E2452.725131 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X233.328836 Y203.003659 Z2 E2457.497043 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X233.512364 Y204.022633 Z2 E2462.232065 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X233.524228 Y205.047283 Z2 E2466.918379 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X233.341909 Y206.053889 Z2 E2471.596759 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.986123 Y207.022745 Z2 E2476.316907 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.513281 Y207.952799 Z2 E2481.088428 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X231.996885 Y208.851616 Z2 E2485.829073 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X231.506255 Y209.733967 Z2 E2490.446176 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X231.093035 Y210.624603 Z2 E2494.936331 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X230.785342 Y211.551154 Z2 E2499.401239 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X230.57144 Y212.52212 Z2 E2503.948198 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X230.411336 Y213.533806 Z2 E2508.632488 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X230.23143 Y214.561506 Z2 E2513.403912 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X229.957905 Y215.565191 Z2 E2518.161425 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X229.549314 Y216.505245 Z2 E2522.849078 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X228.985295 Y217.352431 Z2 E2527.503583 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X228.275416 Y218.094248 Z2 E2532.199195 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X227.452163 Y218.732686 Z2 E2536.963632 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X226.574534 Y219.296237 Z2 E2541.733493 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X225.708363 Y219.841075 Z2 E2546.413222 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X224.902446 Y220.421415 Z2 E2550.955047 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X224.175297 Y221.069759 Z2 E2555.410397 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X223.516236 Y221.79745 Z2 E2559.900351 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X222.894874 Y222.595996 Z2 E2564.527644 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X222.26993 Y223.424182 Z2 E2569.272498 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X221.597505 Y224.22178 Z2 E2574.043449 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X220.83999 Y224.925276 Z2 E2578.771275 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X219.977415 Y225.474842 Z2 E2583.448678 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X219.029343 Y225.857624 Z2 E2588.124527 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X218.018699 Y226.083654 Z2 E2592.860654 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X216.982584 Y226.206633 Z2 E2597.632345 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X215.954587 Y226.289583 Z2 E2602.348935 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X214.956219 Y226.391309 Z2 E2606.938381 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X213.995901 Y226.582525 Z2 E2611.416386 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X213.064156 Y226.880259 Z2 E2615.889767 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X212.145959 Y227.280993 Z2 E2620.471431 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X211.219014 Y227.730581 Z2 E2625.18291 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X210.262116 Y228.1463 Z2 E2629.954203 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X209.275419 Y228.465855 Z2 E2634.69738 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X208.265629 Y228.624932 Z2 E2639.372373 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X207.247408 Y228.600301 Z2 E2644.030336 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X206.235544 Y228.398771 Z2 E2648.74875 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X205.250207 Y228.050788 Z2 E2653.527721 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X204.293992 Y227.642892 Z2 E2658.281997 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X203.3558 Y227.252554 Z2 E2662.929141 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X202.419203 Y226.94131 Z2 E2667.442768 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X201.468514 Y226.73702 Z2 E2671.889772 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X200.48775 Y226.62364 Z2 E2676.404941 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X199.469123 Y226.575801 Z2 E2681.068529 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X198.429157 Y226.527381 Z2 E2685.829725 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X197.394406 Y226.40383 Z2 E2690.595535 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X196.398762 Y226.137794 Z2 E2695.308624 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X195.476379 Y225.700572 Z2 E2699.97684 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X194.644806 Y225.103701 Z2 E2704.65806 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X193.901366 Y224.379263 Z2 E2709.405271 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X193.223273 Y223.586875 Z2 E2714.174836 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X192.577102 Y222.78962 Z2 E2718.86807 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X191.917338 Y222.042359 Z2 E2723.426881 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X191.197683 Y221.381554 Z2 E2727.895054 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X190.404367 Y220.803207 Z2 E2732.384868 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X189.539176 Y220.2858 Z2 E2736.995177 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X188.643023 Y219.769725 Z2 E2741.724527 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X187.765569 Y219.204477 Z2 E2746.497913 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X186.962904 Y218.552646 Z2 E2751.226674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X186.290452 Y217.78565 Z2 E2755.891573 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X185.76467 Y216.909235 Z2 E2760.5656 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X185.397136 Y215.940105 Z2 E2765.305712 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X185.143968 Y214.926899 Z2 E2770.081834 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X184.939505 Y213.911956 Z2 E2774.81669 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X184.719542 Y212.92629 Z2 E2779.435286 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X184.422786 Y211.992456 Z2 E2783.916412 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X184.033438 Y211.100412 Z2 E2788.367625 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X183.544767 Y210.232536 Z2 E2792.922582 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.994354 Y209.366097 Z2 E2797.616973 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.451406 Y208.475655 Z2 E2802.386518 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X181.990799 Y207.541984 Z2 E2807.147776 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X181.687493 Y206.560498 Z2 E2811.845814 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X181.566278 Y205.549355 Z2 E2816.50315 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X181.622163 Y204.524424 Z2 E2821.197396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X181.823492 Y203.503174 Z2 E2825.957741 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.101114 Y202.5 Z2 E2830.717965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.388436 Y201.520999 Z2 E2835.38404 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.603098 Y200.553421 Z2 E2839.916621 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.71272 Y199.583794 Z2 E2844.379237 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.713329 Y198.597504 Z2 E2848.889803 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.638627 Y197.586361 Z2 E2853.526635 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.562096 Y196.551148 Z2 E2858.273862 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.547982 Y195.508438 Z2 E2863.042893 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.665288 Y194.485318 Z2 E2867.752551 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X182.954097 Y193.507549 Z2 E2872.415139 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X183.418465 Y192.593344 Z2 E2877.104485 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X184.037787 Y191.759067 Z2 E2881.856236 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X184.73861 Y190.986294 Z2 E2886.627212 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X185.455886 Y190.245636 Z2 E2891.342467 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X186.125958 Y189.500732 Z2 E2895.924596 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X186.705557 Y188.716319 Z2 E2900.384973 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X187.200597 Y187.874065 Z2 E2904.852885 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X187.621349 Y186.962227 Z2 E2909.445508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X188.021547 Y186.01116 Z2 E2914.164374 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X188.460346 Y185.063618 Z2 E2918.939839 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X188.994152 Y184.172509 Z2 E2923.690373 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X189.658983 Y183.394708 Z2 E2928.369821 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X190.448613 Y182.751076 Z2 E2933.028675 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X191.34776 Y182.247374 Z2 E2937.741982 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X192.314369 Y181.854275 Z2 E2942.51412 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X193.299465 Y181.526213 Z2 E2947.262479 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X194.258507 Y181.198109 Z2 E2951.898008 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X195.163392 Y180.807244 Z2 E2956.405852 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X196.010141 Y180.321953 Z2 E2960.869166 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X196.81305 Y179.742069 Z2 E2965.398612 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X197.605561 Y179.099384 Z2 E2970.064956 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X198.421112 Y178.45119 Z2 E2974.829237 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X199.283649 Y177.869556 Z2 E2979.586906 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X200.206729 Y177.421699 Z2 E2984.279029 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X201.18904 Y177.142703 Z2 E2988.949076 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X202.213352 Y177.052079 Z2 E2993.65183 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X203.25082 Y177.11436 Z2 E2998.404992 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X204.28235 Y177.266576 Z2 E3003.173539 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X205.294467 Y177.43177 Z2 E3007.863471 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X206.281304 Y177.536348 Z2 E3012.401811 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X207.254463 Y177.549665 Z2 E3016.852746 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X208.232787 Y177.451939 Z2 E3021.34915 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X209.226398 Y177.265597 Z2 E3025.972422 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X210.241052 Y177.055648 Z2 E3030.711001 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X211.274285 Y176.895331 Z2 E3035.492793 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X212.308784 Y176.86719 Z2 E3040.225586 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X213.317707 Y177.013475 Z2 E3044.88791 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X214.285107 Y177.337863 Z2 E3049.55419 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X215.198016 Y177.825665 Z2 E3054.287804 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X216.059608 Y178.415657 Z2 E3059.063381 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X216.881788 Y179.043051 Z2 E3063.793133 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X217.698214 Y179.633771 Z2 E3068.401711 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X218.543052 Y180.132464 Z2 E3072.888286 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X219.434336 Y180.530961 Z2 E3077.353227 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X220.380661 Y180.844747 Z2 E3081.912738 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X221.367194 Y181.1309 Z2 E3086.610377 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X222.361465 Y181.446219 Z2 E3091.380632 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X223.31753 Y181.8496 Z2 E3096.126214 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X224.190398 Y182.386837 Z2 E3100.813585 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X224.94683 Y183.074051 Z2 E3105.487395 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X225.573509 Y183.891112 Z2 E3110.196565 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X226.088987 Y184.796402 Z2 E3114.960819 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X226.540278 Y185.734089 Z2 E3119.71992 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X226.984313 Y186.649171 Z2 E3124.371508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X227.469562 Y187.507977 Z2 E3128.882644 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X228.033901 Y188.302176 Z2 E3133.338313 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X228.691215 Y189.040218 Z2 E3137.858142 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X229.420418 Y189.749588 Z2 E3142.510627 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X230.170907 Y190.470695 Z2 E3147.270406 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X230.867121 Y191.24816 Z2 E3152.043212 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X231.442229 Y192.101636 Z2 E3156.749839 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X231.858209 Y193.030972 Z2 E3161.406279 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.101651 Y194.024294 Z2 E3166.083447 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.190869 Y195.059217 Z2 E3170.83398 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.172093 Y196.103532 Z2 E3175.610685 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.122571 Y197.131717 Z2 E3180.318302 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.117644 Y198.132244 Z2 E3184.894035 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.213732 Y199.10529 Z2 E3189.365682 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.418882 Y200.061156 Z2 E3193.836662 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X232.710783 Y201.021523 Z2 E3198.427073 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
G1 X233.037766 Y202.001643 Z2 E3203.152286 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-band-000-layer-000-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=0 id=weave-00000-band-000-layer-000-island-000
G0 X233.037766 Y202.001643 Z6 F2400 ; clayline kind=travel_lift page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave paste-safe lift
G0 X220.766814 Y184.516283 Z6 F2400 ; clayline kind=travel_xy page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave paste-safe traverse
G0 X220.766814 Y184.516283 Z4 F2400 ; clayline kind=travel_approach page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=1 id=weave-00001-band-000-layer-001-island-000
G1 X223.467402 Y187.216871 Z4 E3219.030709 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X223.565664 Y187.426753 Z4 E3219.994191 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X224.023459 Y188.393505 Z4 E3224.441348 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X224.592741 Y189.414748 Z4 E3229.3023 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X225.298301 Y190.407945 Z4 E3234.367403 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X226.095 Y191.292545 Z4 E3239.316849 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X226.879855 Y192.041846 Z4 E3243.828188 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X227.549652 Y192.671806 Z4 E3247.651019 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.046187 Y193.215694 Z4 E3250.712829 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.381408 Y193.706572 Z4 E3253.184136 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.596904 Y194.186492 Z4 E3255.371327 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.726538 Y194.725298 Z4 E3257.675349 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.778556 Y195.394802 Z4 E3260.467208 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.754723 Y196.233391 Z4 E3263.955067 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.695548 Y197.2453 Z4 E3268.169282 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.684931 Y198.091254 Z4 E3271.686626 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X210.987366 Y180.393689 Z4 E3375.741527 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X210.60984 Y180.456148 Z4 E3377.332434 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X209.669067 Y180.661194 Z4 E3381.335534 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X208.576662 Y180.876052 Z4 E3385.964242 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X207.374807 Y181.001414 Z4 E3390.988082 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X206.167956 Y180.983073 Z4 E3396.006164 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X205.888308 Y180.951486 Z4 E3397.176198 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X230.014542 Y205.077719 Z4 E3539.029204 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X229.982117 Y205.25457 Z4 E3539.776721 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X229.763803 Y205.836169 Z4 E3542.359465 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X229.398144 Y206.53793 Z4 E3545.64936 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.913131 Y207.361791 Z4 E3549.624053 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.374919 Y208.309621 Z4 E3554.155657 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X228.123985 Y208.844016 Z4 E3556.610165 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X200.473215 Y181.193247 Z4 E3719.186094 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X200.255486 Y181.343004 Z4 E3720.284757 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X199.560499 Y181.90759 Z4 E3724.007451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X198.753267 Y182.575473 Z4 E3728.363315 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X197.811957 Y183.264365 Z4 E3733.212905 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X197.2247 Y183.601586 Z4 E3736.028341 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X226.982997 Y213.359883 Z4 E3910.995721 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X224.523131 Y216.556871 Z4 E3927.76638 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X193.161547 Y185.195287 Z4 E4112.160475 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X190.718169 Y188.408763 Z4 E4128.943936 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X221.359721 Y219.050315 Z4 E4309.10452 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X220.982677 Y219.470674 Z4 E4311.452189 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X220.318029 Y220.340945 Z4 E4316.004862 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X219.751392 Y221.108683 Z4 E4319.971972 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X219.252744 Y221.712227 Z4 E4323.226843 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X218.810338 Y222.12885 Z4 E4325.75336 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X218.792692 Y222.140141 Z4 E4325.840458 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X188.568258 Y191.915706 Z4 E4503.548549 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X186.083443 Y195.087746 Z4 E4520.300886 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X214.054042 Y223.058345 Z4 E4684.757289 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X213.12276 Y223.240609 Z4 E4688.702565 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X211.957774 Y223.616199 Z4 E4693.791509 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X210.904408 Y224.08573 Z4 E4698.586264 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X210.01293 Y224.529553 Z4 E4702.726513 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X209.913036 Y224.574194 Z4 E4703.181407 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X186.05585 Y200.717007 Z4 E4843.452519 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X186.018217 Y201.048099 Z4 E4844.8379 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X185.755149 Y202.200661 Z4 E4849.752933 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X185.448257 Y203.209954 Z4 E4854.138777 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X185.201323 Y204.066465 Z4 E4857.844772 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X185.053652 Y204.780395 Z4 E4860.875778 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X185.020074 Y205.338085 Z4 E4863.198582 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X203.279967 Y223.597978 Z4 E4970.559755 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X191.496247 Y217.471112 Z4 E5025.777236 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X188.561557 Y214.536422 Z4 E5043.032088 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=interior 2 of 6 · island 1 of 1
G1 X232.088221 Y202.020173 Z4 E5231.327996 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X232.379291 Y202.985129 Z4 E5235.518358 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X232.564169 Y203.967065 Z4 E5239.672499 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X232.57876 Y204.954744 Z4 E5243.779242 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X232.400951 Y205.924555 Z4 E5247.878455 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X232.05101 Y206.856813 Z4 E5252.018396 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.585342 Y207.750508 Z4 E5256.208087 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.077441 Y208.613248 Z4 E5260.37035 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X230.596698 Y209.459871 Z4 E5264.418082 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X230.195025 Y210.315283 Z4 E5268.347033 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X229.900152 Y211.20706 Z4 E5272.252041 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X229.700327 Y212.143743 Z4 E5276.233946 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X229.555542 Y213.121678 Z4 E5280.344046 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X229.392303 Y214.116266 Z4 E5284.534386 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X229.136925 Y215.087629 Z4 E5288.710078 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X228.747642 Y215.996049 Z4 E5292.819019 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X228.20407 Y216.812326 Z4 E5296.896309 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X227.515755 Y217.523995 Z4 E5301.012569 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X226.715308 Y218.133209 Z4 E5305.194658 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X225.861739 Y218.668563 Z4 E5309.383621 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X225.020636 Y219.186104 Z4 E5313.489479 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X224.240763 Y219.740078 Z4 E5317.466568 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X223.540606 Y220.363018 Z4 E5321.36284 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X222.909615 Y221.066496 Z4 E5325.291705 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X222.317315 Y221.842036 Z4 E5329.348815 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X221.722249 Y222.648294 Z4 E5333.514963 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X221.080479 Y223.425067 Z4 E5337.704048 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X220.354365 Y224.108863 Z4 E5341.850784 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X219.524045 Y224.640157 Z4 E5345.94906 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X218.608937 Y225.005996 Z4 E5350.046396 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X217.63185 Y225.216297 Z4 E5354.20168 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X216.629844 Y225.324778 Z4 E5358.391881 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X215.636466 Y225.394481 Z4 E5362.532018 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X214.673298 Y225.484578 Z4 E5366.553888 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X213.748602 Y225.665553 Z4 E5370.471265 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X212.852823 Y225.954351 Z4 E5374.384245 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X211.970896 Y226.347464 Z4 E5378.398638 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X211.080482 Y226.790757 Z4 E5382.533945 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X210.160376 Y227.201938 Z4 E5386.723898 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X209.210609 Y227.518341 Z4 E5390.885923 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X208.237835 Y227.675615 Z4 E5394.982764 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X207.256673 Y227.650528 Z4 E5399.063293 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X206.281869 Y227.449908 Z4 E5403.200997 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X205.333503 Y227.104638 Z4 E5407.39702 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X204.414128 Y226.700799 Z4 E5411.57183 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X203.5126 Y226.315857 Z4 E5415.647326 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X202.612451 Y226.011341 Z4 E5419.598059 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X201.697932 Y225.815173 Z4 E5423.486675 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X200.752913 Y225.711611 Z4 E5427.439126 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X199.769643 Y225.674884 Z4 E5431.529939 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X198.764604 Y225.638856 Z4 E5435.711089 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X197.764309 Y225.528961 Z4 E5439.894855 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X196.802556 Y225.277948 Z4 E5444.027303 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X195.913341 Y224.857277 Z4 E5448.117057 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X195.114304 Y224.278153 Z4 E5452.219842 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X194.402731 Y223.572632 Z4 E5456.385863 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X193.7558 Y222.800314 Z4 E5460.574435 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X193.139938 Y222.024405 Z4 E5464.69294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X192.509509 Y221.299803 Z4 E5468.686081 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X191.81834 Y220.662706 Z4 E5472.594166 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X191.052626 Y220.109088 Z4 E5476.522545 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X190.214123 Y219.617405 Z4 E5480.563771 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X189.343532 Y219.128179 Z4 E5484.715611 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X188.490471 Y218.590839 Z4 E5488.907179 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X187.711162 Y217.967781 Z4 E5493.05538 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X187.061004 Y217.230391 Z4 E5497.142557 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X186.556426 Y216.38438 Z4 E5501.237942 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X186.208724 Y215.446569 Z4 E5505.396261 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X185.974085 Y214.465464 Z4 E5509.590249 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X185.786966 Y213.483272 Z4 E5513.747173 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X185.583143 Y212.530968 Z4 E5517.796062 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X185.301306 Y211.631068 Z4 E5521.716608 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X184.925299 Y210.773611 Z4 E5525.609193 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X184.448591 Y209.940816 Z4 E5529.598674 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.908854 Y209.109865 Z4 E5533.718172 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.375284 Y208.25528 Z4 E5537.906783 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X182.922743 Y207.357789 Z4 E5542.08562 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X182.625775 Y206.412828 Z4 E5546.203746 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X182.509505 Y205.438418 Z4 E5550.283614 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X182.568995 Y204.450371 Z4 E5554.398873 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X182.772582 Y203.466114 Z4 E5558.577561 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.051114 Y202.5 Z4 E5562.75779 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.337527 Y201.558058 Z4 E5566.850963 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.54993 Y200.627474 Z4 E5570.81938 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.655948 Y199.694731 Z4 E5574.722246 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.651611 Y198.745174 Z4 E5578.670088 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.570571 Y197.770556 Z4 E5582.736063 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.485974 Y196.771524 Z4 E5586.904418 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.462483 Y195.764669 Z4 E5591.091572 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.569112 Y194.777038 Z4 E5595.221528 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X183.845958 Y193.834349 Z4 E5599.306288 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X184.296984 Y192.954731 Z4 E5603.416034 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X184.901389 Y192.154389 Z4 E5607.585701 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X185.586071 Y191.414977 Z4 E5611.775354 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X186.286002 Y190.707071 Z4 E5615.914194 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X186.937546 Y189.994268 Z4 E5619.929152 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X187.497312 Y189.241175 Z4 E5623.83033 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X187.971149 Y188.429324 Z4 E5627.738444 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X188.369608 Y187.547092 Z4 E5631.763091 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X188.746448 Y186.624798 Z4 E5635.905268 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X189.160855 Y185.705165 Z4 E5640.09892 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X189.669099 Y184.840904 Z4 E5644.267354 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X190.307242 Y184.088826 Z4 E5648.36804 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X191.06927 Y183.469924 Z4 E5652.449456 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X191.939931 Y182.98993 Z4 E5656.582882 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X192.877206 Y182.61949 Z4 E5660.77293 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X193.831992 Y182.312774 Z4 E5664.942262 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X194.759872 Y182.004739 Z4 E5669.00696 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X195.63289 Y181.632793 Z4 E5672.952231 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X196.447103 Y181.165247 Z4 E5676.855743 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X197.216844 Y180.601915 Z4 E5680.821421 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X197.975465 Y179.974253 Z4 E5684.914972 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X198.756559 Y179.339716 Z4 E5689.098901 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X199.58417 Y178.770473 Z4 E5693.275035 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X200.471893 Y178.333727 Z4 E5697.388245 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X201.418458 Y178.06455 Z4 E5701.479633 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X202.4066 Y177.982049 Z4 E5705.602144 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X203.407621 Y178.051057 Z4 E5709.773782 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X204.402485 Y178.208669 Z4 E5713.961534 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X205.377763 Y178.37792 Z4 E5718.076871 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X206.327629 Y178.485211 Z4 E5722.051066 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X207.263728 Y178.499437 Z4 E5725.943364 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X208.204992 Y178.401257 Z4 E5729.877916 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X209.161588 Y178.21311 Z4 E5733.931174 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X210.139313 Y178.00001 Z4 E5738.091513 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X211.135753 Y177.835155 Z4 E5742.290545 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X212.133721 Y177.800719 Z4 E5746.442082 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X213.106374 Y177.939384 Z4 E5750.526791 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X214.037807 Y178.254835 Z4 E5754.615298 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X214.915095 Y178.732396 Z4 E5758.768026 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X215.741487 Y179.310759 Z4 E5762.961616 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X216.529048 Y179.924905 Z4 E5767.11378 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X217.311365 Y180.501129 Z4 E5771.153323 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X218.122647 Y180.984092 Z4 E5775.078671 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X218.980965 Y181.365646 Z4 E5778.983848 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X219.895035 Y181.661159 Z4 E5782.977774 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X220.850168 Y181.927613 Z4 E5787.10038 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X221.813783 Y182.222107 Z4 E5791.289542 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X222.739971 Y182.60356 Z4 E5795.453977 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X223.583777 Y183.117792 Z4 E5799.562232 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X224.312139 Y183.780792 Z4 E5803.65708 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X224.911826 Y184.572449 Z4 E5807.786117 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X225.40126 Y185.451373 Z4 E5811.968611 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X225.827483 Y186.361762 Z4 E5816.147848 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X226.247459 Y187.248649 Z4 E5820.227613 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X226.7099 Y188.078229 Z4 E5824.176281 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X227.252677 Y188.842281 Z4 E5828.07279 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X227.889543 Y189.549414 Z4 E5832.029285 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X228.599438 Y190.22715 Z4 E5836.10975 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X229.33178 Y190.915935 Z4 E5840.289552 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X230.011326 Y191.660287 Z4 E5844.479876 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X230.571116 Y192.480013 Z4 E5848.606752 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X230.973019 Y193.375066 Z4 E5852.68588 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.203641 Y194.333615 Z4 E5856.784784 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.281313 Y195.333313 Z4 E5860.953571 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.252649 Y196.341899 Z4 E5865.14848 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.194632 Y197.334007 Z4 E5869.280233 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.182531 Y198.298175 Z4 E5873.289093 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.272773 Y199.234623 Z4 E5877.200428 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.473414 Y200.153695 Z4 E5881.111476 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X231.762588 Y201.077091 Z4 E5885.134359 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
G1 X232.088221 Y202.020173 Z4 E5889.282386 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-band-000-layer-001-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=1 id=weave-00001-band-000-layer-001-island-000
G0 X232.088221 Y202.020173 Z8 F2400 ; clayline kind=travel_lift page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave paste-safe lift
G0 X225.307216 Y212.978389 Z8 F2400 ; clayline kind=travel_xy page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave paste-safe traverse
G0 X225.307216 Y212.978389 Z6 F2400 ; clayline kind=travel_approach page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=2 id=weave-00002-band-000-layer-002-island-000
G1 X220.628473 Y217.657132 Z6 E5916.791601 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X210.328235 Y222.300515 Z6 E5963.76527 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X228.534302 Y204.094449 Z6 E6070.809965 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X228.428731 Y203.55363 Z6 E6073.100866 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X228.207305 Y202.811171 Z6 E6076.322002 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X227.912934 Y201.949734 Z6 E6080.106777 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X227.601474 Y200.978696 Z6 E6084.346468 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X227.337505 Y199.907266 Z6 E6088.934156 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X227.304665 Y199.667231 Z6 E6089.941403 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X203.852161 Y223.119735 Z6 E6227.833136 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X203.201022 Y222.754071 Z6 E6230.937918 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X202.435469 Y222.274159 Z6 E6234.694407 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X201.538862 Y221.740002 Z6 E6239.033446 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X200.529824 Y221.247035 Z6 E6243.702419 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X200.191146 Y221.123896 Z6 E6245.200663 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X227.008177 Y194.306865 Z6 E6402.87453 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X224.343083 Y191.315105 Z6 E6419.532302 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X195.703751 Y219.954436 Z6 E6587.920594 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X193.111733 Y216.8896 Z6 E6604.608651 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X221.886481 Y188.114852 Z6 E6773.793141 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X219.300646 Y185.043833 Z6 E6790.484264 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X190.657152 Y213.687327 Z6 E6958.89703 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X187.985346 Y210.702279 Z6 E6975.552574 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X214.806541 Y183.881084 Z6 E7133.250922 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X213.950129 Y183.507338 Z6 E7137.135758 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X213.01161 Y182.997746 Z6 E7141.57575 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X212.173989 Y182.484373 Z6 E7145.6602 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X211.445285 Y182.043562 Z6 E7149.200991 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X211.143237 Y181.887534 Z6 E7150.61441 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X187.695145 Y205.335626 Z6 E7288.480207 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X187.549287 Y204.55585 Z6 E7291.778367 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X187.248361 Y203.513517 Z6 E7296.288867 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X186.927523 Y202.587319 Z6 E7300.364041 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X186.662693 Y201.800361 Z6 E7303.816127 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X186.498604 Y201.13609 Z6 E7306.660857 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X186.4714 Y200.902516 Z6 E7307.638506 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X204.68577 Y182.688146 Z6 E7414.732022 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X194.353987 Y187.363075 Z6 E7461.879198 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X189.69523 Y192.021832 Z6 E7489.270905 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=interior 3 of 6 · island 1 of 1
G1 X230.588939 Y202.049431 Z6 E7664.324 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X230.859157 Y202.955492 Z6 E7668.254919 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X231.039196 Y203.877793 Z6 E7672.161777 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X231.076394 Y204.807697 Z6 E7676.030959 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X230.944234 Y205.724437 Z6 E7679.881725 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X230.661408 Y206.610322 Z6 E7683.747952 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X230.255182 Y207.460306 Z6 E7687.664614 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.778193 Y208.275919 Z6 E7691.59285 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.289373 Y209.066003 Z6 E7695.45549 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X228.835371 Y209.847161 Z6 E7699.211837 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X228.465361 Y210.649295 Z6 E7702.884425 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X228.181478 Y211.484344 Z6 E7706.55129 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X227.975017 Y212.361275 Z6 E7710.296826 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X227.801246 Y213.271668 Z6 E7714.150133 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X227.603025 Y214.194425 Z6 E7718.074026 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X227.336 Y215.099348 Z6 E7721.996635 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X226.957257 Y215.950377 Z6 E7725.869374 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X226.448629 Y216.722496 Z6 E7729.713379 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X225.808458 Y217.396105 Z6 E7733.576893 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X225.057879 Y217.962206 Z6 E7737.485484 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X224.247685 Y218.449992 Z6 E7741.417253 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X223.422558 Y218.89638 Z6 E7745.317563 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X222.624296 Y219.342364 Z6 E7749.119188 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X221.879852 Y219.825311 Z6 E7752.808465 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X221.192815 Y220.372748 Z6 E7756.460712 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X220.555714 Y220.995941 Z6 E7760.165962 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X219.947058 Y221.681571 Z6 E7763.977636 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X219.332058 Y222.391421 Z6 E7767.88241 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X218.672166 Y223.070301 Z6 E7771.818541 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X217.948066 Y223.667278 Z6 E7775.720196 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X217.149955 Y224.135379 Z6 E7779.566962 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X216.285467 Y224.458967 Z6 E7783.40462 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X215.368785 Y224.639646 Z6 E7787.289066 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X214.42402 Y224.692274 Z6 E7791.223031 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X213.480148 Y224.673202 Z6 E7795.147997 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X212.553882 Y224.643976 Z6 E7799.000878 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X211.653673 Y224.659992 Z6 E7802.744104 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X210.780959 Y224.760022 Z6 E7806.396184 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X209.919501 Y224.941597 Z6 E7810.056401 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X209.053729 Y225.208367 Z6 E7813.822864 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X208.173731 Y225.513806 Z6 E7817.695584 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X207.273446 Y225.801429 Z6 E7821.624913 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X206.352175 Y226.009705 Z6 E7825.551773 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X205.42227 Y226.076833 Z6 E7829.427927 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X204.503935 Y225.98997 Z6 E7833.262963 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X203.60934 Y225.746509 Z6 E7837.117528 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X202.748974 Y225.367448 Z6 E7841.026295 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X201.924286 Y224.904324 Z6 E7844.9586 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X201.131606 Y224.407406 Z6 E7848.848198 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X200.34835 Y223.940779 Z6 E7852.638683 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X199.551259 Y223.551358 Z6 E7856.326949 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X198.724665 Y223.25082 Z6 E7859.983627 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X197.861325 Y223.025756 Z6 E7863.692937 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X196.960537 Y222.841366 Z6 E7867.515636 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X196.037733 Y222.654751 Z6 E7871.429871 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X195.12394 Y222.412853 Z6 E7875.359842 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X194.252059 Y222.069812 Z6 E7879.255179 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X193.458003 Y221.589588 Z6 E7883.113254 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X192.762831 Y220.97741 Z6 E7886.964351 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X192.172182 Y220.25271 Z6 E7890.851254 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X191.665747 Y219.45478 Z6 E7894.780423 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X191.21142 Y218.630033 Z6 E7898.695162 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X190.772682 Y217.82046 Z6 E7902.523466 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X190.304125 Y217.058304 Z6 E7906.243056 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X189.773094 Y216.355824 Z6 E7909.904204 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X189.16678 Y215.709194 Z6 E7913.589525 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X188.490268 Y215.101097 Z6 E7917.37138 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X187.785257 Y214.48882 Z6 E7921.253538 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X187.096927 Y213.840802 Z6 E7925.183933 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X186.475063 Y213.135619 Z6 E7929.092878 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.970156 Y212.357482 Z6 E7932.949362 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.605678 Y211.507008 Z6 E7936.796246 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.394792 Y210.598569 Z6 E7940.673524 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.315492 Y209.65992 Z6 E7944.589878 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.318963 Y208.714801 Z6 E7948.519252 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.348018 Y207.782858 Z6 E7952.395703 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.34722 Y206.878155 Z6 E7956.157024 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.275993 Y205.999657 Z6 E7959.821378 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.114021 Y205.133732 Z6 E7963.483914 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X184.864631 Y204.269907 Z6 E7967.221955 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X184.56162 Y203.39517 Z6 E7971.070705 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X184.260374 Y202.5 Z6 E7974.997475 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X184.033668 Y201.582241 Z6 E7978.927764 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X183.92574 Y200.655584 Z6 E7982.806399 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X183.970647 Y199.733476 Z6 E7986.644622 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X184.172922 Y198.830445 Z6 E7990.492021 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X184.52331 Y197.958616 Z6 E7994.398444 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X184.978892 Y197.127758 Z6 E7998.337961 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.472795 Y196.328438 Z6 E8002.244375 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X185.947177 Y195.542732 Z6 E8006.06018 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X186.355023 Y194.750207 Z6 E8009.765817 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X186.678436 Y193.935417 Z6 E8013.410417 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X186.92653 Y193.083904 Z6 E8017.097799 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X187.115696 Y192.188853 Z6 E8020.901188 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X187.294945 Y191.26873 Z6 E8024.798525 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X187.516493 Y190.348615 Z6 E8028.733252 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X187.832996 Y189.461912 Z6 E8032.647541 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X188.282845 Y188.650089 Z6 E8036.506246 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X188.86191 Y187.931674 Z6 E8040.342522 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X189.556558 Y187.31194 Z6 E8044.212825 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X190.338173 Y186.783137 Z6 E8048.136242 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X191.162452 Y186.321298 Z6 E8052.064449 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X191.982942 Y185.886543 Z6 E8055.924934 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X192.761448 Y185.429619 Z6 E8059.677889 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X193.476234 Y184.912207 Z6 E8063.346493 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X194.132016 Y184.323962 Z6 E8067.009078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X194.747624 Y183.665733 Z6 E8070.756011 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X195.357856 Y182.965307 Z6 E8074.618207 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X195.992256 Y182.265363 Z6 E8078.54565 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X196.679501 Y181.620255 Z6 E8082.464472 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X197.440126 Y181.079704 Z6 E8086.344009 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X198.276595 Y180.681365 Z6 E8090.195838 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X199.170732 Y180.435048 Z6 E8094.051705 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X200.103584 Y180.327267 Z6 E8097.955852 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X201.049102 Y180.312317 Z6 E8101.887352 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X201.984393 Y180.336617 Z6 E8105.777153 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X202.896467 Y180.353794 Z6 E8109.569789 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X203.783303 Y180.302586 Z6 E8113.262967 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X204.651875 Y180.160433 Z6 E8116.92211 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X205.514587 Y179.929669 Z6 E8120.634948 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X206.383692 Y179.634368 Z6 E8124.451147 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X207.274288 Y179.335896 Z6 E8128.356218 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X208.185972 Y179.084833 Z6 E8132.287656 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X209.110972 Y178.937499 Z6 E8136.181838 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X210.036012 Y178.941352 Z6 E8140.02774 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X210.948787 Y179.104077 Z6 E8143.882448 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X211.828107 Y179.427462 Z6 E8147.777628 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X212.667342 Y179.860986 Z6 E8151.704795 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X213.474183 Y180.349063 Z6 E8155.625251 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X214.262128 Y180.83199 Z6 E8159.467471 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X215.048596 Y181.259022 Z6 E8163.188129 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X215.853766 Y181.610406 Z6 E8166.840525 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X216.697843 Y181.876701 Z6 E8170.520289 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X217.585071 Y182.07178 Z6 E8174.297065 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X218.5021 Y182.244667 Z6 E8178.176794 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X219.425329 Y182.45222 Z6 E8182.110933 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X220.319823 Y182.747608 Z6 E8186.027336 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X221.151291 Y183.160811 Z6 E8189.887511 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X221.896501 Y183.704218 Z6 E8193.721967 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X222.54427 Y184.370766 Z6 E8197.586205 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X223.092871 Y185.137646 Z6 E8201.506343 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X223.565192 Y185.957498 Z6 E8205.440075 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X224.004352 Y186.781769 Z6 E8209.323035 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X224.454012 Y187.572378 Z6 E8213.10445 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X224.956013 Y188.299658 Z6 E8216.778483 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X225.523368 Y188.968962 Z6 E8220.426357 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X226.161535 Y189.597119 Z6 E8224.149226 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X226.856134 Y190.205686 Z6 E8227.988621 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X227.563268 Y190.828859 Z6 E8231.90725 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X228.231214 Y191.499568 Z6 E8235.842648 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X228.800997 Y192.243599 Z6 E8239.738833 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.232245 Y193.061648 Z6 E8243.583531 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.517871 Y193.94076 Z6 E8247.426526 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.658643 Y194.866255 Z6 E8251.318543 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.694472 Y195.81162 Z6 E8255.251735 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.667081 Y196.752525 Z6 E8259.165222 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.643196 Y197.672075 Z6 E8262.989555 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.677198 Y198.565319 Z6 E8266.705925 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X229.796523 Y199.437498 Z6 E8270.365799 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X230.008302 Y200.297088 Z6 E8274.046423 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X230.286262 Y201.163683 Z6 E8277.830105 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
G1 X230.588939 Y202.049431 Z6 E8281.721688 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-band-000-layer-002-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=2 id=weave-00002-band-000-layer-002-island-000
G0 X230.588939 Y202.049431 Z10 F2400 ; clayline kind=travel_lift page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave paste-safe lift
G0 X215.921714 Y185.768505 Z10 F2400 ; clayline kind=travel_xy page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave paste-safe traverse
G0 X215.921714 Y185.768505 Z8 F2400 ; clayline kind=travel_approach page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=3 id=weave-00003-band-000-layer-003-island-000
G1 X224.875801 Y194.722593 Z8 E8334.368289 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X224.961427 Y195.123789 Z8 E8336.073835 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.016625 Y195.736758 Z8 E8338.632576 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.027762 Y196.461077 Z8 E8341.644304 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.012574 Y197.296982 Z8 E8345.120166 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.019493 Y198.252894 Z8 E8349.09449 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.108288 Y199.271367 Z8 E8353.344869 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.294187 Y200.282271 Z8 E8357.618192 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.492003 Y200.995649 Z8 E8360.695987 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X208.05985 Y183.563496 Z8 E8463.190361 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X203.65525 Y184.81575 Z8 E8482.228268 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.595229 Y206.755729 Z8 E8611.226938 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X225.348067 Y207.139099 Z8 E8613.12334 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X224.861189 Y207.871206 Z8 E8616.778716 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X224.355416 Y208.714791 Z8 E8620.867993 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X223.905202 Y209.639602 Z8 E8625.144315 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X223.610829 Y210.428184 Z8 E8628.643838 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X199.174923 Y185.992277 Z8 E8772.317601 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X195.639765 Y188.113974 Z8 E8789.458946 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X222.195524 Y214.669733 Z8 E8945.596631 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X218.584055 Y216.715118 Z8 E8962.852234 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X193.354493 Y191.485556 Z8 E9111.19239 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X193.204848 Y191.654802 Z8 E9112.131638 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X192.487712 Y192.337559 Z8 E9116.248296 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X191.800059 Y192.921962 Z8 E9120.000195 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X191.201242 Y193.432778 Z8 E9123.272543 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X190.709042 Y193.898244 Z8 E9126.088997 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X190.429975 Y194.217893 Z8 E9127.853144 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X215.35804 Y219.145957 Z8 E9274.420608 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X211.305334 Y220.750106 Z8 E9292.541714 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X189.812385 Y199.257156 Z8 E9418.912019 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X189.81215 Y199.430134 Z8 E9419.631179 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X189.724149 Y200.451599 Z8 E9423.893666 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X189.537352 Y201.46386 Z8 E9428.173214 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X189.279511 Y202.402673 Z8 E9432.220878 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X189.022647 Y203.219057 Z8 E9435.779047 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X188.821307 Y203.922932 Z8 E9438.822787 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X205.56518 Y220.666806 Z8 E9537.270348 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X205.218944 Y220.73033 Z8 E9538.733859 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X204.425328 Y220.882273 Z8 E9542.093258 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X203.744083 Y220.981889 Z8 E9544.955665 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X203.183933 Y221.010691 Z8 E9547.287577 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X202.724547 Y220.968768 Z8 E9549.205416 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X202.305238 Y220.857956 Z8 E9551.008549 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X201.884103 Y220.670717 Z8 E9552.924678 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X201.421631 Y220.377833 Z8 E9555.200561 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X200.895506 Y219.966089 Z8 E9557.978141 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X200.31144 Y219.454997 Z8 E9561.204839 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X199.645242 Y218.862489 Z8 E9564.911527 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X198.874859 Y218.246214 Z8 E9569.013135 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X198.0207 Y217.675559 Z8 E9573.283928 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X197.119266 Y217.191851 Z8 E9577.537124 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X196.240698 Y216.809374 Z8 E9581.520908 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X195.924935 Y216.683415 Z8 E9582.934291 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X192.351305 Y213.109785 Z8 E9603.945867 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=interior 4 of 6 · island 1 of 1
G1 X228.739182 Y202.914149 Z8 E9761.055379 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.912874 Y203.753289 Z8 E9764.618069 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.969931 Y204.601521 Z8 E9768.152577 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.885922 Y205.441604 Z8 E9771.662657 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.668102 Y206.256693 Z8 E9775.170321 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.326924 Y207.039738 Z8 E9778.721438 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.903369 Y207.789354 Z8 E9782.301066 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.439604 Y208.508693 Z8 E9785.85939 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X226.975268 Y209.206903 Z8 E9789.345526 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X226.555557 Y209.906946 Z8 E9792.73898 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X226.205438 Y210.626147 Z8 E9796.064563 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X225.925902 Y211.374981 Z8 E9799.387697 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X225.705881 Y212.159521 Z8 E9802.775274 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X225.507754 Y212.974504 Z8 E9806.262267 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X225.299717 Y213.805836 Z8 E9809.825123 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X225.042611 Y214.627295 Z8 E9813.403724 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X224.702393 Y215.41188 Z8 E9816.959124 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X224.248198 Y216.126918 Z8 E9820.480938 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X223.683055 Y216.752502 Z8 E9823.985954 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X223.025123 Y217.285684 Z8 E9827.506755 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X222.293474 Y217.732008 Z8 E9831.069908 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X221.522355 Y218.11419 Z8 E9834.648 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X220.744024 Y218.457708 Z8 E9838.185078 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X219.987481 Y218.799722 Z8 E9841.636896 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X219.274392 Y219.18078 Z8 E9844.998323 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X218.606717 Y219.618067 Z8 E9848.316557 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X217.979677 Y220.119183 Z8 E9851.653714 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X217.373781 Y220.67664 Z8 E9855.076716 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X216.762474 Y221.262958 Z8 E9858.598268 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X216.126856 Y221.842076 Z8 E9862.17322 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X215.449448 Y222.370201 Z8 E9865.744325 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X214.717747 Y222.807438 Z8 E9869.288136 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X213.93095 Y223.116463 Z8 E9872.802519 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X213.106449 Y223.291887 Z8 E9876.307126 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X212.256426 Y223.337653 Z8 E9879.84623 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X211.398188 Y223.28432 Z8 E9883.421251 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X210.546964 Y223.171409 Z8 E9886.991225 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X209.713517 Y223.03539 Z8 E9890.502139 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X208.898016 Y222.928141 Z8 E9893.92179 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X208.096265 Y222.889893 Z8 E9897.258874 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X207.298671 Y222.928558 Z8 E9900.578781 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X206.497381 Y223.037504 Z8 E9903.940808 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X205.679573 Y223.187546 Z8 E9907.397611 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X204.84144 Y223.348012 Z8 E9910.945449 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X203.989672 Y223.472563 Z8 E9914.524349 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X203.134268 Y223.516547 Z8 E9918.085403 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X202.288523 Y223.439365 Z8 E9921.616214 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X201.472719 Y223.223771 Z8 E9925.124376 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X200.701177 Y222.880739 Z8 E9928.634828 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X199.978894 Y222.423317 Z8 E9932.189264 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X199.300768 Y221.892617 Z8 E9935.769314 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X198.657536 Y221.329751 Z8 E9939.322873 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X198.032584 Y220.773927 Z8 E9942.800071 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X197.396902 Y220.265407 Z8 E9946.184517 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X196.73227 Y219.821374 Z8 E9949.507671 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X196.027456 Y219.443171 Z8 E9952.833166 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X195.27838 Y219.117067 Z8 E9956.22978 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X194.497256 Y218.805475 Z8 E9959.726162 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X193.704123 Y218.478451 Z8 E9963.292927 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X192.930727 Y218.101209 Z8 E9966.870451 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X192.20837 Y217.644538 Z8 E9970.423481 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X191.574185 Y217.083783 Z8 E9973.943001 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X191.045187 Y216.427448 Z8 E9977.447704 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X190.620753 Y215.693519 Z8 E9980.972523 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X190.290477 Y214.90192 Z8 E9984.538574 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X190.026838 Y214.082921 Z8 E9988.115647 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X189.79982 Y213.264458 Z8 E9991.64689 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X189.56692 Y212.469543 Z8 E9995.090689 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X189.285641 Y211.713302 Z8 E9998.445213 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X188.94054 Y210.99377 Z8 E10001.762957 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X188.527366 Y210.304106 Z8 E10005.105428 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X188.058804 Y209.624626 Z8 E10008.536935 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.564755 Y208.934433 Z8 E10012.065813 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.085485 Y208.22007 Z8 E10015.642276 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.666989 Y207.470855 Z8 E10019.21015 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.350018 Y206.680453 Z8 E10022.750647 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.167978 Y205.855302 Z8 E10026.263718 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.123343 Y205.013435 Z8 E10029.768712 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.209988 Y204.165542 Z8 E10033.3122 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.392164 Y203.324691 Z8 E10036.889157 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.628064 Y202.5 Z8 E10040.455339 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X186.880961 Y201.696223 Z8 E10043.958561 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.09828 Y200.904952 Z8 E10047.370101 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.243741 Y200.116689 Z8 E10050.702649 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.312296 Y199.320949 Z8 E10054.023207 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.313397 Y198.510407 Z8 E10057.393051 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.278594 Y197.677245 Z8 E10060.859955 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.240216 Y196.823421 Z8 E10064.413326 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.243526 Y195.962514 Z8 E10067.992591 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.330431 Y195.110813 Z8 E10071.551937 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.539769 Y194.288591 Z8 E10075.07939 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X187.881633 Y193.517524 Z8 E10078.586068 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X188.341661 Y192.808585 Z8 E10082.09965 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X188.904414 Y192.163996 Z8 E10085.65715 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X189.530033 Y191.572358 Z8 E10089.237045 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X190.17934 Y191.018471 Z8 E10092.78531 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X190.814985 Y190.478268 Z8 E10096.253448 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X191.403162 Y189.918287 Z8 E10099.629829 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X191.93229 Y189.319854 Z8 E10102.9509 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X192.402283 Y188.671691 Z8 E10106.279532 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X192.829495 Y187.972789 Z8 E10109.68508 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X193.249332 Y187.241632 Z8 E10113.190368 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X193.688969 Y186.504002 Z8 E10116.76046 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X194.178058 Y185.796483 Z8 E10120.336385 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X194.740539 Y185.153948 Z8 E10123.886712 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X195.393661 Y184.616116 Z8 E10127.404257 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X196.124463 Y184.196015 Z8 E10130.908814 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X196.916627 Y183.890945 Z8 E10134.438035 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X197.750121 Y183.684961 Z8 E10138.007551 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X198.598694 Y183.54528 Z8 E10141.582982 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X199.439823 Y183.438771 Z8 E10145.107915 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X200.257448 Y183.318656 Z8 E10148.543693 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X201.043088 Y183.141719 Z8 E10151.891814 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X201.801964 Y182.894717 Z8 E10155.209768 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X202.542131 Y182.577227 Z8 E10158.558177 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X203.282349 Y182.207567 Z8 E10161.998056 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X204.037644 Y181.816735 Z8 E10165.533707 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X204.815253 Y181.448351 Z8 E10169.111062 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X205.618726 Y181.149058 Z8 E10172.675741 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X206.448294 Y180.95939 Z8 E10176.213683 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X207.291544 Y180.909739 Z8 E10179.725578 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X208.130205 Y180.997271 Z8 E10183.231267 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X208.955515 Y181.213908 Z8 E10186.77875 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X209.759847 Y181.520422 Z8 E10190.357354 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X210.540191 Y181.874434 Z8 E10193.919891 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X211.298506 Y182.237162 Z8 E10197.414712 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X212.050853 Y182.559277 Z8 E10200.81724 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X212.811466 Y182.809289 Z8 E10204.14595 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X213.590857 Y182.98488 Z8 E10207.467498 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X214.395838 Y183.096056 Z8 E10210.845988 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X215.228176 Y183.177914 Z8 E10214.323141 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X216.079803 Y183.263255 Z8 E10217.881526 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X216.930593 Y183.394752 Z8 E10221.4607 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X217.758563 Y183.610728 Z8 E10225.018185 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X218.536833 Y183.946799 Z8 E10228.542639 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X219.243891 Y184.406217 Z8 E10232.048281 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X219.87271 Y184.972092 Z8 E10235.565322 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X220.424581 Y185.626928 Z8 E10239.125701 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X220.916814 Y186.333222 Z8 E10242.704897 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X221.370176 Y187.054687 Z8 E10246.247457 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X221.815369 Y187.757788 Z8 E10249.707321 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X222.289893 Y188.414582 Z8 E10253.076067 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X222.812081 Y189.018543 Z8 E10256.395445 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X223.39196 Y189.571942 Z8 E10259.727974 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X224.026649 Y190.093111 Z8 E10263.142323 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X224.692494 Y190.613603 Z8 E10266.656007 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X225.35832 Y191.156912 Z8 E10270.228833 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X225.983497 Y191.746879 Z8 E10273.802621 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X226.530296 Y192.40185 Z8 E10277.34988 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X226.95879 Y193.130914 Z8 E10280.865728 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.260391 Y193.918036 Z8 E10284.370206 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.437831 Y194.749415 Z8 E10287.904526 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.514898 Y195.605249 Z8 E10291.477069 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.528111 Y196.46457 Z8 E10295.050131 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.512738 Y197.310645 Z8 E10298.568285 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.518706 Y198.13509 Z8 E10301.996017 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.58853 Y198.935967 Z8 E10305.338305 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.732907 Y199.721079 Z8 E10308.657157 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X227.948532 Y200.498683 Z8 E10312.012048 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.211203 Y201.285364 Z8 E10315.460188 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.489945 Y202.090392 Z8 E10319.002057 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
G1 X228.739182 Y202.914149 Z8 E10322.580169 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00003-band-000-layer-003-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=3 id=weave-00003-band-000-layer-003-island-000
G0 X228.739182 Y202.914149 Z12 F2400 ; clayline kind=travel_lift page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave paste-safe lift
G0 X219.820812 Y212.805513 Z12 F2400 ; clayline kind=travel_xy page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave paste-safe traverse
G0 X219.820812 Y212.805513 Z10 F2400 ; clayline kind=travel_approach page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=4 id=weave-00004-band-000-layer-004-island-000
G1 X218.173189 Y214.453136 Z10 E10332.267559 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X217.748412 Y214.615458 Z10 E10334.158127 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X217.099992 Y214.828817 Z10 E10336.996133 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X216.362489 Y215.070069 Z10 E10340.222199 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X215.566252 Y215.366624 Z10 E10343.754712 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X214.754571 Y215.740403 Z10 E10347.469906 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X213.974387 Y216.187778 Z10 E10351.20897 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X213.253571 Y216.681195 Z10 E10354.840644 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X212.611562 Y217.178372 Z10 E10358.216588 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X212.059584 Y217.618788 Z10 E10361.152413 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X211.574283 Y217.974653 Z10 E10363.654387 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X211.140177 Y218.244095 Z10 E10365.778577 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X210.769359 Y218.419761 Z10 E10367.484497 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X210.437392 Y218.519188 Z10 E10368.92523 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X210.10005 Y218.56455 Z10 E10370.340359 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X209.72637 Y218.555504 Z10 E10371.894396 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X209.272356 Y218.482624 Z10 E10373.80613 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X208.721639 Y218.340329 Z10 E10376.170942 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X208.651234 Y218.318237 Z10 E10376.477724 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X223.492441 Y203.47703 Z10 E10463.738334 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X223.325138 Y202.953604 Z10 E10466.022947 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X223.086767 Y202.298999 Z10 E10468.919302 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X222.825252 Y201.572375 Z10 E10472.129953 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X222.566219 Y200.761617 Z10 E10475.668549 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X222.361378 Y199.87223 Z10 E10479.462998 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X222.253629 Y199.058988 Z10 E10482.873612 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X203.954971 Y217.357646 Z10 E10590.462711 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X199.377559 Y216.278204 Z10 E10610.015373 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X221.414221 Y194.241541 Z10 E10739.582503 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X221.084378 Y193.945733 Z10 E10741.424518 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X220.622072 Y193.599009 Z10 E10743.827062 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X220.065365 Y193.223531 Z10 E10746.618816 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X219.422521 Y192.796279 Z10 E10749.827904 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X218.723525 Y192.286581 Z10 E10753.424545 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X218.181477 Y191.817431 Z10 E10756.404988 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X196.812224 Y213.186684 Z10 E10882.048008 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X196.611758 Y213.000499 Z10 E10883.185463 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X195.932959 Y212.459927 Z10 E10886.793139 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X195.259272 Y211.989522 Z10 E10890.209229 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X194.64622 Y211.58143 Z10 E10893.271071 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X194.123469 Y211.216799 Z10 E10895.920895 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X193.714132 Y210.888636 Z10 E10898.102098 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X193.584375 Y210.757679 Z10 E10898.868554 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X215.624609 Y188.717445 Z10 E11028.456682 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X211.044175 Y187.641025 Z10 E11048.018698 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X192.737786 Y205.947413 Z10 E11155.653246 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X192.69969 Y205.570373 Z10 E11157.228779 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X192.545703 Y204.701693 Z10 E11160.896635 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X192.318052 Y203.839935 Z10 E11164.602315 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X192.044043 Y203.0457 Z10 E11168.095345 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X191.782364 Y202.347938 Z10 E11171.193595 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X191.570735 Y201.751626 Z10 E11173.824272 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X191.507672 Y201.520673 Z10 E11174.819615 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X206.347914 Y186.680432 Z10 E11262.074546 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X205.991772 Y186.574358 Z10 E11263.61949 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X205.496732 Y186.471479 Z10 E11265.721602 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X205.0843 Y186.4326 Z10 E11267.443898 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X204.73623 Y186.452405 Z10 E11268.893345 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X204.394153 Y186.526469 Z10 E11270.34849 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X204.047548 Y186.657733 Z10 E11271.88938 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X203.658909 Y186.874032 Z10 E11273.738542 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X203.195798 Y187.193736 Z10 E11276.078168 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X202.667353 Y187.601838 Z10 E11278.854073 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X202.072142 Y188.069863 Z10 E11282.002069 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X201.39938 Y188.56644 Z10 E11285.478501 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X200.643942 Y189.043847 Z10 E11289.193851 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X199.840627 Y189.455678 Z10 E11292.946964 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X199.024718 Y189.793601 Z10 E11296.618546 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X198.247508 Y190.05606 Z10 E11300.029078 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X197.565901 Y190.274317 Z10 E11303.004607 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X196.979051 Y190.483083 Z10 E11305.594232 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X196.818711 Y190.55278 Z10 E11306.321102 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X195.185647 Y192.185844 Z10 E11315.922891 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=interior 5 of 6 · island 1 of 1
G1 X226.087102 Y203.587796 Z10 E11452.862715 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X226.16357 Y204.326841 Z10 E11455.951708 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X226.120858 Y205.061579 Z10 E11459.011553 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X225.962569 Y205.776659 Z10 E11462.056475 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X225.697718 Y206.466393 Z10 E11465.128197 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X225.345935 Y207.125838 Z10 E11468.235561 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.936157 Y207.754409 Z10 E11471.355135 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.498364 Y208.354352 Z10 E11474.4429 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.072287 Y208.941737 Z10 E11477.45979 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X223.684487 Y209.531042 Z10 E11480.392735 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X223.35431 Y210.136731 Z10 E11483.260748 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X223.081722 Y210.766926 Z10 E11486.115392 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X222.850407 Y211.427794 Z10 E11489.026404 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X222.647972 Y212.121391 Z10 E11492.030357 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X222.447678 Y212.834238 Z10 E11495.108794 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X222.219303 Y213.548728 Z10 E11498.227351 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X221.931186 Y214.241501 Z10 E11501.346724 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X221.563737 Y214.886182 Z10 E11504.431795 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X221.10914 Y215.460968 Z10 E11507.478539 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X220.569808 Y215.955955 Z10 E11510.522033 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X219.957702 Y216.370757 Z10 E11513.596165 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X219.287075 Y216.703798 Z10 E11516.709187 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X218.585775 Y216.971789 Z10 E11519.830487 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X217.879326 Y217.204242 Z10 E11522.922473 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X217.187739 Y217.430474 Z10 E11525.947687 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X216.526734 Y217.676662 Z10 E11528.880242 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X215.901499 Y217.964583 Z10 E11531.742044 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X215.304373 Y218.306989 Z10 E11534.603798 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X214.726263 Y218.70272 Z10 E11537.516475 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X214.156601 Y219.14387 Z10 E11540.511991 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X213.578999 Y219.604731 Z10 E11543.584105 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X212.974744 Y220.047825 Z10 E11546.699347 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X212.338346 Y220.442825 Z10 E11549.813399 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X211.668292 Y220.760247 Z10 E11552.895938 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X210.965889 Y220.970623 Z10 E11555.944356 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X210.237239 Y221.068604 Z10 E11559.001 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X209.496957 Y221.050683 Z10 E11562.079637 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X208.760408 Y220.932449 Z10 E11565.181052 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X208.034257 Y220.744825 Z10 E11568.299186 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X207.323569 Y220.521832 Z10 E11571.395915 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X206.631079 Y220.298858 Z10 E11574.420521 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X205.952624 Y220.098551 Z10 E11577.361574 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X205.274385 Y219.95808 Z10 E11580.241206 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X204.589743 Y219.88002 Z10 E11583.106057 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X203.891707 Y219.856921 Z10 E11586.009744 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X203.175294 Y219.878186 Z10 E11588.989555 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X202.439687 Y219.905747 Z10 E11592.050001 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X201.691122 Y219.9138 Z10 E11595.162352 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X200.943281 Y219.869231 Z10 E11598.277028 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X200.210618 Y219.743956 Z10 E11601.367294 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X199.511296 Y219.509849 Z10 E11604.433325 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X198.862219 Y219.166299 Z10 E11607.486562 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X198.269717 Y218.729777 Z10 E11610.546251 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X197.736302 Y218.209709 Z10 E11613.643538 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X197.252437 Y217.636322 Z10 E11616.762779 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X196.806961 Y217.03831 Z10 E11619.863036 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X196.381209 Y216.444045 Z10 E11622.902337 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X195.948136 Y215.879535 Z10 E11625.860384 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X195.483441 Y215.364489 Z10 E11628.744435 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X194.980047 Y214.896954 Z10 E11631.600725 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X194.437151 Y214.464611 Z10 E11634.486106 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X193.850812 Y214.055197 Z10 E11637.459277 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X193.23827 Y213.647445 Z10 E11640.518568 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X192.624804 Y213.219537 Z10 E11643.62823 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X192.038852 Y212.749784 Z10 E11646.750546 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X191.513858 Y212.21993 Z10 E11649.851629 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X191.080952 Y211.625403 Z10 E11652.909226 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.745437 Y210.975538 Z10 E11655.949888 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.509324 Y210.279317 Z10 E11659.006367 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.371859 Y209.546144 Z10 E11662.107661 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.31534 Y208.796582 Z10 E11665.232823 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.306574 Y208.049629 Z10 E11668.338508 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.309168 Y207.316364 Z10 E11671.387087 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.291305 Y206.603075 Z10 E11674.353528 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.221752 Y205.914694 Z10 E11677.230053 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.102161 Y205.240057 Z10 E11680.078596 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X189.924587 Y204.567858 Z10 E11682.969146 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X189.691572 Y203.892449 Z10 E11685.939585 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X189.433765 Y203.20501 Z10 E11688.991995 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X189.183558 Y202.5 Z10 E11692.102203 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X188.98582 Y201.775824 Z10 E11695.2232 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X188.864095 Y201.041884 Z10 E11698.316248 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X188.849173 Y200.307243 Z10 E11701.371161 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X188.944308 Y199.581607 Z10 E11704.413821 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X189.150503 Y198.873075 Z10 E11707.48176 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X189.468229 Y198.197618 Z10 E11710.585151 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X189.856811 Y197.556488 Z10 E11713.70202 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.284398 Y196.943257 Z10 E11716.810118 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X190.716352 Y196.349074 Z10 E11719.86423 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X191.123405 Y195.763807 Z10 E11722.828133 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X191.48343 Y195.170253 Z10 E11725.714317 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X191.790239 Y194.55364 Z10 E11728.577705 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X192.044458 Y193.907554 Z10 E11731.464273 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X192.25251 Y193.226853 Z10 E11734.423537 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X192.447905 Y192.522178 Z10 E11737.463777 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X192.662495 Y191.807783 Z10 E11740.564986 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X192.919396 Y191.103211 Z10 E11743.682903 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X193.242395 Y190.432269 Z10 E11746.778764 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X193.652055 Y189.819145 Z10 E11749.844468 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X194.149845 Y189.277921 Z10 E11752.901641 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X194.728064 Y188.822671 Z10 E11755.961269 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X195.373462 Y188.455032 Z10 E11759.049321 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X196.060713 Y188.156295 Z10 E11762.164845 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X196.765546 Y187.905557 Z10 E11765.275101 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X197.466335 Y187.681158 Z10 E11768.334368 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X198.145494 Y187.451811 Z10 E11771.314634 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X198.790335 Y187.184738 Z10 E11774.216412 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X199.403402 Y186.870441 Z10 E11777.080679 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X199.987429 Y186.501359 Z10 E11779.953006 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X200.556817 Y186.081084 Z10 E11782.895264 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X201.130654 Y185.629865 Z10 E11785.930215 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X201.720578 Y185.174285 Z10 E11789.029066 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X202.337815 Y184.748182 Z10 E11792.147331 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X202.991346 Y184.384456 Z10 E11795.256865 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X203.683003 Y184.122516 Z10 E11798.331747 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X204.398649 Y183.96757 Z10 E11801.375993 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X205.130868 Y183.925906 Z10 E11804.425131 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X205.869534 Y183.995538 Z10 E11807.509761 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X206.60402 Y184.14818 Z10 E11810.628645 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X207.322858 Y184.36228 Z10 E11813.746971 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X208.023934 Y184.593656 Z10 E11816.816338 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X208.710798 Y184.80779 Z10 E11819.807543 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X209.390016 Y184.974612 Z10 E11822.71533 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X210.066746 Y185.085336 Z10 E11825.566256 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X210.753332 Y185.141365 Z10 E11828.430238 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X211.461837 Y185.140532 Z10 E11831.375863 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X212.18987 Y185.111439 Z10 E11834.405088 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X212.933802 Y185.08476 Z10 E11837.499983 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X213.685224 Y185.097129 Z10 E11840.624456 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X214.42752 Y185.185033 Z10 E11843.732129 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X215.142241 Y185.366088 Z10 E11846.797457 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X215.817725 Y185.647825 Z10 E11849.840277 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X216.442368 Y186.033707 Z10 E11852.892823 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X217.007242 Y186.517813 Z10 E11855.985748 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X217.512319 Y187.072492 Z10 E11859.104637 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X217.972478 Y187.66387 Z10 E11862.219929 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X218.40731 Y188.262306 Z10 E11865.295383 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X218.837659 Y188.83998 Z10 E11868.290261 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X219.282383 Y189.378661 Z10 E11871.194448 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X219.758066 Y189.875638 Z10 E11874.054565 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X220.28075 Y190.328029 Z10 E11876.928537 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X220.851578 Y190.744269 Z10 E11879.865701 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X221.456244 Y191.146146 Z10 E11882.884201 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X222.071932 Y191.561404 Z10 E11885.971733 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X222.671979 Y192.011432 Z10 E11889.090094 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X223.227886 Y192.509978 Z10 E11892.194569 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X223.711302 Y193.068025 Z10 E11895.264119 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.105276 Y193.688493 Z10 E11898.319812 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.390711 Y194.367484 Z10 E11901.382022 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.569055 Y195.086761 Z10 E11904.462979 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.661254 Y195.828864 Z10 E11907.572007 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.693163 Y196.577838 Z10 E11910.688703 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.696614 Y197.317955 Z10 E11913.765787 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.69796 Y198.04004 Z10 E11916.767872 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.733502 Y198.74218 Z10 E11919.690766 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.824169 Y199.426499 Z10 E11922.560698 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X224.979174 Y200.099505 Z10 E11925.431986 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X225.192879 Y200.768388 Z10 E11928.351362 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X225.43747 Y201.44799 Z10 E11931.354238 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X225.691285 Y202.145006 Z10 E11934.438248 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X225.919547 Y202.859152 Z10 E11937.5553 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
G1 X226.087102 Y203.587796 Z10 E11940.663713 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00004-band-000-layer-004-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=4 id=weave-00004-band-000-layer-004-island-000
G0 X226.087102 Y203.587796 Z14 F2400 ; clayline kind=travel_lift page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave paste-safe lift
G0 X219.920617 Y204.448554 Z14 F2400 ; clayline kind=travel_xy page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave paste-safe traverse
G0 X219.920617 Y204.448554 Z12 F2400 ; clayline kind=travel_approach page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=5 id=weave-00005-band-000-layer-005-island-000
G1 X219.894595 Y204.704487 Z12 E11941.733243 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.831655 Y204.954779 Z12 E11942.806232 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.729216 Y205.223137 Z12 E11944.000457 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.583722 Y205.496609 Z12 E11945.288319 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.371479 Y205.81018 Z12 E11946.862552 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.088409 Y206.16996 Z12 E11948.765817 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.74637 Y206.569792 Z12 E11950.953381 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.363201 Y207.007012 Z12 E11953.370397 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.955929 Y207.483762 Z12 E11955.977267 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.542189 Y208.006496 Z12 E11958.748907 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.130521 Y208.589349 Z12 E11961.715601 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X216.769425 Y209.198223 Z12 E11964.658695 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X216.454023 Y209.797249 Z12 E11967.473278 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X216.18349 Y210.381392 Z12 E11970.14967 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.944593 Y210.91745 Z12 E11972.589642 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.723319 Y211.404757 Z12 E11974.814707 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.513827 Y211.823636 Z12 E11976.761857 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.314548 Y212.163986 Z12 E11978.401579 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.122548 Y212.428233 Z12 E11979.759569 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.926018 Y212.640391 Z12 E11980.961911 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.731017 Y212.80458 Z12 E11982.021738 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.508288 Y212.943445 Z12 E11983.112971 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.259265 Y213.06073 Z12 E11984.257369 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.97405 Y213.150386 Z12 E11985.500361 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.603274 Y213.225991 Z12 E11987.073591 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.154967 Y213.283527 Z12 E11988.952723 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.638765 Y213.326804 Z12 E11991.106371 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.075027 Y213.364847 Z12 E11993.455452 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.459782 Y213.408419 Z12 E11996.019749 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.788108 Y213.480854 Z12 E11998.828438 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.083357 Y213.599872 Z12 E12001.799941 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.400938 Y213.768457 Z12 E12004.722401 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.755629 Y213.963797 Z12 E12007.525506 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.14255 Y214.183312 Z12 E12010.232855 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.582011 Y214.398777 Z12 E12012.729546 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.07555 Y214.590944 Z12 E12014.981642 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.625206 Y214.744577 Z12 E12016.959906 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.241855 Y214.84889 Z12 E12018.611644 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.906194 Y214.905061 Z12 E12020.026566 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.611457 Y214.922521 Z12 E12021.254089 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.358503 Y214.904363 Z12 E12022.308454 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.098039 Y214.849358 Z12 E12023.415222 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.848539 Y214.764268 Z12 E12024.51119 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.588488 Y214.63186 Z12 E12025.724432 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.27105 Y214.427093 Z12 E12027.29494 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.915816 Y214.15839 Z12 E12029.146751 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.528585 Y213.835051 Z12 E12031.24412 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.112306 Y213.470493 Z12 E12033.544659 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.652578 Y213.068102 Z12 E12036.084726 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.125752 Y212.636611 Z12 E12038.915897 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X201.544348 Y212.221508 Z12 E12041.885953 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.95728 Y211.859805 Z12 E12044.752766 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.362045 Y211.532499 Z12 E12047.576922 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.761772 Y211.24609 Z12 E12050.342084 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.207221 Y210.99964 Z12 E12052.865065 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X198.706614 Y210.776019 Z12 E12055.14456 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X198.275947 Y210.568019 Z12 E12057.132957 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X197.92173 Y210.367625 Z12 E12058.824955 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X197.627751 Y210.164489 Z12 E12060.31058 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X197.403355 Y209.972634 Z12 E12061.538011 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X197.233056 Y209.781563 Z12 E12062.602126 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X197.084331 Y209.563161 Z12 E12063.700674 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.969304 Y209.335587 Z12 E12064.760809 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.875091 Y209.058945 Z12 E12065.97582 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.791585 Y208.695336 Z12 E12067.526884 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.727083 Y208.263401 Z12 E12069.342574 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.680366 Y207.777879 Z12 E12071.370465 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.646175 Y207.233217 Z12 E12073.639361 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.606766 Y206.623627 Z12 E12076.179036 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.543092 Y205.945653 Z12 E12079.010127 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.428507 Y205.245096 Z12 E12081.961407 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.278356 Y204.584567 Z12 E12084.777627 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.094458 Y203.923163 Z12 E12087.631733 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.870293 Y203.283802 Z12 E12090.448532 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.651507 Y202.712414 Z12 E12092.992278 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.451253 Y202.192798 Z12 E12095.307468 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.290104 Y201.740122 Z12 E12097.305175 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.176653 Y201.338515 Z12 E12099.040206 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.10434 Y200.974487 Z12 E12100.583231 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.076556 Y200.679772 Z12 E12101.813948 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.087494 Y200.419115 Z12 E12102.898585 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.131143 Y200.162092 Z12 E12103.982465 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.205932 Y199.925237 Z12 E12105.015119 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.332106 Y199.659037 Z12 E12106.239872 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.522542 Y199.344794 Z12 E12107.767526 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X195.770587 Y199.002135 Z12 E12109.526215 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.071561 Y198.634326 Z12 E12111.502103 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.429127 Y198.229108 Z12 E12113.748912 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X196.832757 Y197.77162 Z12 E12116.285383 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X197.267506 Y197.24984 Z12 E12119.109009 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X197.675686 Y196.687683 Z12 E12121.997305 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X198.044085 Y196.121119 Z12 E12124.806976 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X198.391924 Y195.513465 Z12 E12127.717936 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X198.689225 Y194.901572 Z12 E12130.546277 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X198.942561 Y194.337623 Z12 E12133.116607 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.167927 Y193.826006 Z12 E12135.440885 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.377411 Y193.384117 Z12 E12137.474033 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.585099 Y193.003432 Z12 E12139.276952 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.789982 Y192.687397 Z12 E12140.842825 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.977459 Y192.454036 Z12 E12142.08734 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.168276 Y192.272735 Z12 E12143.181653 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.37684 Y192.120052 Z12 E12144.256284 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.596619 Y192.001664 Z12 E12145.294151 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.871826 Y191.898023 Z12 E12146.516777 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X201.218803 Y191.807447 Z12 E12148.007679 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X201.619309 Y191.738848 Z12 E12149.697037 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.083542 Y191.69196 Z12 E12151.636915 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.622555 Y191.656806 Z12 E12153.88263 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.226986 Y191.619374 Z12 E12156.400376 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.898279 Y191.559803 Z12 E12159.202255 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.567551 Y191.457745 Z12 E12162.01693 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.235114 Y191.327278 Z12 E12164.844844 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.922982 Y191.142262 Z12 E12167.806306 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.56646 Y190.924689 Z12 E12170.630367 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.154304 Y190.702685 Z12 E12173.242815 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.676096 Y190.498489 Z12 E12175.572374 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.144548 Y190.3311 Z12 E12177.640571 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.573264 Y190.20013 Z12 E12179.504282 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.945319 Y190.115906 Z12 E12181.090248 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.24805 Y190.078559 Z12 E12182.358395 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.514532 Y190.081024 Z12 E12183.466349 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.766721 Y190.116097 Z12 E12184.52492 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.01101 Y190.185777 Z12 E12185.581062 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.281666 Y190.301841 Z12 E12186.805417 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.580775 Y190.471316 Z12 E12188.234707 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.903775 Y190.695825 Z12 E12189.870115 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.261729 Y190.985903 Z12 E12191.785627 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.667362 Y191.339771 Z12 E12194.023595 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.117967 Y191.737025 Z12 E12196.521066 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.622585 Y192.161321 Z12 E12199.262085 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.155974 Y192.562824 Z12 E12202.037702 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.726754 Y192.955722 Z12 E12204.918592 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.344742 Y193.313583 Z12 E12207.887577 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.950142 Y193.619884 Z12 E12210.708348 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.52648 Y193.881195 Z12 E12213.339267 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X216.044974 Y194.110093 Z12 E12215.695635 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X216.5098 Y194.327052 Z12 E12217.828299 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X216.913975 Y194.537109 Z12 E12219.722053 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.243153 Y194.739519 Z12 E12221.32864 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.488914 Y194.926042 Z12 E12222.611349 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.683299 Y195.119087 Z12 E12223.750327 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.841288 Y195.319992 Z12 E12224.812924 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X217.968724 Y195.541363 Z12 E12225.874882 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.083122 Y195.811375 Z12 E12227.094061 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.174371 Y196.123503 Z12 E12228.446053 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.244382 Y196.501593 Z12 E12230.04469 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.295473 Y196.958541 Z12 E12231.956297 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.33392 Y197.489766 Z12 E12234.170651 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.372116 Y198.082814 Z12 E12236.641365 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.425865 Y198.720907 Z12 E12239.303642 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.509415 Y199.379049 Z12 E12242.061838 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.632959 Y200.075393 Z12 E12245.002113 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X218.813338 Y200.763635 Z12 E12247.960131 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.019899 Y201.412102 Z12 E12250.789618 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.243029 Y202.007517 Z12 E12253.433179 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.447919 Y202.542636 Z12 E12255.815445 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.63096 Y203.037538 Z12 E12258.00923 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.773789 Y203.476925 Z12 E12259.93008 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.869042 Y203.857521 Z12 E12261.561215 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.915639 Y204.168173 Z12 E12262.867206 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X219.920617 Y204.448554 Z12 E12264.033079 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.709548 Y203.966027 Z12 E12281.655227 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.338283 Y204.389664 Z12 E12283.997154 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.86595 Y204.942572 Z12 E12287.020459 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.337961 Y205.609654 Z12 E12290.557454 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.771347 Y206.411884 Z12 E12294.640774 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.277268 Y207.244994 Z12 E12298.667742 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.867194 Y208.023823 Z12 E12302.327149 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.541678 Y208.726689 Z12 E12305.5475 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.296691 Y209.276411 Z12 E12308.049663 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.266534 Y209.342826 Z12 E12308.352919 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.79908 Y209.374371 Z12 E12310.300785 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.103935 Y209.423601 Z12 E12313.198101 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.24013 Y209.516756 Z12 E12316.810207 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.26951 Y209.680675 Z12 E12320.902719 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.341119 Y209.910025 Z12 E12324.878553 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.501208 Y210.164272 Z12 E12328.526977 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.750581 Y210.433036 Z12 E12331.841734 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.154907 Y210.662007 Z12 E12334.494917 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.030625 Y210.709163 Z12 E12335.047567 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.74761 Y210.461312 Z12 E12336.611632 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.237788 Y210.015074 Z12 E12339.428476 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.557819 Y209.458153 Z12 E12343.082644 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.758128 Y208.8872 Z12 E12347.167799 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.971282 Y208.40241 Z12 E12351.010181 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.188482 Y207.971967 Z12 E12354.724258 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X201.435557 Y207.612722 Z12 E12358.192618 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.835164 Y207.345901 Z12 E12360.924156 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.656101 Y207.265913 Z12 E12361.739514 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.638083 Y206.978887 Z12 E12362.935179 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.59468 Y206.30752 Z12 E12365.732225 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.512755 Y205.435206 Z12 E12369.374845 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.356225 Y204.478209 Z12 E12373.406446 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.157711 Y203.604923 Z12 E12377.129772 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.912881 Y202.724374 Z12 E12380.929542 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.626173 Y201.906629 Z12 E12384.532238 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.385479 Y201.278025 Z12 E12387.330701 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.290603 Y201.031844 Z12 E12388.427581 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.428403 Y200.87568 Z12 E12389.293462 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X199.869639 Y200.375569 Z12 E12392.06625 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.425928 Y199.707917 Z12 E12395.679266 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X200.972956 Y198.954535 Z12 E12399.550055 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X201.459269 Y198.20663 Z12 E12403.259023 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X201.930611 Y197.383225 Z12 E12407.203537 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.313327 Y196.595533 Z12 E12410.844462 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.59728 Y195.963428 Z12 E12413.725435 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.73174 Y195.658183 Z12 E12415.112163 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X202.876341 Y195.648752 Z12 E12415.714622 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.527448 Y195.608429 Z12 E12418.426796 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.377035 Y195.533037 Z12 E12421.972849 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.252961 Y195.399465 Z12 E12425.656624 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.139307 Y195.226241 Z12 E12429.411336 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.084234 Y194.972084 Z12 E12433.479513 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.914094 Y194.691492 Z12 E12437.121552 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.589811 Y194.4363 Z12 E12440.124526 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.964219 Y194.289781 Z12 E12441.796082 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.02996 Y194.347132 Z12 E12442.158786 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.507875 Y194.768462 Z12 E12444.807622 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.130851 Y195.292277 Z12 E12448.191547 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.818114 Y195.809607 Z12 E12451.767887 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.587255 Y196.339046 Z12 E12455.649956 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X212.438074 Y196.831735 Z12 E12459.737525 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.22057 Y197.227637 Z12 E12463.383453 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X213.892839 Y197.532443 Z12 E12466.452286 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.340861 Y197.73023 Z12 E12468.488383 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.34321 Y197.762685 Z12 E12468.623668 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.382921 Y198.379262 Z12 E12471.192406 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.447072 Y199.140842 Z12 E12474.369904 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.553687 Y199.980669 Z12 E12477.889522 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.722686 Y200.93322 Z12 E12481.911612 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X214.970422 Y201.87846 Z12 E12485.974195 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.23905 Y202.721778 Z12 E12489.65388 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.502397 Y203.424512 Z12 E12492.773923 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.704214 Y203.951603 Z12 E12495.120453 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X215.709548 Y203.966027 Z12 E12495.18439 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.179154 Y203.155427 Z12 E12514.318704 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.133734 Y203.212812 Z12 E12514.62297 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.412173 Y204.23442 Z12 E12519.822915 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.785111 Y205.291764 Z12 E12524.933758 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.643409 Y205.560891 Z12 E12526.198276 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.455663 Y205.761478 Z12 E12531.206272 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.281301 Y206.051593 Z12 E12536.23548 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X206.852291 Y206.181457 Z12 E12538.099024 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.971908 Y205.552892 Z12 E12542.596391 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.985284 Y204.945016 Z12 E12547.414341 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.436361 Y204.643176 Z12 E12550.018766 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.283943 Y203.711322 Z12 E12553.944446 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.037065 Y202.625279 Z12 E12558.574877 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X203.81937 Y201.84232 Z12 E12561.953527 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.270227 Y201.221387 Z12 E12565.143806 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X204.874454 Y200.292141 Z12 E12569.75207 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.369117 Y199.427993 Z12 E12573.891763 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X205.938371 Y199.341186 Z12 E12576.285805 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X207.043499 Y199.125204 Z12 E12580.967315 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.169373 Y198.822377 Z12 E12585.814517 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X208.480255 Y199.056391 Z12 E12587.432266 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X209.447756 Y199.722371 Z12 E12592.315515 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.531405 Y200.349886 Z12 E12597.521667 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.570998 Y200.369918 Z12 E12597.706144 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.597958 Y200.58229 Z12 E12598.596171 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X210.812414 Y201.791046 Z12 E12603.700075 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.127506 Y202.993286 Z12 E12608.867223 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X211.179154 Y203.155427 Z12 E12609.5747 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=interior 6 of 6 · island 1 of 1
G1 X222.412331 Y203.959669 Z12 E12656.396365 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X222.422868 Y204.553174 Z12 E12658.864262 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X222.363403 Y205.138046 Z12 E12661.308412 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X222.220069 Y205.708035 Z12 E12663.751929 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X222.00936 Y206.260029 Z12 E12666.208369 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.728458 Y206.788013 Z12 E12668.694806 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.391622 Y207.285659 Z12 E12671.193156 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.021471 Y207.756119 Z12 E12673.681926 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.63638 Y208.206279 Z12 E12676.144841 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.253775 Y208.642854 Z12 E12678.558295 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X219.887165 Y209.072005 Z12 E12680.904894 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X219.544831 Y209.504523 Z12 E12683.198187 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X219.230005 Y209.950264 Z12 E12685.466989 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X218.952024 Y210.418992 Z12 E12687.732662 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X218.69579 Y210.90564 Z12 E12690.01923 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X218.459623 Y211.415582 Z12 E12692.355647 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X218.224531 Y211.9431 Z12 E12694.75675 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X217.980251 Y212.481074 Z12 E12697.213165 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X217.712895 Y213.015652 Z12 E12699.698139 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X217.409588 Y213.533672 Z12 E12702.193829 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X217.057629 Y214.018068 Z12 E12704.683185 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X216.654751 Y214.452982 Z12 E12707.147935 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X216.204905 Y214.83175 Z12 E12709.592844 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X215.706347 Y215.142584 Z12 E12712.035462 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X215.17091 Y215.394766 Z12 E12714.496096 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X214.600321 Y215.574128 Z12 E12716.982772 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X214.012696 Y215.693951 Z12 E12719.476106 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X213.418645 Y215.770192 Z12 E12721.966142 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X212.827371 Y215.819763 Z12 E12724.432999 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X212.247493 Y215.858895 Z12 E12726.849332 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X211.682186 Y215.898929 Z12 E12729.205491 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X211.130594 Y215.958415 Z12 E12731.512044 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X210.592011 Y216.049371 Z12 E12733.782918 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X210.063324 Y216.179978 Z12 E12736.047019 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X209.539643 Y216.3385 Z12 E12738.3218 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X209.012531 Y216.527234 Z12 E12740.649518 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X208.47395 Y216.734258 Z12 E12743.048401 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X207.922828 Y216.943371 Z12 E12745.499095 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X207.357731 Y217.136152 Z12 E12747.981444 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X206.777703 Y217.293983 Z12 E12750.480606 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X206.187223 Y217.392795 Z12 E12752.969671 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X205.595814 Y217.427831 Z12 E12755.432774 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X205.009101 Y217.385715 Z12 E12757.87832 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X204.433867 Y217.264236 Z12 E12760.322612 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X203.872958 Y217.072943 Z12 E12762.786487 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X203.340495 Y216.801832 Z12 E12765.270643 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X202.837383 Y216.477294 Z12 E12767.759767 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X202.359655 Y216.115935 Z12 E12770.250129 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X201.903652 Y215.735172 Z12 E12772.719987 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X201.465241 Y215.351231 Z12 E12775.14284 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X201.036821 Y214.976244 Z12 E12777.509921 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X200.605711 Y214.623148 Z12 E12779.826719 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X200.160736 Y214.30545 Z12 E12782.099837 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X199.698528 Y214.020676 Z12 E12784.356921 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X199.220521 Y213.757831 Z12 E12786.624876 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X198.715657 Y213.516944 Z12 E12788.950538 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X198.189756 Y213.283228 Z12 E12791.343171 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X197.652925 Y213.043425 Z12 E12793.787613 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X197.115593 Y212.783908 Z12 E12796.268485 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X196.59296 Y212.488236 Z12 E12798.76496 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X196.100825 Y212.148177 Z12 E12801.251965 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X195.649868 Y211.762615 Z12 E12803.718674 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X195.258364 Y211.323357 Z12 E12806.164988 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.926465 Y210.835965 Z12 E12808.616538 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.659186 Y210.30717 Z12 E12811.07989 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.467224 Y209.743503 Z12 E12813.555513 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.333319 Y209.160443 Z12 E12816.042701 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.24484 Y208.56795 Z12 E12818.533315 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.18788 Y207.975969 Z12 E12821.005856 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.151233 Y207.392174 Z12 E12823.43777 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.114319 Y206.821193 Z12 E12825.816588 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.062053 Y206.264682 Z12 E12828.140473 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.973683 Y205.7244 Z12 E12830.416553 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.85376 Y205.196844 Z12 E12832.665832 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.707944 Y204.672407 Z12 E12834.928898 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.522868 Y204.144536 Z12 E12837.254511 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.317774 Y203.608908 Z12 E12839.63906 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.106875 Y203.061671 Z12 E12842.077316 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X192.906925 Y202.5 Z12 E12844.556027 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X192.743871 Y201.922797 Z12 E12847.049671 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X192.627365 Y201.336302 Z12 E12849.535677 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X192.571619 Y200.744985 Z12 E12852.004988 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X192.59632 Y200.156378 Z12 E12854.454288 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X192.695281 Y199.573644 Z12 E12856.911702 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X192.873512 Y199.009194 Z12 E12859.372621 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.127792 Y198.472718 Z12 E12861.840887 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.437493 Y197.961674 Z12 E12864.325262 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X193.788904 Y197.476221 Z12 E12866.816842 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.166231 Y197.015103 Z12 E12869.293987 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.55458 Y196.575 Z12 E12871.734221 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X194.934707 Y196.144152 Z12 E12874.122994 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X195.293492 Y195.713542 Z12 E12876.453251 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X195.614892 Y195.270901 Z12 E12878.727488 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X195.909595 Y194.817675 Z12 E12880.975099 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X196.180245 Y194.344866 Z12 E12883.240088 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X196.424162 Y193.842845 Z12 E12885.560563 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X196.658362 Y193.321495 Z12 E12887.936741 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X196.894049 Y192.786448 Z12 E12890.367464 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X197.148792 Y192.249087 Z12 E12892.839876 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X197.435827 Y191.722962 Z12 E12895.331603 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X197.761399 Y191.220764 Z12 E12897.81987 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X198.133696 Y190.757348 Z12 E12900.291268 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X198.562342 Y190.350079 Z12 E12902.7495 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X199.039323 Y190.000895 Z12 E12905.207152 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X199.558633 Y189.721161 Z12 E12907.659502 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X200.113483 Y189.512207 Z12 E12910.124458 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X200.691084 Y189.361429 Z12 E12912.606314 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X201.282268 Y189.26017 Z12 E12915.099964 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X201.876513 Y189.200151 Z12 E12917.583118 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X202.463939 Y189.161839 Z12 E12920.030539 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X203.039197 Y189.126214 Z12 E12922.426766 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X203.599056 Y189.076532 Z12 E12924.763537 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X204.139169 Y188.994169 Z12 E12927.035024 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X204.669994 Y188.890427 Z12 E12929.28369 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X205.197199 Y188.748624 Z12 E12931.553455 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X205.72419 Y188.570438 Z12 E12933.86628 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X206.257111 Y188.369175 Z12 E12936.23465 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X206.799762 Y188.156816 Z12 E12938.657332 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X207.358304 Y187.957237 Z12 E12941.123272 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X207.931197 Y187.782221 Z12 E12943.613749 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X208.515216 Y187.650014 Z12 E12946.103253 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X209.105946 Y187.577138 Z12 E12948.577845 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X209.699045 Y187.582624 Z12 E12951.043766 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X210.284296 Y187.664017 Z12 E12953.500376 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X210.849919 Y187.825353 Z12 E12955.945755 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X211.393907 Y188.05863 Z12 E12958.406574 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X211.913227 Y188.352876 Z12 E12960.888143 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X212.406239 Y188.695556 Z12 E12963.384351 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X212.870992 Y189.072181 Z12 E12965.871373 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X213.315738 Y189.460171 Z12 E12968.325136 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X213.749274 Y189.842376 Z12 E12970.728003 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X214.179918 Y190.204473 Z12 E12973.067206 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X214.617136 Y190.533584 Z12 E12975.342371 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X215.063941 Y190.841143 Z12 E12977.597524 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X215.53641 Y191.114739 Z12 E12979.867395 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X216.031124 Y191.365038 Z12 E12982.172442 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X216.547505 Y191.599164 Z12 E12984.529665 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X217.078605 Y191.833628 Z12 E12986.943318 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X217.615432 Y192.084194 Z12 E12989.406334 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X218.146761 Y192.360334 Z12 E12991.895863 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X218.65698 Y192.674067 Z12 E12994.386044 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X219.13266 Y193.035088 Z12 E12996.868771 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X219.553705 Y193.45323 Z12 E12999.335837 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X219.91794 Y193.916409 Z12 E13001.785605 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.211281 Y194.425974 Z12 E13004.230092 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.441836 Y194.970148 Z12 E13006.68718 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.609503 Y195.543676 Z12 E13009.171438 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.718929 Y196.134629 Z12 E13011.670101 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.785423 Y196.729324 Z12 E13014.157962 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.828114 Y197.319192 Z12 E13016.616762 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.865363 Y197.897534 Z12 E13019.026211 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.91261 Y198.458447 Z12 E13021.366475 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X220.981745 Y199.003036 Z12 E13023.648783 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.076879 Y199.539251 Z12 E13025.912924 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.215161 Y200.066868 Z12 E13028.180588 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.38293 Y200.593555 Z12 E13030.478701 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.580924 Y201.121896 Z12 E13032.824461 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.787735 Y201.662031 Z12 E13035.229063 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X221.993057 Y202.217175 Z12 E13037.689885 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X222.178024 Y202.786194 Z12 E13040.177442 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X222.323506 Y203.367483 Z12 E13042.668696 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
G1 X222.412331 Y203.959669 Z12 E13045.158262 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00005-band-000-layer-005-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=5 id=weave-00005-band-000-layer-005-island-000
; CLAYLINE_BODY_END
; CLAYLINE_PROFILE_END_BEGIN
M83 ;Set to Relative Extrusion Mode
G91 ;Set to Relative Positioning
G1 Z150 E-100 F40000 ;Move Z Axis up and relieve Extruder pressure (v1.3.0: was E-3000, which left the next job dry)
G90 ;Set to Absolute Positioning
G28 Z ;Home Z
G1 X207.5 Y0 F500 ;Move X and Y slow to home position
M82 ;absolute extrusion mode
; CLAYLINE_PROFILE_END_END
