; CLAYLINE_HEADER_BEGIN
; clayline_version=0.1.0.dev0
; generated_utc=reproducible
; job_id=weave-slice-976bdc821d9e261c5818
; prepared_trace_sha256=08bc059a502e053dba200839254d8072a8c61545f150e19d35efd26d37db4eb9
; body_sha256=7bb80f5b4cda0ebfeaa194f3e6023f1f4c79090e5c36ed1ad8f3a44d4709fabf
; profile_name=potterbot-xl
; profile_version=1.3.0
; profile_verified=true
; profile_flavor=marlin
; extrusion_mode=absolute
; bead_width_mm=5
; layer_height_mm=2
; flow_multiplier=1
; wet_density_g_cm3=1.8
; prime_mm=0
; end_early_mm=0
; first_layer_z_mm=2
; speed_default_mm_s=40
; speed_first_layer_mm_s=30
; speed_travel_mm_s=40
; virtual_filament_diameter_mm=1.75
; work_bounds=17,398,12,393,0,710
; machine_envelope=0,490,0,490,0,710
; stats.motion_count=4319
; stats.print_motion_count=4272
; stats.travel_motion_count=47
; stats.stroke_count=18
; stats.page_count=1
; stats.print_path_mm=4297.557171
; stats.deposited_path_mm=4297.557171
; stats.travel_path_mm=279.491318
; stats.total_motion_path_mm=4577.048489
; stats.motion_time_seconds=121.680597
; stats.pause_time_seconds=0
; stats.pressure_time_seconds=0
; stats.estimated_print_time_seconds=121.680597
; stats.body_volume_mm3=43846.097827
; stats.wet_weight_g=78.922976
; stats.body_e=18229.089187
; stats.pressure_e_excluded=0
; stats.warning_count=0
; nominal_label=Weave mesh — hollow-cylinder.obj
; parameter.bottom_layers=3
; parameter.first_layer_flow_factor=1.1
; parameter.first_layer_height_mm=2.0
; parameter.layer_count=12
; parameter.layer_range_from=1
; parameter.layer_range_semantics=one_based_inclusive
; parameter.layer_range_to=9
; parameter.layer_range_total=9
; parameter.level_rim=true
; parameter.mode=weave
; parameter.pattern_part_0001={"extrusion":[{"u":0.0,"value":1.0},{"u":0.5,"value":1.0}],"interpolation":"monotone_cubic_periodic","name":"flat","schema":"cla
; parameter.pattern_part_0002=yline.weave-pattern","seed":null,"settings":{"amplitude":0.0,"bottom_layers":3,"extrusion_phase_offset":0.0,"level_rim":true,"ov
; parameter.pattern_part_0003=erlap_fraction":0.2,"pinned_seam_angle":0.0,"seam":"chained","twist":0.0,"wavelength":18.0,"z_blend":false},"version":1,"wave":[
; parameter.pattern_part_0004={"u":0.0,"value":0.0},{"u":0.5,"value":0.0}]}
; parameter.pattern_part_count=4
; parameter.print_range=printing layers 1–9 of 9, rebased to the bed
; parameter.range_rebased_to_bed=true
; parameter.reproducible=true
; parameter.restore_capsule_v1_b64_part_0001=eyJlbWlzc2lvbiI6eyJlbmRfZWFybHlfbW1faGV4IjoiMHgwLjBwKzAiLCJmbG93X211bHRpcGxpZXJfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzAiLCJwcmltZV9t
; parameter.restore_capsule_v1_b64_part_0002=bV9oZXgiOiIweDAuMHArMCIsInJlcHJvZHVjaWJsZSI6dHJ1ZSwid2V0X2RlbnNpdHlfZ19jbTNfaGV4IjoiMHgxLmNjY2NjY2NjY2NjY2RwKzAifSwiam9iX2lkIjp7
; parameter.restore_capsule_v1_b64_part_0003=ImVuY29kaW5nIjoidXRmLTgvYmFzZTY0IiwicHJlc2VudCI6dHJ1ZSwidXRmOF9iNjQiOiJkMlZoZG1VdGMyeHBZMlV0T1RjMlltUmpPREl4WkRsbE1qWXhZelU0TVRn
; parameter.restore_capsule_v1_b64_part_0004=PSJ9LCJwYXR0ZXJuX2pzb25fdXRmOF9iNjQiOiJleUpsZUhSeWRYTnBiMjRpT2x0N0luVWlPakF1TUN3aWRtRnNkV1VpT2pFdU1IMHNleUoxSWpvd0xqVXNJblpoYkhW
; parameter.restore_capsule_v1_b64_part_0005=bElqb3hMakI5WFN3aWFXNTBaWEp3YjJ4aGRHbHZiaUk2SW0xdmJtOTBiMjVsWDJOMVltbGpYM0JsY21sdlpHbGpJaXdpYm1GdFpTSTZJbVpzWVhRaUxDSnpZMmhsYldF
; parameter.restore_capsule_v1_b64_part_0006=aU9pSmpiR0Y1YkdsdVpTNTNaV0YyWlMxd1lYUjBaWEp1SWl3aWMyVmxaQ0k2Ym5Wc2JDd2ljMlYwZEdsdVozTWlPbnNpWVcxd2JHbDBkV1JsSWpvd0xqQXNJbUp2ZEhS
; parameter.restore_capsule_v1_b64_part_0007=dmJWOXNZWGxsY25NaU9qTXNJbVY0ZEhKMWMybHZibDl3YUdGelpWOXZabVp6WlhRaU9qQXVNQ3dpYkdWMlpXeGZjbWx0SWpwMGNuVmxMQ0p2ZG1WeWJHRndYMlp5WVdO
; parameter.restore_capsule_v1_b64_part_0008=MGFXOXVJam93TGpJc0luQnBibTVsWkY5elpXRnRYMkZ1WjJ4bElqb3dMakFzSW5ObFlXMGlPaUpqYUdGcGJtVmtJaXdpZEhkcGMzUWlPakF1TUN3aWQyRjJaV3hsYm1k
; parameter.restore_capsule_v1_b64_part_0009=MGFDSTZNVGd1TUN3aWVsOWliR1Z1WkNJNlptRnNjMlY5TENKMlpYSnphVzl1SWpveExDSjNZWFpsSWpwYmV5SjFJam93TGpBc0luWmhiSFZsSWpvd0xqQjlMSHNpZFNJ
; parameter.restore_capsule_v1_b64_part_0010=Nk1DNDFMQ0oyWVd4MVpTSTZNQzR3ZlYxOSIsInByb2ZpbGUiOnsiY2VudGVyIjp7IngiOiIweDEuOWYwMDAwMDAwMDAwMHArNyIsInkiOiIweDEuOTUwMDAwMDAwMDAw
; parameter.restore_capsule_v1_b64_part_0011=MHArNyJ9LCJkZWZhdWx0X25venpsZV9kaWFtZXRlcl9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArMiIsImRlc2NyaXB0aW9uIjoiVmVyaWZpZWQgZnJvbSBQZXRlJ3Mg
; parameter.restore_capsule_v1_b64_part_0012=c3VjY2Vzc2Z1bCBKYW51YXJ5IDIwMjYgUG90dGVyQm90IDEwIFhMIHByaW50LiAxMCBtbSBub3p6bGUgYWRkZWQgcGVyIFBldGUgMjAyNi0wNy0xNS4gdjEuMi4wOiB0
; parameter.restore_capsule_v1_b64_part_0013=cmF2ZWwgc3BlZWQgY29ycmVjdGVkIHRvIHByaW50IHNwZWVkIFx1MjAxNCB0aGUgcmVmZXJlbmNlIEN1cmEgcHJvZmlsZSBvbmx5IHVzZWQgMTIwIG91dHNpZGUgc3Bp
; parameter.restore_capsule_v1_b64_part_0014=cmFsaXplIG1vZGUgYW5kIHRoZSBmaXJzdCBjbGF5IHByaW50ICgyMDI2LTA3LTE3KSBzaG93ZWQgZmFzdCB0cmF2ZWxzIHRlYXIgdGhlIHRocmVhZC4gdjEuMy4wOiBl
; parameter.restore_capsule_v1_b64_part_0015=bmQtb2Ytam9iIGRlcHJlc3N1cml6ZSBhbmQgbWF0Y2hpbmcgc3RhcnQgcHJpbWUgcmVkdWNlZCAzMDAwLT4xMDAgXHUyMDE0IHRoZSBDdXJhLWluaGVyaXRlZCBmdWxs
; parameter.restore_capsule_v1_b64_part_0016=IGRlcHJlc3N1cml6ZSBsZWZ0IGJhY2stdG8tYmFjayBqb2JzIHByaW50aW5nIGRyeSBmb3IgMzAtNDBzIChQZXRlLCAyMDI2LTA4LTAyKTsgMTAwIGlzIGVub3VnaCB0
; parameter.restore_capsule_v1_b64_part_0017=byBzdG9wIG9vemUgZHVyaW5nIHRoZSBob21pbmcgbW92ZXMgd2l0aG91dCBlbXB0eWluZyB0aGUgYmFycmVsLiIsImVtaXNzaW9uX2RlZmF1bHRzIjp7ImVuZF9lYXJs
; parameter.restore_capsule_v1_b64_part_0018=eV9tbV9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArMiIsInByaW1lX21tX2hleCI6IjB4MS5lMDAwMDAwMDAwMDAwcCszIn0sImVuZF9nY29kZSI6WyJNODMgO1NldCB0
; parameter.restore_capsule_v1_b64_part_0019=byBSZWxhdGl2ZSBFeHRydXNpb24gTW9kZSIsIkc5MSA7U2V0IHRvIFJlbGF0aXZlIFBvc2l0aW9uaW5nIiwiRzEgWjE1MCBFLTEwMCBGNDAwMDAgO01vdmUgWiBBeGlz
; parameter.restore_capsule_v1_b64_part_0020=IHVwIGFuZCByZWxpZXZlIEV4dHJ1ZGVyIHByZXNzdXJlICh2MS4zLjA6IHdhcyBFLTMwMDAsIHdoaWNoIGxlZnQgdGhlIG5leHQgam9iIGRyeSkiLCJHOTAgO1NldCB0
; parameter.restore_capsule_v1_b64_part_0021=byBBYnNvbHV0ZSBQb3NpdGlvbmluZyIsIkcyOCBaIDtIb21lIFoiLCJHMSBYMjA3LjUgWTAgRjUwMCA7TW92ZSBYIGFuZCBZIHNsb3cgdG8gaG9tZSBwb3NpdGlvbiIs
; parameter.restore_capsule_v1_b64_part_0022=Ik04MiA7YWJzb2x1dGUgZXh0cnVzaW9uIG1vZGUiXSwiZXh0cnVzaW9uX21vZGUiOiJhYnNvbHV0ZSIsImZsYXZvciI6Im1hcmxpbiIsImdjb2RlX3doaXRlbGlzdCI6
; parameter.restore_capsule_v1_b64_part_0023=WyJHMCIsIkcxIiwiRzQiLCJHMjEiLCJHMjgiLCJHOTAiLCJHOTEiLCJHOTIiLCJNODIiLCJNODMiLCJNMTA1IiwiTTEwNyIsIk0xMDkiXSwibWFjaGluZV9lbnZlbG9w
; parameter.restore_capsule_v1_b64_part_0024=ZSI6eyJtYXhfeCI6IjB4MS5lYTAwMDAwMDAwMDAwcCs4IiwibWF4X3kiOiIweDEuZWEwMDAwMDAwMDAwMHArOCIsIm1heF96IjoiMHgxLjYzMDAwMDAwMDAwMDBwKzki
; parameter.restore_capsule_v1_b64_part_0025=LCJtaW5feCI6IjB4MC4wcCswIiwibWluX3kiOiIweDAuMHArMCIsIm1pbl96IjoiMHgwLjBwKzAifSwibmFtZSI6InBvdHRlcmJvdC14bCIsIm5venpsZV9kaWFtZXRl
; parameter.restore_capsule_v1_b64_part_0026=cnNfaGV4IjpbIjB4MS5jMDAwMDAwMDAwMDAwcCsxIiwiMHgxLjA4NTFlYjg1MWViODVwKzIiLCIweDEuNDAwMDAwMDAwMDAwMHArMiIsIjB4MS45OTk5OTk5OTk5OTlh
; parameter.restore_capsule_v1_b64_part_0027=cCsyIiwiMHgxLjQwMDAwMDAwMDAwMDBwKzMiXSwic3BlZWRfZGVmYXVsdF9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArNSIsInNwZWVkX2ZpcnN0X2xheWVyX2hleCI6
; parameter.restore_capsule_v1_b64_part_0028=IjB4MS5lMDAwMDAwMDAwMDAwcCs0Iiwic3BlZWRfdHJhdmVsX2hleCI6IjB4MS40MDAwMDAwMDAwMDAwcCs1Iiwic3RhcnRfZ2NvZGUiOlsiTTEwNSIsIk0xMDkgUzAi
; parameter.restore_capsule_v1_b64_part_0029=LCJNODIgO2Fic29sdXRlIGV4dHJ1c2lvbiBtb2RlIiwiRzI4IDtIb21lIiwiRzEgWDIwNy41IFkyMDIuNSBaMjAgRjEwMDAwIDtNb3ZlIFggYW5kIFkgdG8gY2VudGVy
; parameter.restore_capsule_v1_b64_part_0030=LCBaIHRvIDIwbW0gaGlnaCIsIkc5MiBFMCIsIkcxIEUxMDAgRjQwMDAwIDsgUHJpbWUgRXh0cnVkZXIgKHYxLjMuMDogbWF0Y2hlcyB0aGUgcmVkdWNlZCBlbmQtb2Yt
; parameter.restore_capsule_v1_b64_part_0031=am9iIGRlcHJlc3N1cml6ZSkiLCJHOTIgRTAiLCJHOTIgRTAiLCJHOTIgRTAiLCJNMTA3Il0sInRyYXZlbF9wb2xpY3kiOnsiZHdlbGxfc2Vjb25kc19oZXgiOiIweDAu
; parameter.restore_capsule_v1_b64_part_0032=MHArMCIsImxpZnRfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzEiLCJwYWdlX3BhdXNlX2NvbW1hbmQiOiJHNCBTe3NlY29uZHN9IiwicmVwcmltZV9lX2hleCI6IjB4
; parameter.restore_capsule_v1_b64_part_0033=MC4wcCswIn0sInZlcmlmaWNhdGlvbl9zb3VyY2UiOiJkb2NzL3JlZmVyZW5jZS9wb3R0ZXJib3QtMTB4bC1yZWZlcmVuY2UtaGVhZGVyLWZvb3Rlci5nY29kZSIsInZl
; parameter.restore_capsule_v1_b64_part_0034=cmlmaWVkIjp0cnVlLCJ2ZXJzaW9uIjoiMS4zLjAiLCJ2aXJ0dWFsX2ZpbGFtZW50X2RpYW1ldGVyX2hleCI6IjB4MS5jMDAwMDAwMDAwMDAwcCswIiwid29ya19ib3Vu
; parameter.restore_capsule_v1_b64_part_0035=ZHMiOnsibWF4X3giOiIweDEuOGUwMDAwMDAwMDAwMHArOCIsIm1heF95IjoiMHgxLjg5MDAwMDAwMDAwMDBwKzgiLCJtYXhfeiI6IjB4MS42MzAwMDAwMDAwMDAwcCs5
; parameter.restore_capsule_v1_b64_part_0036=IiwibWluX3giOiIweDEuMTAwMDAwMDAwMDAwMHArNCIsIm1pbl95IjoiMHgxLjgwMDAwMDAwMDAwMDBwKzMiLCJtaW5feiI6IjB4MC4wcCswIn19LCJzY2hlbWEiOiJj
; parameter.restore_capsule_v1_b64_part_0037=bGF5bGluZS53ZWF2ZS1yZXN0b3JlIiwic2xpY2UiOnsiYmVhZF93aWR0aF9tbV9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArMiIsImZpcnN0X2xheWVyX2hlaWdodF9t
; parameter.restore_capsule_v1_b64_part_0038=bV9oZXgiOiIweDEuMDAwMDAwMDAwMDAwMHArMSIsImxheWVyX2hlaWdodF9tbV9oZXgiOiIweDEuMDAwMDAwMDAwMDAwMHArMSIsInJhbmdlX2Zyb20iOjEsInJhbmdl
; parameter.restore_capsule_v1_b64_part_0039=X3RvIjo5LCJzYW1wbGVfc3BhY2luZ19tbV9oZXgiOiIweDEuMDAwMDAwMDAwMDAwMHArMCJ9LCJzb3VyY2UiOnsibGF5ZXJfdG90YWwiOjksIm1lc2hfbmFtZSI6Imhv
; parameter.restore_capsule_v1_b64_part_0040=bGxvdy1jeWxpbmRlci5vYmoiLCJtZXNoX3NoYTI1NiI6ImZlNWE3MzA2YjBkOTJlZTFlNjNjYjhjZDEwZjQ0NmNlMzJhYzdlOWJlNmQzMjIzODA3OGYzM2E4NTM3MDZi
; parameter.restore_capsule_v1_b64_part_0041=NmEiLCJvZmZzZXRfeF9tbV9oZXgiOiIweDAuMHArMCIsIm9mZnNldF95X21tX2hleCI6IjB4MC4wcCswIiwic2NhbGVfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzAi
; parameter.restore_capsule_v1_b64_part_0042=LCJ1cF9heGlzIjoieiJ9LCJ2ZXJzaW9uIjoxfQ==
; parameter.restore_capsule_v1_b64_part_count=42
; parameter.sample_spacing_mm=1.0
; parameter.seam=chained
; parameter.source_mesh=hollow-cylinder.obj
; parameter.source_mesh_sha256=fe5a7306b0d92ee1e63cb8cd10f446ce32ac7e9be6d32238078f33a853706b6a
; parameter.source_offset_x_mm=0.0
; parameter.source_offset_y_mm=0.0
; parameter.source_scale=1.0
; parameter.source_up_axis=z
; parameter.z_blend=false
; pressure_management=profile and marked pressure blocks excluded from body volume
; thermal_policy=no heater or fan commands outside verbatim profile blocks
; CLAYLINE_HEADER_END
; CLAYLINE_PROFILE_START_BEGIN
M105
M109 S0
M82 ;absolute extrusion mode
G28 ;Home
G1 X207.5 Y202.5 Z20 F10000 ;Move X and Y to center, Z to 20mm high
G92 E0
G1 E100 F40000 ; Prime Extruder (v1.3.0: matches the reduced end-of-job depressurize)
G92 E0
G92 E0
G92 E0
M107
; CLAYLINE_PROFILE_START_END
; CLAYLINE_BODY_BEGIN
G21 ; clayline units: millimeters
G90 ; clayline absolute XYZ
M82 ; clayline absolute extrusion
G92 E0 ; clayline body extrusion origin
; CLAYLINE_PAGE index=0
; CLAYLINE_STROKE_BEGIN page=0 layer=0 id=weave-00000-layer-00000-bottom-and-wall
G0 X234.987763 Y202.033654 Z20 F2400 ; clayline kind=travel_xy page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=stroke start XY at safe Z
G0 X234.987763 Y202.033654 Z2 F2400 ; clayline kind=travel_approach page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=stroke start vertical approach
G1 X234.987763 Y202.966346 Z2 E4.265454 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.964509 Y203.871199 Z2 E8.404954 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.898026 Y204.772489 Z2 E12.537996 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.804614 Y205.69905 Z2 E16.796886 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.690359 Y206.599811 Z2 E20.949316 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.535854 Y207.490245 Z2 E25.082357 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.350545 Y208.399952 Z2 E29.328129 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.145878 Y209.28747 Z2 E33.493512 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.90484 Y210.158471 Z2 E37.626552 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.630065 Y211.042268 Z2 E41.859229 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.336495 Y211.907468 Z2 E46.037589 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.011244 Y212.750649 Z2 E50.170628 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X232.650322 Y213.599796 Z2 E54.390232 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X232.270268 Y214.433771 Z2 E58.581592 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X231.863937 Y215.241012 Z2 E62.71463 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X231.421035 Y216.047173 Z2 E66.921186 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.95781 Y216.84128 Z2 E71.125568 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.474312 Y217.604806 Z2 E75.258607 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.954394 Y218.360129 Z2 E79.452135 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.412174 Y219.106073 Z2 E83.669564 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.856165 Y219.818532 Z2 E87.802602 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.264945 Y220.515725 Z2 E91.983128 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.648732 Y221.20565 Z2 E96.213624 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.025568 Y221.86018 Z2 E100.346664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.36944 Y222.492584 Z2 E104.514208 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.685019 Y223.119152 Z2 E108.757796 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.0007 Y223.709449 Z2 E112.890837 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.286674 Y224.271098 Z2 E117.045424 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.540557 Y224.827568 Z2 E121.302126 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.801674 Y225.347948 Z2 E125.435168 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.037299 Y225.833627 Z2 E129.576821 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.237486 Y226.313433 Z2 E133.842275 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.449994 Y226.758745 Z2 E137.979623 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.642752 Y227.165077 Z2 E142.112666 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.79971 Y227.561829 Z2 E146.373743 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.968934 Y227.927042 Z2 E150.524017 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.125752 Y228.252293 Z2 E154.657058 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.249871 Y228.561526 Z2 E158.905015 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X215.383959 Y228.842439 Z2 E163.068238 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.512957 Y229.083478 Z2 E167.201277 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.613258 Y229.302616 Z2 E171.436135 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.720762 Y229.495856 Z2 E175.612331 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.830329 Y229.650361 Z2 E179.74537 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.916018 Y229.777753 Z2 E183.967152 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.005817 Y229.880815 Z2 E188.156343 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X209.104528 Y229.947298 Z2 E192.289382 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.184902 Y229.982228 Z2 E196.49811 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.266107 Y229.993505 Z2 E200.700321 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.362641 Y229.971326 Z2 E204.833359 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.446993 Y229.914013 Z2 E209.029057 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.528861 Y229.832821 Z2 E213.24431 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.631919 Y229.722194 Z2 E217.377348 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.729445 Y229.573785 Z2 E221.560039 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.821281 Y229.400372 Z2 E225.788356 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.939501 Y229.202362 Z2 E229.921395 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.059206 Y228.964917 Z2 E234.091102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.170274 Y228.700467 Z2 E238.332506 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.312149 Y228.416981 Z2 E242.465547 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X197.462759 Y228.093443 Z2 E246.622292 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.602185 Y227.740072 Z2 E250.876806 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.775978 Y227.373839 Z2 E255.009848 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.965854 Y226.968001 Z2 E259.153656 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.142955 Y226.528964 Z2 E263.419111 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.356385 Y226.082979 Z2 E267.554306 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.592857 Y225.599481 Z2 E271.687349 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.818545 Y225.080382 Z2 E275.950616 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.07837 Y224.556115 Z2 E280.098733 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.365911 Y224.000106 Z2 E284.231775 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.649785 Y223.407785 Z2 E288.481917 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.963796 Y222.810059 Z2 E292.64298 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.309266 Y222.186894 Z2 E296.77602 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.658179 Y221.527766 Z2 E301.013059 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.033666 Y220.862177 Z2 E305.187091 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.443369 Y220.177858 Z2 E309.32013 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.863476 Y219.458972 Z2 E313.54409 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.307149 Y218.731841 Z2 E317.731114 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.786769 Y217.992958 Z2 E321.864152 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.283472 Y217.221921 Z2 E326.075055 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X183.801393 Y216.440231 Z2 E330.275094 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X183.355942 Y215.653901 Z2 E334.408132 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X182.933834 Y214.838799 Z2 E338.606001 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X182.53135 Y214.010131 Z2 E342.819078 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X182.165117 Y213.183925 Z2 E346.952116 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X181.827946 Y212.333239 Z2 E351.136974 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X181.50963 Y211.465697 Z2 E355.363112 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X181.226143 Y210.607572 Z2 E359.496151 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.976779 Y209.730088 Z2 E363.66802 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.746377 Y208.832221 Z2 E367.907241 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.548367 Y207.950442 Z2 E372.040281 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.388774 Y207.055161 Z2 E376.199185 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.249167 Y206.135879 Z2 E380.451513 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.13854 Y205.238936 Z2 E384.584555 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.069769 Y204.334984 Z2 E388.730517 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.022932 Y203.403467 Z2 E392.995973 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.000753 Y202.5 Z2 E397.129017 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.022932 Y201.596533 Z2 E401.262061 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.069769 Y200.665016 Z2 E405.527517 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.13854 Y199.761064 Z2 E409.673479 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.249167 Y198.864121 Z2 E413.806521 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.388774 Y197.944839 Z2 E418.058849 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.548367 Y197.049558 Z2 E422.217753 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.746377 Y196.167779 Z2 E426.350793 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X180.976779 Y195.269912 Z2 E430.590014 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X181.226143 Y194.392428 Z2 E434.761883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X181.50963 Y193.534303 Z2 E438.894922 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X181.827946 Y192.666761 Z2 E443.121061 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X182.165117 Y191.816075 Z2 E447.305918 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X182.53135 Y190.989869 Z2 E451.438956 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X182.933834 Y190.161201 Z2 E455.652033 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X183.355942 Y189.346099 Z2 E459.849902 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X183.801393 Y188.559769 Z2 E463.98294 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.283472 Y187.778079 Z2 E468.182979 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.786769 Y187.007042 Z2 E472.393882 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.307149 Y186.268159 Z2 E476.52692 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.863476 Y185.541028 Z2 E480.713944 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.443369 Y184.822142 Z2 E484.937904 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.033666 Y184.137823 Z2 E489.070943 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.658179 Y183.472234 Z2 E493.244975 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.309266 Y182.813106 Z2 E497.482014 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.963796 Y182.189941 Z2 E501.615054 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.649785 Y181.592215 Z2 E505.776117 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.365911 Y180.999894 Z2 E510.026259 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.07837 Y180.443885 Z2 E514.159301 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.818545 Y179.919618 Z2 E518.307418 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.592857 Y179.400519 Z2 E522.570685 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.356385 Y178.917021 Z2 E526.703728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.142955 Y178.471036 Z2 E530.838923 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.965854 Y178.031999 Z2 E535.104378 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.775978 Y177.626161 Z2 E539.248186 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.602185 Y177.259928 Z2 E543.381228 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X197.462759 Y176.906557 Z2 E547.635742 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.312149 Y176.583019 Z2 E551.792487 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.170274 Y176.299533 Z2 E555.925528 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.059206 Y176.035083 Z2 E560.166932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.939501 Y175.797638 Z2 E564.336639 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.821281 Y175.599628 Z2 E568.469678 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.729445 Y175.426215 Z2 E572.697995 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.631919 Y175.277806 Z2 E576.880686 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.528861 Y175.167179 Z2 E581.013724 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.446993 Y175.085987 Z2 E585.228977 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.362641 Y175.028674 Z2 E589.424675 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.266107 Y175.006495 Z2 E593.557713 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.184902 Y175.017772 Z2 E597.759924 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X209.104528 Y175.052702 Z2 E601.968652 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.005817 Y175.119185 Z2 E606.101691 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.916018 Y175.222247 Z2 E610.290882 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.830329 Y175.349639 Z2 E614.512664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.720762 Y175.504144 Z2 E618.645703 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.613258 Y175.697384 Z2 E622.821899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.512957 Y175.916522 Z2 E627.056757 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X215.383959 Y176.157561 Z2 E631.189797 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.249871 Y176.438474 Z2 E635.35302 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.125752 Y176.747707 Z2 E639.600976 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.968934 Y177.072958 Z2 E643.734017 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.79971 Y177.438171 Z2 E647.884291 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.642752 Y177.834923 Z2 E652.145368 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.449994 Y178.241255 Z2 E656.278411 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.237486 Y178.686567 Z2 E660.415759 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.037299 Y179.166373 Z2 E664.681213 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.801674 Y179.652052 Z2 E668.822866 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.540557 Y180.172432 Z2 E672.955908 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.286674 Y180.728902 Z2 E677.21261 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.0007 Y181.290551 Z2 E681.367197 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.685019 Y181.880848 Z2 E685.500238 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.36944 Y182.507416 Z2 E689.743826 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.025568 Y183.13982 Z2 E693.91137 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.648732 Y183.79435 Z2 E698.04441 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.264945 Y184.484275 Z2 E702.274907 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.856165 Y185.181468 Z2 E706.455432 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.412174 Y185.893927 Z2 E710.58847 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.954394 Y186.639871 Z2 E714.805899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.474312 Y187.395194 Z2 E718.999427 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.95781 Y188.15872 Z2 E723.132466 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X231.421035 Y188.952827 Z2 E727.336848 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X231.863937 Y189.758988 Z2 E731.543404 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X232.270268 Y190.566229 Z2 E735.676442 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X232.650322 Y191.400204 Z2 E739.867802 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.011244 Y192.249351 Z2 E744.087407 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.336495 Y193.092532 Z2 E748.220445 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.630065 Y193.957732 Z2 E752.398805 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X233.90484 Y194.841529 Z2 E756.631482 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.145878 Y195.71253 Z2 E760.764522 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.350545 Y196.600048 Z2 E764.929905 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.535854 Y197.509755 Z2 E769.175677 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.690359 Y198.400189 Z2 E773.308718 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.804614 Y199.30095 Z2 E777.461148 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.898026 Y200.227511 Z2 E781.720038 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.964509 Y201.128801 Z2 E785.85308 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X234.987763 Y202.033654 Z2 E789.99258 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.987763 Y202.085044 Z2 E808.287164 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.987763 Y202.914956 Z2 E812.082575 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.968293 Y203.672574 Z2 E815.548508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.912814 Y204.424683 Z2 E818.997452 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.829943 Y205.246692 Z2 E822.775775 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.733642 Y206.00591 Z2 E826.2757 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.60471 Y206.748959 Z2 E829.724639 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.441295 Y207.551189 Z2 E833.468799 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.267654 Y208.304165 Z2 E837.002738 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.066512 Y209.030998 Z2 E840.451674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.825667 Y209.805662 Z2 E844.161691 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.574982 Y210.54447 Z2 E847.729665 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.303567 Y211.248088 Z2 E851.178598 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.989152 Y211.987819 Z2 E854.854492 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.662536 Y212.704533 Z2 E858.456524 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.323461 Y213.378158 Z2 E861.905456 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.940022 Y214.076085 Z2 E865.547247 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.539407 Y214.762859 Z2 E869.183356 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.135938 Y215.400005 Z2 E872.632288 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.688651 Y216.049812 Z2 E876.239998 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.216785 Y216.698969 Z2 E879.910207 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.752808 Y217.293501 Z2 E883.359139 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.247414 Y217.889484 Z2 E886.932789 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.707842 Y218.493599 Z2 E890.637117 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.187824 Y219.039791 Z2 E894.086052 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.630557 Y219.576909 Z2 E897.625662 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.027603 Y220.128896 Z2 E901.36413 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.456553 Y220.621487 Z2 E904.813068 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.854067 Y221.0954 Z2 E908.318661 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.192798 Y221.588587 Z2 E912.091289 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.576214 Y222.022835 Z2 E915.540232 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.935504 Y222.429938 Z2 E919.011829 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.223829 Y222.856871 Z2 E922.80724 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.565209 Y223.229307 Z2 E926.26751 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.891581 Y223.568383 Z2 E929.716455 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.142924 Y223.920716 Z2 E933.500474 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.443466 Y224.228202 Z2 E936.994732 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X215.739847 Y224.499617 Z2 E940.443672 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.966669 Y224.77259 Z2 E944.193524 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.232822 Y225.01066 Z2 E947.721793 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.505989 Y225.211802 Z2 E951.170729 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.716584 Y225.404076 Z2 E954.886435 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.955284 Y225.568909 Z2 E958.448736 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.212237 Y225.697841 Z2 E961.897669 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.414917 Y225.808932 Z2 E965.579248 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X209.633524 Y225.897409 Z2 E969.175602 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.881417 Y225.952888 Z2 E972.624534 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.084428 Y225.983159 Z2 E976.272008 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.290651 Y225.992903 Z2 E979.902436 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.536728 Y225.974395 Z2 E983.351368 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.748161 Y225.925036 Z2 E986.964757 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.949984 Y225.854452 Z2 E990.629281 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.201505 Y225.762136 Z2 E994.078213 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.429215 Y225.635136 Z2 E997.657538 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.634816 Y225.483445 Z2 E1001.356178 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.898989 Y225.31821 Z2 E1004.805113 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.150521 Y225.116323 Z2 E1008.350395 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.368189 Y224.883586 Z2 E1012.083171 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.652101 Y224.647022 Z2 E1015.532109 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.93461 Y224.373726 Z2 E1019.04337 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.17266 Y224.060852 Z2 E1022.810303 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X197.483207 Y223.755238 Z2 E1026.259245 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.803394 Y223.414681 Z2 E1029.736507 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.071177 Y223.024025 Z2 E1033.531918 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.414063 Y222.651442 Z2 E1036.986526 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.776914 Y222.247971 Z2 E1040.435471 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.08861 Y221.786532 Z2 E1044.225187 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.466119 Y221.345621 Z2 E1047.713779 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.871586 Y220.881642 Z2 E1051.162719 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.238797 Y220.358251 Z2 E1054.918265 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.658065 Y219.852238 Z2 E1058.440864 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.111873 Y219.33222 Z2 E1061.8898 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.540022 Y218.753307 Z2 E1065.611196 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.007885 Y218.18617 Z2 E1069.167823 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.515294 Y217.61512 Z2 E1072.616757 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.009082 Y216.987575 Z2 E1076.304022 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.531992 Y216.364007 Z2 E1079.894699 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.097746 Y215.747426 Z2 E1083.343631 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.661111 Y215.078514 Z2 E1086.996788 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.245064 Y214.403895 Z2 E1090.621536 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.873345 Y213.747719 Z2 E1094.070468 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.509437 Y213.045003 Z2 E1097.689536 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.1599 Y212.325348 Z2 E1101.348375 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.854287 Y211.635897 Z2 E1104.797308 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.565446 Y210.907147 Z2 E1108.382308 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.28729 Y210.149059 Z2 E1112.075261 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.050726 Y209.432971 Z2 E1115.524195 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.838475 Y208.686086 Z2 E1119.075149 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.635908 Y207.89669 Z2 E1122.802235 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.470673 Y207.160863 Z2 E1126.251172 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.335715 Y206.403779 Z2 E1129.768102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.212231 Y205.590662 Z2 E1133.529341 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.119914 Y204.842181 Z2 E1136.978282 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.062142 Y204.082792 Z2 E1140.461209 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.020466 Y203.253926 Z2 E1144.256621 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.001958 Y202.5 Z2 E1147.705567 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.020466 Y201.746074 Z2 E1151.154513 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.062142 Y200.917208 Z2 E1154.949926 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.119914 Y200.157819 Z2 E1158.432852 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.212231 Y199.409338 Z2 E1161.881793 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.335715 Y198.596221 Z2 E1165.643033 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.470673 Y197.839137 Z2 E1169.159962 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.635908 Y197.10331 Z2 E1172.608899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X184.838475 Y196.313914 Z2 E1176.335985 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.050726 Y195.567029 Z2 E1179.886939 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.28729 Y194.850941 Z2 E1183.335873 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.565446 Y194.092853 Z2 E1187.028826 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.854287 Y193.364103 Z2 E1190.613827 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.1599 Y192.674652 Z2 E1194.062759 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.509437 Y191.954997 Z2 E1197.721599 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.873345 Y191.252281 Z2 E1201.340667 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.245064 Y190.596105 Z2 E1204.789599 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.661111 Y189.921486 Z2 E1208.414346 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.097746 Y189.252574 Z2 E1212.067503 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.531992 Y188.635993 Z2 E1215.516435 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.009082 Y188.012425 Z2 E1219.107112 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.515294 Y187.38488 Z2 E1222.794378 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.007885 Y186.81383 Z2 E1226.243312 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.540022 Y186.246693 Z2 E1229.799939 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.111873 Y185.66778 Z2 E1233.521334 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.658065 Y185.147762 Z2 E1236.970271 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.238797 Y184.641749 Z2 E1240.49287 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.871586 Y184.118358 Z2 E1244.248415 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.466119 Y183.654379 Z2 E1247.697355 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.08861 Y183.213468 Z2 E1251.185948 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.776914 Y182.752029 Z2 E1254.975663 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.414063 Y182.348558 Z2 E1258.424608 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.071177 Y181.975975 Z2 E1261.879216 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.803394 Y181.585319 Z2 E1265.674628 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X197.483207 Y181.244762 Z2 E1269.151889 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.17266 Y180.939148 Z2 E1272.600831 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.93461 Y180.626274 Z2 E1276.367765 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.652101 Y180.352978 Z2 E1279.879026 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.368189 Y180.116414 Z2 E1283.327963 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.150521 Y179.883677 Z2 E1287.06074 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.898989 Y179.68179 Z2 E1290.606022 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.634816 Y179.516555 Z2 E1294.054956 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.429215 Y179.364864 Z2 E1297.753596 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.201505 Y179.237864 Z2 E1301.332921 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.949984 Y179.145548 Z2 E1304.781854 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.748161 Y179.074964 Z2 E1308.446378 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.536728 Y179.025605 Z2 E1312.059766 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.290651 Y179.007097 Z2 E1315.508698 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.084428 Y179.016841 Z2 E1319.139126 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.881417 Y179.047112 Z2 E1322.7866 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X209.633524 Y179.102591 Z2 E1326.235532 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.414917 Y179.191068 Z2 E1329.831886 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.212237 Y179.302159 Z2 E1333.513465 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.955284 Y179.431091 Z2 E1336.962399 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.716584 Y179.595924 Z2 E1340.524699 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.505989 Y179.788198 Z2 E1344.240405 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.232822 Y179.98934 Z2 E1347.689341 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.966669 Y180.22741 Z2 E1351.21761 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X215.739847 Y180.500383 Z2 E1354.967462 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.443466 Y180.771798 Z2 E1358.416402 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.142924 Y181.079284 Z2 E1361.910661 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.891581 Y181.431617 Z2 E1365.69468 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.565209 Y181.770693 Z2 E1369.143624 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.223829 Y182.143129 Z2 E1372.603895 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.935504 Y182.570062 Z2 E1376.399305 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.576214 Y182.977165 Z2 E1379.870902 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.192798 Y183.411413 Z2 E1383.319845 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.854067 Y183.9046 Z2 E1387.092473 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.456553 Y184.378513 Z2 E1390.598066 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.027603 Y184.871104 Z2 E1394.047004 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.630557 Y185.423091 Z2 E1397.785472 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.187824 Y185.960209 Z2 E1401.325082 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.707842 Y186.506401 Z2 E1404.774018 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.247414 Y187.110516 Z2 E1408.478346 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.752808 Y187.706499 Z2 E1412.051995 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.216785 Y188.301031 Z2 E1415.500928 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.688651 Y188.950188 Z2 E1419.171136 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.135938 Y189.599995 Z2 E1422.778846 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.539407 Y190.237141 Z2 E1426.227778 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.940022 Y190.923915 Z2 E1429.863888 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.323461 Y191.621842 Z2 E1433.505679 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.662536 Y192.295467 Z2 E1436.954611 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.989152 Y193.012181 Z2 E1440.556642 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.303567 Y193.751912 Z2 E1444.232536 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.574982 Y194.45553 Z2 E1447.681469 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X229.825667 Y195.194338 Z2 E1451.249444 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.066512 Y195.969002 Z2 E1454.959461 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.267654 Y196.695835 Z2 E1458.408396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.441295 Y197.448811 Z2 E1461.942335 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.60471 Y198.251041 Z2 E1465.686495 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.733642 Y198.99409 Z2 E1469.135434 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.829943 Y199.753308 Z2 E1472.635359 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.912814 Y200.575317 Z2 E1476.413683 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.968293 Y201.327426 Z2 E1479.862626 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X230.987763 Y202.085044 Z2 E1483.32856 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.987828 Y201.800931 Z2 E1492.566633 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.898222 Y200.369371 Z2 E1499.126355 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.70389 Y198.950741 Z2 E1505.674717 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.428532 Y197.577441 Z2 E1512.080193 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.057122 Y196.192032 Z2 E1518.639771 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.589327 Y194.84402 Z2 E1525.165244 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.047435 Y193.547048 Z2 E1531.593552 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.408948 Y192.262689 Z2 E1538.153033 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.687807 Y191.037262 Z2 E1544.655626 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.898718 Y189.867993 Z2 E1551.106778 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.018462 Y188.735579 Z2 E1557.666207 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.073816 Y187.679566 Z2 E1564.145931 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.066698 Y186.684734 Z2 E1570.619939 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.979559 Y185.749141 Z2 E1577.179362 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.849742 Y184.902446 Z2 E1583.636227 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.66252 Y184.122277 Z2 E1590.133102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.411579 Y183.42058 Z2 E1596.692565 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.141863 Y182.814677 Z2 E1603.126583 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.819793 Y182.281262 Z2 E1609.646335 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.45462 Y181.841276 Z2 E1616.205884 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.095407 Y181.498039 Z2 E1622.617068 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.689353 Y181.234022 Z2 E1629.159707 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X209.264045 Y181.073189 Z2 E1635.719388 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.867617 Y181.00405 Z2 E1642.113452 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.433361 Y181.022205 Z2 E1648.673216 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.005611 Y181.146256 Z2 E1655.227302 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.621607 Y181.353181 Z2 E1661.627073 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.219404 Y181.655092 Z2 E1668.186682 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.848709 Y182.056005 Z2 E1674.717877 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.5277 Y182.532674 Z2 E1681.140475 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.213115 Y183.106366 Z2 E1687.699976 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.952419 Y183.766606 Z2 E1694.208288 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.746627 Y184.496262 Z2 E1700.653728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.571753 Y185.318993 Z2 E1707.213166 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.469347 Y186.211048 Z2 E1713.698606 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.42685 Y187.166895 Z2 E1720.166899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.438243 Y188.206058 Z2 E1726.726319 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.535916 Y189.293585 Z2 E1733.188898 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.69873 Y190.439765 Z2 E1739.680055 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.935568 Y191.654181 Z2 E1746.239504 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.267025 Y192.893481 Z2 E1752.679232 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.66941 Y194.186419 Z2 E1759.193264 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.161941 Y195.527965 Z2 E1765.752788 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.751544 Y196.869735 Z2 E1772.169678 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.418612 Y198.259796 Z2 E1778.706595 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.186952 Y199.67531 Z2 E1785.266239 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.048843 Y201.066611 Z2 E1791.660304 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X185.995501 Y202.5 Z2 E1798.220115 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.048843 Y203.933389 Z2 E1804.779925 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.186952 Y205.32469 Z2 E1811.17399 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.418612 Y206.740204 Z2 E1817.733634 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X186.751544 Y208.130265 Z2 E1824.270551 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.161941 Y209.472035 Z2 E1830.687441 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X187.66941 Y210.813581 Z2 E1837.246965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.267025 Y212.106519 Z2 E1843.760997 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X188.935568 Y213.345819 Z2 E1850.200725 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.69873 Y214.560235 Z2 E1856.760174 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.535916 Y215.706415 Z2 E1863.251331 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.438243 Y216.793942 Z2 E1869.71391 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.42685 Y217.833105 Z2 E1876.27333 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.469347 Y218.788952 Z2 E1882.741623 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.571753 Y219.681007 Z2 E1889.227063 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.746627 Y220.503738 Z2 E1895.786501 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.952419 Y221.233394 Z2 E1902.231941 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.213115 Y221.893634 Z2 E1908.740253 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.5277 Y222.467326 Z2 E1915.299754 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X200.848709 Y222.943995 Z2 E1921.722352 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.219404 Y223.344908 Z2 E1928.253547 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.621607 Y223.646819 Z2 E1934.813156 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.005611 Y223.853744 Z2 E1941.212927 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.433361 Y223.977795 Z2 E1947.767013 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.867617 Y223.99595 Z2 E1954.326777 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X209.264045 Y223.926811 Z2 E1960.720841 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.689353 Y223.765978 Z2 E1967.280522 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.095407 Y223.501961 Z2 E1973.823161 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.45462 Y223.158724 Z2 E1980.234345 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.819793 Y222.718738 Z2 E1986.793894 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.141863 Y222.185323 Z2 E1993.313646 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.411579 Y221.57942 Z2 E1999.747664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.66252 Y220.877723 Z2 E2006.307127 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.849742 Y220.097554 Z2 E2012.804002 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.979559 Y219.250859 Z2 E2019.260867 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.066698 Y218.315266 Z2 E2025.82029 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.073816 Y217.320434 Z2 E2032.294298 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.018462 Y216.264421 Z2 E2038.774022 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.898718 Y215.132007 Z2 E2045.333451 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X225.687807 Y213.962738 Z2 E2051.784603 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X226.408948 Y212.737311 Z2 E2058.287196 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.047435 Y211.452952 Z2 E2064.846677 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X227.589327 Y210.15598 Z2 E2071.274985 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.057122 Y208.807968 Z2 E2077.800458 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.428532 Y207.422559 Z2 E2084.360036 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.70389 Y206.049259 Z2 E2090.765512 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.898222 Y204.630629 Z2 E2097.313874 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.987828 Y203.199069 Z2 E2103.873596 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X228.987828 Y201.800931 Z2 E2110.267659 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.987828 Y201.925994 Z2 E2128.569672 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.915239 Y200.766287 Z2 E2133.883702 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.757665 Y199.616003 Z2 E2139.19339 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.531783 Y198.489452 Z2 E2144.447952 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.230905 Y197.367137 Z2 E2149.761845 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.850901 Y196.272106 Z2 E2155.062684 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.407212 Y195.210174 Z2 E2160.326037 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.889977 Y194.169722 Z2 E2165.639837 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.303092 Y193.172434 Z2 E2170.931839 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.658214 Y192.216857 Z2 E2176.203994 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.945125 Y191.299497 Z2 E2181.517745 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.174918 Y190.438488 Z2 E2186.800919 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.353393 Y189.626984 Z2 E2192.081889 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.472708 Y188.869066 Z2 E2197.395633 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.549805 Y188.177435 Z2 E2202.669992 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.583162 Y187.542216 Z2 E2207.959786 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X215.569782 Y186.973776 Z2 E2213.273569 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.530656 Y186.477909 Z2 E2218.539122 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.456205 Y186.044401 Z2 E2223.837751 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.350283 Y185.68797 Z2 E2229.151616 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.235815 Y185.406537 Z2 E2234.408375 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.095206 Y185.192364 Z2 E2239.715849 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.940566 Y185.062073 Z2 E2245.029841 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.793958 Y185.005303 Z2 E2250.28001 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.632066 Y185.02001 Z2 E2255.594082 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.474914 Y185.12055 Z2 E2260.905982 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.339047 Y185.290376 Z2 E2266.158349 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.203126 Y185.534953 Z2 E2271.472272 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.09018 Y185.860477 Z2 E2276.775322 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.008058 Y186.250947 Z2 E2282.036476 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.943119 Y186.715692 Z2 E2287.350295 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.917601 Y187.252766 Z2 E2292.644505 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X197.931716 Y187.849352 Z2 E2297.91446 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.979958 Y188.515841 Z2 E2303.228218 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.08154 Y189.242831 Z2 E2308.513598 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.23076 Y190.022896 Z2 E2313.792363 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.429896 Y190.864716 Z2 E2319.106105 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.693165 Y191.752659 Z2 E2324.382667 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.011207 Y192.686317 Z2 E2329.670254 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.392974 Y193.670109 Z2 E2334.984023 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.8461 Y194.683866 Z2 E2340.251776 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.360193 Y195.735126 Z2 E2345.548195 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.949094 Y196.821906 Z2 E2350.862036 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.612754 Y197.921553 Z2 E2356.120992 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.342551 Y199.049706 Z2 E2361.426254 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.154884 Y200.196411 Z2 E2366.74021 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.041482 Y201.338809 Z2 E2371.990381 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X189.998269 Y202.5 Z2 E2377.304496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.041482 Y203.661191 Z2 E2382.618611 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.154884 Y204.803589 Z2 E2387.868782 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.342551 Y205.950294 Z2 E2393.182738 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.612754 Y207.078447 Z2 E2398.488 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X190.949094 Y208.178094 Z2 E2403.746956 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.360193 Y209.264874 Z2 E2409.060797 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X191.8461 Y210.316134 Z2 E2414.357217 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X192.392974 Y211.329891 Z2 E2419.62497 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.011207 Y212.313683 Z2 E2424.938739 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X193.693165 Y213.247341 Z2 E2430.226326 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X194.429896 Y214.135284 Z2 E2435.502887 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X195.23076 Y214.977104 Z2 E2440.816629 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.08154 Y215.757169 Z2 E2446.095394 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X196.979958 Y216.484159 Z2 E2451.380775 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X197.931716 Y217.150648 Z2 E2456.694533 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X198.917601 Y217.747234 Z2 E2461.964487 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X199.943119 Y218.284308 Z2 E2467.258697 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X201.008058 Y218.749053 Z2 E2472.572516 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X202.09018 Y219.139523 Z2 E2477.833671 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X203.203126 Y219.465047 Z2 E2483.136721 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X204.339047 Y219.709624 Z2 E2488.450644 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X205.474914 Y219.87945 Z2 E2493.70301 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X206.632066 Y219.97999 Z2 E2499.014911 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X207.793958 Y219.994697 Z2 E2504.328982 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X208.940566 Y219.937927 Z2 E2509.579152 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X210.095206 Y219.807636 Z2 E2514.893143 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X211.235815 Y219.593463 Z2 E2520.200618 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X212.350283 Y219.31203 Z2 E2525.457377 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X213.456205 Y218.955599 Z2 E2530.771242 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X214.530656 Y218.522091 Z2 E2536.069871 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X215.569782 Y218.026224 Z2 E2541.335424 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X216.583162 Y217.457784 Z2 E2546.649207 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X217.549805 Y216.822565 Z2 E2551.939001 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X218.472708 Y216.130934 Z2 E2557.213359 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X219.353393 Y215.373016 Z2 E2562.527104 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.174918 Y214.561512 Z2 E2567.808073 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X220.945125 Y213.700503 Z2 E2573.091248 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X221.658214 Y212.783143 Z2 E2578.404998 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.303092 Y211.827566 Z2 E2583.677154 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X222.889977 Y210.830278 Z2 E2588.969156 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.407212 Y209.789826 Z2 E2594.282955 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X223.850901 Y208.727894 Z2 E2599.546309 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.230905 Y207.632863 Z2 E2604.847148 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.531783 Y206.510548 Z2 E2610.161041 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.757665 Y205.383997 Z2 E2615.415603 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.915239 Y204.233713 Z2 E2620.72529 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.987828 Y203.074006 Z2 E2626.03932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X224.987828 Y201.925994 Z2 E2631.289489 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=bottom 1 of 3 · island 1 of 1
G1 X237.487763 Y202.001535 Z2 E2688.456096 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.487763 Y202.998465 Z2 E2693.015327 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.462144 Y203.995339 Z2 E2697.575806 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.388783 Y204.989868 Z2 E2702.13641 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.288784 Y205.981773 Z2 E2706.695654 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.163308 Y206.971 Z2 E2711.255899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.992819 Y207.953549 Z2 E2715.816504 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.793827 Y208.930429 Z2 E2720.375783 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.569769 Y209.902035 Z2 E2724.935819 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.303795 Y210.863142 Z2 E2729.496424 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.007814 Y211.815147 Z2 E2734.055764 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X235.68744 Y212.759341 Z2 E2738.615615 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X235.328542 Y213.68975 Z2 E2743.176219 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X234.938554 Y214.607282 Z2 E2747.735644 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X234.525102 Y215.514546 Z2 E2752.295334 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X234.076735 Y216.405296 Z2 E2756.855938 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X233.596668 Y217.279103 Z2 E2761.415471 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X233.094311 Y218.140293 Z2 E2765.975025 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X232.560795 Y218.982807 Z2 E2770.535629 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X231.995484 Y219.804076 Z2 E2775.095295 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X231.409292 Y220.610513 Z2 E2779.654735 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X230.795764 Y221.396677 Z2 E2784.21534 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X230.150903 Y222.157126 Z2 E2788.775163 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X229.486788 Y222.900682 Z2 E2793.334515 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X228.799157 Y223.622923 Z2 E2797.895119 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X228.081242 Y224.314881 Z2 E2802.455123 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X227.345904 Y224.988062 Z2 E2807.014411 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X226.590792 Y225.639426 Z2 E2811.575016 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X225.807054 Y226.25591 Z2 E2816.135224 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X225.007907 Y226.85193 Z2 E2820.694472 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X224.192586 Y227.426144 Z2 E2825.255077 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X223.350921 Y227.960932 Z2 E2829.815515 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X222.496022 Y228.473785 Z2 E2834.374746 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X221.627984 Y228.964644 Z2 E2838.935266 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X220.737233 Y229.41301 Z2 E2843.495871 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X219.835201 Y229.837524 Z2 E2848.05511 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X218.922352 Y230.238817 Z2 E2852.615393 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X217.991943 Y230.597716 Z2 E2857.175998 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X217.051872 Y230.929611 Z2 E2861.735269 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X216.103419 Y231.237301 Z2 E2866.295339 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X215.142312 Y231.503275 Z2 E2870.855943 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X214.173679 Y231.739204 Z2 E2875.415271 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X213.199186 Y231.950197 Z2 E2879.975152 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X212.216637 Y232.120686 Z2 E2884.535756 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X211.229206 Y232.258266 Z2 E2889.095165 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X210.238501 Y232.370443 Z2 E2893.65488 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X209.243972 Y232.443804 Z2 E2898.215485 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X208.247698 Y232.481645 Z2 E2902.774998 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X207.250767 Y232.493882 Z2 E2907.334572 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X206.253837 Y232.469408 Z2 E2911.895177 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X205.258764 Y232.407124 Z2 E2916.454819 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X204.265659 Y232.319302 Z2 E2921.014276 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X203.275928 Y232.19723 Z2 E2925.574881 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X202.292088 Y232.035441 Z2 E2930.134676 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X201.312821 Y231.848451 Z2 E2934.694041 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X200.339821 Y231.629956 Z2 E2939.254646 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X199.377134 Y231.370288 Z2 E2943.814618 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X198.421577 Y231.086017 Z2 E2948.373914 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X197.474679 Y230.773204 Z2 E2952.934519 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X196.542852 Y230.418266 Z2 E2957.494692 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X195.620638 Y230.039584 Z2 E2962.053945 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X194.70896 Y229.635465 Z2 E2966.614549 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X193.817391 Y229.188827 Z2 E2971.174948 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X192.937817 Y228.719551 Z2 E2975.73418 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X192.070336 Y228.22769 Z2 E2980.294742 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X191.227821 Y227.694174 Z2 E2984.855347 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X190.399754 Y227.139037 Z2 E2989.414583 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X189.586028 Y226.562674 Z2 E2993.974904 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X188.799864 Y225.949146 Z2 E2998.535508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X188.031652 Y225.313744 Z2 E3003.094773 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X187.279879 Y224.658696 Z2 E3007.654876 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X186.557637 Y223.971065 Z2 E3012.215481 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X185.857027 Y223.261802 Z2 E3016.774798 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X185.174779 Y222.534682 Z2 E3021.334708 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X184.523415 Y221.77957 Z2 E3025.895312 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X183.897472 Y221.003595 Z2 E3030.454706 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X183.291623 Y220.211737 Z2 E3035.014447 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X182.717409 Y219.396416 Z2 E3039.575051 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X182.172447 Y218.56155 Z2 E3044.134545 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X181.649098 Y217.712942 Z2 E3048.694142 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X181.157565 Y216.845264 Z2 E3053.254746 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X180.699082 Y215.959921 Z2 E3057.814365 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X180.263506 Y215.063121 Z2 E3062.373841 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X179.859386 Y214.151443 Z2 E3066.934445 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X179.492009 Y213.224545 Z2 E3071.494213 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X179.148592 Y212.288597 Z2 E3076.053592 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.835779 Y211.341698 Z2 E3080.614196 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.563218 Y210.382589 Z2 E3085.174137 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.31542 Y209.416929 Z2 E3089.733444 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.096925 Y208.443928 Z2 E3094.294048 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.921936 Y207.462274 Z2 E3098.854186 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.772252 Y206.476639 Z2 E3103.413444 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.65018 Y205.486908 Z2 E3107.974049 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.574536 Y204.492604 Z2 E3112.534408 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.524473 Y203.496931 Z2 E3117.093642 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.5 Y202.5 Z2 E3121.654247 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.524473 Y201.503069 Z2 E3126.214851 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.574536 Y200.507396 Z2 E3130.774085 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.65018 Y199.513092 Z2 E3135.334445 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.772252 Y198.523361 Z2 E3139.895049 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X177.921936 Y197.537726 Z2 E3144.454307 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.096925 Y196.556072 Z2 E3149.014445 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.31542 Y195.583071 Z2 E3153.57505 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.563218 Y194.617411 Z2 E3158.134356 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X178.835779 Y193.658302 Z2 E3162.694297 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X179.148592 Y192.711403 Z2 E3167.254902 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X179.492009 Y191.775455 Z2 E3171.814281 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X179.859386 Y190.848557 Z2 E3176.374048 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X180.263506 Y189.936879 Z2 E3180.934653 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X180.699082 Y189.040079 Z2 E3185.494128 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X181.157565 Y188.154736 Z2 E3190.053747 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X181.649098 Y187.287058 Z2 E3194.614352 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X182.172447 Y186.43845 Z2 E3199.173948 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X182.717409 Y185.603584 Z2 E3203.733442 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X183.291623 Y184.788263 Z2 E3208.294047 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X183.897472 Y183.996405 Z2 E3212.853788 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X184.523415 Y183.22043 Z2 E3217.413181 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X185.174779 Y182.465318 Z2 E3221.973786 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X185.857027 Y181.738198 Z2 E3226.533696 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X186.557637 Y181.028935 Z2 E3231.093013 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X187.279879 Y180.341304 Z2 E3235.653617 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X188.031652 Y179.686256 Z2 E3240.213721 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X188.799864 Y179.050854 Z2 E3244.772985 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X189.586028 Y178.437326 Z2 E3249.33359 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X190.399754 Y177.860963 Z2 E3253.89391 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X191.227821 Y177.305826 Z2 E3258.453147 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X192.070336 Y176.77231 Z2 E3263.013751 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X192.937817 Y176.280449 Z2 E3267.574313 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X193.817391 Y175.811173 Z2 E3272.133546 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X194.70896 Y175.364535 Z2 E3276.693944 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X195.620638 Y174.960416 Z2 E3281.254549 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X196.542852 Y174.581734 Z2 E3285.813801 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X197.474679 Y174.226796 Z2 E3290.373974 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X198.421577 Y173.913983 Z2 E3294.934579 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X199.377134 Y173.629712 Z2 E3299.493876 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X200.339821 Y173.370044 Z2 E3304.053848 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X201.312821 Y173.151549 Z2 E3308.614452 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X202.292088 Y172.964559 Z2 E3313.173818 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X203.275928 Y172.80277 Z2 E3317.733612 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X204.265659 Y172.680698 Z2 E3322.294217 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X205.258764 Y172.592876 Z2 E3326.853675 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X206.253837 Y172.530592 Z2 E3331.413317 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X207.250767 Y172.506118 Z2 E3335.973921 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X208.247698 Y172.518355 Z2 E3340.533496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X209.243972 Y172.556196 Z2 E3345.093009 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X210.238501 Y172.629557 Z2 E3349.653613 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X211.229206 Y172.741734 Z2 E3354.213329 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X212.216637 Y172.879314 Z2 E3358.772737 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X213.199186 Y173.049803 Z2 E3363.333342 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X214.173679 Y173.260796 Z2 E3367.893222 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X215.142312 Y173.496725 Z2 E3372.45255 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X216.103419 Y173.762699 Z2 E3377.013155 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X217.051872 Y174.070389 Z2 E3381.573224 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X217.991943 Y174.402284 Z2 E3386.132496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X218.922352 Y174.761183 Z2 E3390.6931 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X219.835201 Y175.162476 Z2 E3395.253383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X220.737233 Y175.58699 Z2 E3399.812622 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X221.627984 Y176.035356 Z2 E3404.373227 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X222.496022 Y176.526215 Z2 E3408.933747 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X223.350921 Y177.039068 Z2 E3413.492979 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X224.192586 Y177.573856 Z2 E3418.053417 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X225.007907 Y178.14807 Z2 E3422.614021 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X225.807054 Y178.74409 Z2 E3427.173269 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X226.590792 Y179.360574 Z2 E3431.733478 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X227.345904 Y180.011938 Z2 E3436.294082 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X228.081242 Y180.685119 Z2 E3440.85337 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X228.799157 Y181.377077 Z2 E3445.413374 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X229.486788 Y182.099318 Z2 E3449.973979 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X230.150903 Y182.842874 Z2 E3454.533331 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X230.795764 Y183.603323 Z2 E3459.093153 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X231.409292 Y184.389487 Z2 E3463.653758 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X231.995484 Y185.195924 Z2 E3468.213199 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X232.560795 Y186.017193 Z2 E3472.772864 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X233.094311 Y186.859707 Z2 E3477.333469 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X233.596668 Y187.720897 Z2 E3481.893022 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X234.076735 Y188.594704 Z2 E3486.452555 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X234.525102 Y189.485454 Z2 E3491.01316 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X234.938554 Y190.392718 Z2 E3495.57285 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X235.328542 Y191.31025 Z2 E3500.132274 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X235.68744 Y192.240659 Z2 E3504.692879 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.007814 Y193.184853 Z2 E3509.25273 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.303795 Y194.136858 Z2 E3513.81207 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.569769 Y195.097965 Z2 E3518.372674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.793827 Y196.069571 Z2 E3522.93271 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X236.992819 Y197.046451 Z2 E3527.49199 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.163308 Y198.029 Z2 E3532.052594 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.288784 Y199.018227 Z2 E3536.61284 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.388783 Y200.010132 Z2 E3541.172083 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.462144 Y201.004661 Z2 E3545.732688 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
G1 X237.487763 Y202.001535 Z2 E3550.293166 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-layer-00000-bottom-and-wall note=weave wall
; CLAYLINE_STROKE_END page=0 layer=0 id=weave-00000-layer-00000-bottom-and-wall
G0 X237.487763 Y202.001535 Z4 F2400 ; clayline kind=travel_lift page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z4 F2400 ; clayline kind=travel_xy page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave paste-safe traverse
G0 X222.487828 Y202.004158 Z2 F2400 ; clayline kind=travel_approach page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=0 id=weave-00001-layer-00000-island-001
G1 X222.487828 Y202.995842 Z2 E3554.828402 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z2 E3559.363875 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z2 E3563.89939 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z2 E3568.434631 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z2 E3572.96997 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z2 E3577.505414 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z2 E3582.04067 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z2 E3586.575919 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z2 E3591.111301 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z2 E3595.646585 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z2 E3600.181786 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z2 E3604.717117 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z2 E3609.252438 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z2 E3613.787633 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z2 E3618.322925 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z2 E3622.858293 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z2 E3627.393526 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z2 E3631.928788 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z2 E3636.464215 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z2 E3640.999528 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z2 E3645.534772 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z2 E3650.070268 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z2 E3654.605704 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z2 E3659.14094 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z2 E3663.676453 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z2 E3668.211988 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z2 E3672.747226 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z2 E3677.282595 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z2 E3681.818056 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z2 E3686.353307 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z2 E3690.888575 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z2 E3695.423971 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z2 E3699.959247 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z2 E3704.494456 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z2 E3709.029799 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z2 E3713.565109 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z2 E3718.100302 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z2 E3722.635602 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z2 E3727.170958 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z2 E3731.706178 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z2 E3736.241446 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z2 E3740.776858 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z2 E3745.312147 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z2 E3749.847394 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z2 E3754.382872 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z2 E3758.918273 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z2 E3763.453509 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X192.5 Y202.5 Z2 E3767.989065 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z2 E3772.524621 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z2 E3777.059857 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z2 E3781.595258 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z2 E3786.130736 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z2 E3790.665984 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z2 E3795.201272 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z2 E3799.736684 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z2 E3804.271952 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z2 E3808.807172 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z2 E3813.342528 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z2 E3817.877828 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z2 E3822.413021 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z2 E3826.948331 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z2 E3831.483674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z2 E3836.018883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z2 E3840.554159 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z2 E3845.089555 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z2 E3849.624823 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z2 E3854.160074 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z2 E3858.695535 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z2 E3863.230904 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z2 E3867.766142 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z2 E3872.301677 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z2 E3876.83719 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z2 E3881.372426 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z2 E3885.907862 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z2 E3890.443358 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z2 E3894.978602 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z2 E3899.513915 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z2 E3904.049342 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z2 E3908.584604 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z2 E3913.119837 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z2 E3917.655205 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z2 E3922.190497 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z2 E3926.725692 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z2 E3931.261013 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z2 E3935.796344 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z2 E3940.331545 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z2 E3944.866829 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z2 E3949.402211 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z2 E3953.93746 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z2 E3958.472716 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z2 E3963.00816 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z2 E3967.543499 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z2 E3972.07874 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z2 E3976.614255 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z2 E3981.149728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00001-layer-00000-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=0 id=weave-00001-layer-00000-island-001
G0 X222.487828 Y202.004158 Z6 F2400 ; clayline kind=travel_lift page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave paste-safe lift
G0 X234.987763 Y202.033654 Z6 F2400 ; clayline kind=travel_xy page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave paste-safe traverse
G0 X234.987763 Y202.033654 Z4 F2400 ; clayline kind=travel_approach page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=1 id=weave-00002-layer-00001-bottom-and-wall
G1 X234.987763 Y202.966346 Z4 E3985.027414 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.964509 Y203.871199 Z4 E3988.790596 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.898026 Y204.772489 Z4 E3992.547907 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.804614 Y205.69905 Z4 E3996.419625 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.690359 Y206.599811 Z4 E4000.194561 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.535854 Y207.490245 Z4 E4003.951871 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.350545 Y208.399952 Z4 E4007.811664 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.145878 Y209.28747 Z4 E4011.598376 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.90484 Y210.158471 Z4 E4015.355685 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.630065 Y211.042268 Z4 E4019.203573 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.336495 Y211.907468 Z4 E4023.002082 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.011244 Y212.750649 Z4 E4026.75939 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X232.650322 Y213.599796 Z4 E4030.595394 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X232.270268 Y214.433771 Z4 E4034.405721 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X231.863937 Y215.241012 Z4 E4038.163029 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X231.421035 Y216.047173 Z4 E4041.98717 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.95781 Y216.84128 Z4 E4045.809336 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.474312 Y217.604806 Z4 E4049.566644 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.954394 Y218.360129 Z4 E4053.378943 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.412174 Y219.106073 Z4 E4057.212968 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.856165 Y219.818532 Z4 E4060.970276 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.264945 Y220.515725 Z4 E4064.770754 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.648732 Y221.20565 Z4 E4068.61666 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.025568 Y221.86018 Z4 E4072.373968 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.36944 Y222.492584 Z4 E4076.162645 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.685019 Y223.119152 Z4 E4080.020452 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.0007 Y223.709449 Z4 E4083.777762 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.286674 Y224.271098 Z4 E4087.55466 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.540557 Y224.827568 Z4 E4091.424388 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.801674 Y225.347948 Z4 E4095.181699 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.037299 Y225.833627 Z4 E4098.946839 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.237486 Y226.313433 Z4 E4102.824524 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.449994 Y226.758745 Z4 E4106.585749 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.642752 Y227.165077 Z4 E4110.343061 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.79971 Y227.561829 Z4 E4114.216768 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.968934 Y227.927042 Z4 E4117.989744 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.125752 Y228.252293 Z4 E4121.747054 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.249871 Y228.561526 Z4 E4125.608833 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X215.383959 Y228.842439 Z4 E4129.393581 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.512957 Y229.083478 Z4 E4133.15089 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.613258 Y229.302616 Z4 E4137.00076 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.720762 Y229.495856 Z4 E4140.797302 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.830329 Y229.650361 Z4 E4144.55461 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.916018 Y229.777753 Z4 E4148.392594 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.005817 Y229.880815 Z4 E4152.20095 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X209.104528 Y229.947298 Z4 E4155.958257 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.184902 Y229.982228 Z4 E4159.784374 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.266107 Y229.993505 Z4 E4163.604566 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.362641 Y229.971326 Z4 E4167.361873 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.446993 Y229.914013 Z4 E4171.176144 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.528861 Y229.832821 Z4 E4175.008192 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.631919 Y229.722194 Z4 E4178.7655 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.729445 Y229.573785 Z4 E4182.567946 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.821281 Y229.400372 Z4 E4186.411871 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.939501 Y229.202362 Z4 E4190.169179 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.059206 Y228.964917 Z4 E4193.959821 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.170274 Y228.700467 Z4 E4197.815643 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.312149 Y228.416981 Z4 E4201.572953 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X197.462759 Y228.093443 Z4 E4205.351812 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.602185 Y227.740072 Z4 E4209.219553 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.775978 Y227.373839 Z4 E4212.976863 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.965854 Y226.968001 Z4 E4216.743961 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.142955 Y226.528964 Z4 E4220.621647 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.356385 Y226.082979 Z4 E4224.380916 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.592857 Y225.599481 Z4 E4228.138228 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.818545 Y225.080382 Z4 E4232.013925 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.07837 Y224.556115 Z4 E4235.784941 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.365911 Y224.000106 Z4 E4239.542251 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.649785 Y223.407785 Z4 E4243.406016 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.963796 Y222.810059 Z4 E4247.188801 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.309266 Y222.186894 Z4 E4250.94611 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.658179 Y221.527766 Z4 E4254.797964 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.033666 Y220.862177 Z4 E4258.592539 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.443369 Y220.177858 Z4 E4262.349847 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.863476 Y219.458972 Z4 E4266.18981 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.307149 Y218.731841 Z4 E4269.996196 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.786769 Y217.992958 Z4 E4273.753503 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.283472 Y217.221921 Z4 E4277.581597 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X183.801393 Y216.440231 Z4 E4281.399814 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X183.355942 Y215.653901 Z4 E4285.157122 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X182.933834 Y214.838799 Z4 E4288.973366 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X182.53135 Y214.010131 Z4 E4292.803436 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X182.165117 Y213.183925 Z4 E4296.560743 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X181.827946 Y212.333239 Z4 E4300.365159 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X181.50963 Y211.465697 Z4 E4304.207103 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X181.226143 Y210.607572 Z4 E4307.964411 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.976779 Y209.730088 Z4 E4311.757019 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.746377 Y208.832221 Z4 E4315.610857 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.548367 Y207.950442 Z4 E4319.368166 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.388774 Y207.055161 Z4 E4323.148988 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.249167 Y206.135879 Z4 E4327.01474 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.13854 Y205.238936 Z4 E4330.772051 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.069769 Y204.334984 Z4 E4334.541107 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.022932 Y203.403467 Z4 E4338.418795 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.000753 Y202.5 Z4 E4342.176108 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.022932 Y201.596533 Z4 E4345.93342 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.069769 Y200.665016 Z4 E4349.811108 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.13854 Y199.761064 Z4 E4353.580164 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.249167 Y198.864121 Z4 E4357.337475 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.388774 Y197.944839 Z4 E4361.203227 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.548367 Y197.049558 Z4 E4364.984049 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.746377 Y196.167779 Z4 E4368.741358 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X180.976779 Y195.269912 Z4 E4372.595196 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X181.226143 Y194.392428 Z4 E4376.387804 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X181.50963 Y193.534303 Z4 E4380.145113 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X181.827946 Y192.666761 Z4 E4383.987056 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X182.165117 Y191.816075 Z4 E4387.791472 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X182.53135 Y190.989869 Z4 E4391.548779 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X182.933834 Y190.161201 Z4 E4395.37885 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X183.355942 Y189.346099 Z4 E4399.195094 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X183.801393 Y188.559769 Z4 E4402.952401 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.283472 Y187.778079 Z4 E4406.770619 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.786769 Y187.007042 Z4 E4410.598712 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.307149 Y186.268159 Z4 E4414.356019 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.863476 Y185.541028 Z4 E4418.162405 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.443369 Y184.822142 Z4 E4422.002368 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.033666 Y184.137823 Z4 E4425.759676 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.658179 Y183.472234 Z4 E4429.554251 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.309266 Y182.813106 Z4 E4433.406105 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.963796 Y182.189941 Z4 E4437.163414 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.649785 Y181.592215 Z4 E4440.946199 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.365911 Y180.999894 Z4 E4444.809964 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.07837 Y180.443885 Z4 E4448.567274 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.818545 Y179.919618 Z4 E4452.33829 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.592857 Y179.400519 Z4 E4456.213987 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.356385 Y178.917021 Z4 E4459.9713 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.142955 Y178.471036 Z4 E4463.730568 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.965854 Y178.031999 Z4 E4467.608254 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.775978 Y177.626161 Z4 E4471.375352 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.602185 Y177.259928 Z4 E4475.132663 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X197.462759 Y176.906557 Z4 E4479.000403 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.312149 Y176.583019 Z4 E4482.779262 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.170274 Y176.299533 Z4 E4486.536572 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.059206 Y176.035083 Z4 E4490.392394 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.939501 Y175.797638 Z4 E4494.183036 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.821281 Y175.599628 Z4 E4497.940345 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.729445 Y175.426215 Z4 E4501.784269 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.631919 Y175.277806 Z4 E4505.586716 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.528861 Y175.167179 Z4 E4509.344023 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.446993 Y175.085987 Z4 E4513.176071 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.362641 Y175.028674 Z4 E4516.990342 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.266107 Y175.006495 Z4 E4520.74765 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.184902 Y175.017772 Z4 E4524.567841 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X209.104528 Y175.052702 Z4 E4528.393958 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.005817 Y175.119185 Z4 E4532.151265 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.916018 Y175.222247 Z4 E4535.959622 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.830329 Y175.349639 Z4 E4539.797605 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.720762 Y175.504144 Z4 E4543.554913 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.613258 Y175.697384 Z4 E4547.351455 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.512957 Y175.916522 Z4 E4551.201326 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X215.383959 Y176.157561 Z4 E4554.958634 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.249871 Y176.438474 Z4 E4558.743383 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.125752 Y176.747707 Z4 E4562.605161 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.968934 Y177.072958 Z4 E4566.362471 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.79971 Y177.438171 Z4 E4570.135447 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.642752 Y177.834923 Z4 E4574.009154 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.449994 Y178.241255 Z4 E4577.766466 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.237486 Y178.686567 Z4 E4581.527691 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.037299 Y179.166373 Z4 E4585.405376 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.801674 Y179.652052 Z4 E4589.170516 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.540557 Y180.172432 Z4 E4592.927827 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.286674 Y180.728902 Z4 E4596.797556 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.0007 Y181.290551 Z4 E4600.574453 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.685019 Y181.880848 Z4 E4604.331763 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.36944 Y182.507416 Z4 E4608.18957 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.025568 Y183.13982 Z4 E4611.978247 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.648732 Y183.79435 Z4 E4615.735556 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.264945 Y184.484275 Z4 E4619.581462 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.856165 Y185.181468 Z4 E4623.381939 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.412174 Y185.893927 Z4 E4627.139247 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.954394 Y186.639871 Z4 E4630.973273 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.474312 Y187.395194 Z4 E4634.785572 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.95781 Y188.15872 Z4 E4638.542879 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X231.421035 Y188.952827 Z4 E4642.365045 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X231.863937 Y189.758988 Z4 E4646.189186 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X232.270268 Y190.566229 Z4 E4649.946494 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X232.650322 Y191.400204 Z4 E4653.756821 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.011244 Y192.249351 Z4 E4657.592825 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.336495 Y193.092532 Z4 E4661.350133 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.630065 Y193.957732 Z4 E4665.148642 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X233.90484 Y194.841529 Z4 E4668.996531 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.145878 Y195.71253 Z4 E4672.753839 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.350545 Y196.600048 Z4 E4676.540552 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.535854 Y197.509755 Z4 E4680.400344 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.690359 Y198.400189 Z4 E4684.157654 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.804614 Y199.30095 Z4 E4687.932591 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.898026 Y200.227511 Z4 E4691.804308 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.964509 Y201.128801 Z4 E4695.56162 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X234.987763 Y202.033654 Z4 E4699.324801 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.987763 Y202.085044 Z4 E4715.956241 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.987763 Y202.914956 Z4 E4719.406614 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.968293 Y203.672574 Z4 E4722.557463 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.912814 Y204.424683 Z4 E4725.692866 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.829943 Y205.246692 Z4 E4729.127706 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.733642 Y206.00591 Z4 E4732.309456 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.60471 Y206.748959 Z4 E4735.444855 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.441295 Y207.551189 Z4 E4738.848637 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.267654 Y208.304165 Z4 E4742.061309 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.066512 Y209.030998 Z4 E4745.196705 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.825667 Y209.805662 Z4 E4748.569447 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.574982 Y210.54447 Z4 E4751.81306 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.303567 Y211.248088 Z4 E4754.948454 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.989152 Y211.987819 Z4 E4758.290176 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.662536 Y212.704533 Z4 E4761.56475 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.323461 Y213.378158 Z4 E4764.700143 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.940022 Y214.076085 Z4 E4768.010862 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.539407 Y214.762859 Z4 E4771.316416 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.135938 Y215.400005 Z4 E4774.451809 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.688651 Y216.049812 Z4 E4777.731545 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.216785 Y216.698969 Z4 E4781.068098 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.752808 Y217.293501 Z4 E4784.203492 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.247414 Y217.889484 Z4 E4787.452264 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.707842 Y218.493599 Z4 E4790.819835 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.187824 Y219.039791 Z4 E4793.95523 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.630557 Y219.576909 Z4 E4797.173058 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.027603 Y220.128896 Z4 E4800.571665 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.456553 Y220.621487 Z4 E4803.707063 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.854067 Y221.0954 Z4 E4806.893966 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.192798 Y221.588587 Z4 E4810.323628 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.576214 Y222.022835 Z4 E4813.45903 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.935504 Y222.429938 Z4 E4816.615028 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.223829 Y222.856871 Z4 E4820.065401 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.565209 Y223.229307 Z4 E4823.211102 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.891581 Y223.568383 Z4 E4826.346505 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.142924 Y223.920716 Z4 E4829.786523 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.443466 Y224.228202 Z4 E4832.963122 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X215.739847 Y224.499617 Z4 E4836.098521 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.966669 Y224.77259 Z4 E4839.507478 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.232822 Y225.01066 Z4 E4842.714995 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.505989 Y225.211802 Z4 E4845.850391 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.716584 Y225.404076 Z4 E4849.228306 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.955284 Y225.568909 Z4 E4852.466761 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.212237 Y225.697841 Z4 E4855.602155 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.414917 Y225.808932 Z4 E4858.949045 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X209.633524 Y225.897409 Z4 E4862.218458 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.881417 Y225.952888 Z4 E4865.353851 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.084428 Y225.983159 Z4 E4868.669736 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.290651 Y225.992903 Z4 E4871.970125 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.536728 Y225.974395 Z4 E4875.105518 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.748161 Y225.925036 Z4 E4878.390417 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.949984 Y225.854452 Z4 E4881.721802 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.201505 Y225.762136 Z4 E4884.857195 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.429215 Y225.635136 Z4 E4888.111127 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.634816 Y225.483445 Z4 E4891.473527 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.898989 Y225.31821 Z4 E4894.608922 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.150521 Y225.116323 Z4 E4897.831905 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.368189 Y224.883586 Z4 E4901.225339 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.652101 Y224.647022 Z4 E4904.360737 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.93461 Y224.373726 Z4 E4907.552792 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.17266 Y224.060852 Z4 E4910.977277 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X197.483207 Y223.755238 Z4 E4914.112678 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.803394 Y223.414681 Z4 E4917.273825 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.071177 Y223.024025 Z4 E4920.724199 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.414063 Y222.651442 Z4 E4923.864752 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.776914 Y222.247971 Z4 E4927.000157 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.08861 Y221.786532 Z4 E4930.445353 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.466119 Y221.345621 Z4 E4933.6168 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.871586 Y220.881642 Z4 E4936.752201 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.238797 Y220.358251 Z4 E4940.166333 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.658065 Y219.852238 Z4 E4943.368695 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.111873 Y219.33222 Z4 E4946.504092 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.540022 Y218.753307 Z4 E4949.887179 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.007885 Y218.18617 Z4 E4953.120476 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.515294 Y217.61512 Z4 E4956.255871 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.009082 Y216.987575 Z4 E4959.607931 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.531992 Y216.364007 Z4 E4962.872182 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.097746 Y215.747426 Z4 E4966.007575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.661111 Y215.078514 Z4 E4969.328627 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.245064 Y214.403895 Z4 E4972.623852 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.873345 Y213.747719 Z4 E4975.759245 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.509437 Y213.045003 Z4 E4979.049306 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.1599 Y212.325348 Z4 E4982.375524 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.854287 Y211.635897 Z4 E4985.510917 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.565446 Y210.907147 Z4 E4988.770009 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.28729 Y210.149059 Z4 E4992.127238 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.050726 Y209.432971 Z4 E4995.262633 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.838475 Y208.686086 Z4 E4998.490773 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.635908 Y207.89669 Z4 E5001.879033 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.470673 Y207.160863 Z4 E5005.01443 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.335715 Y206.403779 Z4 E5008.211639 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.212231 Y205.590662 Z4 E5011.630947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.119914 Y204.842181 Z4 E5014.766348 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.062142 Y204.082792 Z4 E5017.932645 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.020466 Y203.253926 Z4 E5021.38302 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.001958 Y202.5 Z4 E5024.518426 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.020466 Y201.746074 Z4 E5027.653831 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.062142 Y200.917208 Z4 E5031.104206 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.119914 Y200.157819 Z4 E5034.270503 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.212231 Y199.409338 Z4 E5037.405904 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.335715 Y198.596221 Z4 E5040.825213 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.470673 Y197.839137 Z4 E5044.022421 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.635908 Y197.10331 Z4 E5047.157819 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X184.838475 Y196.313914 Z4 E5050.546079 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.050726 Y195.567029 Z4 E5053.774219 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.28729 Y194.850941 Z4 E5056.909613 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.565446 Y194.092853 Z4 E5060.266843 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.854287 Y193.364103 Z4 E5063.525934 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.1599 Y192.674652 Z4 E5066.661328 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.509437 Y191.954997 Z4 E5069.987546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.873345 Y191.252281 Z4 E5073.277607 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.245064 Y190.596105 Z4 E5076.413 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.661111 Y189.921486 Z4 E5079.708225 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.097746 Y189.252574 Z4 E5083.029277 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.531992 Y188.635993 Z4 E5086.16467 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.009082 Y188.012425 Z4 E5089.428921 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.515294 Y187.38488 Z4 E5092.780981 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.007885 Y186.81383 Z4 E5095.916375 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.540022 Y186.246693 Z4 E5099.149673 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.111873 Y185.66778 Z4 E5102.53276 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.658065 Y185.147762 Z4 E5105.668156 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.238797 Y184.641749 Z4 E5108.870519 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.871586 Y184.118358 Z4 E5112.284651 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.466119 Y183.654379 Z4 E5115.420052 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.08861 Y183.213468 Z4 E5118.591499 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.776914 Y182.752029 Z4 E5122.036695 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.414063 Y182.348558 Z4 E5125.1721 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.071177 Y181.975975 Z4 E5128.312653 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.803394 Y181.585319 Z4 E5131.763026 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X197.483207 Y181.244762 Z4 E5134.924173 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.17266 Y180.939148 Z4 E5138.059575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.93461 Y180.626274 Z4 E5141.48406 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.652101 Y180.352978 Z4 E5144.676115 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.368189 Y180.116414 Z4 E5147.811513 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.150521 Y179.883677 Z4 E5151.204947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.898989 Y179.68179 Z4 E5154.42793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.634816 Y179.516555 Z4 E5157.563325 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.429215 Y179.364864 Z4 E5160.925725 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.201505 Y179.237864 Z4 E5164.179657 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.949984 Y179.145548 Z4 E5167.31505 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.748161 Y179.074964 Z4 E5170.646435 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.536728 Y179.025605 Z4 E5173.931334 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.290651 Y179.007097 Z4 E5177.066727 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.084428 Y179.016841 Z4 E5180.367116 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.881417 Y179.047112 Z4 E5183.683001 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X209.633524 Y179.102591 Z4 E5186.818394 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.414917 Y179.191068 Z4 E5190.087807 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.212237 Y179.302159 Z4 E5193.434697 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.955284 Y179.431091 Z4 E5196.570091 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.716584 Y179.595924 Z4 E5199.808546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.505989 Y179.788198 Z4 E5203.186461 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.232822 Y179.98934 Z4 E5206.321857 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.966669 Y180.22741 Z4 E5209.529374 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X215.739847 Y180.500383 Z4 E5212.938331 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.443466 Y180.771798 Z4 E5216.07373 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.142924 Y181.079284 Z4 E5219.250329 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.891581 Y181.431617 Z4 E5222.690346 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.565209 Y181.770693 Z4 E5225.82575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.223829 Y182.143129 Z4 E5228.971451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.935504 Y182.570062 Z4 E5232.421824 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.576214 Y182.977165 Z4 E5235.577822 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.192798 Y183.411413 Z4 E5238.713224 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.854067 Y183.9046 Z4 E5242.142886 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.456553 Y184.378513 Z4 E5245.329788 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.027603 Y184.871104 Z4 E5248.465187 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.630557 Y185.423091 Z4 E5251.863794 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.187824 Y185.960209 Z4 E5255.081622 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.707842 Y186.506401 Z4 E5258.217017 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.247414 Y187.110516 Z4 E5261.584588 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.752808 Y187.706499 Z4 E5264.83336 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.216785 Y188.301031 Z4 E5267.968754 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.688651 Y188.950188 Z4 E5271.305307 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.135938 Y189.599995 Z4 E5274.585043 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.539407 Y190.237141 Z4 E5277.720436 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.940022 Y190.923915 Z4 E5281.02599 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.323461 Y191.621842 Z4 E5284.336709 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.662536 Y192.295467 Z4 E5287.472102 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.989152 Y193.012181 Z4 E5290.746676 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.303567 Y193.751912 Z4 E5294.088398 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.574982 Y194.45553 Z4 E5297.223791 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X229.825667 Y195.194338 Z4 E5300.467405 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.066512 Y195.969002 Z4 E5303.840147 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.267654 Y196.695835 Z4 E5306.975543 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.441295 Y197.448811 Z4 E5310.188215 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.60471 Y198.251041 Z4 E5313.591997 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.733642 Y198.99409 Z4 E5316.727396 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.829943 Y199.753308 Z4 E5319.909146 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.912814 Y200.575317 Z4 E5323.343986 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.968293 Y201.327426 Z4 E5326.479389 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X230.987763 Y202.085044 Z4 E5329.630237 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.987828 Y201.800931 Z4 E5338.028486 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.898222 Y200.369371 Z4 E5343.991869 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.70389 Y198.950741 Z4 E5349.944926 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.428532 Y197.577441 Z4 E5355.768086 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.057122 Y196.192032 Z4 E5361.731339 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.589327 Y194.84402 Z4 E5367.663587 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.047435 Y193.547048 Z4 E5373.507503 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.408948 Y192.262689 Z4 E5379.470668 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.687807 Y191.037262 Z4 E5385.382116 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.898718 Y189.867993 Z4 E5391.2468 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.018462 Y188.735579 Z4 E5397.209917 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.073816 Y187.679566 Z4 E5403.100575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.066698 Y186.684734 Z4 E5408.986036 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.979559 Y185.749141 Z4 E5414.949149 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.849742 Y184.902446 Z4 E5420.819026 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.66252 Y184.122277 Z4 E5426.725275 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.411579 Y183.42058 Z4 E5432.688424 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.141863 Y182.814677 Z4 E5438.537531 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.819793 Y182.281262 Z4 E5444.464579 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.45462 Y181.841276 Z4 E5450.427805 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.095407 Y181.498039 Z4 E5456.256154 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.689353 Y181.234022 Z4 E5462.204007 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X209.264045 Y181.073189 Z4 E5468.167354 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.867617 Y181.00405 Z4 E5473.980139 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.433361 Y181.022205 Z4 E5479.943561 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.005611 Y181.146256 Z4 E5485.901821 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.621607 Y181.353181 Z4 E5491.719795 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.219404 Y181.655092 Z4 E5497.683076 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.848709 Y182.056005 Z4 E5503.620525 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.5277 Y182.532674 Z4 E5509.459252 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.213115 Y183.106366 Z4 E5515.422434 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.952419 Y183.766606 Z4 E5521.339082 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.746627 Y184.496262 Z4 E5527.198572 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.571753 Y185.318993 Z4 E5533.161697 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.469347 Y186.211048 Z4 E5539.057552 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.42685 Y187.166895 Z4 E5544.937818 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.438243 Y188.206058 Z4 E5550.900928 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.535916 Y189.293585 Z4 E5556.775999 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.69873 Y190.439765 Z4 E5562.677051 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.935568 Y191.654181 Z4 E5568.640186 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.267025 Y192.893481 Z4 E5574.494485 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.66941 Y194.186419 Z4 E5580.416332 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.161941 Y195.527965 Z4 E5586.379535 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.751544 Y196.869735 Z4 E5592.213072 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.418612 Y198.259796 Z4 E5598.155724 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.186952 Y199.67531 Z4 E5604.119036 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.048843 Y201.066611 Z4 E5609.931823 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X185.995501 Y202.5 Z4 E5615.895287 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.048843 Y203.933389 Z4 E5621.858751 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.186952 Y205.32469 Z4 E5627.671538 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.418612 Y206.740204 Z4 E5633.634851 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X186.751544 Y208.130265 Z4 E5639.577502 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.161941 Y209.472035 Z4 E5645.411039 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X187.66941 Y210.813581 Z4 E5651.374242 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.267025 Y212.106519 Z4 E5657.296089 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X188.935568 Y213.345819 Z4 E5663.150388 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.69873 Y214.560235 Z4 E5669.113523 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.535916 Y215.706415 Z4 E5675.014575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.438243 Y216.793942 Z4 E5680.889647 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.42685 Y217.833105 Z4 E5686.852756 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.469347 Y218.788952 Z4 E5692.733022 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.571753 Y219.681007 Z4 E5698.628877 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.746627 Y220.503738 Z4 E5704.592002 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.952419 Y221.233394 Z4 E5710.451493 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.213115 Y221.893634 Z4 E5716.36814 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.5277 Y222.467326 Z4 E5722.331323 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X200.848709 Y222.943995 Z4 E5728.170049 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.219404 Y223.344908 Z4 E5734.107498 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.621607 Y223.646819 Z4 E5740.07078 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.005611 Y223.853744 Z4 E5745.888753 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.433361 Y223.977795 Z4 E5751.847013 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.867617 Y223.99595 Z4 E5757.810435 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X209.264045 Y223.926811 Z4 E5763.623221 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.689353 Y223.765978 Z4 E5769.586567 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.095407 Y223.501961 Z4 E5775.534421 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.45462 Y223.158724 Z4 E5781.362769 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.819793 Y222.718738 Z4 E5787.325996 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.141863 Y222.185323 Z4 E5793.253043 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.411579 Y221.57942 Z4 E5799.10215 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.66252 Y220.877723 Z4 E5805.065299 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.849742 Y220.097554 Z4 E5810.971549 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.979559 Y219.250859 Z4 E5816.841426 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.066698 Y218.315266 Z4 E5822.804538 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.073816 Y217.320434 Z4 E5828.69 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.018462 Y216.264421 Z4 E5834.580657 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.898718 Y215.132007 Z4 E5840.543775 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X225.687807 Y213.962738 Z4 E5846.408458 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X226.408948 Y212.737311 Z4 E5852.319907 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.047435 Y211.452952 Z4 E5858.283071 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X227.589327 Y210.15598 Z4 E5864.126987 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.057122 Y208.807968 Z4 E5870.059235 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.428532 Y207.422559 Z4 E5876.022488 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.70389 Y206.049259 Z4 E5881.845649 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.898222 Y204.630629 Z4 E5887.798705 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.987828 Y203.199069 Z4 E5893.762088 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X228.987828 Y201.800931 Z4 E5899.574873 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.987828 Y201.925994 Z4 E5916.213067 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.915239 Y200.766287 Z4 E5921.044003 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.757665 Y199.616003 Z4 E5925.870992 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.531783 Y198.489452 Z4 E5930.647866 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.230905 Y197.367137 Z4 E5935.478678 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.850901 Y196.272106 Z4 E5940.297623 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.407212 Y195.210174 Z4 E5945.08249 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.889977 Y194.169722 Z4 E5949.913217 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.303092 Y193.172434 Z4 E5954.724127 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.658214 Y192.216857 Z4 E5959.516996 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.945125 Y191.299497 Z4 E5964.347678 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.174918 Y190.438488 Z4 E5969.150564 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.353393 Y189.626984 Z4 E5973.951445 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.472708 Y188.869066 Z4 E5978.782123 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.549805 Y188.177435 Z4 E5983.576994 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.583162 Y187.542216 Z4 E5988.385897 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X215.569782 Y186.973776 Z4 E5993.216609 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.530656 Y186.477909 Z4 E5998.003475 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.456205 Y186.044401 Z4 E6002.820411 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.350283 Y185.68797 Z4 E6007.651198 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.235815 Y185.406537 Z4 E6012.430069 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.095206 Y185.192364 Z4 E6017.255046 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.940566 Y185.062073 Z4 E6022.085947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.793958 Y185.005303 Z4 E6026.858829 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.632066 Y185.02001 Z4 E6031.689803 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.474914 Y185.12055 Z4 E6036.518803 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.339047 Y185.290376 Z4 E6041.293682 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.203126 Y185.534953 Z4 E6046.124521 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.09018 Y185.860477 Z4 E6050.945476 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.008058 Y186.250947 Z4 E6055.728343 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.943119 Y186.715692 Z4 E6060.559088 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.917601 Y187.252766 Z4 E6065.372006 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X197.931716 Y187.849352 Z4 E6070.162874 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.979958 Y188.515841 Z4 E6074.993563 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.08154 Y189.242831 Z4 E6079.798454 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.23076 Y190.022896 Z4 E6084.597332 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.429896 Y190.864716 Z4 E6089.428006 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.693165 Y191.752659 Z4 E6094.22488 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.011207 Y192.686317 Z4 E6099.031777 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.392974 Y193.670109 Z4 E6103.862477 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.8461 Y194.683866 Z4 E6108.651343 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.360193 Y195.735126 Z4 E6113.46627 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.949094 Y196.821906 Z4 E6118.297034 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.612754 Y197.921553 Z4 E6123.077903 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.342551 Y199.049706 Z4 E6127.900869 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.154884 Y200.196411 Z4 E6132.731738 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.041482 Y201.338809 Z4 E6137.504621 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X189.998269 Y202.5 Z4 E6142.335634 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.041482 Y203.661191 Z4 E6147.166648 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.154884 Y204.803589 Z4 E6151.93953 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.342551 Y205.950294 Z4 E6156.7704 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.612754 Y207.078447 Z4 E6161.593365 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X190.949094 Y208.178094 Z4 E6166.374234 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.360193 Y209.264874 Z4 E6171.204999 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X191.8461 Y210.316134 Z4 E6176.019925 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X192.392974 Y211.329891 Z4 E6180.808792 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.011207 Y212.313683 Z4 E6185.639491 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X193.693165 Y213.247341 Z4 E6190.446388 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X194.429896 Y214.135284 Z4 E6195.243262 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X195.23076 Y214.977104 Z4 E6200.073937 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.08154 Y215.757169 Z4 E6204.872814 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X196.979958 Y216.484159 Z4 E6209.677705 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X197.931716 Y217.150648 Z4 E6214.508395 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X198.917601 Y217.747234 Z4 E6219.299262 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X199.943119 Y218.284308 Z4 E6224.112181 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X201.008058 Y218.749053 Z4 E6228.942925 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X202.09018 Y219.139523 Z4 E6233.725793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X203.203126 Y219.465047 Z4 E6238.546748 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X204.339047 Y219.709624 Z4 E6243.377587 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X205.474914 Y219.87945 Z4 E6248.152465 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X206.632066 Y219.97999 Z4 E6252.981466 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X207.793958 Y219.994697 Z4 E6257.81244 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X208.940566 Y219.937927 Z4 E6262.585321 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X210.095206 Y219.807636 Z4 E6267.416222 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X211.235815 Y219.593463 Z4 E6272.241199 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X212.350283 Y219.31203 Z4 E6277.020071 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X213.456205 Y218.955599 Z4 E6281.850858 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X214.530656 Y218.522091 Z4 E6286.667793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X215.569782 Y218.026224 Z4 E6291.454659 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X216.583162 Y217.457784 Z4 E6296.285371 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X217.549805 Y216.822565 Z4 E6301.094275 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X218.472708 Y216.130934 Z4 E6305.889146 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X219.353393 Y215.373016 Z4 E6310.719823 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.174918 Y214.561512 Z4 E6315.520704 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X220.945125 Y213.700503 Z4 E6320.32359 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X221.658214 Y212.783143 Z4 E6325.154272 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.303092 Y211.827566 Z4 E6329.947141 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.889977 Y210.830278 Z4 E6334.758052 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.407212 Y209.789826 Z4 E6339.588779 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X223.850901 Y208.727894 Z4 E6344.373645 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.230905 Y207.632863 Z4 E6349.19259 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.531783 Y206.510548 Z4 E6354.023402 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.757665 Y205.383997 Z4 E6358.800277 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.915239 Y204.233713 Z4 E6363.627265 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.987828 Y203.074006 Z4 E6368.458202 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X224.987828 Y201.925994 Z4 E6373.231083 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=bottom 2 of 3 · island 1 of 1
G1 X222.487828 Y202.004158 Z4 E6383.629954 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.487828 Y202.995842 Z4 E6387.752895 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.425874 Y203.98564 Z4 E6391.876052 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.291275 Y204.968209 Z4 E6395.999248 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.096315 Y205.940541 Z4 E6400.122194 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X221.839519 Y206.898422 Z4 E6404.24523 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X221.514385 Y207.83534 Z4 E6408.36836 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X221.132072 Y208.750371 Z4 E6412.491321 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X220.69062 Y209.638382 Z4 E6416.614274 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X220.187644 Y210.493084 Z4 E6420.737349 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X219.632899 Y211.315102 Z4 E6424.860334 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X219.024289 Y212.098055 Z4 E6428.983244 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X218.363106 Y212.837187 Z4 E6433.106272 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X217.657577 Y213.534109 Z4 E6437.229291 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X216.905927 Y214.18098 Z4 E6441.352196 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X216.112345 Y214.775697 Z4 E6445.475188 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X215.283564 Y215.320321 Z4 E6449.598251 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X214.418659 Y215.805476 Z4 E6453.72119 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X213.523651 Y216.23257 Z4 E6457.844155 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X212.603962 Y216.603637 Z4 E6461.967271 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X211.660073 Y216.907847 Z4 E6466.090283 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X210.698571 Y217.150651 Z4 E6470.213231 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X209.723864 Y217.333673 Z4 E6474.33641 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X208.738391 Y217.444874 Z4 E6478.459533 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X207.747921 Y217.493914 Z4 E6482.582475 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X206.756256 Y217.481362 Z4 E6486.705668 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X205.768229 Y217.395516 Z4 E6490.828882 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X204.787447 Y217.248877 Z4 E6494.951826 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X203.817952 Y217.040134 Z4 E6499.074889 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X202.866099 Y216.761727 Z4 E6503.198035 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X201.933282 Y216.425132 Z4 E6507.320991 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X201.024372 Y216.02848 Z4 E6511.443961 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X200.145841 Y215.568383 Z4 E6515.567049 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X199.297396 Y215.054967 Z4 E6519.690027 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X198.485086 Y214.486129 Z4 E6523.812944 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X197.714161 Y213.862305 Z4 E6527.935983 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X196.983203 Y213.192103 Z4 E6532.058992 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X196.299679 Y212.473624 Z4 E6536.181895 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X195.666445 Y211.71042 Z4 E6540.304895 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X195.081505 Y210.909588 Z4 E6544.427946 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X194.553853 Y210.069937 Z4 E6548.550873 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X194.083022 Y209.197143 Z4 E6552.673844 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X193.666932 Y208.296931 Z4 E6556.796946 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X193.316064 Y207.36938 Z4 E6560.919936 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X193.02601 Y206.421061 Z4 E6565.042888 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X192.795013 Y205.456601 Z4 E6569.16605 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X192.634841 Y204.477901 Z4 E6573.289141 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X192.536882 Y203.491068 Z4 E6577.412084 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X192.5 Y202.5 Z4 E6581.535316 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X192.536882 Y201.508932 Z4 E6585.658549 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X192.634841 Y200.522099 Z4 E6589.781491 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X192.795013 Y199.543399 Z4 E6593.904583 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X193.02601 Y198.578939 Z4 E6598.027745 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X193.316064 Y197.63062 Z4 E6602.150697 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X193.666932 Y196.703069 Z4 E6606.273686 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X194.083022 Y195.802857 Z4 E6610.396788 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X194.553853 Y194.930063 Z4 E6614.519759 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X195.081505 Y194.090412 Z4 E6618.642686 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X195.666445 Y193.28958 Z4 E6622.765737 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X196.299679 Y192.526376 Z4 E6626.888737 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X196.983203 Y191.807897 Z4 E6631.01164 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X197.714161 Y191.137695 Z4 E6635.134649 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X198.485086 Y190.513871 Z4 E6639.257688 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X199.297396 Y189.945033 Z4 E6643.380605 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X200.145841 Y189.431617 Z4 E6647.503583 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X201.024372 Y188.97152 Z4 E6651.626671 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X201.933282 Y188.574868 Z4 E6655.749641 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X202.866099 Y188.238273 Z4 E6659.872597 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X203.817952 Y187.959866 Z4 E6663.995743 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X204.787447 Y187.751123 Z4 E6668.118806 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X205.768229 Y187.604484 Z4 E6672.24175 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X206.756256 Y187.518638 Z4 E6676.364964 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X207.747921 Y187.506086 Z4 E6680.488157 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X208.738391 Y187.555126 Z4 E6684.611099 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X209.723864 Y187.666327 Z4 E6688.734222 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X210.698571 Y187.849349 Z4 E6692.857401 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X211.660073 Y188.092153 Z4 E6696.980349 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X212.603962 Y188.396363 Z4 E6701.103361 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X213.523651 Y188.76743 Z4 E6705.226477 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X214.418659 Y189.194524 Z4 E6709.349442 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X215.283564 Y189.679679 Z4 E6713.472381 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X216.112345 Y190.224303 Z4 E6717.595444 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X216.905927 Y190.81902 Z4 E6721.718436 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X217.657577 Y191.465891 Z4 E6725.841341 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X218.363106 Y192.162813 Z4 E6729.96436 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X219.024289 Y192.901945 Z4 E6734.087388 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X219.632899 Y193.684898 Z4 E6738.210298 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X220.187644 Y194.506916 Z4 E6742.333283 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X220.69062 Y195.361618 Z4 E6746.456358 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X221.132072 Y196.249629 Z4 E6750.579311 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X221.514385 Y197.16466 Z4 E6754.702272 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X221.839519 Y198.101578 Z4 E6758.825402 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.096315 Y199.059459 Z4 E6762.948438 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.291275 Y200.031791 Z4 E6767.071384 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.425874 Y201.01436 Z4 E6771.19458 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
G1 X222.487828 Y202.004158 Z4 E6775.317737 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00002-layer-00001-bottom-and-wall note=weave wall
; CLAYLINE_STROKE_END page=0 layer=1 id=weave-00002-layer-00001-bottom-and-wall
G0 X222.487828 Y202.004158 Z6 F2400 ; clayline kind=travel_lift page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave paste-safe lift
G0 X237.487763 Y202.001535 Z6 F2400 ; clayline kind=travel_xy page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave paste-safe traverse
G0 X237.487763 Y202.001535 Z4 F2400 ; clayline kind=travel_approach page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=1 id=weave-00003-layer-00001-island-000
G1 X237.487763 Y202.998465 Z4 E6779.462493 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.462144 Y203.995339 Z4 E6783.608383 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.388783 Y204.989868 Z4 E6787.754387 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.288784 Y205.981773 Z4 E6791.899153 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.163308 Y206.971 Z4 E6796.044831 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.992819 Y207.953549 Z4 E6800.190835 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.793827 Y208.930429 Z4 E6804.335635 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.569769 Y209.902035 Z4 E6808.481122 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.303795 Y210.863142 Z4 E6812.627126 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.007814 Y211.815147 Z4 E6816.771981 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X235.68744 Y212.759341 Z4 E6820.9173 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X235.328542 Y213.68975 Z4 E6825.063304 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X234.938554 Y214.607282 Z4 E6829.208235 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X234.525102 Y215.514546 Z4 E6833.353408 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X234.076735 Y216.405296 Z4 E6837.499412 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X233.596668 Y217.279103 Z4 E6841.644442 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X233.094311 Y218.140293 Z4 E6845.789491 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X232.560795 Y218.982807 Z4 E6849.935495 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X231.995484 Y219.804076 Z4 E6854.080646 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X231.409292 Y220.610513 Z4 E6858.225592 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X230.795764 Y221.396677 Z4 E6862.371596 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X230.150903 Y222.157126 Z4 E6866.516889 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X229.486788 Y222.900682 Z4 E6870.661755 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X228.799157 Y223.622923 Z4 E6874.807759 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X228.081242 Y224.314881 Z4 E6878.953217 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X227.345904 Y224.988062 Z4 E6883.098024 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X226.590792 Y225.639426 Z4 E6887.244028 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X225.807054 Y226.25591 Z4 E6891.389672 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X225.007907 Y226.85193 Z4 E6895.534443 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X224.192586 Y227.426144 Z4 E6899.680447 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X223.350921 Y227.960932 Z4 E6903.8263 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X222.496022 Y228.473785 Z4 E6907.971056 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X221.627984 Y228.964644 Z4 E6912.116983 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X220.737233 Y229.41301 Z4 E6916.262987 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X219.835201 Y229.837524 Z4 E6920.407751 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X218.922352 Y230.238817 Z4 E6924.553462 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X217.991943 Y230.597716 Z4 E6928.699466 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X217.051872 Y230.929611 Z4 E6932.844259 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X216.103419 Y231.237301 Z4 E6936.989776 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X215.142312 Y231.503275 Z4 E6941.135781 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X214.173679 Y231.739204 Z4 E6945.280624 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X213.199186 Y231.950197 Z4 E6949.42597 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X212.216637 Y232.120686 Z4 E6953.571974 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X211.229206 Y232.258266 Z4 E6957.716891 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X210.238501 Y232.370443 Z4 E6961.862087 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X209.243972 Y232.443804 Z4 E6966.008091 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X208.247698 Y232.481645 Z4 E6970.153103 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X207.250767 Y232.493882 Z4 E6974.29817 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X206.253837 Y232.469408 Z4 E6978.444175 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X205.258764 Y232.407124 Z4 E6982.589304 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X204.265659 Y232.319302 Z4 E6986.734265 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X203.275928 Y232.19723 Z4 E6990.880269 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X202.292088 Y232.035441 Z4 E6995.025537 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X201.312821 Y231.848451 Z4 E6999.170415 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X200.339821 Y231.629956 Z4 E7003.316419 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X199.377134 Y231.370288 Z4 E7007.461848 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X198.421577 Y231.086017 Z4 E7011.606663 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X197.474679 Y230.773204 Z4 E7015.752667 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X196.542852 Y230.418266 Z4 E7019.898279 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X195.620638 Y230.039584 Z4 E7024.043054 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X194.70896 Y229.635465 Z4 E7028.189059 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X193.817391 Y229.188827 Z4 E7032.334875 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X192.937817 Y228.719551 Z4 E7036.479632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X192.070336 Y228.22769 Z4 E7040.625597 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X191.227821 Y227.694174 Z4 E7044.771602 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X190.399754 Y227.139037 Z4 E7048.916362 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X189.586028 Y226.562674 Z4 E7053.062108 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X188.799864 Y225.949146 Z4 E7057.208112 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X188.031652 Y225.313744 Z4 E7061.352898 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X187.279879 Y224.658696 Z4 E7065.498447 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X186.557637 Y223.971065 Z4 E7069.644451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X185.857027 Y223.261802 Z4 E7073.789284 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X185.174779 Y222.534682 Z4 E7077.934657 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X184.523415 Y221.77957 Z4 E7082.080661 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X183.897472 Y221.003595 Z4 E7086.225564 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X183.291623 Y220.211737 Z4 E7090.370784 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X182.717409 Y219.396416 Z4 E7094.516788 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X182.172447 Y218.56155 Z4 E7098.661782 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X181.649098 Y217.712942 Z4 E7102.80687 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X181.157565 Y216.845264 Z4 E7106.952874 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X180.699082 Y215.959921 Z4 E7111.097982 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X180.263506 Y215.063121 Z4 E7115.24296 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X179.859386 Y214.151443 Z4 E7119.388964 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X179.492009 Y213.224545 Z4 E7123.534207 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X179.148592 Y212.288597 Z4 E7127.679097 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.835779 Y211.341698 Z4 E7131.825101 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.563218 Y210.382589 Z4 E7135.970502 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.31542 Y209.416929 Z4 E7140.115326 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.096925 Y208.443928 Z4 E7144.26133 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.921936 Y207.462274 Z4 E7148.40691 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.772252 Y206.476639 Z4 E7152.55169 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.65018 Y205.486908 Z4 E7156.697695 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.574536 Y204.492604 Z4 E7160.843476 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.524473 Y203.496931 Z4 E7164.988234 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.5 Y202.5 Z4 E7169.134238 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.524473 Y201.503069 Z4 E7173.280242 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.574536 Y200.507396 Z4 E7177.425001 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.65018 Y199.513092 Z4 E7181.570782 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.772252 Y198.523361 Z4 E7185.716786 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X177.921936 Y197.537726 Z4 E7189.861566 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.096925 Y196.556072 Z4 E7194.007146 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.31542 Y195.583071 Z4 E7198.15315 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.563218 Y194.617411 Z4 E7202.297974 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X178.835779 Y193.658302 Z4 E7206.443375 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X179.148592 Y192.711403 Z4 E7210.589379 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X179.492009 Y191.775455 Z4 E7214.734269 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X179.859386 Y190.848557 Z4 E7218.879512 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X180.263506 Y189.936879 Z4 E7223.025516 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X180.699082 Y189.040079 Z4 E7227.170494 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X181.157565 Y188.154736 Z4 E7231.315602 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X181.649098 Y187.287058 Z4 E7235.461606 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X182.172447 Y186.43845 Z4 E7239.606694 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X182.717409 Y185.603584 Z4 E7243.751688 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X183.291623 Y184.788263 Z4 E7247.897693 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X183.897472 Y183.996405 Z4 E7252.042912 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X184.523415 Y183.22043 Z4 E7256.187815 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X185.174779 Y182.465318 Z4 E7260.333819 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X185.857027 Y181.738198 Z4 E7264.479192 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X186.557637 Y181.028935 Z4 E7268.624025 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X187.279879 Y180.341304 Z4 E7272.77003 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X188.031652 Y179.686256 Z4 E7276.915578 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X188.799864 Y179.050854 Z4 E7281.060364 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X189.586028 Y178.437326 Z4 E7285.206368 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X190.399754 Y177.860963 Z4 E7289.352114 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X191.227821 Y177.305826 Z4 E7293.496875 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X192.070336 Y176.77231 Z4 E7297.642879 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X192.937817 Y176.280449 Z4 E7301.788844 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X193.817391 Y175.811173 Z4 E7305.933601 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X194.70896 Y175.364535 Z4 E7310.079418 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X195.620638 Y174.960416 Z4 E7314.225422 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X196.542852 Y174.581734 Z4 E7318.370197 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X197.474679 Y174.226796 Z4 E7322.515809 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X198.421577 Y173.913983 Z4 E7326.661813 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X199.377134 Y173.629712 Z4 E7330.806628 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X200.339821 Y173.370044 Z4 E7334.952057 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X201.312821 Y173.151549 Z4 E7339.098061 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X202.292088 Y172.964559 Z4 E7343.242939 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X203.275928 Y172.80277 Z4 E7347.388207 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X204.265659 Y172.680698 Z4 E7351.534211 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X205.258764 Y172.592876 Z4 E7355.679173 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X206.253837 Y172.530592 Z4 E7359.824302 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X207.250767 Y172.506118 Z4 E7363.970306 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X208.247698 Y172.518355 Z4 E7368.115374 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X209.243972 Y172.556196 Z4 E7372.260385 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X210.238501 Y172.629557 Z4 E7376.40639 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X211.229206 Y172.741734 Z4 E7380.551585 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X212.216637 Y172.879314 Z4 E7384.696502 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X213.199186 Y173.049803 Z4 E7388.842506 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X214.173679 Y173.260796 Z4 E7392.987852 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X215.142312 Y173.496725 Z4 E7397.132696 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X216.103419 Y173.762699 Z4 E7401.2787 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X217.051872 Y174.070389 Z4 E7405.424218 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X217.991943 Y174.402284 Z4 E7409.56901 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X218.922352 Y174.761183 Z4 E7413.715014 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X219.835201 Y175.162476 Z4 E7417.860726 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X220.737233 Y175.58699 Z4 E7422.005489 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X221.627984 Y176.035356 Z4 E7426.151493 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X222.496022 Y176.526215 Z4 E7430.29742 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X223.350921 Y177.039068 Z4 E7434.442176 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X224.192586 Y177.573856 Z4 E7438.588029 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X225.007907 Y178.14807 Z4 E7442.734033 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X225.807054 Y178.74409 Z4 E7446.878804 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X226.590792 Y179.360574 Z4 E7451.024448 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X227.345904 Y180.011938 Z4 E7455.170452 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X228.081242 Y180.685119 Z4 E7459.31526 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X228.799157 Y181.377077 Z4 E7463.460717 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X229.486788 Y182.099318 Z4 E7467.606722 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X230.150903 Y182.842874 Z4 E7471.751587 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X230.795764 Y183.603323 Z4 E7475.89688 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X231.409292 Y184.389487 Z4 E7480.042885 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X231.995484 Y185.195924 Z4 E7484.187831 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X232.560795 Y186.017193 Z4 E7488.332981 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X233.094311 Y186.859707 Z4 E7492.478986 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X233.596668 Y187.720897 Z4 E7496.624034 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X234.076735 Y188.594704 Z4 E7500.769064 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X234.525102 Y189.485454 Z4 E7504.915068 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X234.938554 Y190.392718 Z4 E7509.060241 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X235.328542 Y191.31025 Z4 E7513.205172 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X235.68744 Y192.240659 Z4 E7517.351176 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.007814 Y193.184853 Z4 E7521.496496 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.303795 Y194.136858 Z4 E7525.64135 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.569769 Y195.097965 Z4 E7529.787354 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.793827 Y196.069571 Z4 E7533.932842 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X236.992819 Y197.046451 Z4 E7538.077641 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.163308 Y198.029 Z4 E7542.223645 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.288784 Y199.018227 Z4 E7546.369323 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.388783 Y200.010132 Z4 E7550.514089 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.462144 Y201.004661 Z4 E7554.660093 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
G1 X237.487763 Y202.001535 Z4 E7558.805983 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00003-layer-00001-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=1 id=weave-00003-layer-00001-island-000
G0 X237.487763 Y202.001535 Z8 F2400 ; clayline kind=travel_lift page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave paste-safe lift
G0 X234.987763 Y202.033654 Z8 F2400 ; clayline kind=travel_xy page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave paste-safe traverse
G0 X234.987763 Y202.033654 Z6 F2400 ; clayline kind=travel_approach page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=2 id=weave-00004-layer-00002-bottom-and-wall
G1 X234.987763 Y202.966346 Z6 E7562.683669 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.964509 Y203.871199 Z6 E7566.44685 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.898026 Y204.772489 Z6 E7570.204162 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.804614 Y205.69905 Z6 E7574.075879 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.690359 Y206.599811 Z6 E7577.850816 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.535854 Y207.490245 Z6 E7581.608126 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.350545 Y208.399952 Z6 E7585.467918 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.145878 Y209.28747 Z6 E7589.254631 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.90484 Y210.158471 Z6 E7593.011939 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.630065 Y211.042268 Z6 E7596.859828 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.336495 Y211.907468 Z6 E7600.658337 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.011244 Y212.750649 Z6 E7604.415645 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X232.650322 Y213.599796 Z6 E7608.251649 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X232.270268 Y214.433771 Z6 E7612.061976 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X231.863937 Y215.241012 Z6 E7615.819284 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X231.421035 Y216.047173 Z6 E7619.643425 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.95781 Y216.84128 Z6 E7623.465591 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.474312 Y217.604806 Z6 E7627.222899 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.954394 Y218.360129 Z6 E7631.035197 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.412174 Y219.106073 Z6 E7634.869223 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.856165 Y219.818532 Z6 E7638.626531 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.264945 Y220.515725 Z6 E7642.427008 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.648732 Y221.20565 Z6 E7646.272914 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.025568 Y221.86018 Z6 E7650.030223 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.36944 Y222.492584 Z6 E7653.8189 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.685019 Y223.119152 Z6 E7657.676707 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.0007 Y223.709449 Z6 E7661.434017 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.286674 Y224.271098 Z6 E7665.210914 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.540557 Y224.827568 Z6 E7669.080643 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.801674 Y225.347948 Z6 E7672.837954 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.037299 Y225.833627 Z6 E7676.603094 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.237486 Y226.313433 Z6 E7680.480779 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.449994 Y226.758745 Z6 E7684.242004 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.642752 Y227.165077 Z6 E7687.999316 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.79971 Y227.561829 Z6 E7691.873023 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.968934 Y227.927042 Z6 E7695.645999 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.125752 Y228.252293 Z6 E7699.403309 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.249871 Y228.561526 Z6 E7703.265087 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X215.383959 Y228.842439 Z6 E7707.049836 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.512957 Y229.083478 Z6 E7710.807145 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.613258 Y229.302616 Z6 E7714.657015 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.720762 Y229.495856 Z6 E7718.453557 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.830329 Y229.650361 Z6 E7722.210865 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.916018 Y229.777753 Z6 E7726.048849 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.005817 Y229.880815 Z6 E7729.857205 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X209.104528 Y229.947298 Z6 E7733.614512 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.184902 Y229.982228 Z6 E7737.440629 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.266107 Y229.993505 Z6 E7741.260821 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.362641 Y229.971326 Z6 E7745.018128 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.446993 Y229.914013 Z6 E7748.832399 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.528861 Y229.832821 Z6 E7752.664447 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.631919 Y229.722194 Z6 E7756.421755 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.729445 Y229.573785 Z6 E7760.224201 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.821281 Y229.400372 Z6 E7764.068125 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.939501 Y229.202362 Z6 E7767.825434 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.059206 Y228.964917 Z6 E7771.616076 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.170274 Y228.700467 Z6 E7775.471898 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.312149 Y228.416981 Z6 E7779.229208 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X197.462759 Y228.093443 Z6 E7783.008067 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.602185 Y227.740072 Z6 E7786.875807 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.775978 Y227.373839 Z6 E7790.633118 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.965854 Y226.968001 Z6 E7794.400216 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.142955 Y226.528964 Z6 E7798.277902 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.356385 Y226.082979 Z6 E7802.037171 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.592857 Y225.599481 Z6 E7805.794483 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.818545 Y225.080382 Z6 E7809.67018 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.07837 Y224.556115 Z6 E7813.441196 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.365911 Y224.000106 Z6 E7817.198506 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.649785 Y223.407785 Z6 E7821.062271 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.963796 Y222.810059 Z6 E7824.845056 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.309266 Y222.186894 Z6 E7828.602365 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.658179 Y221.527766 Z6 E7832.454219 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.033666 Y220.862177 Z6 E7836.248794 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.443369 Y220.177858 Z6 E7840.006102 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.863476 Y219.458972 Z6 E7843.846065 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.307149 Y218.731841 Z6 E7847.652451 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.786769 Y217.992958 Z6 E7851.409758 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.283472 Y217.221921 Z6 E7855.237852 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X183.801393 Y216.440231 Z6 E7859.056069 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X183.355942 Y215.653901 Z6 E7862.813376 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X182.933834 Y214.838799 Z6 E7866.62962 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X182.53135 Y214.010131 Z6 E7870.459691 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X182.165117 Y213.183925 Z6 E7874.216998 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X181.827946 Y212.333239 Z6 E7878.021414 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X181.50963 Y211.465697 Z6 E7881.863358 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X181.226143 Y210.607572 Z6 E7885.620666 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.976779 Y209.730088 Z6 E7889.413274 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.746377 Y208.832221 Z6 E7893.267112 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.548367 Y207.950442 Z6 E7897.024421 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.388774 Y207.055161 Z6 E7900.805243 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.249167 Y206.135879 Z6 E7904.670995 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.13854 Y205.238936 Z6 E7908.428306 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.069769 Y204.334984 Z6 E7912.197362 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.022932 Y203.403467 Z6 E7916.07505 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.000753 Y202.5 Z6 E7919.832362 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.022932 Y201.596533 Z6 E7923.589675 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.069769 Y200.665016 Z6 E7927.467363 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.13854 Y199.761064 Z6 E7931.236419 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.249167 Y198.864121 Z6 E7934.99373 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.388774 Y197.944839 Z6 E7938.859482 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.548367 Y197.049558 Z6 E7942.640304 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.746377 Y196.167779 Z6 E7946.397613 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X180.976779 Y195.269912 Z6 E7950.251451 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X181.226143 Y194.392428 Z6 E7954.044059 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X181.50963 Y193.534303 Z6 E7957.801367 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X181.827946 Y192.666761 Z6 E7961.643311 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X182.165117 Y191.816075 Z6 E7965.447727 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X182.53135 Y190.989869 Z6 E7969.205034 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X182.933834 Y190.161201 Z6 E7973.035105 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X183.355942 Y189.346099 Z6 E7976.851349 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X183.801393 Y188.559769 Z6 E7980.608656 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.283472 Y187.778079 Z6 E7984.426873 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.786769 Y187.007042 Z6 E7988.254967 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.307149 Y186.268159 Z6 E7992.012274 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.863476 Y185.541028 Z6 E7995.81866 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.443369 Y184.822142 Z6 E7999.658623 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.033666 Y184.137823 Z6 E8003.415931 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.658179 Y183.472234 Z6 E8007.210506 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.309266 Y182.813106 Z6 E8011.06236 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.963796 Y182.189941 Z6 E8014.819669 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.649785 Y181.592215 Z6 E8018.602454 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.365911 Y180.999894 Z6 E8022.466219 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.07837 Y180.443885 Z6 E8026.223529 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.818545 Y179.919618 Z6 E8029.994545 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.592857 Y179.400519 Z6 E8033.870242 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.356385 Y178.917021 Z6 E8037.627554 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.142955 Y178.471036 Z6 E8041.386823 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.965854 Y178.031999 Z6 E8045.264509 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.775978 Y177.626161 Z6 E8049.031607 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.602185 Y177.259928 Z6 E8052.788918 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X197.462759 Y176.906557 Z6 E8056.656658 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.312149 Y176.583019 Z6 E8060.435517 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.170274 Y176.299533 Z6 E8064.192827 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.059206 Y176.035083 Z6 E8068.048649 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.939501 Y175.797638 Z6 E8071.839291 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.821281 Y175.599628 Z6 E8075.5966 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.729445 Y175.426215 Z6 E8079.440524 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.631919 Y175.277806 Z6 E8083.24297 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.528861 Y175.167179 Z6 E8087.000278 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.446993 Y175.085987 Z6 E8090.832326 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.362641 Y175.028674 Z6 E8094.646597 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.266107 Y175.006495 Z6 E8098.403904 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.184902 Y175.017772 Z6 E8102.224096 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X209.104528 Y175.052702 Z6 E8106.050213 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.005817 Y175.119185 Z6 E8109.80752 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.916018 Y175.222247 Z6 E8113.615876 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.830329 Y175.349639 Z6 E8117.45386 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.720762 Y175.504144 Z6 E8121.211168 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.613258 Y175.697384 Z6 E8125.00771 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.512957 Y175.916522 Z6 E8128.85758 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X215.383959 Y176.157561 Z6 E8132.614889 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.249871 Y176.438474 Z6 E8136.399637 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.125752 Y176.747707 Z6 E8140.261416 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.968934 Y177.072958 Z6 E8144.018726 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.79971 Y177.438171 Z6 E8147.791702 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.642752 Y177.834923 Z6 E8151.665409 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.449994 Y178.241255 Z6 E8155.422721 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.237486 Y178.686567 Z6 E8159.183946 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.037299 Y179.166373 Z6 E8163.061631 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.801674 Y179.652052 Z6 E8166.826771 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.540557 Y180.172432 Z6 E8170.584082 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.286674 Y180.728902 Z6 E8174.453811 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.0007 Y181.290551 Z6 E8178.230708 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.685019 Y181.880848 Z6 E8181.988018 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.36944 Y182.507416 Z6 E8185.845825 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.025568 Y183.13982 Z6 E8189.634502 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.648732 Y183.79435 Z6 E8193.39181 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.264945 Y184.484275 Z6 E8197.237717 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.856165 Y185.181468 Z6 E8201.038194 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.412174 Y185.893927 Z6 E8204.795502 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.954394 Y186.639871 Z6 E8208.629528 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.474312 Y187.395194 Z6 E8212.441826 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.95781 Y188.15872 Z6 E8216.199134 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X231.421035 Y188.952827 Z6 E8220.0213 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X231.863937 Y189.758988 Z6 E8223.845441 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X232.270268 Y190.566229 Z6 E8227.602749 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X232.650322 Y191.400204 Z6 E8231.413076 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.011244 Y192.249351 Z6 E8235.24908 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.336495 Y193.092532 Z6 E8239.006388 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.630065 Y193.957732 Z6 E8242.804897 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X233.90484 Y194.841529 Z6 E8246.652786 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.145878 Y195.71253 Z6 E8250.410094 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.350545 Y196.600048 Z6 E8254.196807 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.535854 Y197.509755 Z6 E8258.056599 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.690359 Y198.400189 Z6 E8261.813909 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.804614 Y199.30095 Z6 E8265.588845 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.898026 Y200.227511 Z6 E8269.460563 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.964509 Y201.128801 Z6 E8273.217875 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X234.987763 Y202.033654 Z6 E8276.981056 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.987763 Y202.085044 Z6 E8293.612496 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.987763 Y202.914956 Z6 E8297.062869 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.968293 Y203.672574 Z6 E8300.213718 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.912814 Y204.424683 Z6 E8303.349121 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.829943 Y205.246692 Z6 E8306.783961 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.733642 Y206.00591 Z6 E8309.965711 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.60471 Y206.748959 Z6 E8313.10111 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.441295 Y207.551189 Z6 E8316.504892 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.267654 Y208.304165 Z6 E8319.717564 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.066512 Y209.030998 Z6 E8322.85296 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.825667 Y209.805662 Z6 E8326.225702 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.574982 Y210.54447 Z6 E8329.469315 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.303567 Y211.248088 Z6 E8332.604709 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.989152 Y211.987819 Z6 E8335.946431 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.662536 Y212.704533 Z6 E8339.221005 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.323461 Y213.378158 Z6 E8342.356397 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.940022 Y214.076085 Z6 E8345.667117 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.539407 Y214.762859 Z6 E8348.972671 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.135938 Y215.400005 Z6 E8352.108064 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.688651 Y216.049812 Z6 E8355.3878 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.216785 Y216.698969 Z6 E8358.724353 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.752808 Y217.293501 Z6 E8361.859747 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.247414 Y217.889484 Z6 E8365.108519 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.707842 Y218.493599 Z6 E8368.47609 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.187824 Y219.039791 Z6 E8371.611485 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.630557 Y219.576909 Z6 E8374.829313 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.027603 Y220.128896 Z6 E8378.22792 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.456553 Y220.621487 Z6 E8381.363318 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.854067 Y221.0954 Z6 E8384.550221 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.192798 Y221.588587 Z6 E8387.979883 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.576214 Y222.022835 Z6 E8391.115285 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.935504 Y222.429938 Z6 E8394.271283 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.223829 Y222.856871 Z6 E8397.721656 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.565209 Y223.229307 Z6 E8400.867356 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.891581 Y223.568383 Z6 E8404.00276 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.142924 Y223.920716 Z6 E8407.442778 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.443466 Y224.228202 Z6 E8410.619376 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X215.739847 Y224.499617 Z6 E8413.754776 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.966669 Y224.77259 Z6 E8417.163733 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.232822 Y225.01066 Z6 E8420.37125 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.505989 Y225.211802 Z6 E8423.506646 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.716584 Y225.404076 Z6 E8426.884561 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.955284 Y225.568909 Z6 E8430.123016 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.212237 Y225.697841 Z6 E8433.25841 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.414917 Y225.808932 Z6 E8436.6053 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X209.633524 Y225.897409 Z6 E8439.874713 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.881417 Y225.952888 Z6 E8443.010106 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.084428 Y225.983159 Z6 E8446.325991 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.290651 Y225.992903 Z6 E8449.62638 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.536728 Y225.974395 Z6 E8452.761773 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.748161 Y225.925036 Z6 E8456.046671 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.949984 Y225.854452 Z6 E8459.378057 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.201505 Y225.762136 Z6 E8462.51345 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.429215 Y225.635136 Z6 E8465.767382 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.634816 Y225.483445 Z6 E8469.129782 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.898989 Y225.31821 Z6 E8472.265177 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.150521 Y225.116323 Z6 E8475.48816 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.368189 Y224.883586 Z6 E8478.881594 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.652101 Y224.647022 Z6 E8482.016991 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.93461 Y224.373726 Z6 E8485.209047 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.17266 Y224.060852 Z6 E8488.633532 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X197.483207 Y223.755238 Z6 E8491.768933 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.803394 Y223.414681 Z6 E8494.93008 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.071177 Y223.024025 Z6 E8498.380454 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.414063 Y222.651442 Z6 E8501.521007 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.776914 Y222.247971 Z6 E8504.656412 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.08861 Y221.786532 Z6 E8508.101608 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.466119 Y221.345621 Z6 E8511.273055 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.871586 Y220.881642 Z6 E8514.408455 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.238797 Y220.358251 Z6 E8517.822588 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.658065 Y219.852238 Z6 E8521.02495 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.111873 Y219.33222 Z6 E8524.160347 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.540022 Y218.753307 Z6 E8527.543434 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.007885 Y218.18617 Z6 E8530.776731 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.515294 Y217.61512 Z6 E8533.912126 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.009082 Y216.987575 Z6 E8537.264185 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.531992 Y216.364007 Z6 E8540.528437 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.097746 Y215.747426 Z6 E8543.66383 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.661111 Y215.078514 Z6 E8546.984881 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.245064 Y214.403895 Z6 E8550.280107 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.873345 Y213.747719 Z6 E8553.415499 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.509437 Y213.045003 Z6 E8556.705561 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.1599 Y212.325348 Z6 E8560.031779 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.854287 Y211.635897 Z6 E8563.167172 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.565446 Y210.907147 Z6 E8566.426264 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.28729 Y210.149059 Z6 E8569.783493 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.050726 Y209.432971 Z6 E8572.918888 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.838475 Y208.686086 Z6 E8576.147028 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.635908 Y207.89669 Z6 E8579.535288 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.470673 Y207.160863 Z6 E8582.670685 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.335715 Y206.403779 Z6 E8585.867894 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.212231 Y205.590662 Z6 E8589.287202 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.119914 Y204.842181 Z6 E8592.422603 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.062142 Y204.082792 Z6 E8595.5889 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.020466 Y203.253926 Z6 E8599.039275 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.001958 Y202.5 Z6 E8602.174681 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.020466 Y201.746074 Z6 E8605.310086 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.062142 Y200.917208 Z6 E8608.760461 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.119914 Y200.157819 Z6 E8611.926758 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.212231 Y199.409338 Z6 E8615.062159 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.335715 Y198.596221 Z6 E8618.481468 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.470673 Y197.839137 Z6 E8621.678676 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.635908 Y197.10331 Z6 E8624.814074 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X184.838475 Y196.313914 Z6 E8628.202333 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.050726 Y195.567029 Z6 E8631.430474 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.28729 Y194.850941 Z6 E8634.565868 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.565446 Y194.092853 Z6 E8637.923098 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.854287 Y193.364103 Z6 E8641.182189 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.1599 Y192.674652 Z6 E8644.317582 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.509437 Y191.954997 Z6 E8647.643801 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.873345 Y191.252281 Z6 E8650.933862 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.245064 Y190.596105 Z6 E8654.069255 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.661111 Y189.921486 Z6 E8657.36448 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.097746 Y189.252574 Z6 E8660.685531 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.531992 Y188.635993 Z6 E8663.820924 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.009082 Y188.012425 Z6 E8667.085176 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.515294 Y187.38488 Z6 E8670.437236 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.007885 Y186.81383 Z6 E8673.57263 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.540022 Y186.246693 Z6 E8676.805928 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.111873 Y185.66778 Z6 E8680.189014 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.658065 Y185.147762 Z6 E8683.324411 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.238797 Y184.641749 Z6 E8686.526774 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.871586 Y184.118358 Z6 E8689.940906 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.466119 Y183.654379 Z6 E8693.076306 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.08861 Y183.213468 Z6 E8696.247754 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.776914 Y182.752029 Z6 E8699.69295 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.414063 Y182.348558 Z6 E8702.828355 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.071177 Y181.975975 Z6 E8705.968907 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.803394 Y181.585319 Z6 E8709.419281 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X197.483207 Y181.244762 Z6 E8712.580428 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.17266 Y180.939148 Z6 E8715.71583 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.93461 Y180.626274 Z6 E8719.140315 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.652101 Y180.352978 Z6 E8722.33237 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.368189 Y180.116414 Z6 E8725.467768 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.150521 Y179.883677 Z6 E8728.861201 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.898989 Y179.68179 Z6 E8732.084185 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.634816 Y179.516555 Z6 E8735.21958 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.429215 Y179.364864 Z6 E8738.58198 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.201505 Y179.237864 Z6 E8741.835911 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.949984 Y179.145548 Z6 E8744.971305 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.748161 Y179.074964 Z6 E8748.30269 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.536728 Y179.025605 Z6 E8751.587589 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.290651 Y179.007097 Z6 E8754.722981 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.084428 Y179.016841 Z6 E8758.023371 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.881417 Y179.047112 Z6 E8761.339256 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X209.633524 Y179.102591 Z6 E8764.474649 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.414917 Y179.191068 Z6 E8767.744061 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.212237 Y179.302159 Z6 E8771.090952 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.955284 Y179.431091 Z6 E8774.226346 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.716584 Y179.595924 Z6 E8777.464801 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.505989 Y179.788198 Z6 E8780.842715 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.232822 Y179.98934 Z6 E8783.978112 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.966669 Y180.22741 Z6 E8787.185629 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X215.739847 Y180.500383 Z6 E8790.594586 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.443466 Y180.771798 Z6 E8793.729985 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.142924 Y181.079284 Z6 E8796.906584 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.891581 Y181.431617 Z6 E8800.346601 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.565209 Y181.770693 Z6 E8803.482005 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.223829 Y182.143129 Z6 E8806.627706 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.935504 Y182.570062 Z6 E8810.078079 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.576214 Y182.977165 Z6 E8813.234077 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.192798 Y183.411413 Z6 E8816.369479 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.854067 Y183.9046 Z6 E8819.799141 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.456553 Y184.378513 Z6 E8822.986043 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.027603 Y184.871104 Z6 E8826.121442 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.630557 Y185.423091 Z6 E8829.520049 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.187824 Y185.960209 Z6 E8832.737877 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.707842 Y186.506401 Z6 E8835.873272 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.247414 Y187.110516 Z6 E8839.240843 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.752808 Y187.706499 Z6 E8842.489615 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.216785 Y188.301031 Z6 E8845.625009 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.688651 Y188.950188 Z6 E8848.961562 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.135938 Y189.599995 Z6 E8852.241298 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.539407 Y190.237141 Z6 E8855.376691 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.940022 Y190.923915 Z6 E8858.682245 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.323461 Y191.621842 Z6 E8861.992964 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.662536 Y192.295467 Z6 E8865.128357 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.989152 Y193.012181 Z6 E8868.402931 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.303567 Y193.751912 Z6 E8871.744652 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.574982 Y194.45553 Z6 E8874.880046 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X229.825667 Y195.194338 Z6 E8878.12366 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.066512 Y195.969002 Z6 E8881.496402 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.267654 Y196.695835 Z6 E8884.631798 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.441295 Y197.448811 Z6 E8887.84447 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.60471 Y198.251041 Z6 E8891.248252 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.733642 Y198.99409 Z6 E8894.383651 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.829943 Y199.753308 Z6 E8897.565401 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.912814 Y200.575317 Z6 E8901.00024 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.968293 Y201.327426 Z6 E8904.135644 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X230.987763 Y202.085044 Z6 E8907.286492 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.987828 Y201.800931 Z6 E8915.684741 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.898222 Y200.369371 Z6 E8921.648124 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.70389 Y198.950741 Z6 E8927.601181 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.428532 Y197.577441 Z6 E8933.424341 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.057122 Y196.192032 Z6 E8939.387594 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.589327 Y194.84402 Z6 E8945.319842 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.047435 Y193.547048 Z6 E8951.163758 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.408948 Y192.262689 Z6 E8957.126922 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.687807 Y191.037262 Z6 E8963.038371 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.898718 Y189.867993 Z6 E8968.903054 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.018462 Y188.735579 Z6 E8974.866172 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.073816 Y187.679566 Z6 E8980.75683 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.066698 Y186.684734 Z6 E8986.642291 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.979559 Y185.749141 Z6 E8992.605403 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.849742 Y184.902446 Z6 E8998.475281 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.66252 Y184.122277 Z6 E9004.38153 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.411579 Y183.42058 Z6 E9010.344679 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.141863 Y182.814677 Z6 E9016.193786 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.819793 Y182.281262 Z6 E9022.120833 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.45462 Y181.841276 Z6 E9028.08406 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.095407 Y181.498039 Z6 E9033.912408 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.689353 Y181.234022 Z6 E9039.860262 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X209.264045 Y181.073189 Z6 E9045.823609 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.867617 Y181.00405 Z6 E9051.636394 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.433361 Y181.022205 Z6 E9057.599816 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.005611 Y181.146256 Z6 E9063.558076 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.621607 Y181.353181 Z6 E9069.376049 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.219404 Y181.655092 Z6 E9075.339331 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.848709 Y182.056005 Z6 E9081.27678 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.5277 Y182.532674 Z6 E9087.115507 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.213115 Y183.106366 Z6 E9093.078689 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.952419 Y183.766606 Z6 E9098.995336 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.746627 Y184.496262 Z6 E9104.854827 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.571753 Y185.318993 Z6 E9110.817952 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.469347 Y186.211048 Z6 E9116.713807 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.42685 Y187.166895 Z6 E9122.594073 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.438243 Y188.206058 Z6 E9128.557183 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.535916 Y189.293585 Z6 E9134.432254 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.69873 Y190.439765 Z6 E9140.333306 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.935568 Y191.654181 Z6 E9146.296441 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.267025 Y192.893481 Z6 E9152.15074 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.66941 Y194.186419 Z6 E9158.072587 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.161941 Y195.527965 Z6 E9164.03579 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.751544 Y196.869735 Z6 E9169.869327 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.418612 Y198.259796 Z6 E9175.811979 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.186952 Y199.67531 Z6 E9181.775291 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.048843 Y201.066611 Z6 E9187.588078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X185.995501 Y202.5 Z6 E9193.551542 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.048843 Y203.933389 Z6 E9199.515006 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.186952 Y205.32469 Z6 E9205.327793 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.418612 Y206.740204 Z6 E9211.291105 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X186.751544 Y208.130265 Z6 E9217.233757 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.161941 Y209.472035 Z6 E9223.067294 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X187.66941 Y210.813581 Z6 E9229.030497 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.267025 Y212.106519 Z6 E9234.952344 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X188.935568 Y213.345819 Z6 E9240.806643 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.69873 Y214.560235 Z6 E9246.769778 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.535916 Y215.706415 Z6 E9252.67083 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.438243 Y216.793942 Z6 E9258.545901 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.42685 Y217.833105 Z6 E9264.509011 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.469347 Y218.788952 Z6 E9270.389277 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.571753 Y219.681007 Z6 E9276.285132 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.746627 Y220.503738 Z6 E9282.248257 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.952419 Y221.233394 Z6 E9288.107748 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.213115 Y221.893634 Z6 E9294.024395 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.5277 Y222.467326 Z6 E9299.987577 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X200.848709 Y222.943995 Z6 E9305.826304 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.219404 Y223.344908 Z6 E9311.763753 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.621607 Y223.646819 Z6 E9317.727035 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.005611 Y223.853744 Z6 E9323.545008 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.433361 Y223.977795 Z6 E9329.503268 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.867617 Y223.99595 Z6 E9335.46669 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X209.264045 Y223.926811 Z6 E9341.279475 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.689353 Y223.765978 Z6 E9347.242822 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.095407 Y223.501961 Z6 E9353.190676 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.45462 Y223.158724 Z6 E9359.019024 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.819793 Y222.718738 Z6 E9364.982251 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.141863 Y222.185323 Z6 E9370.909298 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.411579 Y221.57942 Z6 E9376.758405 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.66252 Y220.877723 Z6 E9382.721554 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.849742 Y220.097554 Z6 E9388.627803 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.979559 Y219.250859 Z6 E9394.497681 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.066698 Y218.315266 Z6 E9400.460793 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.073816 Y217.320434 Z6 E9406.346254 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.018462 Y216.264421 Z6 E9412.236912 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.898718 Y215.132007 Z6 E9418.20003 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X225.687807 Y213.962738 Z6 E9424.064713 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X226.408948 Y212.737311 Z6 E9429.976162 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.047435 Y211.452952 Z6 E9435.939326 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X227.589327 Y210.15598 Z6 E9441.783242 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.057122 Y208.807968 Z6 E9447.71549 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.428532 Y207.422559 Z6 E9453.678743 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.70389 Y206.049259 Z6 E9459.501903 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.898222 Y204.630629 Z6 E9465.45496 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.987828 Y203.199069 Z6 E9471.418343 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X228.987828 Y201.800931 Z6 E9477.231128 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.987828 Y201.925994 Z6 E9493.869322 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.915239 Y200.766287 Z6 E9498.700258 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.757665 Y199.616003 Z6 E9503.527247 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.531783 Y198.489452 Z6 E9508.304121 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.230905 Y197.367137 Z6 E9513.134933 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.850901 Y196.272106 Z6 E9517.953878 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.407212 Y195.210174 Z6 E9522.738744 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.889977 Y194.169722 Z6 E9527.569471 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.303092 Y193.172434 Z6 E9532.380382 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.658214 Y192.216857 Z6 E9537.173251 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.945125 Y191.299497 Z6 E9542.003933 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.174918 Y190.438488 Z6 E9546.806819 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.353393 Y189.626984 Z6 E9551.6077 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.472708 Y188.869066 Z6 E9556.438377 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.549805 Y188.177435 Z6 E9561.233248 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.583162 Y187.542216 Z6 E9566.042152 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X215.569782 Y186.973776 Z6 E9570.872864 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.530656 Y186.477909 Z6 E9575.65973 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.456205 Y186.044401 Z6 E9580.476666 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.350283 Y185.68797 Z6 E9585.307453 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.235815 Y185.406537 Z6 E9590.086324 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.095206 Y185.192364 Z6 E9594.911301 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.940566 Y185.062073 Z6 E9599.742202 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.793958 Y185.005303 Z6 E9604.515084 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.632066 Y185.02001 Z6 E9609.346058 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.474914 Y185.12055 Z6 E9614.175058 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.339047 Y185.290376 Z6 E9618.949937 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.203126 Y185.534953 Z6 E9623.780776 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.09018 Y185.860477 Z6 E9628.601731 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.008058 Y186.250947 Z6 E9633.384598 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.943119 Y186.715692 Z6 E9638.215343 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.917601 Y187.252766 Z6 E9643.028261 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X197.931716 Y187.849352 Z6 E9647.819128 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.979958 Y188.515841 Z6 E9652.649818 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.08154 Y189.242831 Z6 E9657.454709 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.23076 Y190.022896 Z6 E9662.253586 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.429896 Y190.864716 Z6 E9667.084261 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.693165 Y191.752659 Z6 E9671.881135 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.011207 Y192.686317 Z6 E9676.688032 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.392974 Y193.670109 Z6 E9681.518731 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.8461 Y194.683866 Z6 E9686.307598 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.360193 Y195.735126 Z6 E9691.122525 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.949094 Y196.821906 Z6 E9695.953289 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.612754 Y197.921553 Z6 E9700.734158 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.342551 Y199.049706 Z6 E9705.557124 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.154884 Y200.196411 Z6 E9710.387993 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.041482 Y201.338809 Z6 E9715.160875 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X189.998269 Y202.5 Z6 E9719.991889 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.041482 Y203.661191 Z6 E9724.822903 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.154884 Y204.803589 Z6 E9729.595785 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.342551 Y205.950294 Z6 E9734.426654 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.612754 Y207.078447 Z6 E9739.24962 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X190.949094 Y208.178094 Z6 E9744.030489 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.360193 Y209.264874 Z6 E9748.861254 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X191.8461 Y210.316134 Z6 E9753.67618 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X192.392974 Y211.329891 Z6 E9758.465047 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.011207 Y212.313683 Z6 E9763.295746 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X193.693165 Y213.247341 Z6 E9768.102643 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X194.429896 Y214.135284 Z6 E9772.899517 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X195.23076 Y214.977104 Z6 E9777.730192 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.08154 Y215.757169 Z6 E9782.529069 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X196.979958 Y216.484159 Z6 E9787.33396 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X197.931716 Y217.150648 Z6 E9792.16465 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X198.917601 Y217.747234 Z6 E9796.955517 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X199.943119 Y218.284308 Z6 E9801.768436 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X201.008058 Y218.749053 Z6 E9806.59918 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X202.09018 Y219.139523 Z6 E9811.382047 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X203.203126 Y219.465047 Z6 E9816.203002 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X204.339047 Y219.709624 Z6 E9821.033842 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X205.474914 Y219.87945 Z6 E9825.80872 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X206.632066 Y219.97999 Z6 E9830.637721 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X207.793958 Y219.994697 Z6 E9835.468694 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X208.940566 Y219.937927 Z6 E9840.241576 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X210.095206 Y219.807636 Z6 E9845.072477 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X211.235815 Y219.593463 Z6 E9849.897454 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X212.350283 Y219.31203 Z6 E9854.676326 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X213.456205 Y218.955599 Z6 E9859.507112 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X214.530656 Y218.522091 Z6 E9864.324048 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X215.569782 Y218.026224 Z6 E9869.110914 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X216.583162 Y217.457784 Z6 E9873.941626 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X217.549805 Y216.822565 Z6 E9878.75053 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X218.472708 Y216.130934 Z6 E9883.545401 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X219.353393 Y215.373016 Z6 E9888.376078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.174918 Y214.561512 Z6 E9893.176959 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X220.945125 Y213.700503 Z6 E9897.979845 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X221.658214 Y212.783143 Z6 E9902.810527 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.303092 Y211.827566 Z6 E9907.603396 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X222.889977 Y210.830278 Z6 E9912.414307 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.407212 Y209.789826 Z6 E9917.245034 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X223.850901 Y208.727894 Z6 E9922.0299 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.230905 Y207.632863 Z6 E9926.848845 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.531783 Y206.510548 Z6 E9931.679657 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.757665 Y205.383997 Z6 E9936.456532 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.915239 Y204.233713 Z6 E9941.28352 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.987828 Y203.074006 Z6 E9946.114456 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X224.987828 Y201.925994 Z6 E9950.887337 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=bottom 3 of 3 · island 1 of 1
G1 X237.487763 Y202.001535 Z6 E10002.85698 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.487763 Y202.998465 Z6 E10007.001735 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.462144 Y203.995339 Z6 E10011.147625 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.388783 Y204.989868 Z6 E10015.293629 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.288784 Y205.981773 Z6 E10019.438396 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.163308 Y206.971 Z6 E10023.584073 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.992819 Y207.953549 Z6 E10027.730078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.793827 Y208.930429 Z6 E10031.874877 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.569769 Y209.902035 Z6 E10036.020364 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.303795 Y210.863142 Z6 E10040.166369 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.007814 Y211.815147 Z6 E10044.311223 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X235.68744 Y212.759341 Z6 E10048.456542 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X235.328542 Y213.68975 Z6 E10052.602546 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X234.938554 Y214.607282 Z6 E10056.747477 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X234.525102 Y215.514546 Z6 E10060.89265 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X234.076735 Y216.405296 Z6 E10065.038655 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X233.596668 Y217.279103 Z6 E10069.183684 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X233.094311 Y218.140293 Z6 E10073.328733 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X232.560795 Y218.982807 Z6 E10077.474737 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X231.995484 Y219.804076 Z6 E10081.619888 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X231.409292 Y220.610513 Z6 E10085.764834 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X230.795764 Y221.396677 Z6 E10089.910838 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X230.150903 Y222.157126 Z6 E10094.056131 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X229.486788 Y222.900682 Z6 E10098.200997 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X228.799157 Y223.622923 Z6 E10102.347001 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X228.081242 Y224.314881 Z6 E10106.492459 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X227.345904 Y224.988062 Z6 E10110.637266 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X226.590792 Y225.639426 Z6 E10114.78327 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X225.807054 Y226.25591 Z6 E10118.928915 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X225.007907 Y226.85193 Z6 E10123.073685 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X224.192586 Y227.426144 Z6 E10127.219689 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X223.350921 Y227.960932 Z6 E10131.365542 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X222.496022 Y228.473785 Z6 E10135.510298 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X221.627984 Y228.964644 Z6 E10139.656225 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X220.737233 Y229.41301 Z6 E10143.80223 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X219.835201 Y229.837524 Z6 E10147.946993 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X218.922352 Y230.238817 Z6 E10152.092704 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X217.991943 Y230.597716 Z6 E10156.238709 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X217.051872 Y230.929611 Z6 E10160.383501 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X216.103419 Y231.237301 Z6 E10164.529019 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X215.142312 Y231.503275 Z6 E10168.675023 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X214.173679 Y231.739204 Z6 E10172.819866 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X213.199186 Y231.950197 Z6 E10176.965212 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X212.216637 Y232.120686 Z6 E10181.111216 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X211.229206 Y232.258266 Z6 E10185.256133 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X210.238501 Y232.370443 Z6 E10189.401329 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X209.243972 Y232.443804 Z6 E10193.547333 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X208.247698 Y232.481645 Z6 E10197.692345 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X207.250767 Y232.493882 Z6 E10201.837413 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X206.253837 Y232.469408 Z6 E10205.983417 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X205.258764 Y232.407124 Z6 E10210.128546 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X204.265659 Y232.319302 Z6 E10214.273507 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X203.275928 Y232.19723 Z6 E10218.419512 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X202.292088 Y232.035441 Z6 E10222.56478 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X201.312821 Y231.848451 Z6 E10226.709657 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X200.339821 Y231.629956 Z6 E10230.855661 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X199.377134 Y231.370288 Z6 E10235.00109 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X198.421577 Y231.086017 Z6 E10239.145905 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X197.474679 Y230.773204 Z6 E10243.29191 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X196.542852 Y230.418266 Z6 E10247.437522 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X195.620638 Y230.039584 Z6 E10251.582297 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X194.70896 Y229.635465 Z6 E10255.728301 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X193.817391 Y229.188827 Z6 E10259.874117 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X192.937817 Y228.719551 Z6 E10264.018874 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X192.070336 Y228.22769 Z6 E10268.16484 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X191.227821 Y227.694174 Z6 E10272.310844 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X190.399754 Y227.139037 Z6 E10276.455604 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X189.586028 Y226.562674 Z6 E10280.60135 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X188.799864 Y225.949146 Z6 E10284.747354 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X188.031652 Y225.313744 Z6 E10288.89214 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X187.279879 Y224.658696 Z6 E10293.037689 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X186.557637 Y223.971065 Z6 E10297.183693 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X185.857027 Y223.261802 Z6 E10301.328527 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X185.174779 Y222.534682 Z6 E10305.473899 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X184.523415 Y221.77957 Z6 E10309.619904 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X183.897472 Y221.003595 Z6 E10313.764807 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X183.291623 Y220.211737 Z6 E10317.910026 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X182.717409 Y219.396416 Z6 E10322.05603 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X182.172447 Y218.56155 Z6 E10326.201025 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X181.649098 Y217.712942 Z6 E10330.346112 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X181.157565 Y216.845264 Z6 E10334.492116 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X180.699082 Y215.959921 Z6 E10338.637224 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X180.263506 Y215.063121 Z6 E10342.782202 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X179.859386 Y214.151443 Z6 E10346.928206 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X179.492009 Y213.224545 Z6 E10351.07345 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X179.148592 Y212.288597 Z6 E10355.21834 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.835779 Y211.341698 Z6 E10359.364344 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.563218 Y210.382589 Z6 E10363.509744 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.31542 Y209.416929 Z6 E10367.654568 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.096925 Y208.443928 Z6 E10371.800573 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.921936 Y207.462274 Z6 E10375.946152 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.772252 Y206.476639 Z6 E10380.090933 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.65018 Y205.486908 Z6 E10384.236937 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.574536 Y204.492604 Z6 E10388.382718 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.524473 Y203.496931 Z6 E10392.527476 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.5 Y202.5 Z6 E10396.67348 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.524473 Y201.503069 Z6 E10400.819485 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.574536 Y200.507396 Z6 E10404.964243 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.65018 Y199.513092 Z6 E10409.110024 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.772252 Y198.523361 Z6 E10413.256028 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X177.921936 Y197.537726 Z6 E10417.400808 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.096925 Y196.556072 Z6 E10421.546388 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.31542 Y195.583071 Z6 E10425.692392 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.563218 Y194.617411 Z6 E10429.837216 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X178.835779 Y193.658302 Z6 E10433.982617 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X179.148592 Y192.711403 Z6 E10438.128621 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X179.492009 Y191.775455 Z6 E10442.273511 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X179.859386 Y190.848557 Z6 E10446.418754 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X180.263506 Y189.936879 Z6 E10450.564759 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X180.699082 Y189.040079 Z6 E10454.709736 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X181.157565 Y188.154736 Z6 E10458.854844 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X181.649098 Y187.287058 Z6 E10463.000849 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X182.172447 Y186.43845 Z6 E10467.145936 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X182.717409 Y185.603584 Z6 E10471.290931 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X183.291623 Y184.788263 Z6 E10475.436935 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X183.897472 Y183.996405 Z6 E10479.582154 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X184.523415 Y183.22043 Z6 E10483.727057 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X185.174779 Y182.465318 Z6 E10487.873061 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X185.857027 Y181.738198 Z6 E10492.018434 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X186.557637 Y181.028935 Z6 E10496.163268 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X187.279879 Y180.341304 Z6 E10500.309272 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X188.031652 Y179.686256 Z6 E10504.45482 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X188.799864 Y179.050854 Z6 E10508.599606 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X189.586028 Y178.437326 Z6 E10512.74561 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X190.399754 Y177.860963 Z6 E10516.891356 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X191.227821 Y177.305826 Z6 E10521.036117 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X192.070336 Y176.77231 Z6 E10525.182121 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X192.937817 Y176.280449 Z6 E10529.328087 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X193.817391 Y175.811173 Z6 E10533.472843 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X194.70896 Y175.364535 Z6 E10537.61866 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X195.620638 Y174.960416 Z6 E10541.764664 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X196.542852 Y174.581734 Z6 E10545.909439 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X197.474679 Y174.226796 Z6 E10550.055051 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X198.421577 Y173.913983 Z6 E10554.201055 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X199.377134 Y173.629712 Z6 E10558.34587 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X200.339821 Y173.370044 Z6 E10562.491299 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X201.312821 Y173.151549 Z6 E10566.637304 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X202.292088 Y172.964559 Z6 E10570.782181 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X203.275928 Y172.80277 Z6 E10574.927449 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X204.265659 Y172.680698 Z6 E10579.073453 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X205.258764 Y172.592876 Z6 E10583.218415 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X206.253837 Y172.530592 Z6 E10587.363544 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X207.250767 Y172.506118 Z6 E10591.509548 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X208.247698 Y172.518355 Z6 E10595.654616 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X209.243972 Y172.556196 Z6 E10599.799628 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X210.238501 Y172.629557 Z6 E10603.945632 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X211.229206 Y172.741734 Z6 E10608.090828 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X212.216637 Y172.879314 Z6 E10612.235744 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X213.199186 Y173.049803 Z6 E10616.381749 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X214.173679 Y173.260796 Z6 E10620.527094 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X215.142312 Y173.496725 Z6 E10624.671938 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X216.103419 Y173.762699 Z6 E10628.817942 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X217.051872 Y174.070389 Z6 E10632.96346 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X217.991943 Y174.402284 Z6 E10637.108252 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X218.922352 Y174.761183 Z6 E10641.254256 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X219.835201 Y175.162476 Z6 E10645.399968 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X220.737233 Y175.58699 Z6 E10649.544731 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X221.627984 Y176.035356 Z6 E10653.690735 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X222.496022 Y176.526215 Z6 E10657.836663 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X223.350921 Y177.039068 Z6 E10661.981418 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X224.192586 Y177.573856 Z6 E10666.127271 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X225.007907 Y178.14807 Z6 E10670.273276 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X225.807054 Y178.74409 Z6 E10674.418046 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X226.590792 Y179.360574 Z6 E10678.563691 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X227.345904 Y180.011938 Z6 E10682.709695 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X228.081242 Y180.685119 Z6 E10686.854502 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X228.799157 Y181.377077 Z6 E10690.99996 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X229.486788 Y182.099318 Z6 E10695.145964 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X230.150903 Y182.842874 Z6 E10699.290829 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X230.795764 Y183.603323 Z6 E10703.436123 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X231.409292 Y184.389487 Z6 E10707.582127 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X231.995484 Y185.195924 Z6 E10711.727073 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X232.560795 Y186.017193 Z6 E10715.872224 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X233.094311 Y186.859707 Z6 E10720.018228 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X233.596668 Y187.720897 Z6 E10724.163276 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X234.076735 Y188.594704 Z6 E10728.308306 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X234.525102 Y189.485454 Z6 E10732.45431 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X234.938554 Y190.392718 Z6 E10736.599483 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X235.328542 Y191.31025 Z6 E10740.744414 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X235.68744 Y192.240659 Z6 E10744.890419 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.007814 Y193.184853 Z6 E10749.035738 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.303795 Y194.136858 Z6 E10753.180592 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.569769 Y195.097965 Z6 E10757.326596 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.793827 Y196.069571 Z6 E10761.472084 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X236.992819 Y197.046451 Z6 E10765.616883 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.163308 Y198.029 Z6 E10769.762887 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.288784 Y199.018227 Z6 E10773.908565 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.388783 Y200.010132 Z6 E10778.053331 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.462144 Y201.004661 Z6 E10782.199336 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
G1 X237.487763 Y202.001535 Z6 E10786.345226 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00004-layer-00002-bottom-and-wall note=weave wall
; CLAYLINE_STROKE_END page=0 layer=2 id=weave-00004-layer-00002-bottom-and-wall
G0 X237.487763 Y202.001535 Z8 F2400 ; clayline kind=travel_lift page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z8 F2400 ; clayline kind=travel_xy page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave paste-safe traverse
G0 X222.487828 Y202.004158 Z6 F2400 ; clayline kind=travel_approach page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=2 id=weave-00005-layer-00002-island-001
G1 X222.487828 Y202.995842 Z6 E10790.468167 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z6 E10794.591324 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z6 E10798.71452 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z6 E10802.837466 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z6 E10806.960502 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z6 E10811.083632 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z6 E10815.206593 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z6 E10819.329546 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z6 E10823.452621 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z6 E10827.575606 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z6 E10831.698516 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z6 E10835.821544 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z6 E10839.944563 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z6 E10844.067468 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z6 E10848.19046 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z6 E10852.313523 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z6 E10856.436462 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z6 E10860.559427 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z6 E10864.682543 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z6 E10868.805555 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z6 E10872.928503 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z6 E10877.051682 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z6 E10881.174805 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z6 E10885.297747 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z6 E10889.42094 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z6 E10893.544154 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z6 E10897.667098 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z6 E10901.790161 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z6 E10905.913307 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z6 E10910.036263 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z6 E10914.159233 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z6 E10918.282321 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z6 E10922.405299 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z6 E10926.528216 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z6 E10930.651255 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z6 E10934.774264 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z6 E10938.897167 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z6 E10943.020167 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z6 E10947.143218 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z6 E10951.266145 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z6 E10955.389116 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z6 E10959.512217 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z6 E10963.635207 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z6 E10967.758159 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z6 E10971.881321 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z6 E10976.004413 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z6 E10980.127355 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X192.5 Y202.5 Z6 E10984.250588 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z6 E10988.37382 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z6 E10992.496763 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z6 E10996.619854 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z6 E11000.743016 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z6 E11004.865968 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z6 E11008.988958 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z6 E11013.11206 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z6 E11017.235031 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z6 E11021.357958 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z6 E11025.481008 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z6 E11029.604009 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z6 E11033.726912 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z6 E11037.849921 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z6 E11041.97296 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z6 E11046.095877 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z6 E11050.218855 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z6 E11054.341943 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z6 E11058.464913 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z6 E11062.587869 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z6 E11066.711015 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z6 E11070.834078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z6 E11074.957022 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z6 E11079.080236 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z6 E11083.203429 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z6 E11087.326371 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z6 E11091.449494 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z6 E11095.572673 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z6 E11099.695621 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z6 E11103.818633 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z6 E11107.941749 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z6 E11112.064714 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z6 E11116.187653 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z6 E11120.310716 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z6 E11124.433708 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z6 E11128.556613 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z6 E11132.679632 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z6 E11136.80266 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z6 E11140.92557 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z6 E11145.048555 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z6 E11149.17163 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z6 E11153.294583 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z6 E11157.417544 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z6 E11161.540674 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z6 E11165.66371 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z6 E11169.786656 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z6 E11173.909852 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z6 E11178.033009 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00005-layer-00002-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=2 id=weave-00005-layer-00002-island-001
G0 X222.487828 Y202.004158 Z10 F2400 ; clayline kind=travel_lift page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z8 F2400 ; clayline kind=travel_approach page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=3 id=weave-00006-layer-00003-island-001
G1 X222.487828 Y202.995842 Z8 E11182.15595 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z8 E11186.279108 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z8 E11190.402304 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z8 E11194.525249 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z8 E11198.648285 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z8 E11202.771416 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z8 E11206.894376 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z8 E11211.01733 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z8 E11215.140405 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z8 E11219.263389 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z8 E11223.386299 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z8 E11227.509328 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z8 E11231.632347 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z8 E11235.755252 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z8 E11239.878244 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z8 E11244.001306 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z8 E11248.124245 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z8 E11252.247211 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z8 E11256.370327 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z8 E11260.493338 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z8 E11264.616287 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z8 E11268.739466 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z8 E11272.862589 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z8 E11276.98553 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z8 E11281.108724 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z8 E11285.231938 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z8 E11289.354882 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z8 E11293.477944 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z8 E11297.60109 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z8 E11301.724046 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z8 E11305.847017 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z8 E11309.970105 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z8 E11314.093082 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z8 E11318.215999 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z8 E11322.339039 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z8 E11326.462048 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z8 E11330.584951 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z8 E11334.707951 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z8 E11338.831002 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z8 E11342.953928 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z8 E11347.0769 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z8 E11351.200001 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z8 E11355.322991 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z8 E11359.445943 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z8 E11363.569105 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z8 E11367.692197 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z8 E11371.815139 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X192.5 Y202.5 Z8 E11375.938372 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z8 E11380.061604 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z8 E11384.184546 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z8 E11388.307638 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z8 E11392.4308 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z8 E11396.553752 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z8 E11400.676742 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z8 E11404.799843 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z8 E11408.922815 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z8 E11413.045742 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z8 E11417.168792 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z8 E11421.291793 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z8 E11425.414695 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z8 E11429.537704 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z8 E11433.660744 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z8 E11437.783661 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z8 E11441.906639 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z8 E11446.029726 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z8 E11450.152697 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z8 E11454.275653 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z8 E11458.398799 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z8 E11462.521862 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z8 E11466.644805 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z8 E11470.768019 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z8 E11474.891213 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z8 E11479.014154 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z8 E11483.137278 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z8 E11487.260456 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z8 E11491.383405 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z8 E11495.506417 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z8 E11499.629532 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z8 E11503.752498 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z8 E11507.875437 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z8 E11511.998499 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z8 E11516.121491 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z8 E11520.244397 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z8 E11524.367415 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z8 E11528.490444 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z8 E11532.613354 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z8 E11536.736338 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z8 E11540.859413 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z8 E11544.982367 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z8 E11549.105327 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z8 E11553.228458 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z8 E11557.351494 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z8 E11561.47444 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z8 E11565.597636 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z8 E11569.720793 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00006-layer-00003-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=3 id=weave-00006-layer-00003-island-001
G0 X222.487828 Y202.004158 Z10 F2400 ; clayline kind=travel_lift page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave paste-safe lift
G0 X237.487763 Y202.001535 Z10 F2400 ; clayline kind=travel_xy page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave paste-safe traverse
G0 X237.487763 Y202.001535 Z8 F2400 ; clayline kind=travel_approach page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=3 id=weave-00007-layer-00003-island-000
G1 X237.487763 Y202.998465 Z8 E11573.865548 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.462144 Y203.995339 Z8 E11578.011438 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.388783 Y204.989868 Z8 E11582.157443 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.288784 Y205.981773 Z8 E11586.302209 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.163308 Y206.971 Z8 E11590.447887 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.992819 Y207.953549 Z8 E11594.593891 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.793827 Y208.930429 Z8 E11598.73869 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.569769 Y209.902035 Z8 E11602.884178 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.303795 Y210.863142 Z8 E11607.030182 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.007814 Y211.815147 Z8 E11611.175036 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X235.68744 Y212.759341 Z8 E11615.320355 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X235.328542 Y213.68975 Z8 E11619.46636 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X234.938554 Y214.607282 Z8 E11623.611291 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X234.525102 Y215.514546 Z8 E11627.756464 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X234.076735 Y216.405296 Z8 E11631.902468 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X233.596668 Y217.279103 Z8 E11636.047498 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X233.094311 Y218.140293 Z8 E11640.192546 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X232.560795 Y218.982807 Z8 E11644.33855 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X231.995484 Y219.804076 Z8 E11648.483701 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X231.409292 Y220.610513 Z8 E11652.628647 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X230.795764 Y221.396677 Z8 E11656.774651 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X230.150903 Y222.157126 Z8 E11660.919945 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X229.486788 Y222.900682 Z8 E11665.06481 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X228.799157 Y223.622923 Z8 E11669.210814 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X228.081242 Y224.314881 Z8 E11673.356272 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X227.345904 Y224.988062 Z8 E11677.501079 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X226.590792 Y225.639426 Z8 E11681.647084 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X225.807054 Y226.25591 Z8 E11685.792728 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X225.007907 Y226.85193 Z8 E11689.937498 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X224.192586 Y227.426144 Z8 E11694.083503 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X223.350921 Y227.960932 Z8 E11698.229356 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X222.496022 Y228.473785 Z8 E11702.374111 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X221.627984 Y228.964644 Z8 E11706.520039 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X220.737233 Y229.41301 Z8 E11710.666043 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X219.835201 Y229.837524 Z8 E11714.810806 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X218.922352 Y230.238817 Z8 E11718.956518 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X217.991943 Y230.597716 Z8 E11723.102522 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X217.051872 Y230.929611 Z8 E11727.247314 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X216.103419 Y231.237301 Z8 E11731.392832 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X215.142312 Y231.503275 Z8 E11735.538836 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X214.173679 Y231.739204 Z8 E11739.68368 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X213.199186 Y231.950197 Z8 E11743.829025 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X212.216637 Y232.120686 Z8 E11747.97503 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X211.229206 Y232.258266 Z8 E11752.119946 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X210.238501 Y232.370443 Z8 E11756.265142 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X209.243972 Y232.443804 Z8 E11760.411146 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X208.247698 Y232.481645 Z8 E11764.556158 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X207.250767 Y232.493882 Z8 E11768.701226 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X206.253837 Y232.469408 Z8 E11772.84723 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X205.258764 Y232.407124 Z8 E11776.992359 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X204.265659 Y232.319302 Z8 E11781.137321 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X203.275928 Y232.19723 Z8 E11785.283325 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X202.292088 Y232.035441 Z8 E11789.428593 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X201.312821 Y231.848451 Z8 E11793.57347 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X200.339821 Y231.629956 Z8 E11797.719475 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X199.377134 Y231.370288 Z8 E11801.864904 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X198.421577 Y231.086017 Z8 E11806.009719 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X197.474679 Y230.773204 Z8 E11810.155723 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X196.542852 Y230.418266 Z8 E11814.301335 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X195.620638 Y230.039584 Z8 E11818.44611 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X194.70896 Y229.635465 Z8 E11822.592114 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X193.817391 Y229.188827 Z8 E11826.737931 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X192.937817 Y228.719551 Z8 E11830.882687 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X192.070336 Y228.22769 Z8 E11835.028653 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X191.227821 Y227.694174 Z8 E11839.174657 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X190.399754 Y227.139037 Z8 E11843.319418 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X189.586028 Y226.562674 Z8 E11847.465164 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X188.799864 Y225.949146 Z8 E11851.611168 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X188.031652 Y225.313744 Z8 E11855.755954 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X187.279879 Y224.658696 Z8 E11859.901502 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X186.557637 Y223.971065 Z8 E11864.047506 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X185.857027 Y223.261802 Z8 E11868.19234 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X185.174779 Y222.534682 Z8 E11872.337713 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X184.523415 Y221.77957 Z8 E11876.483717 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X183.897472 Y221.003595 Z8 E11880.62862 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X183.291623 Y220.211737 Z8 E11884.773839 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X182.717409 Y219.396416 Z8 E11888.919843 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X182.172447 Y218.56155 Z8 E11893.064838 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X181.649098 Y217.712942 Z8 E11897.209926 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X181.157565 Y216.845264 Z8 E11901.35593 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X180.699082 Y215.959921 Z8 E11905.501038 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X180.263506 Y215.063121 Z8 E11909.646015 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X179.859386 Y214.151443 Z8 E11913.79202 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X179.492009 Y213.224545 Z8 E11917.937263 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X179.148592 Y212.288597 Z8 E11922.082153 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.835779 Y211.341698 Z8 E11926.228157 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.563218 Y210.382589 Z8 E11930.373558 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.31542 Y209.416929 Z8 E11934.518382 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.096925 Y208.443928 Z8 E11938.664386 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.921936 Y207.462274 Z8 E11942.809966 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.772252 Y206.476639 Z8 E11946.954746 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.65018 Y205.486908 Z8 E11951.10075 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.574536 Y204.492604 Z8 E11955.246531 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.524473 Y203.496931 Z8 E11959.391289 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.5 Y202.5 Z8 E11963.537294 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.524473 Y201.503069 Z8 E11967.683298 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.574536 Y200.507396 Z8 E11971.828056 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.65018 Y199.513092 Z8 E11975.973837 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.772252 Y198.523361 Z8 E11980.119841 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X177.921936 Y197.537726 Z8 E11984.264622 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.096925 Y196.556072 Z8 E11988.410201 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.31542 Y195.583071 Z8 E11992.556206 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.563218 Y194.617411 Z8 E11996.70103 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X178.835779 Y193.658302 Z8 E12000.84643 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X179.148592 Y192.711403 Z8 E12004.992434 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X179.492009 Y191.775455 Z8 E12009.137324 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X179.859386 Y190.848557 Z8 E12013.282568 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X180.263506 Y189.936879 Z8 E12017.428572 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X180.699082 Y189.040079 Z8 E12021.57355 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X181.157565 Y188.154736 Z8 E12025.718658 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X181.649098 Y187.287058 Z8 E12029.864662 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X182.172447 Y186.43845 Z8 E12034.009749 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X182.717409 Y185.603584 Z8 E12038.154744 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X183.291623 Y184.788263 Z8 E12042.300748 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X183.897472 Y183.996405 Z8 E12046.445967 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X184.523415 Y183.22043 Z8 E12050.59087 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X185.174779 Y182.465318 Z8 E12054.736875 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X185.857027 Y181.738198 Z8 E12058.882247 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X186.557637 Y181.028935 Z8 E12063.027081 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X187.279879 Y180.341304 Z8 E12067.173085 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X188.031652 Y179.686256 Z8 E12071.318634 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X188.799864 Y179.050854 Z8 E12075.46342 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X189.586028 Y178.437326 Z8 E12079.609424 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X190.399754 Y177.860963 Z8 E12083.75517 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X191.227821 Y177.305826 Z8 E12087.89993 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X192.070336 Y176.77231 Z8 E12092.045934 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X192.937817 Y176.280449 Z8 E12096.1919 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X193.817391 Y175.811173 Z8 E12100.336657 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X194.70896 Y175.364535 Z8 E12104.482473 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X195.620638 Y174.960416 Z8 E12108.628477 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X196.542852 Y174.581734 Z8 E12112.773252 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X197.474679 Y174.226796 Z8 E12116.918864 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X198.421577 Y173.913983 Z8 E12121.064869 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X199.377134 Y173.629712 Z8 E12125.209684 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X200.339821 Y173.370044 Z8 E12129.355113 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X201.312821 Y173.151549 Z8 E12133.501117 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X202.292088 Y172.964559 Z8 E12137.645994 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X203.275928 Y172.80277 Z8 E12141.791262 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X204.265659 Y172.680698 Z8 E12145.937267 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X205.258764 Y172.592876 Z8 E12150.082228 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X206.253837 Y172.530592 Z8 E12154.227357 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X207.250767 Y172.506118 Z8 E12158.373361 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X208.247698 Y172.518355 Z8 E12162.518429 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X209.243972 Y172.556196 Z8 E12166.663441 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X210.238501 Y172.629557 Z8 E12170.809445 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X211.229206 Y172.741734 Z8 E12174.954641 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X212.216637 Y172.879314 Z8 E12179.099558 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X213.199186 Y173.049803 Z8 E12183.245562 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X214.173679 Y173.260796 Z8 E12187.390908 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X215.142312 Y173.496725 Z8 E12191.535751 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X216.103419 Y173.762699 Z8 E12195.681755 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X217.051872 Y174.070389 Z8 E12199.827273 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X217.991943 Y174.402284 Z8 E12203.972065 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X218.922352 Y174.761183 Z8 E12208.11807 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X219.835201 Y175.162476 Z8 E12212.263781 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X220.737233 Y175.58699 Z8 E12216.408544 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X221.627984 Y176.035356 Z8 E12220.554549 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X222.496022 Y176.526215 Z8 E12224.700476 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X223.350921 Y177.039068 Z8 E12228.845232 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X224.192586 Y177.573856 Z8 E12232.991085 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X225.007907 Y178.14807 Z8 E12237.137089 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X225.807054 Y178.74409 Z8 E12241.281859 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X226.590792 Y179.360574 Z8 E12245.427504 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X227.345904 Y180.011938 Z8 E12249.573508 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X228.081242 Y180.685119 Z8 E12253.718315 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X228.799157 Y181.377077 Z8 E12257.863773 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X229.486788 Y182.099318 Z8 E12262.009777 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X230.150903 Y182.842874 Z8 E12266.154643 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X230.795764 Y183.603323 Z8 E12270.299936 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X231.409292 Y184.389487 Z8 E12274.44594 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X231.995484 Y185.195924 Z8 E12278.590886 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X232.560795 Y186.017193 Z8 E12282.736037 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X233.094311 Y186.859707 Z8 E12286.882041 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X233.596668 Y187.720897 Z8 E12291.02709 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X234.076735 Y188.594704 Z8 E12295.172119 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X234.525102 Y189.485454 Z8 E12299.318124 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X234.938554 Y190.392718 Z8 E12303.463297 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X235.328542 Y191.31025 Z8 E12307.608228 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X235.68744 Y192.240659 Z8 E12311.754232 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.007814 Y193.184853 Z8 E12315.899551 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.303795 Y194.136858 Z8 E12320.044405 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.569769 Y195.097965 Z8 E12324.19041 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.793827 Y196.069571 Z8 E12328.335897 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X236.992819 Y197.046451 Z8 E12332.480696 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.163308 Y198.029 Z8 E12336.626701 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.288784 Y199.018227 Z8 E12340.772378 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.388783 Y200.010132 Z8 E12344.917145 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.462144 Y201.004661 Z8 E12349.063149 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
G1 X237.487763 Y202.001535 Z8 E12353.209039 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00007-layer-00003-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=3 id=weave-00007-layer-00003-island-000
G0 X237.487763 Y202.001535 Z12 F2400 ; clayline kind=travel_lift page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave paste-safe lift
G0 X237.487763 Y202.001535 Z10 F2400 ; clayline kind=travel_approach page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=4 id=weave-00008-layer-00004-island-000
G1 X237.487763 Y202.998465 Z10 E12357.353794 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.462144 Y203.995339 Z10 E12361.499684 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.388783 Y204.989868 Z10 E12365.645688 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.288784 Y205.981773 Z10 E12369.790455 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.163308 Y206.971 Z10 E12373.936133 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.992819 Y207.953549 Z10 E12378.082137 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.793827 Y208.930429 Z10 E12382.226936 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.569769 Y209.902035 Z10 E12386.372424 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.303795 Y210.863142 Z10 E12390.518428 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.007814 Y211.815147 Z10 E12394.663282 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X235.68744 Y212.759341 Z10 E12398.808601 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X235.328542 Y213.68975 Z10 E12402.954606 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X234.938554 Y214.607282 Z10 E12407.099537 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X234.525102 Y215.514546 Z10 E12411.24471 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X234.076735 Y216.405296 Z10 E12415.390714 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X233.596668 Y217.279103 Z10 E12419.535744 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X233.094311 Y218.140293 Z10 E12423.680792 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X232.560795 Y218.982807 Z10 E12427.826796 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X231.995484 Y219.804076 Z10 E12431.971947 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X231.409292 Y220.610513 Z10 E12436.116893 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X230.795764 Y221.396677 Z10 E12440.262897 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X230.150903 Y222.157126 Z10 E12444.408191 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X229.486788 Y222.900682 Z10 E12448.553056 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X228.799157 Y223.622923 Z10 E12452.69906 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X228.081242 Y224.314881 Z10 E12456.844518 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X227.345904 Y224.988062 Z10 E12460.989325 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X226.590792 Y225.639426 Z10 E12465.135329 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X225.807054 Y226.25591 Z10 E12469.280974 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X225.007907 Y226.85193 Z10 E12473.425744 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X224.192586 Y227.426144 Z10 E12477.571749 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X223.350921 Y227.960932 Z10 E12481.717602 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X222.496022 Y228.473785 Z10 E12485.862357 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X221.627984 Y228.964644 Z10 E12490.008285 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X220.737233 Y229.41301 Z10 E12494.154289 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X219.835201 Y229.837524 Z10 E12498.299052 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X218.922352 Y230.238817 Z10 E12502.444764 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X217.991943 Y230.597716 Z10 E12506.590768 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X217.051872 Y230.929611 Z10 E12510.73556 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X216.103419 Y231.237301 Z10 E12514.881078 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X215.142312 Y231.503275 Z10 E12519.027082 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X214.173679 Y231.739204 Z10 E12523.171926 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X213.199186 Y231.950197 Z10 E12527.317271 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X212.216637 Y232.120686 Z10 E12531.463276 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X211.229206 Y232.258266 Z10 E12535.608192 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X210.238501 Y232.370443 Z10 E12539.753388 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X209.243972 Y232.443804 Z10 E12543.899392 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X208.247698 Y232.481645 Z10 E12548.044404 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X207.250767 Y232.493882 Z10 E12552.189472 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X206.253837 Y232.469408 Z10 E12556.335476 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X205.258764 Y232.407124 Z10 E12560.480605 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X204.265659 Y232.319302 Z10 E12564.625567 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X203.275928 Y232.19723 Z10 E12568.771571 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X202.292088 Y232.035441 Z10 E12572.916839 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X201.312821 Y231.848451 Z10 E12577.061716 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X200.339821 Y231.629956 Z10 E12581.207721 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X199.377134 Y231.370288 Z10 E12585.353149 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X198.421577 Y231.086017 Z10 E12589.497965 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X197.474679 Y230.773204 Z10 E12593.643969 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X196.542852 Y230.418266 Z10 E12597.789581 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X195.620638 Y230.039584 Z10 E12601.934356 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X194.70896 Y229.635465 Z10 E12606.08036 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X193.817391 Y229.188827 Z10 E12610.226177 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X192.937817 Y228.719551 Z10 E12614.370933 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X192.070336 Y228.22769 Z10 E12618.516899 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X191.227821 Y227.694174 Z10 E12622.662903 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X190.399754 Y227.139037 Z10 E12626.807663 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X189.586028 Y226.562674 Z10 E12630.953409 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X188.799864 Y225.949146 Z10 E12635.099414 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X188.031652 Y225.313744 Z10 E12639.2442 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X187.279879 Y224.658696 Z10 E12643.389748 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X186.557637 Y223.971065 Z10 E12647.535752 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X185.857027 Y223.261802 Z10 E12651.680586 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X185.174779 Y222.534682 Z10 E12655.825959 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X184.523415 Y221.77957 Z10 E12659.971963 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X183.897472 Y221.003595 Z10 E12664.116866 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X183.291623 Y220.211737 Z10 E12668.262085 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X182.717409 Y219.396416 Z10 E12672.408089 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X182.172447 Y218.56155 Z10 E12676.553084 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X181.649098 Y217.712942 Z10 E12680.698171 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X181.157565 Y216.845264 Z10 E12684.844176 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X180.699082 Y215.959921 Z10 E12688.989284 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X180.263506 Y215.063121 Z10 E12693.134261 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X179.859386 Y214.151443 Z10 E12697.280266 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X179.492009 Y213.224545 Z10 E12701.425509 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X179.148592 Y212.288597 Z10 E12705.570399 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.835779 Y211.341698 Z10 E12709.716403 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.563218 Y210.382589 Z10 E12713.861804 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.31542 Y209.416929 Z10 E12718.006628 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.096925 Y208.443928 Z10 E12722.152632 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.921936 Y207.462274 Z10 E12726.298212 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.772252 Y206.476639 Z10 E12730.442992 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.65018 Y205.486908 Z10 E12734.588996 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.574536 Y204.492604 Z10 E12738.734777 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.524473 Y203.496931 Z10 E12742.879535 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.5 Y202.5 Z10 E12747.02554 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.524473 Y201.503069 Z10 E12751.171544 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.574536 Y200.507396 Z10 E12755.316302 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.65018 Y199.513092 Z10 E12759.462083 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.772252 Y198.523361 Z10 E12763.608087 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X177.921936 Y197.537726 Z10 E12767.752867 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.096925 Y196.556072 Z10 E12771.898447 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.31542 Y195.583071 Z10 E12776.044452 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.563218 Y194.617411 Z10 E12780.189276 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X178.835779 Y193.658302 Z10 E12784.334676 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X179.148592 Y192.711403 Z10 E12788.48068 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X179.492009 Y191.775455 Z10 E12792.62557 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X179.859386 Y190.848557 Z10 E12796.770814 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X180.263506 Y189.936879 Z10 E12800.916818 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X180.699082 Y189.040079 Z10 E12805.061796 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X181.157565 Y188.154736 Z10 E12809.206904 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X181.649098 Y187.287058 Z10 E12813.352908 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X182.172447 Y186.43845 Z10 E12817.497995 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X182.717409 Y185.603584 Z10 E12821.64299 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X183.291623 Y184.788263 Z10 E12825.788994 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X183.897472 Y183.996405 Z10 E12829.934213 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X184.523415 Y183.22043 Z10 E12834.079116 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X185.174779 Y182.465318 Z10 E12838.22512 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X185.857027 Y181.738198 Z10 E12842.370493 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X186.557637 Y181.028935 Z10 E12846.515327 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X187.279879 Y180.341304 Z10 E12850.661331 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X188.031652 Y179.686256 Z10 E12854.80688 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X188.799864 Y179.050854 Z10 E12858.951666 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X189.586028 Y178.437326 Z10 E12863.09767 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X190.399754 Y177.860963 Z10 E12867.243416 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X191.227821 Y177.305826 Z10 E12871.388176 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X192.070336 Y176.77231 Z10 E12875.53418 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X192.937817 Y176.280449 Z10 E12879.680146 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X193.817391 Y175.811173 Z10 E12883.824903 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X194.70896 Y175.364535 Z10 E12887.970719 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X195.620638 Y174.960416 Z10 E12892.116723 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X196.542852 Y174.581734 Z10 E12896.261498 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X197.474679 Y174.226796 Z10 E12900.40711 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X198.421577 Y173.913983 Z10 E12904.553114 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X199.377134 Y173.629712 Z10 E12908.69793 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X200.339821 Y173.370044 Z10 E12912.843359 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X201.312821 Y173.151549 Z10 E12916.989363 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X202.292088 Y172.964559 Z10 E12921.13424 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X203.275928 Y172.80277 Z10 E12925.279508 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X204.265659 Y172.680698 Z10 E12929.425513 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X205.258764 Y172.592876 Z10 E12933.570474 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X206.253837 Y172.530592 Z10 E12937.715603 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X207.250767 Y172.506118 Z10 E12941.861607 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X208.247698 Y172.518355 Z10 E12946.006675 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X209.243972 Y172.556196 Z10 E12950.151687 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X210.238501 Y172.629557 Z10 E12954.297691 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X211.229206 Y172.741734 Z10 E12958.442887 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X212.216637 Y172.879314 Z10 E12962.587804 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X213.199186 Y173.049803 Z10 E12966.733808 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X214.173679 Y173.260796 Z10 E12970.879154 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X215.142312 Y173.496725 Z10 E12975.023997 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X216.103419 Y173.762699 Z10 E12979.170001 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X217.051872 Y174.070389 Z10 E12983.315519 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X217.991943 Y174.402284 Z10 E12987.460311 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X218.922352 Y174.761183 Z10 E12991.606316 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X219.835201 Y175.162476 Z10 E12995.752027 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X220.737233 Y175.58699 Z10 E12999.89679 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X221.627984 Y176.035356 Z10 E13004.042794 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X222.496022 Y176.526215 Z10 E13008.188722 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X223.350921 Y177.039068 Z10 E13012.333478 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X224.192586 Y177.573856 Z10 E13016.479331 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X225.007907 Y178.14807 Z10 E13020.625335 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X225.807054 Y178.74409 Z10 E13024.770105 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X226.590792 Y179.360574 Z10 E13028.91575 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X227.345904 Y180.011938 Z10 E13033.061754 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X228.081242 Y180.685119 Z10 E13037.206561 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X228.799157 Y181.377077 Z10 E13041.352019 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X229.486788 Y182.099318 Z10 E13045.498023 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X230.150903 Y182.842874 Z10 E13049.642889 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X230.795764 Y183.603323 Z10 E13053.788182 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X231.409292 Y184.389487 Z10 E13057.934186 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X231.995484 Y185.195924 Z10 E13062.079132 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X232.560795 Y186.017193 Z10 E13066.224283 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X233.094311 Y186.859707 Z10 E13070.370287 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X233.596668 Y187.720897 Z10 E13074.515336 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X234.076735 Y188.594704 Z10 E13078.660365 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X234.525102 Y189.485454 Z10 E13082.80637 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X234.938554 Y190.392718 Z10 E13086.951542 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X235.328542 Y191.31025 Z10 E13091.096474 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X235.68744 Y192.240659 Z10 E13095.242478 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.007814 Y193.184853 Z10 E13099.387797 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.303795 Y194.136858 Z10 E13103.532651 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.569769 Y195.097965 Z10 E13107.678655 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.793827 Y196.069571 Z10 E13111.824143 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X236.992819 Y197.046451 Z10 E13115.968942 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.163308 Y198.029 Z10 E13120.114947 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.288784 Y199.018227 Z10 E13124.260624 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.388783 Y200.010132 Z10 E13128.405391 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.462144 Y201.004661 Z10 E13132.551395 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
G1 X237.487763 Y202.001535 Z10 E13136.697285 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00008-layer-00004-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=4 id=weave-00008-layer-00004-island-000
G0 X237.487763 Y202.001535 Z12 F2400 ; clayline kind=travel_lift page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z12 F2400 ; clayline kind=travel_xy page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave paste-safe traverse
G0 X222.487828 Y202.004158 Z10 F2400 ; clayline kind=travel_approach page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=4 id=weave-00009-layer-00004-island-001
G1 X222.487828 Y202.995842 Z10 E13140.820226 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z10 E13144.943383 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z10 E13149.066579 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z10 E13153.189525 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z10 E13157.312561 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z10 E13161.435692 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z10 E13165.558652 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z10 E13169.681606 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z10 E13173.80468 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z10 E13177.927665 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z10 E13182.050575 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z10 E13186.173604 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z10 E13190.296622 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z10 E13194.419527 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z10 E13198.54252 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z10 E13202.665582 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z10 E13206.788521 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z10 E13210.911486 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z10 E13215.034602 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z10 E13219.157614 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z10 E13223.280562 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z10 E13227.403741 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z10 E13231.526865 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z10 E13235.649806 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z10 E13239.773 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z10 E13243.896213 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z10 E13248.019157 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z10 E13252.14222 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z10 E13256.265366 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z10 E13260.388322 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z10 E13264.511292 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z10 E13268.63438 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z10 E13272.757358 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z10 E13276.880275 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z10 E13281.003314 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z10 E13285.126324 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z10 E13289.249226 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z10 E13293.372227 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z10 E13297.495277 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z10 E13301.618204 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z10 E13305.741175 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z10 E13309.864277 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z10 E13313.987267 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z10 E13318.110219 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z10 E13322.233381 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z10 E13326.356473 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z10 E13330.479415 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X192.5 Y202.5 Z10 E13334.602647 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z10 E13338.72588 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z10 E13342.848822 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z10 E13346.971914 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z10 E13351.095076 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z10 E13355.218028 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z10 E13359.341018 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z10 E13363.464119 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z10 E13367.58709 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z10 E13371.710017 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z10 E13375.833068 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z10 E13379.956068 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z10 E13384.078971 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z10 E13388.20198 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z10 E13392.325019 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z10 E13396.447937 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z10 E13400.570914 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z10 E13404.694002 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z10 E13408.816973 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z10 E13412.939928 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z10 E13417.063074 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z10 E13421.186137 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z10 E13425.309081 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z10 E13429.432295 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z10 E13433.555488 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z10 E13437.67843 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z10 E13441.801553 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z10 E13445.924732 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z10 E13450.04768 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z10 E13454.170692 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z10 E13458.293808 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z10 E13462.416773 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z10 E13466.539713 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z10 E13470.662775 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z10 E13474.785767 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z10 E13478.908672 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z10 E13483.031691 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z10 E13487.154719 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z10 E13491.277629 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z10 E13495.400614 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z10 E13499.523689 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z10 E13503.646642 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z10 E13507.769603 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z10 E13511.892733 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z10 E13516.015769 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z10 E13520.138715 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z10 E13524.261911 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z10 E13528.385069 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00009-layer-00004-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=4 id=weave-00009-layer-00004-island-001
G0 X222.487828 Y202.004158 Z14 F2400 ; clayline kind=travel_lift page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z12 F2400 ; clayline kind=travel_approach page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=5 id=weave-00010-layer-00005-island-001
G1 X222.487828 Y202.995842 Z12 E13532.50801 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z12 E13536.631167 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z12 E13540.754363 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z12 E13544.877309 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z12 E13549.000345 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z12 E13553.123475 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z12 E13557.246436 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z12 E13561.369389 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z12 E13565.492464 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z12 E13569.615449 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z12 E13573.738359 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z12 E13577.861387 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z12 E13581.984406 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z12 E13586.107311 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z12 E13590.230303 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z12 E13594.353366 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z12 E13598.476305 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z12 E13602.59927 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z12 E13606.722386 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z12 E13610.845398 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z12 E13614.968346 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z12 E13619.091525 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z12 E13623.214648 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z12 E13627.33759 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z12 E13631.460783 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z12 E13635.583997 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z12 E13639.706941 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z12 E13643.830004 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z12 E13647.95315 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z12 E13652.076105 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z12 E13656.199076 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z12 E13660.322164 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z12 E13664.445141 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z12 E13668.568059 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z12 E13672.691098 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z12 E13676.814107 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z12 E13680.93701 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z12 E13685.06001 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z12 E13689.183061 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z12 E13693.305988 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z12 E13697.428959 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z12 E13701.55206 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z12 E13705.67505 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z12 E13709.798002 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z12 E13713.921164 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z12 E13718.044256 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z12 E13722.167198 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X192.5 Y202.5 Z12 E13726.290431 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z12 E13730.413663 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z12 E13734.536606 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z12 E13738.659697 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z12 E13742.782859 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z12 E13746.905811 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z12 E13751.028801 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z12 E13755.151903 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z12 E13759.274874 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z12 E13763.397801 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z12 E13767.520851 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z12 E13771.643852 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z12 E13775.766755 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z12 E13779.889764 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z12 E13784.012803 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z12 E13788.13572 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z12 E13792.258698 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z12 E13796.381786 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z12 E13800.504756 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z12 E13804.627712 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z12 E13808.750858 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z12 E13812.873921 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z12 E13816.996865 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z12 E13821.120079 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z12 E13825.243272 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z12 E13829.366213 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z12 E13833.489337 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z12 E13837.612516 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z12 E13841.735464 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z12 E13845.858476 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z12 E13849.981592 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z12 E13854.104557 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z12 E13858.227496 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z12 E13862.350559 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z12 E13866.473551 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z12 E13870.596456 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z12 E13874.719474 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z12 E13878.842503 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z12 E13882.965413 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z12 E13887.088398 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z12 E13891.211472 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z12 E13895.334426 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z12 E13899.457386 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z12 E13903.580517 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z12 E13907.703553 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z12 E13911.826499 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z12 E13915.949695 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z12 E13920.072852 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00010-layer-00005-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=5 id=weave-00010-layer-00005-island-001
G0 X222.487828 Y202.004158 Z14 F2400 ; clayline kind=travel_lift page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave paste-safe lift
G0 X237.487763 Y202.001535 Z14 F2400 ; clayline kind=travel_xy page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave paste-safe traverse
G0 X237.487763 Y202.001535 Z12 F2400 ; clayline kind=travel_approach page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=5 id=weave-00011-layer-00005-island-000
G1 X237.487763 Y202.998465 Z12 E13924.217608 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.462144 Y203.995339 Z12 E13928.363498 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.388783 Y204.989868 Z12 E13932.509502 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.288784 Y205.981773 Z12 E13936.654268 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.163308 Y206.971 Z12 E13940.799946 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.992819 Y207.953549 Z12 E13944.94595 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.793827 Y208.930429 Z12 E13949.09075 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.569769 Y209.902035 Z12 E13953.236237 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.303795 Y210.863142 Z12 E13957.382241 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.007814 Y211.815147 Z12 E13961.527096 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X235.68744 Y212.759341 Z12 E13965.672415 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X235.328542 Y213.68975 Z12 E13969.818419 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X234.938554 Y214.607282 Z12 E13973.96335 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X234.525102 Y215.514546 Z12 E13978.108523 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X234.076735 Y216.405296 Z12 E13982.254527 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X233.596668 Y217.279103 Z12 E13986.399557 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X233.094311 Y218.140293 Z12 E13990.544606 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X232.560795 Y218.982807 Z12 E13994.69061 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X231.995484 Y219.804076 Z12 E13998.83576 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X231.409292 Y220.610513 Z12 E14002.980706 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X230.795764 Y221.396677 Z12 E14007.126711 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X230.150903 Y222.157126 Z12 E14011.272004 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X229.486788 Y222.900682 Z12 E14015.416869 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X228.799157 Y223.622923 Z12 E14019.562874 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X228.081242 Y224.314881 Z12 E14023.708332 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X227.345904 Y224.988062 Z12 E14027.853139 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X226.590792 Y225.639426 Z12 E14031.999143 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X225.807054 Y226.25591 Z12 E14036.144787 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X225.007907 Y226.85193 Z12 E14040.289558 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X224.192586 Y227.426144 Z12 E14044.435562 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X223.350921 Y227.960932 Z12 E14048.581415 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X222.496022 Y228.473785 Z12 E14052.726171 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X221.627984 Y228.964644 Z12 E14056.872098 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X220.737233 Y229.41301 Z12 E14061.018102 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X219.835201 Y229.837524 Z12 E14065.162865 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X218.922352 Y230.238817 Z12 E14069.308577 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X217.991943 Y230.597716 Z12 E14073.454581 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X217.051872 Y230.929611 Z12 E14077.599373 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X216.103419 Y231.237301 Z12 E14081.744891 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X215.142312 Y231.503275 Z12 E14085.890895 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X214.173679 Y231.739204 Z12 E14090.035739 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X213.199186 Y231.950197 Z12 E14094.181085 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X212.216637 Y232.120686 Z12 E14098.327089 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X211.229206 Y232.258266 Z12 E14102.472006 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X210.238501 Y232.370443 Z12 E14106.617201 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X209.243972 Y232.443804 Z12 E14110.763206 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X208.247698 Y232.481645 Z12 E14114.908218 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X207.250767 Y232.493882 Z12 E14119.053285 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X206.253837 Y232.469408 Z12 E14123.199289 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X205.258764 Y232.407124 Z12 E14127.344418 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X204.265659 Y232.319302 Z12 E14131.48938 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X203.275928 Y232.19723 Z12 E14135.635384 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X202.292088 Y232.035441 Z12 E14139.780652 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X201.312821 Y231.848451 Z12 E14143.92553 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X200.339821 Y231.629956 Z12 E14148.071534 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X199.377134 Y231.370288 Z12 E14152.216963 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X198.421577 Y231.086017 Z12 E14156.361778 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X197.474679 Y230.773204 Z12 E14160.507782 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X196.542852 Y230.418266 Z12 E14164.653394 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X195.620638 Y230.039584 Z12 E14168.798169 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X194.70896 Y229.635465 Z12 E14172.944173 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X193.817391 Y229.188827 Z12 E14177.08999 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X192.937817 Y228.719551 Z12 E14181.234747 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X192.070336 Y228.22769 Z12 E14185.380712 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X191.227821 Y227.694174 Z12 E14189.526716 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X190.399754 Y227.139037 Z12 E14193.671477 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X189.586028 Y226.562674 Z12 E14197.817223 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X188.799864 Y225.949146 Z12 E14201.963227 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X188.031652 Y225.313744 Z12 E14206.108013 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X187.279879 Y224.658696 Z12 E14210.253561 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X186.557637 Y223.971065 Z12 E14214.399566 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X185.857027 Y223.261802 Z12 E14218.544399 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X185.174779 Y222.534682 Z12 E14222.689772 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X184.523415 Y221.77957 Z12 E14226.835776 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X183.897472 Y221.003595 Z12 E14230.980679 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X183.291623 Y220.211737 Z12 E14235.125899 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X182.717409 Y219.396416 Z12 E14239.271903 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X182.172447 Y218.56155 Z12 E14243.416897 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X181.649098 Y217.712942 Z12 E14247.561985 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X181.157565 Y216.845264 Z12 E14251.707989 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X180.699082 Y215.959921 Z12 E14255.853097 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X180.263506 Y215.063121 Z12 E14259.998075 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X179.859386 Y214.151443 Z12 E14264.144079 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X179.492009 Y213.224545 Z12 E14268.289322 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X179.148592 Y212.288597 Z12 E14272.434212 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.835779 Y211.341698 Z12 E14276.580216 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.563218 Y210.382589 Z12 E14280.725617 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.31542 Y209.416929 Z12 E14284.870441 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.096925 Y208.443928 Z12 E14289.016445 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.921936 Y207.462274 Z12 E14293.162025 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.772252 Y206.476639 Z12 E14297.306805 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.65018 Y205.486908 Z12 E14301.452809 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.574536 Y204.492604 Z12 E14305.598591 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.524473 Y203.496931 Z12 E14309.743349 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.5 Y202.5 Z12 E14313.889353 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.524473 Y201.503069 Z12 E14318.035357 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.574536 Y200.507396 Z12 E14322.180115 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.65018 Y199.513092 Z12 E14326.325896 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.772252 Y198.523361 Z12 E14330.471901 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X177.921936 Y197.537726 Z12 E14334.616681 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.096925 Y196.556072 Z12 E14338.762261 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.31542 Y195.583071 Z12 E14342.908265 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.563218 Y194.617411 Z12 E14347.053089 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X178.835779 Y193.658302 Z12 E14351.19849 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X179.148592 Y192.711403 Z12 E14355.344494 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X179.492009 Y191.775455 Z12 E14359.489384 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X179.859386 Y190.848557 Z12 E14363.634627 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X180.263506 Y189.936879 Z12 E14367.780631 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X180.699082 Y189.040079 Z12 E14371.925609 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X181.157565 Y188.154736 Z12 E14376.070717 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X181.649098 Y187.287058 Z12 E14380.216721 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X182.172447 Y186.43845 Z12 E14384.361809 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X182.717409 Y185.603584 Z12 E14388.506803 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X183.291623 Y184.788263 Z12 E14392.652807 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X183.897472 Y183.996405 Z12 E14396.798027 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X184.523415 Y183.22043 Z12 E14400.94293 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X185.174779 Y182.465318 Z12 E14405.088934 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X185.857027 Y181.738198 Z12 E14409.234307 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X186.557637 Y181.028935 Z12 E14413.37914 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X187.279879 Y180.341304 Z12 E14417.525144 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X188.031652 Y179.686256 Z12 E14421.670693 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X188.799864 Y179.050854 Z12 E14425.815479 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X189.586028 Y178.437326 Z12 E14429.961483 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X190.399754 Y177.860963 Z12 E14434.107229 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X191.227821 Y177.305826 Z12 E14438.251989 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X192.070336 Y176.77231 Z12 E14442.397994 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X192.937817 Y176.280449 Z12 E14446.543959 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X193.817391 Y175.811173 Z12 E14450.688716 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X194.70896 Y175.364535 Z12 E14454.834533 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X195.620638 Y174.960416 Z12 E14458.980537 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X196.542852 Y174.581734 Z12 E14463.125312 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X197.474679 Y174.226796 Z12 E14467.270924 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X198.421577 Y173.913983 Z12 E14471.416928 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X199.377134 Y173.629712 Z12 E14475.561743 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X200.339821 Y173.370044 Z12 E14479.707172 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X201.312821 Y173.151549 Z12 E14483.853176 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X202.292088 Y172.964559 Z12 E14487.998054 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X203.275928 Y172.80277 Z12 E14492.143322 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X204.265659 Y172.680698 Z12 E14496.289326 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X205.258764 Y172.592876 Z12 E14500.434287 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X206.253837 Y172.530592 Z12 E14504.579416 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X207.250767 Y172.506118 Z12 E14508.725421 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X208.247698 Y172.518355 Z12 E14512.870488 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X209.243972 Y172.556196 Z12 E14517.0155 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X210.238501 Y172.629557 Z12 E14521.161504 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X211.229206 Y172.741734 Z12 E14525.3067 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X212.216637 Y172.879314 Z12 E14529.451617 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X213.199186 Y173.049803 Z12 E14533.597621 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X214.173679 Y173.260796 Z12 E14537.742967 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X215.142312 Y173.496725 Z12 E14541.887811 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X216.103419 Y173.762699 Z12 E14546.033815 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X217.051872 Y174.070389 Z12 E14550.179332 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X217.991943 Y174.402284 Z12 E14554.324125 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X218.922352 Y174.761183 Z12 E14558.470129 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X219.835201 Y175.162476 Z12 E14562.615841 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X220.737233 Y175.58699 Z12 E14566.760604 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X221.627984 Y176.035356 Z12 E14570.906608 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X222.496022 Y176.526215 Z12 E14575.052535 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X223.350921 Y177.039068 Z12 E14579.197291 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X224.192586 Y177.573856 Z12 E14583.343144 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X225.007907 Y178.14807 Z12 E14587.489148 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X225.807054 Y178.74409 Z12 E14591.633919 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X226.590792 Y179.360574 Z12 E14595.779563 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X227.345904 Y180.011938 Z12 E14599.925567 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X228.081242 Y180.685119 Z12 E14604.070374 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X228.799157 Y181.377077 Z12 E14608.215832 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X229.486788 Y182.099318 Z12 E14612.361836 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X230.150903 Y182.842874 Z12 E14616.506702 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X230.795764 Y183.603323 Z12 E14620.651995 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X231.409292 Y184.389487 Z12 E14624.797999 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X231.995484 Y185.195924 Z12 E14628.942946 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X232.560795 Y186.017193 Z12 E14633.088096 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X233.094311 Y186.859707 Z12 E14637.2341 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X233.596668 Y187.720897 Z12 E14641.379149 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X234.076735 Y188.594704 Z12 E14645.524179 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X234.525102 Y189.485454 Z12 E14649.670183 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X234.938554 Y190.392718 Z12 E14653.815356 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X235.328542 Y191.31025 Z12 E14657.960287 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X235.68744 Y192.240659 Z12 E14662.106291 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.007814 Y193.184853 Z12 E14666.25161 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.303795 Y194.136858 Z12 E14670.396465 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.569769 Y195.097965 Z12 E14674.542469 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.793827 Y196.069571 Z12 E14678.687956 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X236.992819 Y197.046451 Z12 E14682.832756 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.163308 Y198.029 Z12 E14686.97876 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.288784 Y199.018227 Z12 E14691.124438 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.388783 Y200.010132 Z12 E14695.269204 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.462144 Y201.004661 Z12 E14699.415208 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
G1 X237.487763 Y202.001535 Z12 E14703.561098 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00011-layer-00005-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=5 id=weave-00011-layer-00005-island-000
G0 X237.487763 Y202.001535 Z16 F2400 ; clayline kind=travel_lift page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave paste-safe lift
G0 X237.487763 Y202.001535 Z14 F2400 ; clayline kind=travel_approach page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=6 id=weave-00012-layer-00006-island-000
G1 X237.487763 Y202.998465 Z14 E14707.705854 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.462144 Y203.995339 Z14 E14711.851744 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.388783 Y204.989868 Z14 E14715.997748 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.288784 Y205.981773 Z14 E14720.142514 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.163308 Y206.971 Z14 E14724.288192 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.992819 Y207.953549 Z14 E14728.434196 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.793827 Y208.930429 Z14 E14732.578996 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.569769 Y209.902035 Z14 E14736.724483 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.303795 Y210.863142 Z14 E14740.870487 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.007814 Y211.815147 Z14 E14745.015341 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X235.68744 Y212.759341 Z14 E14749.160661 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X235.328542 Y213.68975 Z14 E14753.306665 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X234.938554 Y214.607282 Z14 E14757.451596 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X234.525102 Y215.514546 Z14 E14761.596769 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X234.076735 Y216.405296 Z14 E14765.742773 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X233.596668 Y217.279103 Z14 E14769.887803 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X233.094311 Y218.140293 Z14 E14774.032851 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X232.560795 Y218.982807 Z14 E14778.178856 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X231.995484 Y219.804076 Z14 E14782.324006 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X231.409292 Y220.610513 Z14 E14786.468952 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X230.795764 Y221.396677 Z14 E14790.614957 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X230.150903 Y222.157126 Z14 E14794.76025 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X229.486788 Y222.900682 Z14 E14798.905115 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X228.799157 Y223.622923 Z14 E14803.05112 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X228.081242 Y224.314881 Z14 E14807.196578 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X227.345904 Y224.988062 Z14 E14811.341385 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X226.590792 Y225.639426 Z14 E14815.487389 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X225.807054 Y226.25591 Z14 E14819.633033 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X225.007907 Y226.85193 Z14 E14823.777804 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X224.192586 Y227.426144 Z14 E14827.923808 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X223.350921 Y227.960932 Z14 E14832.069661 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X222.496022 Y228.473785 Z14 E14836.214417 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X221.627984 Y228.964644 Z14 E14840.360344 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X220.737233 Y229.41301 Z14 E14844.506348 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X219.835201 Y229.837524 Z14 E14848.651111 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X218.922352 Y230.238817 Z14 E14852.796823 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X217.991943 Y230.597716 Z14 E14856.942827 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X217.051872 Y230.929611 Z14 E14861.087619 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X216.103419 Y231.237301 Z14 E14865.233137 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X215.142312 Y231.503275 Z14 E14869.379141 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X214.173679 Y231.739204 Z14 E14873.523985 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X213.199186 Y231.950197 Z14 E14877.669331 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X212.216637 Y232.120686 Z14 E14881.815335 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X211.229206 Y232.258266 Z14 E14885.960252 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X210.238501 Y232.370443 Z14 E14890.105447 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X209.243972 Y232.443804 Z14 E14894.251452 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X208.247698 Y232.481645 Z14 E14898.396463 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X207.250767 Y232.493882 Z14 E14902.541531 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X206.253837 Y232.469408 Z14 E14906.687535 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X205.258764 Y232.407124 Z14 E14910.832664 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X204.265659 Y232.319302 Z14 E14914.977626 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X203.275928 Y232.19723 Z14 E14919.12363 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X202.292088 Y232.035441 Z14 E14923.268898 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X201.312821 Y231.848451 Z14 E14927.413776 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X200.339821 Y231.629956 Z14 E14931.55978 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X199.377134 Y231.370288 Z14 E14935.705209 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X198.421577 Y231.086017 Z14 E14939.850024 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X197.474679 Y230.773204 Z14 E14943.996028 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X196.542852 Y230.418266 Z14 E14948.14164 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X195.620638 Y230.039584 Z14 E14952.286415 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X194.70896 Y229.635465 Z14 E14956.432419 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X193.817391 Y229.188827 Z14 E14960.578236 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X192.937817 Y228.719551 Z14 E14964.722993 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X192.070336 Y228.22769 Z14 E14968.868958 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X191.227821 Y227.694174 Z14 E14973.014962 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X190.399754 Y227.139037 Z14 E14977.159723 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X189.586028 Y226.562674 Z14 E14981.305469 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X188.799864 Y225.949146 Z14 E14985.451473 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X188.031652 Y225.313744 Z14 E14989.596259 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X187.279879 Y224.658696 Z14 E14993.741807 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X186.557637 Y223.971065 Z14 E14997.887812 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X185.857027 Y223.261802 Z14 E15002.032645 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X185.174779 Y222.534682 Z14 E15006.178018 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X184.523415 Y221.77957 Z14 E15010.324022 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X183.897472 Y221.003595 Z14 E15014.468925 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X183.291623 Y220.211737 Z14 E15018.614144 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X182.717409 Y219.396416 Z14 E15022.760149 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X182.172447 Y218.56155 Z14 E15026.905143 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X181.649098 Y217.712942 Z14 E15031.050231 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X181.157565 Y216.845264 Z14 E15035.196235 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X180.699082 Y215.959921 Z14 E15039.341343 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X180.263506 Y215.063121 Z14 E15043.486321 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X179.859386 Y214.151443 Z14 E15047.632325 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X179.492009 Y213.224545 Z14 E15051.777568 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X179.148592 Y212.288597 Z14 E15055.922458 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.835779 Y211.341698 Z14 E15060.068462 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.563218 Y210.382589 Z14 E15064.213863 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.31542 Y209.416929 Z14 E15068.358687 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.096925 Y208.443928 Z14 E15072.504691 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.921936 Y207.462274 Z14 E15076.650271 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.772252 Y206.476639 Z14 E15080.795051 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.65018 Y205.486908 Z14 E15084.941055 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.574536 Y204.492604 Z14 E15089.086836 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.524473 Y203.496931 Z14 E15093.231595 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.5 Y202.5 Z14 E15097.377599 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.524473 Y201.503069 Z14 E15101.523603 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.574536 Y200.507396 Z14 E15105.668361 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.65018 Y199.513092 Z14 E15109.814142 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.772252 Y198.523361 Z14 E15113.960147 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X177.921936 Y197.537726 Z14 E15118.104927 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.096925 Y196.556072 Z14 E15122.250507 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.31542 Y195.583071 Z14 E15126.396511 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.563218 Y194.617411 Z14 E15130.541335 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X178.835779 Y193.658302 Z14 E15134.686736 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X179.148592 Y192.711403 Z14 E15138.83274 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X179.492009 Y191.775455 Z14 E15142.97763 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X179.859386 Y190.848557 Z14 E15147.122873 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X180.263506 Y189.936879 Z14 E15151.268877 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X180.699082 Y189.040079 Z14 E15155.413855 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X181.157565 Y188.154736 Z14 E15159.558963 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X181.649098 Y187.287058 Z14 E15163.704967 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X182.172447 Y186.43845 Z14 E15167.850055 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X182.717409 Y185.603584 Z14 E15171.995049 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X183.291623 Y184.788263 Z14 E15176.141053 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X183.897472 Y183.996405 Z14 E15180.286273 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X184.523415 Y183.22043 Z14 E15184.431176 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X185.174779 Y182.465318 Z14 E15188.57718 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X185.857027 Y181.738198 Z14 E15192.722553 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X186.557637 Y181.028935 Z14 E15196.867386 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X187.279879 Y180.341304 Z14 E15201.01339 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X188.031652 Y179.686256 Z14 E15205.158939 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X188.799864 Y179.050854 Z14 E15209.303725 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X189.586028 Y178.437326 Z14 E15213.449729 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X190.399754 Y177.860963 Z14 E15217.595475 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X191.227821 Y177.305826 Z14 E15221.740235 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X192.070336 Y176.77231 Z14 E15225.88624 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X192.937817 Y176.280449 Z14 E15230.032205 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X193.817391 Y175.811173 Z14 E15234.176962 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X194.70896 Y175.364535 Z14 E15238.322778 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X195.620638 Y174.960416 Z14 E15242.468783 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X196.542852 Y174.581734 Z14 E15246.613558 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X197.474679 Y174.226796 Z14 E15250.75917 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X198.421577 Y173.913983 Z14 E15254.905174 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X199.377134 Y173.629712 Z14 E15259.049989 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X200.339821 Y173.370044 Z14 E15263.195418 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X201.312821 Y173.151549 Z14 E15267.341422 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X202.292088 Y172.964559 Z14 E15271.4863 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X203.275928 Y172.80277 Z14 E15275.631568 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X204.265659 Y172.680698 Z14 E15279.777572 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X205.258764 Y172.592876 Z14 E15283.922533 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X206.253837 Y172.530592 Z14 E15288.067662 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X207.250767 Y172.506118 Z14 E15292.213667 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X208.247698 Y172.518355 Z14 E15296.358734 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X209.243972 Y172.556196 Z14 E15300.503746 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X210.238501 Y172.629557 Z14 E15304.64975 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X211.229206 Y172.741734 Z14 E15308.794946 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X212.216637 Y172.879314 Z14 E15312.939863 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X213.199186 Y173.049803 Z14 E15317.085867 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X214.173679 Y173.260796 Z14 E15321.231213 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X215.142312 Y173.496725 Z14 E15325.376056 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X216.103419 Y173.762699 Z14 E15329.522061 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X217.051872 Y174.070389 Z14 E15333.667578 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X217.991943 Y174.402284 Z14 E15337.812371 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X218.922352 Y174.761183 Z14 E15341.958375 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X219.835201 Y175.162476 Z14 E15346.104086 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X220.737233 Y175.58699 Z14 E15350.24885 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X221.627984 Y176.035356 Z14 E15354.394854 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X222.496022 Y176.526215 Z14 E15358.540781 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X223.350921 Y177.039068 Z14 E15362.685537 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X224.192586 Y177.573856 Z14 E15366.83139 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X225.007907 Y178.14807 Z14 E15370.977394 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X225.807054 Y178.74409 Z14 E15375.122165 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X226.590792 Y179.360574 Z14 E15379.267809 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X227.345904 Y180.011938 Z14 E15383.413813 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X228.081242 Y180.685119 Z14 E15387.55862 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X228.799157 Y181.377077 Z14 E15391.704078 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X229.486788 Y182.099318 Z14 E15395.850082 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X230.150903 Y182.842874 Z14 E15399.994948 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X230.795764 Y183.603323 Z14 E15404.140241 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X231.409292 Y184.389487 Z14 E15408.286245 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X231.995484 Y185.195924 Z14 E15412.431191 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X232.560795 Y186.017193 Z14 E15416.576342 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X233.094311 Y186.859707 Z14 E15420.722346 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X233.596668 Y187.720897 Z14 E15424.867395 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X234.076735 Y188.594704 Z14 E15429.012425 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X234.525102 Y189.485454 Z14 E15433.158429 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X234.938554 Y190.392718 Z14 E15437.303602 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X235.328542 Y191.31025 Z14 E15441.448533 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X235.68744 Y192.240659 Z14 E15445.594537 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.007814 Y193.184853 Z14 E15449.739856 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.303795 Y194.136858 Z14 E15453.884711 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.569769 Y195.097965 Z14 E15458.030715 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.793827 Y196.069571 Z14 E15462.176202 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X236.992819 Y197.046451 Z14 E15466.321002 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.163308 Y198.029 Z14 E15470.467006 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.288784 Y199.018227 Z14 E15474.612684 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.388783 Y200.010132 Z14 E15478.75745 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.462144 Y201.004661 Z14 E15482.903454 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
G1 X237.487763 Y202.001535 Z14 E15487.049344 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00012-layer-00006-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=6 id=weave-00012-layer-00006-island-000
G0 X237.487763 Y202.001535 Z16 F2400 ; clayline kind=travel_lift page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z16 F2400 ; clayline kind=travel_xy page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave paste-safe traverse
G0 X222.487828 Y202.004158 Z14 F2400 ; clayline kind=travel_approach page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=6 id=weave-00013-layer-00006-island-001
G1 X222.487828 Y202.995842 Z14 E15491.172285 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z14 E15495.295442 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z14 E15499.418638 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z14 E15503.541584 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z14 E15507.66462 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z14 E15511.787751 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z14 E15515.910711 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z14 E15520.033665 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z14 E15524.15674 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z14 E15528.279724 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z14 E15532.402634 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z14 E15536.525663 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z14 E15540.648681 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z14 E15544.771587 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z14 E15548.894579 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z14 E15553.017641 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z14 E15557.14058 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z14 E15561.263546 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z14 E15565.386661 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z14 E15569.509673 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z14 E15573.632622 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z14 E15577.755801 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z14 E15581.878924 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z14 E15586.001865 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z14 E15590.125059 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z14 E15594.248273 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z14 E15598.371216 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z14 E15602.494279 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z14 E15606.617425 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z14 E15610.740381 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z14 E15614.863352 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z14 E15618.986439 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z14 E15623.109417 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z14 E15627.232334 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z14 E15631.355374 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z14 E15635.478383 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z14 E15639.601285 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z14 E15643.724286 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z14 E15647.847336 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z14 E15651.970263 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z14 E15656.093235 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z14 E15660.216336 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z14 E15664.339326 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z14 E15668.462278 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z14 E15672.58544 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z14 E15676.708532 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z14 E15680.831474 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X192.5 Y202.5 Z14 E15684.954706 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z14 E15689.077939 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z14 E15693.200881 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z14 E15697.323973 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z14 E15701.447135 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z14 E15705.570087 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z14 E15709.693077 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z14 E15713.816178 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z14 E15717.93915 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z14 E15722.062077 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z14 E15726.185127 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z14 E15730.308127 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z14 E15734.43103 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z14 E15738.554039 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z14 E15742.677079 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z14 E15746.799996 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z14 E15750.922974 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z14 E15755.046061 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z14 E15759.169032 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z14 E15763.291988 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z14 E15767.415134 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z14 E15771.538196 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z14 E15775.66114 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z14 E15779.784354 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z14 E15783.907548 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z14 E15788.030489 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z14 E15792.153612 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z14 E15796.276791 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z14 E15800.39974 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z14 E15804.522751 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z14 E15808.645867 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z14 E15812.768833 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z14 E15816.891772 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z14 E15821.014834 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z14 E15825.137826 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z14 E15829.260731 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z14 E15833.38375 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z14 E15837.506779 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z14 E15841.629689 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z14 E15845.752673 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z14 E15849.875748 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z14 E15853.998702 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z14 E15858.121662 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z14 E15862.244793 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z14 E15866.367829 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z14 E15870.490774 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z14 E15874.613971 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z14 E15878.737128 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00013-layer-00006-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=6 id=weave-00013-layer-00006-island-001
G0 X222.487828 Y202.004158 Z18 F2400 ; clayline kind=travel_lift page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z16 F2400 ; clayline kind=travel_approach page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=7 id=weave-00014-layer-00007-island-001
G1 X222.487828 Y202.995842 Z16 E15882.860069 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z16 E15886.983226 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z16 E15891.106422 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z16 E15895.229368 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z16 E15899.352404 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z16 E15903.475535 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z16 E15907.598495 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z16 E15911.721449 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z16 E15915.844523 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z16 E15919.967508 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z16 E15924.090418 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z16 E15928.213447 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z16 E15932.336465 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z16 E15936.45937 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z16 E15940.582362 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z16 E15944.705425 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z16 E15948.828364 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z16 E15952.951329 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z16 E15957.074445 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z16 E15961.197457 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z16 E15965.320405 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z16 E15969.443584 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z16 E15973.566708 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z16 E15977.689649 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z16 E15981.812842 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z16 E15985.936056 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z16 E15990.059 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z16 E15994.182063 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z16 E15998.305209 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z16 E16002.428165 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z16 E16006.551135 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z16 E16010.674223 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z16 E16014.797201 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z16 E16018.920118 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z16 E16023.043157 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z16 E16027.166166 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z16 E16031.289069 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z16 E16035.41207 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z16 E16039.53512 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z16 E16043.658047 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z16 E16047.781018 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z16 E16051.90412 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z16 E16056.02711 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z16 E16060.150062 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z16 E16064.273224 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z16 E16068.396315 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z16 E16072.519258 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X192.5 Y202.5 Z16 E16076.64249 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z16 E16080.765723 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z16 E16084.888665 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z16 E16089.011757 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z16 E16093.134919 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z16 E16097.257871 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z16 E16101.380861 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z16 E16105.503962 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z16 E16109.626933 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z16 E16113.74986 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z16 E16117.872911 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z16 E16121.995911 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z16 E16126.118814 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z16 E16130.241823 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z16 E16134.364862 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z16 E16138.48778 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z16 E16142.610757 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z16 E16146.733845 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z16 E16150.856816 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z16 E16154.979771 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z16 E16159.102917 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z16 E16163.22598 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z16 E16167.348924 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z16 E16171.472138 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z16 E16175.595331 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z16 E16179.718273 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z16 E16183.841396 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z16 E16187.964575 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z16 E16192.087523 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z16 E16196.210535 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z16 E16200.333651 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z16 E16204.456616 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z16 E16208.579555 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z16 E16212.702618 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z16 E16216.82561 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z16 E16220.948515 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z16 E16225.071534 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z16 E16229.194562 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z16 E16233.317472 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z16 E16237.440457 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z16 E16241.563532 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z16 E16245.686485 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z16 E16249.809446 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z16 E16253.932576 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z16 E16258.055612 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z16 E16262.178558 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z16 E16266.301754 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z16 E16270.424911 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00014-layer-00007-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=7 id=weave-00014-layer-00007-island-001
G0 X222.487828 Y202.004158 Z18 F2400 ; clayline kind=travel_lift page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave paste-safe lift
G0 X237.487763 Y202.001535 Z18 F2400 ; clayline kind=travel_xy page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave paste-safe traverse
G0 X237.487763 Y202.001535 Z16 F2400 ; clayline kind=travel_approach page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=7 id=weave-00015-layer-00007-island-000
G1 X237.487763 Y202.998465 Z16 E16274.569667 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.462144 Y203.995339 Z16 E16278.715557 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.388783 Y204.989868 Z16 E16282.861561 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.288784 Y205.981773 Z16 E16287.006328 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.163308 Y206.971 Z16 E16291.152005 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.992819 Y207.953549 Z16 E16295.298009 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.793827 Y208.930429 Z16 E16299.442809 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.569769 Y209.902035 Z16 E16303.588296 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.303795 Y210.863142 Z16 E16307.734301 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.007814 Y211.815147 Z16 E16311.879155 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X235.68744 Y212.759341 Z16 E16316.024474 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X235.328542 Y213.68975 Z16 E16320.170478 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X234.938554 Y214.607282 Z16 E16324.315409 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X234.525102 Y215.514546 Z16 E16328.460582 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X234.076735 Y216.405296 Z16 E16332.606586 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X233.596668 Y217.279103 Z16 E16336.751616 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X233.094311 Y218.140293 Z16 E16340.896665 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X232.560795 Y218.982807 Z16 E16345.042669 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X231.995484 Y219.804076 Z16 E16349.18782 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X231.409292 Y220.610513 Z16 E16353.332766 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X230.795764 Y221.396677 Z16 E16357.47877 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X230.150903 Y222.157126 Z16 E16361.624063 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X229.486788 Y222.900682 Z16 E16365.768929 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X228.799157 Y223.622923 Z16 E16369.914933 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X228.081242 Y224.314881 Z16 E16374.060391 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X227.345904 Y224.988062 Z16 E16378.205198 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X226.590792 Y225.639426 Z16 E16382.351202 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X225.807054 Y226.25591 Z16 E16386.496847 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X225.007907 Y226.85193 Z16 E16390.641617 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X224.192586 Y227.426144 Z16 E16394.787621 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X223.350921 Y227.960932 Z16 E16398.933474 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X222.496022 Y228.473785 Z16 E16403.07823 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X221.627984 Y228.964644 Z16 E16407.224157 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X220.737233 Y229.41301 Z16 E16411.370162 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X219.835201 Y229.837524 Z16 E16415.514925 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X218.922352 Y230.238817 Z16 E16419.660636 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X217.991943 Y230.597716 Z16 E16423.80664 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X217.051872 Y230.929611 Z16 E16427.951433 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X216.103419 Y231.237301 Z16 E16432.09695 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X215.142312 Y231.503275 Z16 E16436.242955 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X214.173679 Y231.739204 Z16 E16440.387798 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X213.199186 Y231.950197 Z16 E16444.533144 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X212.216637 Y232.120686 Z16 E16448.679148 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X211.229206 Y232.258266 Z16 E16452.824065 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X210.238501 Y232.370443 Z16 E16456.969261 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X209.243972 Y232.443804 Z16 E16461.115265 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X208.247698 Y232.481645 Z16 E16465.260277 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X207.250767 Y232.493882 Z16 E16469.405345 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X206.253837 Y232.469408 Z16 E16473.551349 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X205.258764 Y232.407124 Z16 E16477.696478 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X204.265659 Y232.319302 Z16 E16481.841439 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X203.275928 Y232.19723 Z16 E16485.987443 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X202.292088 Y232.035441 Z16 E16490.132711 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X201.312821 Y231.848451 Z16 E16494.277589 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X200.339821 Y231.629956 Z16 E16498.423593 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X199.377134 Y231.370288 Z16 E16502.569022 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X198.421577 Y231.086017 Z16 E16506.713837 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X197.474679 Y230.773204 Z16 E16510.859842 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X196.542852 Y230.418266 Z16 E16515.005453 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X195.620638 Y230.039584 Z16 E16519.150228 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X194.70896 Y229.635465 Z16 E16523.296233 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X193.817391 Y229.188827 Z16 E16527.442049 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X192.937817 Y228.719551 Z16 E16531.586806 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X192.070336 Y228.22769 Z16 E16535.732772 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X191.227821 Y227.694174 Z16 E16539.878776 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X190.399754 Y227.139037 Z16 E16544.023536 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X189.586028 Y226.562674 Z16 E16548.169282 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X188.799864 Y225.949146 Z16 E16552.315286 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X188.031652 Y225.313744 Z16 E16556.460072 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X187.279879 Y224.658696 Z16 E16560.605621 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X186.557637 Y223.971065 Z16 E16564.751625 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X185.857027 Y223.261802 Z16 E16568.896458 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X185.174779 Y222.534682 Z16 E16573.041831 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X184.523415 Y221.77957 Z16 E16577.187836 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X183.897472 Y221.003595 Z16 E16581.332739 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X183.291623 Y220.211737 Z16 E16585.477958 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X182.717409 Y219.396416 Z16 E16589.623962 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X182.172447 Y218.56155 Z16 E16593.768957 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X181.649098 Y217.712942 Z16 E16597.914044 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X181.157565 Y216.845264 Z16 E16602.060048 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X180.699082 Y215.959921 Z16 E16606.205156 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X180.263506 Y215.063121 Z16 E16610.350134 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X179.859386 Y214.151443 Z16 E16614.496138 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X179.492009 Y213.224545 Z16 E16618.641381 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X179.148592 Y212.288597 Z16 E16622.786271 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.835779 Y211.341698 Z16 E16626.932276 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.563218 Y210.382589 Z16 E16631.077676 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.31542 Y209.416929 Z16 E16635.2225 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.096925 Y208.443928 Z16 E16639.368504 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.921936 Y207.462274 Z16 E16643.514084 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.772252 Y206.476639 Z16 E16647.658865 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.65018 Y205.486908 Z16 E16651.804869 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.574536 Y204.492604 Z16 E16655.95065 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.524473 Y203.496931 Z16 E16660.095408 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.5 Y202.5 Z16 E16664.241412 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.524473 Y201.503069 Z16 E16668.387416 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.574536 Y200.507396 Z16 E16672.532175 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.65018 Y199.513092 Z16 E16676.677956 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.772252 Y198.523361 Z16 E16680.82396 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X177.921936 Y197.537726 Z16 E16684.96874 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.096925 Y196.556072 Z16 E16689.11432 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.31542 Y195.583071 Z16 E16693.260324 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.563218 Y194.617411 Z16 E16697.405148 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X178.835779 Y193.658302 Z16 E16701.550549 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X179.148592 Y192.711403 Z16 E16705.696553 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X179.492009 Y191.775455 Z16 E16709.841443 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X179.859386 Y190.848557 Z16 E16713.986686 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X180.263506 Y189.936879 Z16 E16718.13269 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X180.699082 Y189.040079 Z16 E16722.277668 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X181.157565 Y188.154736 Z16 E16726.422776 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X181.649098 Y187.287058 Z16 E16730.56878 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X182.172447 Y186.43845 Z16 E16734.713868 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X182.717409 Y185.603584 Z16 E16738.858862 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X183.291623 Y184.788263 Z16 E16743.004867 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X183.897472 Y183.996405 Z16 E16747.150086 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X184.523415 Y183.22043 Z16 E16751.294989 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X185.174779 Y182.465318 Z16 E16755.440993 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X185.857027 Y181.738198 Z16 E16759.586366 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X186.557637 Y181.028935 Z16 E16763.7312 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X187.279879 Y180.341304 Z16 E16767.877204 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X188.031652 Y179.686256 Z16 E16772.022752 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X188.799864 Y179.050854 Z16 E16776.167538 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X189.586028 Y178.437326 Z16 E16780.313542 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X190.399754 Y177.860963 Z16 E16784.459288 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X191.227821 Y177.305826 Z16 E16788.604049 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X192.070336 Y176.77231 Z16 E16792.750053 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X192.937817 Y176.280449 Z16 E16796.896018 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X193.817391 Y175.811173 Z16 E16801.040775 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X194.70896 Y175.364535 Z16 E16805.186592 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X195.620638 Y174.960416 Z16 E16809.332596 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X196.542852 Y174.581734 Z16 E16813.477371 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X197.474679 Y174.226796 Z16 E16817.622983 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X198.421577 Y173.913983 Z16 E16821.768987 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X199.377134 Y173.629712 Z16 E16825.913802 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X200.339821 Y173.370044 Z16 E16830.059231 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X201.312821 Y173.151549 Z16 E16834.205235 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X202.292088 Y172.964559 Z16 E16838.350113 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X203.275928 Y172.80277 Z16 E16842.495381 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X204.265659 Y172.680698 Z16 E16846.641385 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X205.258764 Y172.592876 Z16 E16850.786347 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X206.253837 Y172.530592 Z16 E16854.931476 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X207.250767 Y172.506118 Z16 E16859.07748 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X208.247698 Y172.518355 Z16 E16863.222548 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X209.243972 Y172.556196 Z16 E16867.36756 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X210.238501 Y172.629557 Z16 E16871.513564 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X211.229206 Y172.741734 Z16 E16875.658759 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X212.216637 Y172.879314 Z16 E16879.803676 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X213.199186 Y173.049803 Z16 E16883.94968 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X214.173679 Y173.260796 Z16 E16888.095026 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X215.142312 Y173.496725 Z16 E16892.23987 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X216.103419 Y173.762699 Z16 E16896.385874 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X217.051872 Y174.070389 Z16 E16900.531392 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X217.991943 Y174.402284 Z16 E16904.676184 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X218.922352 Y174.761183 Z16 E16908.822188 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X219.835201 Y175.162476 Z16 E16912.9679 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X220.737233 Y175.58699 Z16 E16917.112663 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X221.627984 Y176.035356 Z16 E16921.258667 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X222.496022 Y176.526215 Z16 E16925.404594 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X223.350921 Y177.039068 Z16 E16929.54935 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X224.192586 Y177.573856 Z16 E16933.695203 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X225.007907 Y178.14807 Z16 E16937.841207 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X225.807054 Y178.74409 Z16 E16941.985978 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X226.590792 Y179.360574 Z16 E16946.131622 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X227.345904 Y180.011938 Z16 E16950.277627 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X228.081242 Y180.685119 Z16 E16954.422434 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X228.799157 Y181.377077 Z16 E16958.567892 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X229.486788 Y182.099318 Z16 E16962.713896 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X230.150903 Y182.842874 Z16 E16966.858761 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X230.795764 Y183.603323 Z16 E16971.004055 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X231.409292 Y184.389487 Z16 E16975.150059 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X231.995484 Y185.195924 Z16 E16979.295005 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X232.560795 Y186.017193 Z16 E16983.440155 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X233.094311 Y186.859707 Z16 E16987.58616 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X233.596668 Y187.720897 Z16 E16991.731208 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X234.076735 Y188.594704 Z16 E16995.876238 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X234.525102 Y189.485454 Z16 E17000.022242 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X234.938554 Y190.392718 Z16 E17004.167415 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X235.328542 Y191.31025 Z16 E17008.312346 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X235.68744 Y192.240659 Z16 E17012.45835 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.007814 Y193.184853 Z16 E17016.60367 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.303795 Y194.136858 Z16 E17020.748524 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.569769 Y195.097965 Z16 E17024.894528 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.793827 Y196.069571 Z16 E17029.040016 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X236.992819 Y197.046451 Z16 E17033.184815 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.163308 Y198.029 Z16 E17037.330819 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.288784 Y199.018227 Z16 E17041.476497 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.388783 Y200.010132 Z16 E17045.621263 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.462144 Y201.004661 Z16 E17049.767268 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
G1 X237.487763 Y202.001535 Z16 E17053.913157 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00015-layer-00007-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=7 id=weave-00015-layer-00007-island-000
G0 X237.487763 Y202.001535 Z20 F2400 ; clayline kind=travel_lift page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave paste-safe lift
G0 X237.487763 Y202.001535 Z18 F2400 ; clayline kind=travel_approach page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=8 id=weave-00016-layer-00008-island-000
G1 X237.487763 Y202.998465 Z18 E17058.057913 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.462144 Y203.995339 Z18 E17062.203803 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.388783 Y204.989868 Z18 E17066.349807 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.288784 Y205.981773 Z18 E17070.494573 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.163308 Y206.971 Z18 E17074.640251 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.992819 Y207.953549 Z18 E17078.786255 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.793827 Y208.930429 Z18 E17082.931055 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.569769 Y209.902035 Z18 E17087.076542 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.303795 Y210.863142 Z18 E17091.222546 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.007814 Y211.815147 Z18 E17095.367401 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X235.68744 Y212.759341 Z18 E17099.51272 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X235.328542 Y213.68975 Z18 E17103.658724 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X234.938554 Y214.607282 Z18 E17107.803655 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X234.525102 Y215.514546 Z18 E17111.948828 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X234.076735 Y216.405296 Z18 E17116.094832 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X233.596668 Y217.279103 Z18 E17120.239862 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X233.094311 Y218.140293 Z18 E17124.384911 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X232.560795 Y218.982807 Z18 E17128.530915 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X231.995484 Y219.804076 Z18 E17132.676066 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X231.409292 Y220.610513 Z18 E17136.821012 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X230.795764 Y221.396677 Z18 E17140.967016 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X230.150903 Y222.157126 Z18 E17145.112309 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X229.486788 Y222.900682 Z18 E17149.257175 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X228.799157 Y223.622923 Z18 E17153.403179 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X228.081242 Y224.314881 Z18 E17157.548637 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X227.345904 Y224.988062 Z18 E17161.693444 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X226.590792 Y225.639426 Z18 E17165.839448 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X225.807054 Y226.25591 Z18 E17169.985092 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X225.007907 Y226.85193 Z18 E17174.129863 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X224.192586 Y227.426144 Z18 E17178.275867 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X223.350921 Y227.960932 Z18 E17182.42172 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X222.496022 Y228.473785 Z18 E17186.566476 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X221.627984 Y228.964644 Z18 E17190.712403 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X220.737233 Y229.41301 Z18 E17194.858407 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X219.835201 Y229.837524 Z18 E17199.003171 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X218.922352 Y230.238817 Z18 E17203.148882 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X217.991943 Y230.597716 Z18 E17207.294886 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X217.051872 Y230.929611 Z18 E17211.439679 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X216.103419 Y231.237301 Z18 E17215.585196 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X215.142312 Y231.503275 Z18 E17219.731201 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X214.173679 Y231.739204 Z18 E17223.876044 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X213.199186 Y231.950197 Z18 E17228.02139 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X212.216637 Y232.120686 Z18 E17232.167394 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X211.229206 Y232.258266 Z18 E17236.312311 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X210.238501 Y232.370443 Z18 E17240.457507 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X209.243972 Y232.443804 Z18 E17244.603511 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X208.247698 Y232.481645 Z18 E17248.748523 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X207.250767 Y232.493882 Z18 E17252.89359 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X206.253837 Y232.469408 Z18 E17257.039595 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X205.258764 Y232.407124 Z18 E17261.184724 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X204.265659 Y232.319302 Z18 E17265.329685 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X203.275928 Y232.19723 Z18 E17269.475689 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X202.292088 Y232.035441 Z18 E17273.620957 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X201.312821 Y231.848451 Z18 E17277.765835 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X200.339821 Y231.629956 Z18 E17281.911839 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X199.377134 Y231.370288 Z18 E17286.057268 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X198.421577 Y231.086017 Z18 E17290.202083 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X197.474679 Y230.773204 Z18 E17294.348087 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X196.542852 Y230.418266 Z18 E17298.493699 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X195.620638 Y230.039584 Z18 E17302.638474 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X194.70896 Y229.635465 Z18 E17306.784479 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X193.817391 Y229.188827 Z18 E17310.930295 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X192.937817 Y228.719551 Z18 E17315.075052 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X192.070336 Y228.22769 Z18 E17319.221017 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X191.227821 Y227.694174 Z18 E17323.367022 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X190.399754 Y227.139037 Z18 E17327.511782 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X189.586028 Y226.562674 Z18 E17331.657528 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X188.799864 Y225.949146 Z18 E17335.803532 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X188.031652 Y225.313744 Z18 E17339.948318 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X187.279879 Y224.658696 Z18 E17344.093867 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X186.557637 Y223.971065 Z18 E17348.239871 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X185.857027 Y223.261802 Z18 E17352.384704 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X185.174779 Y222.534682 Z18 E17356.530077 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X184.523415 Y221.77957 Z18 E17360.676081 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X183.897472 Y221.003595 Z18 E17364.820985 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X183.291623 Y220.211737 Z18 E17368.966204 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X182.717409 Y219.396416 Z18 E17373.112208 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X182.172447 Y218.56155 Z18 E17377.257202 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X181.649098 Y217.712942 Z18 E17381.40229 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X181.157565 Y216.845264 Z18 E17385.548294 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X180.699082 Y215.959921 Z18 E17389.693402 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X180.263506 Y215.063121 Z18 E17393.83838 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X179.859386 Y214.151443 Z18 E17397.984384 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X179.492009 Y213.224545 Z18 E17402.129627 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X179.148592 Y212.288597 Z18 E17406.274517 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.835779 Y211.341698 Z18 E17410.420522 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.563218 Y210.382589 Z18 E17414.565922 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.31542 Y209.416929 Z18 E17418.710746 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.096925 Y208.443928 Z18 E17422.85675 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.921936 Y207.462274 Z18 E17427.00233 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.772252 Y206.476639 Z18 E17431.14711 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.65018 Y205.486908 Z18 E17435.293115 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.574536 Y204.492604 Z18 E17439.438896 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.524473 Y203.496931 Z18 E17443.583654 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.5 Y202.5 Z18 E17447.729658 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.524473 Y201.503069 Z18 E17451.875662 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.574536 Y200.507396 Z18 E17456.020421 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.65018 Y199.513092 Z18 E17460.166202 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.772252 Y198.523361 Z18 E17464.312206 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X177.921936 Y197.537726 Z18 E17468.456986 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.096925 Y196.556072 Z18 E17472.602566 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.31542 Y195.583071 Z18 E17476.74857 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.563218 Y194.617411 Z18 E17480.893394 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X178.835779 Y193.658302 Z18 E17485.038795 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X179.148592 Y192.711403 Z18 E17489.184799 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X179.492009 Y191.775455 Z18 E17493.329689 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X179.859386 Y190.848557 Z18 E17497.474932 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X180.263506 Y189.936879 Z18 E17501.620936 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X180.699082 Y189.040079 Z18 E17505.765914 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X181.157565 Y188.154736 Z18 E17509.911022 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X181.649098 Y187.287058 Z18 E17514.057026 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X182.172447 Y186.43845 Z18 E17518.202114 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X182.717409 Y185.603584 Z18 E17522.347108 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X183.291623 Y184.788263 Z18 E17526.493113 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X183.897472 Y183.996405 Z18 E17530.638332 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X184.523415 Y183.22043 Z18 E17534.783235 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X185.174779 Y182.465318 Z18 E17538.929239 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X185.857027 Y181.738198 Z18 E17543.074612 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X186.557637 Y181.028935 Z18 E17547.219445 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X187.279879 Y180.341304 Z18 E17551.36545 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X188.031652 Y179.686256 Z18 E17555.510998 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X188.799864 Y179.050854 Z18 E17559.655784 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X189.586028 Y178.437326 Z18 E17563.801788 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X190.399754 Y177.860963 Z18 E17567.947534 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X191.227821 Y177.305826 Z18 E17572.092295 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X192.070336 Y176.77231 Z18 E17576.238299 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X192.937817 Y176.280449 Z18 E17580.384264 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X193.817391 Y175.811173 Z18 E17584.529021 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X194.70896 Y175.364535 Z18 E17588.674838 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X195.620638 Y174.960416 Z18 E17592.820842 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X196.542852 Y174.581734 Z18 E17596.965617 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X197.474679 Y174.226796 Z18 E17601.111229 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X198.421577 Y173.913983 Z18 E17605.257233 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X199.377134 Y173.629712 Z18 E17609.402048 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X200.339821 Y173.370044 Z18 E17613.547477 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X201.312821 Y173.151549 Z18 E17617.693481 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X202.292088 Y172.964559 Z18 E17621.838359 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X203.275928 Y172.80277 Z18 E17625.983627 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X204.265659 Y172.680698 Z18 E17630.129631 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X205.258764 Y172.592876 Z18 E17634.274593 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X206.253837 Y172.530592 Z18 E17638.419722 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X207.250767 Y172.506118 Z18 E17642.565726 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X208.247698 Y172.518355 Z18 E17646.710794 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X209.243972 Y172.556196 Z18 E17650.855805 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X210.238501 Y172.629557 Z18 E17655.00181 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X211.229206 Y172.741734 Z18 E17659.147005 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X212.216637 Y172.879314 Z18 E17663.291922 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X213.199186 Y173.049803 Z18 E17667.437926 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X214.173679 Y173.260796 Z18 E17671.583272 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X215.142312 Y173.496725 Z18 E17675.728116 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X216.103419 Y173.762699 Z18 E17679.87412 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X217.051872 Y174.070389 Z18 E17684.019638 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X217.991943 Y174.402284 Z18 E17688.16443 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X218.922352 Y174.761183 Z18 E17692.310434 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X219.835201 Y175.162476 Z18 E17696.456146 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X220.737233 Y175.58699 Z18 E17700.600909 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X221.627984 Y176.035356 Z18 E17704.746913 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X222.496022 Y176.526215 Z18 E17708.89284 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X223.350921 Y177.039068 Z18 E17713.037596 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X224.192586 Y177.573856 Z18 E17717.183449 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X225.007907 Y178.14807 Z18 E17721.329453 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X225.807054 Y178.74409 Z18 E17725.474224 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X226.590792 Y179.360574 Z18 E17729.619868 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X227.345904 Y180.011938 Z18 E17733.765873 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X228.081242 Y180.685119 Z18 E17737.91068 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X228.799157 Y181.377077 Z18 E17742.056137 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X229.486788 Y182.099318 Z18 E17746.202142 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X230.150903 Y182.842874 Z18 E17750.347007 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X230.795764 Y183.603323 Z18 E17754.492301 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X231.409292 Y184.389487 Z18 E17758.638305 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X231.995484 Y185.195924 Z18 E17762.783251 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X232.560795 Y186.017193 Z18 E17766.928401 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X233.094311 Y186.859707 Z18 E17771.074406 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X233.596668 Y187.720897 Z18 E17775.219454 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X234.076735 Y188.594704 Z18 E17779.364484 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X234.525102 Y189.485454 Z18 E17783.510488 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X234.938554 Y190.392718 Z18 E17787.655661 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X235.328542 Y191.31025 Z18 E17791.800592 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X235.68744 Y192.240659 Z18 E17795.946596 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.007814 Y193.184853 Z18 E17800.091916 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.303795 Y194.136858 Z18 E17804.23677 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.569769 Y195.097965 Z18 E17808.382774 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.793827 Y196.069571 Z18 E17812.528262 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X236.992819 Y197.046451 Z18 E17816.673061 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.163308 Y198.029 Z18 E17820.819065 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.288784 Y199.018227 Z18 E17824.964743 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.388783 Y200.010132 Z18 E17829.109509 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.462144 Y201.004661 Z18 E17833.255513 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
G1 X237.487763 Y202.001535 Z18 E17837.401403 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00016-layer-00008-island-000 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=8 id=weave-00016-layer-00008-island-000
G0 X237.487763 Y202.001535 Z20 F2400 ; clayline kind=travel_lift page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave paste-safe lift
G0 X222.487828 Y202.004158 Z20 F2400 ; clayline kind=travel_xy page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave paste-safe traverse
G0 X222.487828 Y202.004158 Z18 F2400 ; clayline kind=travel_approach page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=8 id=weave-00017-layer-00008-island-001
G1 X222.487828 Y202.995842 Z18 E17841.524344 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X222.425874 Y203.98564 Z18 E17845.647502 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X222.291275 Y204.968209 Z18 E17849.770698 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X222.096315 Y205.940541 Z18 E17853.893644 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X221.839519 Y206.898422 Z18 E17858.01668 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X221.514385 Y207.83534 Z18 E17862.13981 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X221.132072 Y208.750371 Z18 E17866.262771 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X220.69062 Y209.638382 Z18 E17870.385724 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X220.187644 Y210.493084 Z18 E17874.508799 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X219.632899 Y211.315102 Z18 E17878.631784 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X219.024289 Y212.098055 Z18 E17882.754693 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X218.363106 Y212.837187 Z18 E17886.877722 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X217.657577 Y213.534109 Z18 E17891.000741 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X216.905927 Y214.18098 Z18 E17895.123646 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X216.112345 Y214.775697 Z18 E17899.246638 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X215.283564 Y215.320321 Z18 E17903.3697 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X214.418659 Y215.805476 Z18 E17907.492639 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X213.523651 Y216.23257 Z18 E17911.615605 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X212.603962 Y216.603637 Z18 E17915.738721 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X211.660073 Y216.907847 Z18 E17919.861732 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X210.698571 Y217.150651 Z18 E17923.984681 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X209.723864 Y217.333673 Z18 E17928.10786 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X208.738391 Y217.444874 Z18 E17932.230983 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X207.747921 Y217.493914 Z18 E17936.353924 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X206.756256 Y217.481362 Z18 E17940.477118 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X205.768229 Y217.395516 Z18 E17944.600332 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X204.787447 Y217.248877 Z18 E17948.723276 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X203.817952 Y217.040134 Z18 E17952.846338 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X202.866099 Y216.761727 Z18 E17956.969484 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X201.933282 Y216.425132 Z18 E17961.09244 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X201.024372 Y216.02848 Z18 E17965.215411 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X200.145841 Y215.568383 Z18 E17969.338499 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X199.297396 Y215.054967 Z18 E17973.461476 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X198.485086 Y214.486129 Z18 E17977.584394 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X197.714161 Y213.862305 Z18 E17981.707433 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X196.983203 Y213.192103 Z18 E17985.830442 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X196.299679 Y212.473624 Z18 E17989.953345 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X195.666445 Y211.71042 Z18 E17994.076345 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X195.081505 Y210.909588 Z18 E17998.199396 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X194.553853 Y210.069937 Z18 E18002.322323 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X194.083022 Y209.197143 Z18 E18006.445294 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X193.666932 Y208.296931 Z18 E18010.568395 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X193.316064 Y207.36938 Z18 E18014.691385 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X193.02601 Y206.421061 Z18 E18018.814337 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X192.795013 Y205.456601 Z18 E18022.937499 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X192.634841 Y204.477901 Z18 E18027.060591 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X192.536882 Y203.491068 Z18 E18031.183533 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X192.5 Y202.5 Z18 E18035.306766 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X192.536882 Y201.508932 Z18 E18039.429998 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X192.634841 Y200.522099 Z18 E18043.55294 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X192.795013 Y199.543399 Z18 E18047.676032 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X193.02601 Y198.578939 Z18 E18051.799194 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X193.316064 Y197.63062 Z18 E18055.922146 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X193.666932 Y196.703069 Z18 E18060.045136 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X194.083022 Y195.802857 Z18 E18064.168238 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X194.553853 Y194.930063 Z18 E18068.291209 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X195.081505 Y194.090412 Z18 E18072.414136 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X195.666445 Y193.28958 Z18 E18076.537186 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X196.299679 Y192.526376 Z18 E18080.660187 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X196.983203 Y191.807897 Z18 E18084.783089 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X197.714161 Y191.137695 Z18 E18088.906099 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X198.485086 Y190.513871 Z18 E18093.029138 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X199.297396 Y189.945033 Z18 E18097.152055 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X200.145841 Y189.431617 Z18 E18101.275033 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X201.024372 Y188.97152 Z18 E18105.398121 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X201.933282 Y188.574868 Z18 E18109.521091 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X202.866099 Y188.238273 Z18 E18113.644047 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X203.817952 Y187.959866 Z18 E18117.767193 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X204.787447 Y187.751123 Z18 E18121.890256 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X205.768229 Y187.604484 Z18 E18126.013199 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X206.756256 Y187.518638 Z18 E18130.136413 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X207.747921 Y187.506086 Z18 E18134.259607 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X208.738391 Y187.555126 Z18 E18138.382548 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X209.723864 Y187.666327 Z18 E18142.505672 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X210.698571 Y187.849349 Z18 E18146.62885 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X211.660073 Y188.092153 Z18 E18150.751799 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X212.603962 Y188.396363 Z18 E18154.874811 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X213.523651 Y188.76743 Z18 E18158.997926 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X214.418659 Y189.194524 Z18 E18163.120892 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X215.283564 Y189.679679 Z18 E18167.243831 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X216.112345 Y190.224303 Z18 E18171.366893 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X216.905927 Y190.81902 Z18 E18175.489886 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X217.657577 Y191.465891 Z18 E18179.612791 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X218.363106 Y192.162813 Z18 E18183.735809 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X219.024289 Y192.901945 Z18 E18187.858838 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X219.632899 Y193.684898 Z18 E18191.981748 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X220.187644 Y194.506916 Z18 E18196.104733 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X220.69062 Y195.361618 Z18 E18200.227807 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X221.132072 Y196.249629 Z18 E18204.350761 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X221.514385 Y197.16466 Z18 E18208.473721 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X221.839519 Y198.101578 Z18 E18212.596852 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X222.096315 Y199.059459 Z18 E18216.719888 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X222.291275 Y200.031791 Z18 E18220.842834 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X222.425874 Y201.01436 Z18 E18224.96603 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
G1 X222.487828 Y202.004158 Z18 E18229.089187 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00017-layer-00008-island-001 note=weave wall
; CLAYLINE_STROKE_END page=0 layer=8 id=weave-00017-layer-00008-island-001
; CLAYLINE_BODY_END
; CLAYLINE_PROFILE_END_BEGIN
M83 ;Set to Relative Extrusion Mode
G91 ;Set to Relative Positioning
G1 Z150 E-100 F40000 ;Move Z Axis up and relieve Extruder pressure (v1.3.0: was E-3000, which left the next job dry)
G90 ;Set to Absolute Positioning
G28 Z ;Home Z
G1 X207.5 Y0 F500 ;Move X and Y slow to home position
M82 ;absolute extrusion mode
; CLAYLINE_PROFILE_END_END
