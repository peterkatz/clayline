; CLAYLINE_HEADER_BEGIN
; clayline_version=0.1.0.dev0
; generated_utc=reproducible
; job_id=weave-slice-cbe91dc0fa7e96dee0c1
; prepared_trace_sha256=dba0f39988202fafb09d0e1bf8f5ac4af8e5c4ee96f8158a1618c4c7063b5f29
; body_sha256=b06b3d0a3cc3fbf1e1a1392903d9a052b02ab01080ba113dd0a9856d03b4a6d3
; profile_name=potterbot-xl
; profile_version=1.3.0
; profile_verified=true
; profile_flavor=marlin
; extrusion_mode=absolute
; bead_width_mm=5
; layer_height_mm=2
; flow_multiplier=1
; wet_density_g_cm3=1.8
; prime_mm=0
; end_early_mm=0
; first_layer_z_mm=2
; speed_default_mm_s=40
; speed_first_layer_mm_s=30
; speed_travel_mm_s=40
; virtual_filament_diameter_mm=1.75
; work_bounds=17,398,12,393,0,710
; machine_envelope=0,490,0,490,0,710
; stats.motion_count=3670
; stats.print_motion_count=3662
; stats.travel_motion_count=8
; stats.stroke_count=3
; stats.page_count=1
; stats.print_path_mm=5048.132745
; stats.deposited_path_mm=5048.132745
; stats.travel_path_mm=59.657556
; stats.total_motion_path_mm=5107.790301
; stats.motion_time_seconds=133.355043
; stats.pause_time_seconds=0
; stats.pressure_time_seconds=0
; stats.estimated_print_time_seconds=133.355043
; stats.body_volume_mm3=51160.561664
; stats.wet_weight_g=92.089011
; stats.body_e=21270.089875
; stats.pressure_e_excluded=0
; stats.warning_count=1
; nominal_label=Weave mesh — lobed-tumbler.obj
; stats.warning_count.overhang=1
; parameter.bottom_layers=3
; parameter.first_layer_flow_factor=1.1
; parameter.first_layer_height_mm=2.0
; parameter.layer_count=17
; parameter.layer_range_from=1
; parameter.layer_range_semantics=one_based_inclusive
; parameter.layer_range_to=14
; parameter.layer_range_total=14
; parameter.level_rim=true
; parameter.mode=weave
; parameter.pattern_part_0001={"extrusion":[{"u":0.0,"value":1.0},{"u":0.5,"value":1.0}],"interpolation":"monotone_cubic_periodic","name":"sine","schema":"cla
; parameter.pattern_part_0002=yline.weave-pattern","seed":null,"settings":{"amplitude":3.0,"bottom_layers":3,"extrusion_phase_offset":0.0,"level_rim":true,"ov
; parameter.pattern_part_0003=erlap_fraction":0.2,"pinned_seam_angle":0.0,"seam":"chained","twist":0.5,"wavelength":18.0,"z_blend":true},"version":1,"wave":[{
; parameter.pattern_part_0004="u":0.0,"value":0.0},{"u":0.0625,"value":0.3826834323650898},{"u":0.125,"value":0.7071067811865475},{"u":0.1875,"value":0.923879
; parameter.pattern_part_0005=5325112867},{"u":0.25,"value":1.0},{"u":0.3125,"value":0.9238795325112867},{"u":0.375,"value":0.7071067811865476},{"u":0.4375,"v
; parameter.pattern_part_0006=alue":0.3826834323650899},{"u":0.5,"value":1.2246467991473532e-16},{"u":0.5625,"value":-0.38268343236508967},{"u":0.625,"value":
; parameter.pattern_part_0007=-0.7071067811865475},{"u":0.6875,"value":-0.9238795325112865},{"u":0.75,"value":-1.0},{"u":0.8125,"value":-0.9238795325112866},{
; parameter.pattern_part_0008="u":0.875,"value":-0.7071067811865477},{"u":0.9375,"value":-0.3826834323650904}]}
; parameter.pattern_part_count=8
; parameter.print_range=printing layers 1–14 of 14, rebased to the bed
; parameter.range_rebased_to_bed=true
; parameter.reproducible=true
; parameter.restore_capsule_v1_b64_part_0001=eyJlbWlzc2lvbiI6eyJlbmRfZWFybHlfbW1faGV4IjoiMHgwLjBwKzAiLCJmbG93X211bHRpcGxpZXJfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzAiLCJwcmltZV9t
; parameter.restore_capsule_v1_b64_part_0002=bV9oZXgiOiIweDAuMHArMCIsInJlcHJvZHVjaWJsZSI6dHJ1ZSwid2V0X2RlbnNpdHlfZ19jbTNfaGV4IjoiMHgxLmNjY2NjY2NjY2NjY2RwKzAifSwiam9iX2lkIjp7
; parameter.restore_capsule_v1_b64_part_0003=ImVuY29kaW5nIjoidXRmLTgvYmFzZTY0IiwicHJlc2VudCI6dHJ1ZSwidXRmOF9iNjQiOiJkMlZoZG1VdGMyeHBZMlV0WTJKbE9URmtZekJtWVRkbE9UWmtaV1V3WXpF
; parameter.restore_capsule_v1_b64_part_0004=PSJ9LCJwYXR0ZXJuX2pzb25fdXRmOF9iNjQiOiJleUpsZUhSeWRYTnBiMjRpT2x0N0luVWlPakF1TUN3aWRtRnNkV1VpT2pFdU1IMHNleUoxSWpvd0xqVXNJblpoYkhW
; parameter.restore_capsule_v1_b64_part_0005=bElqb3hMakI5WFN3aWFXNTBaWEp3YjJ4aGRHbHZiaUk2SW0xdmJtOTBiMjVsWDJOMVltbGpYM0JsY21sdlpHbGpJaXdpYm1GdFpTSTZJbk5wYm1VaUxDSnpZMmhsYldF
; parameter.restore_capsule_v1_b64_part_0006=aU9pSmpiR0Y1YkdsdVpTNTNaV0YyWlMxd1lYUjBaWEp1SWl3aWMyVmxaQ0k2Ym5Wc2JDd2ljMlYwZEdsdVozTWlPbnNpWVcxd2JHbDBkV1JsSWpvekxqQXNJbUp2ZEhS
; parameter.restore_capsule_v1_b64_part_0007=dmJWOXNZWGxsY25NaU9qTXNJbVY0ZEhKMWMybHZibDl3YUdGelpWOXZabVp6WlhRaU9qQXVNQ3dpYkdWMlpXeGZjbWx0SWpwMGNuVmxMQ0p2ZG1WeWJHRndYMlp5WVdO
; parameter.restore_capsule_v1_b64_part_0008=MGFXOXVJam93TGpJc0luQnBibTVsWkY5elpXRnRYMkZ1WjJ4bElqb3dMakFzSW5ObFlXMGlPaUpqYUdGcGJtVmtJaXdpZEhkcGMzUWlPakF1TlN3aWQyRjJaV3hsYm1k
; parameter.restore_capsule_v1_b64_part_0009=MGFDSTZNVGd1TUN3aWVsOWliR1Z1WkNJNmRISjFaWDBzSW5abGNuTnBiMjRpT2pFc0luZGhkbVVpT2x0N0luVWlPakF1TUN3aWRtRnNkV1VpT2pBdU1IMHNleUoxSWpv
; parameter.restore_capsule_v1_b64_part_0010=d0xqQTJNalVzSW5aaGJIVmxJam93TGpNNE1qWTRNelF6TWpNMk5UQTRPVGg5TEhzaWRTSTZNQzR4TWpVc0luWmhiSFZsSWpvd0xqY3dOekV3TmpjNE1URTROalUwTnpW
; parameter.restore_capsule_v1_b64_part_0011=OUxIc2lkU0k2TUM0eE9EYzFMQ0oyWVd4MVpTSTZNQzQ1TWpNNE56azFNekkxTVRFeU9EWTNmU3g3SW5VaU9qQXVNalVzSW5aaGJIVmxJam94TGpCOUxIc2lkU0k2TUM0
; parameter.restore_capsule_v1_b64_part_0012=ek1USTFMQ0oyWVd4MVpTSTZNQzQ1TWpNNE56azFNekkxTVRFeU9EWTNmU3g3SW5VaU9qQXVNemMxTENKMllXeDFaU0k2TUM0M01EY3hNRFkzT0RFeE9EWTFORGMyZlN4
; parameter.restore_capsule_v1_b64_part_0013=N0luVWlPakF1TkRNM05Td2lkbUZzZFdVaU9qQXVNemd5Tmpnek5ETXlNelkxTURnNU9YMHNleUoxSWpvd0xqVXNJblpoYkhWbElqb3hMakl5TkRZME5qYzVPVEUwTnpN
; parameter.restore_capsule_v1_b64_part_0014=MU16SmxMVEUyZlN4N0luVWlPakF1TlRZeU5Td2lkbUZzZFdVaU9pMHdMak00TWpZNE16UXpNak0yTlRBNE9UWTNmU3g3SW5VaU9qQXVOakkxTENKMllXeDFaU0k2TFRB
; parameter.restore_capsule_v1_b64_part_0015=dU56QTNNVEEyTnpneE1UZzJOVFEzTlgwc2V5SjFJam93TGpZNE56VXNJblpoYkhWbElqb3RNQzQ1TWpNNE56azFNekkxTVRFeU9EWTFmU3g3SW5VaU9qQXVOelVzSW5a
; parameter.restore_capsule_v1_b64_part_0016=aGJIVmxJam90TVM0d2ZTeDdJblVpT2pBdU9ERXlOU3dpZG1Gc2RXVWlPaTB3TGpreU16ZzNPVFV6TWpVeE1USTROalo5TEhzaWRTSTZNQzQ0TnpVc0luWmhiSFZsSWpv
; parameter.restore_capsule_v1_b64_part_0017=dE1DNDNNRGN4TURZM09ERXhPRFkxTkRjM2ZTeDdJblVpT2pBdU9UTTNOU3dpZG1Gc2RXVWlPaTB3TGpNNE1qWTRNelF6TWpNMk5UQTVNRFI5WFgwPSIsInByb2ZpbGUi
; parameter.restore_capsule_v1_b64_part_0018=OnsiY2VudGVyIjp7IngiOiIweDEuOWYwMDAwMDAwMDAwMHArNyIsInkiOiIweDEuOTUwMDAwMDAwMDAwMHArNyJ9LCJkZWZhdWx0X25venpsZV9kaWFtZXRlcl9oZXgi
; parameter.restore_capsule_v1_b64_part_0019=OiIweDEuNDAwMDAwMDAwMDAwMHArMiIsImRlc2NyaXB0aW9uIjoiVmVyaWZpZWQgZnJvbSBQZXRlJ3Mgc3VjY2Vzc2Z1bCBKYW51YXJ5IDIwMjYgUG90dGVyQm90IDEw
; parameter.restore_capsule_v1_b64_part_0020=IFhMIHByaW50LiAxMCBtbSBub3p6bGUgYWRkZWQgcGVyIFBldGUgMjAyNi0wNy0xNS4gdjEuMi4wOiB0cmF2ZWwgc3BlZWQgY29ycmVjdGVkIHRvIHByaW50IHNwZWVk
; parameter.restore_capsule_v1_b64_part_0021=IFx1MjAxNCB0aGUgcmVmZXJlbmNlIEN1cmEgcHJvZmlsZSBvbmx5IHVzZWQgMTIwIG91dHNpZGUgc3BpcmFsaXplIG1vZGUgYW5kIHRoZSBmaXJzdCBjbGF5IHByaW50
; parameter.restore_capsule_v1_b64_part_0022=ICgyMDI2LTA3LTE3KSBzaG93ZWQgZmFzdCB0cmF2ZWxzIHRlYXIgdGhlIHRocmVhZC4gdjEuMy4wOiBlbmQtb2Ytam9iIGRlcHJlc3N1cml6ZSBhbmQgbWF0Y2hpbmcg
; parameter.restore_capsule_v1_b64_part_0023=c3RhcnQgcHJpbWUgcmVkdWNlZCAzMDAwLT4xMDAgXHUyMDE0IHRoZSBDdXJhLWluaGVyaXRlZCBmdWxsIGRlcHJlc3N1cml6ZSBsZWZ0IGJhY2stdG8tYmFjayBqb2Jz
; parameter.restore_capsule_v1_b64_part_0024=IHByaW50aW5nIGRyeSBmb3IgMzAtNDBzIChQZXRlLCAyMDI2LTA4LTAyKTsgMTAwIGlzIGVub3VnaCB0byBzdG9wIG9vemUgZHVyaW5nIHRoZSBob21pbmcgbW92ZXMg
; parameter.restore_capsule_v1_b64_part_0025=d2l0aG91dCBlbXB0eWluZyB0aGUgYmFycmVsLiIsImVtaXNzaW9uX2RlZmF1bHRzIjp7ImVuZF9lYXJseV9tbV9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArMiIsInBy
; parameter.restore_capsule_v1_b64_part_0026=aW1lX21tX2hleCI6IjB4MS5lMDAwMDAwMDAwMDAwcCszIn0sImVuZF9nY29kZSI6WyJNODMgO1NldCB0byBSZWxhdGl2ZSBFeHRydXNpb24gTW9kZSIsIkc5MSA7U2V0
; parameter.restore_capsule_v1_b64_part_0027=IHRvIFJlbGF0aXZlIFBvc2l0aW9uaW5nIiwiRzEgWjE1MCBFLTEwMCBGNDAwMDAgO01vdmUgWiBBeGlzIHVwIGFuZCByZWxpZXZlIEV4dHJ1ZGVyIHByZXNzdXJlICh2
; parameter.restore_capsule_v1_b64_part_0028=MS4zLjA6IHdhcyBFLTMwMDAsIHdoaWNoIGxlZnQgdGhlIG5leHQgam9iIGRyeSkiLCJHOTAgO1NldCB0byBBYnNvbHV0ZSBQb3NpdGlvbmluZyIsIkcyOCBaIDtIb21l
; parameter.restore_capsule_v1_b64_part_0029=IFoiLCJHMSBYMjA3LjUgWTAgRjUwMCA7TW92ZSBYIGFuZCBZIHNsb3cgdG8gaG9tZSBwb3NpdGlvbiIsIk04MiA7YWJzb2x1dGUgZXh0cnVzaW9uIG1vZGUiXSwiZXh0
; parameter.restore_capsule_v1_b64_part_0030=cnVzaW9uX21vZGUiOiJhYnNvbHV0ZSIsImZsYXZvciI6Im1hcmxpbiIsImdjb2RlX3doaXRlbGlzdCI6WyJHMCIsIkcxIiwiRzQiLCJHMjEiLCJHMjgiLCJHOTAiLCJH
; parameter.restore_capsule_v1_b64_part_0031=OTEiLCJHOTIiLCJNODIiLCJNODMiLCJNMTA1IiwiTTEwNyIsIk0xMDkiXSwibWFjaGluZV9lbnZlbG9wZSI6eyJtYXhfeCI6IjB4MS5lYTAwMDAwMDAwMDAwcCs4Iiwi
; parameter.restore_capsule_v1_b64_part_0032=bWF4X3kiOiIweDEuZWEwMDAwMDAwMDAwMHArOCIsIm1heF96IjoiMHgxLjYzMDAwMDAwMDAwMDBwKzkiLCJtaW5feCI6IjB4MC4wcCswIiwibWluX3kiOiIweDAuMHAr
; parameter.restore_capsule_v1_b64_part_0033=MCIsIm1pbl96IjoiMHgwLjBwKzAifSwibmFtZSI6InBvdHRlcmJvdC14bCIsIm5venpsZV9kaWFtZXRlcnNfaGV4IjpbIjB4MS5jMDAwMDAwMDAwMDAwcCsxIiwiMHgx
; parameter.restore_capsule_v1_b64_part_0034=LjA4NTFlYjg1MWViODVwKzIiLCIweDEuNDAwMDAwMDAwMDAwMHArMiIsIjB4MS45OTk5OTk5OTk5OTlhcCsyIiwiMHgxLjQwMDAwMDAwMDAwMDBwKzMiXSwic3BlZWRf
; parameter.restore_capsule_v1_b64_part_0035=ZGVmYXVsdF9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArNSIsInNwZWVkX2ZpcnN0X2xheWVyX2hleCI6IjB4MS5lMDAwMDAwMDAwMDAwcCs0Iiwic3BlZWRfdHJhdmVs
; parameter.restore_capsule_v1_b64_part_0036=X2hleCI6IjB4MS40MDAwMDAwMDAwMDAwcCs1Iiwic3RhcnRfZ2NvZGUiOlsiTTEwNSIsIk0xMDkgUzAiLCJNODIgO2Fic29sdXRlIGV4dHJ1c2lvbiBtb2RlIiwiRzI4
; parameter.restore_capsule_v1_b64_part_0037=IDtIb21lIiwiRzEgWDIwNy41IFkyMDIuNSBaMjAgRjEwMDAwIDtNb3ZlIFggYW5kIFkgdG8gY2VudGVyLCBaIHRvIDIwbW0gaGlnaCIsIkc5MiBFMCIsIkcxIEUxMDAg
; parameter.restore_capsule_v1_b64_part_0038=RjQwMDAwIDsgUHJpbWUgRXh0cnVkZXIgKHYxLjMuMDogbWF0Y2hlcyB0aGUgcmVkdWNlZCBlbmQtb2Ytam9iIGRlcHJlc3N1cml6ZSkiLCJHOTIgRTAiLCJHOTIgRTAi
; parameter.restore_capsule_v1_b64_part_0039=LCJHOTIgRTAiLCJNMTA3Il0sInRyYXZlbF9wb2xpY3kiOnsiZHdlbGxfc2Vjb25kc19oZXgiOiIweDAuMHArMCIsImxpZnRfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBw
; parameter.restore_capsule_v1_b64_part_0040=KzEiLCJwYWdlX3BhdXNlX2NvbW1hbmQiOiJHNCBTe3NlY29uZHN9IiwicmVwcmltZV9lX2hleCI6IjB4MC4wcCswIn0sInZlcmlmaWNhdGlvbl9zb3VyY2UiOiJkb2Nz
; parameter.restore_capsule_v1_b64_part_0041=L3JlZmVyZW5jZS9wb3R0ZXJib3QtMTB4bC1yZWZlcmVuY2UtaGVhZGVyLWZvb3Rlci5nY29kZSIsInZlcmlmaWVkIjp0cnVlLCJ2ZXJzaW9uIjoiMS4zLjAiLCJ2aXJ0
; parameter.restore_capsule_v1_b64_part_0042=dWFsX2ZpbGFtZW50X2RpYW1ldGVyX2hleCI6IjB4MS5jMDAwMDAwMDAwMDAwcCswIiwid29ya19ib3VuZHMiOnsibWF4X3giOiIweDEuOGUwMDAwMDAwMDAwMHArOCIs
; parameter.restore_capsule_v1_b64_part_0043=Im1heF95IjoiMHgxLjg5MDAwMDAwMDAwMDBwKzgiLCJtYXhfeiI6IjB4MS42MzAwMDAwMDAwMDAwcCs5IiwibWluX3giOiIweDEuMTAwMDAwMDAwMDAwMHArNCIsIm1p
; parameter.restore_capsule_v1_b64_part_0044=bl95IjoiMHgxLjgwMDAwMDAwMDAwMDBwKzMiLCJtaW5feiI6IjB4MC4wcCswIn19LCJzY2hlbWEiOiJjbGF5bGluZS53ZWF2ZS1yZXN0b3JlIiwic2xpY2UiOnsiYmVh
; parameter.restore_capsule_v1_b64_part_0045=ZF93aWR0aF9tbV9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArMiIsImZpcnN0X2xheWVyX2hlaWdodF9tbV9oZXgiOiIweDEuMDAwMDAwMDAwMDAwMHArMSIsImxheWVy
; parameter.restore_capsule_v1_b64_part_0046=X2hlaWdodF9tbV9oZXgiOiIweDEuMDAwMDAwMDAwMDAwMHArMSIsInJhbmdlX2Zyb20iOjEsInJhbmdlX3RvIjoxNCwic2FtcGxlX3NwYWNpbmdfbW1faGV4IjoiMHgx
; parameter.restore_capsule_v1_b64_part_0047=LjAwMDAwMDAwMDAwMDBwKzAifSwic291cmNlIjp7ImxheWVyX3RvdGFsIjoxNCwibWVzaF9uYW1lIjoibG9iZWQtdHVtYmxlci5vYmoiLCJtZXNoX3NoYTI1NiI6IjQ5
; parameter.restore_capsule_v1_b64_part_0048=MWU2ZDAwOTZjMDI5NGY5YWMyMmViMGViMmJlMmYwN2YyYWFhZDYwYjE4M2RjMDY1NjE0YjI4MjQyODgwY2EiLCJvZmZzZXRfeF9tbV9oZXgiOiIweDAuMHArMCIsIm9m
; parameter.restore_capsule_v1_b64_part_0049=ZnNldF95X21tX2hleCI6IjB4MC4wcCswIiwic2NhbGVfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzAiLCJ1cF9heGlzIjoieiJ9LCJ2ZXJzaW9uIjoxfQ==
; parameter.restore_capsule_v1_b64_part_count=49
; parameter.sample_spacing_mm=1.0
; parameter.seam=chained
; parameter.source_mesh=lobed-tumbler.obj
; parameter.source_mesh_sha256=491e6d0096c0294f9ac22eb0eb2be2f07f2aaad60b183dc065614b28242880ca
; parameter.source_offset_x_mm=0.0
; parameter.source_offset_y_mm=0.0
; parameter.source_scale=1.0
; parameter.source_up_axis=z
; parameter.z_blend=true
; pressure_management=profile and marked pressure blocks excluded from body volume
; thermal_policy=no heater or fan commands outside verbatim profile blocks
; CLAYLINE_HEADER_END
; CLAYLINE_PROFILE_START_BEGIN
M105
M109 S0
M82 ;absolute extrusion mode
G28 ;Home
G1 X207.5 Y202.5 Z20 F10000 ;Move X and Y to center, Z to 20mm high
G92 E0
G1 E100 F40000 ; Prime Extruder (v1.3.0: matches the reduced end-of-job depressurize)
G92 E0
G92 E0
G92 E0
M107
; CLAYLINE_PROFILE_START_END
; CLAYLINE_BODY_BEGIN
G21 ; clayline units: millimeters
G90 ; clayline absolute XYZ
M82 ; clayline absolute extrusion
G92 E0 ; clayline body extrusion origin
; CLAYLINE_PAGE index=0
; CLAYLINE_STROKE_BEGIN page=0 layer=0 id=weave-00000-zblend-wall-layer-000
G0 X232.357951 Y202.5 Z20 F2400 ; clayline kind=travel_xy page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=stroke start XY at safe Z
G0 X232.357951 Y202.5 Z2 F2400 ; clayline kind=travel_approach page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=stroke start vertical approach
G1 X231.046508 Y203.229649 Z2 E6.863366 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X230.173504 Y203.715364 Z2 E11.432183 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X229.3005 Y204.201078 Z2 E16.001 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X228.427496 Y204.686792 Z2 E20.569817 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X226.681488 Y205.658221 Z2 E29.707451 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X225.808484 Y206.143935 Z2 E34.276268 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X224.935481 Y206.629649 Z2 E38.845085 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X224.062477 Y207.115364 Z2 E43.413902 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X223.189473 Y207.601078 Z2 E47.982719 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X222.316469 Y208.086792 Z2 E52.551536 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X220.839465 Y208.908555 Z2 E60.281351 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.719704 Y210.848039 Z2 E70.523292 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.746539 Y212.538042 Z2 E78.253107 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.7624 Y213.536943 Z2 E82.821924 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.778261 Y214.535844 Z2 E87.390741 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.809983 Y216.533645 Z2 E96.528375 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.825844 Y217.532546 Z2 E101.097192 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.841705 Y218.531446 Z2 E105.666009 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.857566 Y219.530347 Z2 E110.234826 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.889288 Y221.528148 Z2 E119.37246 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.905149 Y222.527049 Z2 E123.941277 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.92101 Y223.52595 Z2 E128.510094 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.928976 Y224.027617 Z2 E130.804643 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.498502 Y223.769885 Z2 E133.099192 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X218.641359 Y223.256699 Z2 E137.668009 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X217.784216 Y222.743512 Z2 E142.236826 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X216.06993 Y221.717139 Z2 E151.37446 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.212787 Y221.203953 Z2 E155.943277 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X214.355645 Y220.690767 Z2 E160.512094 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X213.498502 Y220.17758 Z2 E165.080911 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X212.641359 Y219.664394 Z2 E169.649728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X211.784216 Y219.151207 Z2 E174.218545 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X210.927073 Y218.638021 Z2 E178.787362 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X210.06993 Y218.124835 Z2 E183.356179 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X208.619762 Y217.256593 Z2 E191.085994 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X206.380238 Y217.256593 Z2 E201.327934 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X204.93007 Y218.124835 Z2 E209.057749 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X204.072927 Y218.638021 Z2 E213.626566 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X203.215784 Y219.151207 Z2 E218.195383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X202.358641 Y219.664394 Z2 E222.7642 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X201.501498 Y220.17758 Z2 E227.333017 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X200.644355 Y220.690767 Z2 E231.901834 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.787213 Y221.203953 Z2 E236.470651 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X198.93007 Y221.717139 Z2 E241.039468 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X198.072927 Y222.230326 Z2 E245.608285 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X197.215784 Y222.743512 Z2 E250.177102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X196.358641 Y223.256699 Z2 E254.745919 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.501498 Y223.769885 Z2 E259.314736 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.071024 Y224.027617 Z2 E261.609285 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.07899 Y223.52595 Z2 E263.903834 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.094851 Y222.527049 Z2 E268.472651 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.110712 Y221.528148 Z2 E273.041468 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.126573 Y220.529248 Z2 E277.610285 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.142434 Y219.530347 Z2 E282.179102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.158295 Y218.531446 Z2 E286.747919 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.174156 Y217.532546 Z2 E291.316736 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.190017 Y216.533645 Z2 E295.885553 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.221739 Y214.535844 Z2 E305.023187 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.2376 Y213.536943 Z2 E309.592004 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.280296 Y210.848039 Z2 E321.890636 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X194.160535 Y208.908555 Z2 E332.132577 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X192.683531 Y208.086792 Z2 E339.862392 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X191.810527 Y207.601078 Z2 E344.431209 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X190.937523 Y207.115364 Z2 E349.000026 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X190.064519 Y206.629649 Z2 E353.568843 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X189.191516 Y206.143935 Z2 E358.13766 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X188.318512 Y205.658221 Z2 E362.706477 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X187.445508 Y205.172507 Z2 E367.275294 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X186.572504 Y204.686792 Z2 E371.844111 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X185.6995 Y204.201078 Z2 E376.412928 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X184.826496 Y203.715364 Z2 E380.981745 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X183.953492 Y203.229649 Z2 E385.550562 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X183.080488 Y202.743935 Z2 E390.119379 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X182.642049 Y202.5 Z2 E392.413928 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X183.953492 Y201.770351 Z2 E399.277294 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X184.826496 Y201.284636 Z2 E403.846111 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X186.572504 Y200.313208 Z2 E412.983745 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X187.445508 Y199.827493 Z2 E417.552562 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X188.318512 Y199.341779 Z2 E422.121379 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X189.191516 Y198.856065 Z2 E426.690196 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X190.937523 Y197.884636 Z2 E435.82783 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X191.810527 Y197.398922 Z2 E440.396647 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X192.683531 Y196.913208 Z2 E444.965464 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X194.160535 Y196.091445 Z2 E452.695279 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.280296 Y194.151961 Z2 E462.93722 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.253461 Y192.461958 Z2 E470.667035 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.2376 Y191.463057 Z2 E475.235852 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.221739 Y190.464156 Z2 E479.804669 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.205878 Y189.465256 Z2 E484.373486 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.174156 Y187.467454 Z2 E493.51112 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.158295 Y186.468554 Z2 E498.079937 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.142434 Y185.469653 Z2 E502.648754 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.126573 Y184.470752 Z2 E507.217571 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.094851 Y182.472951 Z2 E516.355205 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.07899 Y181.47405 Z2 E520.924022 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X195.071024 Y180.972383 Z2 E523.218571 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X196.358641 Y181.743301 Z2 E530.081937 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X197.215784 Y182.256488 Z2 E534.650754 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X198.072927 Y182.769674 Z2 E539.219571 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X198.93007 Y183.282861 Z2 E543.788388 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X200.644355 Y184.309233 Z2 E552.926022 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X201.501498 Y184.82242 Z2 E557.494839 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X202.358641 Y185.335606 Z2 E562.063656 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X203.215784 Y185.848793 Z2 E566.632473 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X204.93007 Y186.875165 Z2 E575.770107 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X206.380238 Y187.743407 Z2 E583.499922 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X208.619762 Y187.743407 Z2 E593.741862 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X210.06993 Y186.875165 Z2 E601.471678 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X211.784216 Y185.848793 Z2 E610.609312 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X212.641359 Y185.335606 Z2 E615.178129 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X213.498502 Y184.82242 Z2 E619.746946 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X214.355645 Y184.309233 Z2 E624.315763 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.212787 Y183.796047 Z2 E628.884579 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X216.06993 Y183.282861 Z2 E633.453396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X217.784216 Y182.256488 Z2 E642.59103 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X218.641359 Y181.743301 Z2 E647.159847 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.498502 Y181.230115 Z2 E651.728664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.928976 Y180.972383 Z2 E654.023213 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.92101 Y181.47405 Z2 E656.317762 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.905149 Y182.472951 Z2 E660.886579 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.889288 Y183.471852 Z2 E665.455396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.873427 Y184.470752 Z2 E670.024213 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.857566 Y185.469653 Z2 E674.59303 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.841705 Y186.468554 Z2 E679.161847 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.825844 Y187.467454 Z2 E683.730664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.809983 Y188.466355 Z2 E688.299481 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.778261 Y190.464156 Z2 E697.437115 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.7624 Y191.463057 Z2 E702.005932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.746539 Y192.461958 Z2 E706.574749 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X219.719704 Y194.151961 Z2 E714.304564 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X220.839465 Y196.091445 Z2 E724.546505 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X223.189473 Y197.398922 Z2 E736.845137 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X224.062477 Y197.884636 Z2 E741.413954 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X224.935481 Y198.370351 Z2 E745.982771 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X225.808484 Y198.856065 Z2 E750.551588 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X226.681488 Y199.341779 Z2 E755.120405 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X227.554492 Y199.827493 Z2 E759.689222 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X228.427496 Y200.313208 Z2 E764.258039 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X229.3005 Y200.798922 Z2 E768.826856 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X230.173504 Y201.284636 Z2 E773.395673 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X231.046508 Y201.770351 Z2 E777.96449 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X231.919512 Y202.256065 Z2 E782.533307 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X232.357951 Y202.5 Z2 E784.827856 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X224.130673 Y202.5 Z2 E822.453408 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X223.863734 Y202.648517 Z2 E823.850418 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X222.99073 Y203.134231 Z2 E828.419235 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X222.117727 Y203.619946 Z2 E832.988052 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X221.244723 Y204.10566 Z2 E837.556869 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X220.371719 Y204.591374 Z2 E842.125686 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X217.928316 Y205.950814 Z2 E854.913098 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.70265 Y209.80578 Z2 E875.270233 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.747043 Y212.601548 Z2 E888.057645 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.762904 Y213.600449 Z2 E892.626462 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.778765 Y214.59935 Z2 E897.195279 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.810487 Y216.597151 Z2 E906.332913 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.815337 Y216.902586 Z2 E907.729923 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.553247 Y216.745668 Z2 E909.126934 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X214.696105 Y216.232482 Z2 E913.695751 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X213.838962 Y215.719295 Z2 E918.264568 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X212.981819 Y215.206109 Z2 E922.833385 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X212.124676 Y214.692923 Z2 E927.402202 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X209.725666 Y213.256593 Z2 E940.189614 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X205.274334 Y213.256593 Z2 E960.546748 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X202.875324 Y214.692923 Z2 E973.334161 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X202.018181 Y215.206109 Z2 E977.902978 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X201.161038 Y215.719295 Z2 E982.471795 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X200.303895 Y216.232482 Z2 E987.040612 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.446753 Y216.745668 Z2 E991.609429 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.184663 Y216.902586 Z2 E993.006439 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.189513 Y216.597151 Z2 E994.403449 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.221235 Y214.59935 Z2 E1003.541083 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.237096 Y213.600449 Z2 E1008.1099 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.29735 Y209.80578 Z2 E1025.466129 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X197.071684 Y205.950814 Z2 E1045.823264 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X194.628281 Y204.591374 Z2 E1058.610676 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X193.755277 Y204.10566 Z2 E1063.179493 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X192.882273 Y203.619946 Z2 E1067.74831 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X192.00927 Y203.134231 Z2 E1072.317127 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X191.136266 Y202.648517 Z2 E1076.885944 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X190.869327 Y202.5 Z2 E1078.282955 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X191.136266 Y202.351483 Z2 E1079.679965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X192.882273 Y201.380054 Z2 E1088.817599 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X193.755277 Y200.89434 Z2 E1093.386416 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X194.628281 Y200.408626 Z2 E1097.955233 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X197.071684 Y199.049186 Z2 E1110.742645 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.29735 Y195.19422 Z2 E1131.09978 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.252957 Y192.398452 Z2 E1143.887192 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.237096 Y191.399551 Z2 E1148.456009 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.221235 Y190.40065 Z2 E1153.024826 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.205374 Y189.40175 Z2 E1157.593643 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.184663 Y188.097414 Z2 E1163.55947 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.446753 Y188.254332 Z2 E1164.956481 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X200.303895 Y188.767518 Z2 E1169.525298 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X201.161038 Y189.280705 Z2 E1174.094115 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X202.875324 Y190.307077 Z2 E1183.231749 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X205.274334 Y191.743407 Z2 E1196.019161 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X209.725666 Y191.743407 Z2 E1216.376295 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X212.124676 Y190.307077 Z2 E1229.163707 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X213.838962 Y189.280705 Z2 E1238.301341 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X214.696105 Y188.767518 Z2 E1242.870158 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.553247 Y188.254332 Z2 E1247.438975 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.815337 Y188.097414 Z2 E1248.835986 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.810487 Y188.402849 Z2 E1250.232996 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.778765 Y190.40065 Z2 E1259.37063 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.762904 Y191.399551 Z2 E1263.939447 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.747043 Y192.398452 Z2 E1268.508264 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.70265 Y195.19422 Z2 E1281.295676 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X217.928316 Y199.049186 Z2 E1301.652811 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X221.244723 Y200.89434 Z2 E1319.00904 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X222.117727 Y201.380054 Z2 E1323.577857 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X222.99073 Y201.865769 Z2 E1328.146674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X223.863734 Y202.351483 Z2 E1332.715491 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X224.130673 Y202.5 Z2 E1334.112501 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.903395 Y202.5 Z2 E1371.738053 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.017166 Y202.993072 Z2 E1376.376083 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X211.685596 Y208.763521 Z2 E1406.848411 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X211.701698 Y209.777554 Z2 E1411.486441 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X210.83157 Y209.256593 Z2 E1416.124471 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X204.16843 Y209.256593 Z2 E1446.5968 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X203.298302 Y209.777554 Z2 E1451.23483 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X203.314404 Y208.763521 Z2 E1455.87286 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.982834 Y202.993072 Z2 E1486.345188 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.096605 Y202.5 Z2 E1490.983218 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X199.982834 Y202.006928 Z2 E1495.621248 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X203.314404 Y196.236479 Z2 E1526.093577 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X203.298302 Y195.222446 Z2 E1530.731607 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X204.16843 Y195.743407 Z2 E1535.369637 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X210.83157 Y195.743407 Z2 E1565.841965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X211.701698 Y195.222446 Z2 E1570.479995 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X211.685596 Y196.236479 Z2 E1575.118025 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.017166 Y202.006928 Z2 E1605.590353 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X215.903395 Y202.5 Z2 E1610.228383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X210.68304 Y202.5 Z2 E1634.102472 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X209.09152 Y205.256593 Z2 E1648.659367 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X205.90848 Y205.256593 Z2 E1663.216263 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X204.31696 Y202.5 Z2 E1677.773158 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X205.90848 Y199.743407 Z2 E1692.330053 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X209.09152 Y199.743407 Z2 E1706.886948 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X210.68304 Y202.5 Z2 E1721.443843 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 3 · island 1 of 1
G1 X237.5 Y202.5 Z2 E1844.085005 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X237.160571 Y203.944741 Z2.009524 E1850.872232 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X236.747944 Y205.257918 Z2.019048 E1857.167395 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X236.200392 Y206.328588 Z2.028571 E1862.66719 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X235.460824 Y207.054134 Z2.038095 E1867.405478 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X234.521116 Y207.419957 Z2.047619 E1872.017383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X233.401693 Y207.462768 Z2.057143 E1877.140731 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X232.117619 Y207.209641 Z2.066667 E1883.126319 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X230.732736 Y206.775323 Z2.07619 E1889.76406 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X229.317576 Y206.286588 Z2.085714 E1896.61119 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X227.947002 Y205.877989 Z2.095238 E1903.151949 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X226.688786 Y205.671337 Z2.104762 E1908.983368 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.60972 Y205.786684 Z2.114286 E1913.94653 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.713684 Y206.231001 Z2.12381 E1918.520689 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.008649 Y207.018616 Z2.133333 E1923.355182 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.492786 Y208.146241 Z2.142857 E1929.026299 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.100311 Y209.495639 Z2.152381 E1935.453333 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X222.814278 Y210.914973 Z2.161905 E1942.074968 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.487625 Y211.825658 Z2.171429 E1947.254755 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.44185 Y212.463488 Z2.180952 E1952.503989 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.049476 Y213.452992 Z2.190476 E1957.814534 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.277567 Y214.448523 Z2.2 E1962.485537 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.081198 Y215.450794 Z2.209524 E1967.156539 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.505294 Y216.459091 Z2.219048 E1972.467085 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.624257 Y217.472233 Z2.228571 E1978.607494 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X222.562816 Y218.488239 Z2.238095 E1985.327268 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X221.469584 Y219.504751 Z2.247619 E1992.154383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.497208 Y220.519343 Z2.257143 E1998.581417 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.778588 Y221.529906 Z2.266667 E2004.252534 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.449011 Y222.534292 Z2.27619 E2009.087027 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.512239 Y223.532441 Z2.285714 E2013.661185 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.951879 Y224.524612 Z2.295238 E2018.624348 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.759953 Y225.510934 Z2.304762 E2024.455766 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X221.799096 Y226.493586 Z2.314286 E2030.996526 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X222.929933 Y227.474783 Z2.32381 E2037.843656 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.249347 Y229.778669 Z2.333333 E2048.480815 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.438678 Y229.978841 Z2.342857 E2061.367391 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.321179 Y229.900511 Z2.352381 E2066.49074 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.393559 Y229.505037 Z2.361905 E2071.102645 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.677399 Y228.756377 Z2.371429 E2075.840933 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.164116 Y227.668862 Z2.380952 E2081.340728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.793389 Y226.343246 Z2.390476 E2087.635891 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.5 Y224.888457 Z2.4 E2094.423118 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.206611 Y223.433669 Z2.409524 E2101.210345 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.835884 Y222.108052 Z2.419048 E2107.505508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.322601 Y221.020538 Z2.428571 E2113.005302 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.606441 Y220.271877 Z2.438095 E2117.74359 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.678821 Y219.876404 Z2.447619 E2122.355496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X212.561322 Y219.798074 Z2.457143 E2127.478844 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X211.269859 Y220.010306 Z2.466667 E2133.464432 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X209.871884 Y220.400436 Z2.47619 E2140.102172 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.441921 Y220.843995 Z2.485714 E2146.949303 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.477509 Y221.388065 Z2.495238 E2152.013451 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.733626 Y222.151728 Z2.504762 E2155.697328 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.708508 Y222.765485 Z2.514286 E2158.50689 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.8757 Y223.319317 Z2.52381 E2163.081048 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X205.841088 Y223.536087 Z2.533333 E2167.915542 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X204.606605 Y223.419026 Z2.542857 E2173.586659 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X203.241754 Y223.08422 Z2.552381 E2180.013692 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.814813 Y222.645709 Z2.561905 E2186.840807 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.404205 Y222.234477 Z2.571429 E2193.560581 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.08628 Y221.978048 Z2.580952 E2199.700991 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.925117 Y221.983449 Z2.590476 E2205.011536 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.958941 Y222.314523 Z2.6 E2209.682539 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.210832 Y223.009822 Z2.609524 E2214.353541 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.657709 Y224.030794 Z2.619048 E2219.664087 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.261348 Y225.313596 Z2.628571 E2225.804496 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.95767 Y226.7512 Z2.638095 E2232.52427 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.670326 Y228.216084 Z2.647619 E2239.351385 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.32089 Y229.577262 Z2.657143 E2245.778419 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X191.194643 Y230.741706 Z2.666667 E2261.035217 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X189.560038 Y227.434927 Z2.67619 E2277.904821 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X189.623267 Y226.436779 Z2.685714 E2282.478979 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.062906 Y225.444607 Z2.695238 E2287.442141 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.87098 Y224.458286 Z2.704762 E2293.27356 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X191.910124 Y223.475633 Z2.714286 E2299.814319 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.04096 Y222.494437 Z2.72381 E2306.661449 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.109532 Y221.512251 Z2.733333 E2313.29919 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.970785 Y220.526774 Z2.742857 E2319.284778 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.493421 Y219.53592 Z2.752381 E2324.408126 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.646462 Y218.539198 Z2.761905 E2329.020031 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.387905 Y217.53594 Z2.771429 E2333.75832 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.734454 Y216.526411 Z2.780952 E2339.258114 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.803522 Y215.512477 Z2.790476 E2345.553277 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z2.8 E2352.340504 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X191.640587 Y213.479828 Z2.809524 E2359.127731 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.709655 Y212.465893 Z2.819048 E2365.422894 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.142838 Y212.180996 Z2.828571 E2368.324448 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.24491 Y212.886847 Z2.838095 E2371.586363 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.081927 Y212.762815 Z2.847619 E2372.524032 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X189.455342 Y211.834197 Z2.857143 E2377.64738 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X188.993408 Y210.609641 Z2.866667 E2383.632967 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X188.632284 Y209.203894 Z2.87619 E2390.270708 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X188.301435 Y207.74373 Z2.885714 E2397.117838 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X187.926002 Y206.363703 Z2.895238 E2403.658598 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X187.43821 Y205.185623 Z2.904762 E2409.490016 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X186.771268 Y204.329541 Z2.914286 E2414.453179 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X185.921296 Y203.80243 Z2.92381 E2419.027337 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X184.880324 Y203.618616 Z2.933333 E2423.86183 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X183.650179 Y203.774812 Z2.942857 E2429.532948 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X182.296646 Y204.152782 Z2.952381 E2435.959981 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X180.884347 Y204.636376 Z2.961905 E2442.787096 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X179.487507 Y205.092185 Z2.971429 E2449.50687 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X178.178387 Y205.390328 Z2.980952 E2455.647279 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X177.017638 Y205.421796 Z2.990476 E2460.957825 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X174.5 Y202.5 Z3 E2478.596349 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X177.017638 Y199.578204 Z3.009524 E2496.234873 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X178.178387 Y199.609672 Z3.019048 E2501.545419 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X179.487507 Y199.907815 Z3.028571 E2507.685829 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X180.884347 Y200.363624 Z3.038095 E2514.405603 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X182.296646 Y200.847218 Z3.047619 E2521.232717 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X183.650179 Y201.225188 Z3.057143 E2527.659751 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X184.880324 Y201.381384 Z3.066667 E2533.330868 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X185.921296 Y201.19757 Z3.07619 E2538.165361 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X186.771268 Y200.670459 Z3.085714 E2542.73952 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X187.43821 Y199.814377 Z3.095238 E2547.702682 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X187.926002 Y198.636297 Z3.104762 E2553.534101 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X188.301435 Y197.25627 Z3.114286 E2560.07486 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X188.632284 Y195.796106 Z3.12381 E2566.92199 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X188.993408 Y194.390359 Z3.133333 E2573.559731 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X189.455342 Y193.165803 Z3.142857 E2579.545319 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.081927 Y192.237185 Z3.152381 E2584.668667 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.24491 Y192.113153 Z3.161905 E2585.606336 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.142838 Y192.819004 Z3.171429 E2588.86825 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.709655 Y192.534107 Z3.180952 E2591.769804 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X191.640587 Y191.520172 Z3.190476 E2598.064967 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z3.2 E2604.852194 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.803522 Y189.487523 Z3.209524 E2611.639421 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.734454 Y188.473589 Z3.219048 E2617.934584 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.387905 Y187.46406 Z3.228571 E2623.434379 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.646462 Y186.460802 Z3.238095 E2628.172667 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.493421 Y185.46408 Z3.247619 E2632.784572 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.970785 Y184.473226 Z3.257143 E2637.90792 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.109532 Y183.487749 Z3.266667 E2643.893508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.04096 Y182.505563 Z3.27619 E2650.531249 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X191.910124 Y181.524367 Z3.285714 E2657.378379 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.87098 Y180.541714 Z3.295238 E2663.919139 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X190.062906 Y179.555393 Z3.304762 E2669.750557 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X189.623267 Y178.563221 Z3.314286 E2674.71372 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X189.560038 Y177.565073 Z3.32381 E2679.287878 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X191.194643 Y174.258294 Z3.333333 E2696.157482 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.32089 Y175.422738 Z3.342857 E2711.41428 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.670326 Y176.783916 Z3.352381 E2717.841313 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.95767 Y178.2488 Z3.361905 E2724.668428 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.261348 Y179.686404 Z3.371429 E2731.388202 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.657709 Y180.969206 Z3.380952 E2737.528612 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.210832 Y181.990178 Z3.390476 E2742.839157 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.958941 Y182.685477 Z3.4 E2747.51016 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.925117 Y183.016551 Z3.409524 E2752.181162 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.08628 Y183.021952 Z3.419048 E2757.491708 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.404205 Y182.765523 Z3.428571 E2763.632117 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.814813 Y182.354291 Z3.438095 E2770.351891 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X203.241754 Y181.91578 Z3.447619 E2777.179006 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X204.606605 Y181.580974 Z3.457143 E2783.606039 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X205.841088 Y181.463913 Z3.466667 E2789.277157 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.8757 Y181.680683 Z3.47619 E2794.11165 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.708508 Y182.234515 Z3.485714 E2798.685808 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.733626 Y182.848272 Z3.495238 E2801.49537 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.477509 Y183.611935 Z3.504762 E2805.179247 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.441921 Y184.156005 Z3.514286 E2810.243396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X209.871884 Y184.599564 Z3.52381 E2817.090526 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X211.269859 Y184.989694 Z3.533333 E2823.728267 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X212.561322 Y185.201926 Z3.542857 E2829.713855 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.678821 Y185.123596 Z3.552381 E2834.837203 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.606441 Y184.728123 Z3.561905 E2839.449108 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.322601 Y183.979462 Z3.571429 E2844.187396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.835884 Y182.891948 Z3.580952 E2849.687191 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.206611 Y181.566331 Z3.590476 E2855.982354 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.5 Y180.111543 Z3.6 E2862.769581 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.793389 Y178.656754 Z3.609524 E2869.556808 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.164116 Y177.331138 Z3.619048 E2875.851971 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.677399 Y176.243623 Z3.628571 E2881.351765 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.393559 Y175.494963 Z3.638095 E2886.090054 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.321179 Y175.099489 Z3.647619 E2890.701959 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.438678 Y175.021159 Z3.657143 E2895.825307 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.249347 Y175.221331 Z3.666667 E2908.711883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X222.929933 Y177.525217 Z3.67619 E2919.349042 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X221.799096 Y178.506414 Z3.685714 E2926.196173 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.759953 Y179.489066 Z3.695238 E2932.736932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.951879 Y180.475388 Z3.704762 E2938.568351 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.512239 Y181.467559 Z3.714286 E2943.531513 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.449011 Y182.465708 Z3.72381 E2948.105671 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.778588 Y183.470094 Z3.733333 E2952.940165 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.497208 Y184.480657 Z3.742857 E2958.611282 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X221.469584 Y185.495249 Z3.752381 E2965.038315 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X222.562816 Y186.511761 Z3.761905 E2971.86543 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.624257 Y187.527767 Z3.771429 E2978.585204 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.505294 Y188.540909 Z3.780952 E2984.725614 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.081198 Y189.549206 Z3.790476 E2990.036159 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.277567 Y190.551477 Z3.8 E2994.707162 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.049476 Y191.547008 Z3.809524 E2999.378164 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.44185 Y192.536512 Z3.819048 E3004.68871 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.487625 Y193.174342 Z3.828571 E3009.937944 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X222.814278 Y194.085027 Z3.838095 E3015.117731 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.100311 Y195.504361 Z3.847619 E3021.739366 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X223.492786 Y196.853759 Z3.857143 E3028.166399 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.008649 Y197.981384 Z3.866667 E3033.837516 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X224.713684 Y198.768999 Z3.87619 E3038.67201 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X225.60972 Y199.213316 Z3.885714 E3043.246168 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X226.688786 Y199.328663 Z3.895238 E3048.20933 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X227.947002 Y199.122011 Z3.904762 E3054.040749 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X229.317576 Y198.713412 Z3.914286 E3060.581508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X230.732736 Y198.224677 Z3.92381 E3067.428639 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X232.117619 Y197.790359 Z3.933333 E3074.066379 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X233.401693 Y197.537232 Z3.942857 E3080.051967 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X234.521116 Y197.580043 Z3.952381 E3085.175315 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X235.460824 Y197.945866 Z3.961905 E3089.78722 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X236.200392 Y198.671412 Z3.971429 E3094.525509 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X236.747944 Y199.742082 Z3.980952 E3100.025303 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X237.160571 Y201.055259 Z3.990476 E3106.320466 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
; CLAYLINE_STROKE_END page=0 layer=0 id=weave-00000-zblend-wall-layer-000
G0 X237.160571 Y201.055259 Z6 F2400 ; clayline kind=travel_lift page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave paste-safe lift
G0 X232.357951 Y202.5 Z6 F2400 ; clayline kind=travel_xy page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave paste-safe traverse
G0 X232.357951 Y202.5 Z4 F2400 ; clayline kind=travel_approach page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=1 id=weave-00001-zblend-wall-layer-001
G1 X231.046508 Y203.229649 Z4 E3112.55989 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X230.173504 Y203.715364 Z4 E3116.71336 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X229.3005 Y204.201078 Z4 E3120.86683 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X228.427496 Y204.686792 Z4 E3125.0203 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X226.681488 Y205.658221 Z4 E3133.32724 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X225.808484 Y206.143935 Z4 E3137.48071 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X224.062477 Y207.115364 Z4 E3145.78765 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X223.189473 Y207.601078 Z4 E3149.94112 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X222.316469 Y208.086792 Z4 E3154.09459 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X220.839465 Y208.908555 Z4 E3161.121694 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.719704 Y210.848039 Z4 E3170.43255 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.746539 Y212.538042 Z4 E3177.459654 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.7624 Y213.536943 Z4 E3181.613124 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.778261 Y214.535844 Z4 E3185.766594 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.794122 Y215.534744 Z4 E3189.920064 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.809983 Y216.533645 Z4 E3194.073534 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.825844 Y217.532546 Z4 E3198.227004 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.841705 Y218.531446 Z4 E3202.380474 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.857566 Y219.530347 Z4 E3206.533944 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.889288 Y221.528148 Z4 E3214.840884 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.905149 Y222.527049 Z4 E3218.994354 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.92101 Y223.52595 Z4 E3223.147824 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.928976 Y224.027617 Z4 E3225.233778 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X218.641359 Y223.256699 Z4 E3231.473201 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X217.784216 Y222.743512 Z4 E3235.626671 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X216.927073 Y222.230326 Z4 E3239.780141 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X216.06993 Y221.717139 Z4 E3243.933611 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.212787 Y221.203953 Z4 E3248.087081 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X214.355645 Y220.690767 Z4 E3252.240551 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X213.498502 Y220.17758 Z4 E3256.394021 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X212.641359 Y219.664394 Z4 E3260.547491 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X211.784216 Y219.151207 Z4 E3264.700961 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.927073 Y218.638021 Z4 E3268.854431 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.06993 Y218.124835 Z4 E3273.007901 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X208.619762 Y217.256593 Z4 E3280.035006 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X206.380238 Y217.256593 Z4 E3289.345861 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X204.93007 Y218.124835 Z4 E3296.372966 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X204.072927 Y218.638021 Z4 E3300.526436 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X203.215784 Y219.151207 Z4 E3304.679906 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X202.358641 Y219.664394 Z4 E3308.833376 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X201.501498 Y220.17758 Z4 E3312.986846 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X200.644355 Y220.690767 Z4 E3317.140316 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.787213 Y221.203953 Z4 E3321.293786 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X198.93007 Y221.717139 Z4 E3325.447256 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X198.072927 Y222.230326 Z4 E3329.600726 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X197.215784 Y222.743512 Z4 E3333.754196 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X196.358641 Y223.256699 Z4 E3337.907666 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.501498 Y223.769885 Z4 E3342.061136 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.071024 Y224.027617 Z4 E3344.147089 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.110712 Y221.528148 Z4 E3354.539983 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.126573 Y220.529248 Z4 E3358.693453 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.142434 Y219.530347 Z4 E3362.846923 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.174156 Y217.532546 Z4 E3371.153863 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.190017 Y216.533645 Z4 E3375.307333 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.205878 Y215.534744 Z4 E3379.460803 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.221739 Y214.535844 Z4 E3383.614273 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.2376 Y213.536943 Z4 E3387.767743 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.253461 Y212.538042 Z4 E3391.921213 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.280296 Y210.848039 Z4 E3398.948317 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X194.160535 Y208.908555 Z4 E3408.259173 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X192.683531 Y208.086792 Z4 E3415.286277 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X191.810527 Y207.601078 Z4 E3419.439747 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X190.937523 Y207.115364 Z4 E3423.593217 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X190.064519 Y206.629649 Z4 E3427.746687 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X189.191516 Y206.143935 Z4 E3431.900157 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X188.318512 Y205.658221 Z4 E3436.053627 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X187.445508 Y205.172507 Z4 E3440.207097 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X186.572504 Y204.686792 Z4 E3444.360567 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X185.6995 Y204.201078 Z4 E3448.514037 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X184.826496 Y203.715364 Z4 E3452.667507 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X183.953492 Y203.229649 Z4 E3456.820977 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X183.080488 Y202.743935 Z4 E3460.974447 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X182.642049 Y202.5 Z4 E3463.060401 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X183.953492 Y201.770351 Z4 E3469.299824 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X184.826496 Y201.284636 Z4 E3473.453294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X186.572504 Y200.313208 Z4 E3481.760234 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X187.445508 Y199.827493 Z4 E3485.913704 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X188.318512 Y199.341779 Z4 E3490.067174 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X189.191516 Y198.856065 Z4 E3494.220644 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X190.064519 Y198.370351 Z4 E3498.374114 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X190.937523 Y197.884636 Z4 E3502.527584 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X191.810527 Y197.398922 Z4 E3506.681054 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X194.160535 Y196.091445 Z4 E3517.861629 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.280296 Y194.151961 Z4 E3527.172484 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.221739 Y190.464156 Z4 E3542.506529 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.205878 Y189.465256 Z4 E3546.659999 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.190017 Y188.466355 Z4 E3550.813469 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.174156 Y187.467454 Z4 E3554.966939 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.158295 Y186.468554 Z4 E3559.120409 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.142434 Y185.469653 Z4 E3563.273879 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.126573 Y184.470752 Z4 E3567.427349 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.094851 Y182.472951 Z4 E3575.734289 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.07899 Y181.47405 Z4 E3579.887759 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.071024 Y180.972383 Z4 E3581.973712 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X195.501498 Y181.230115 Z4 E3584.059666 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X196.358641 Y181.743301 Z4 E3588.213136 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X197.215784 Y182.256488 Z4 E3592.366606 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X198.072927 Y182.769674 Z4 E3596.520076 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X198.93007 Y183.282861 Z4 E3600.673546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X200.644355 Y184.309233 Z4 E3608.980486 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X201.501498 Y184.82242 Z4 E3613.133956 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X202.358641 Y185.335606 Z4 E3617.287426 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X203.215784 Y185.848793 Z4 E3621.440896 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X204.93007 Y186.875165 Z4 E3629.747836 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X206.380238 Y187.743407 Z4 E3636.774941 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X208.619762 Y187.743407 Z4 E3646.085796 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.06993 Y186.875165 Z4 E3653.1129 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.927073 Y186.361979 Z4 E3657.26637 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X211.784216 Y185.848793 Z4 E3661.41984 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X213.498502 Y184.82242 Z4 E3669.72678 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X214.355645 Y184.309233 Z4 E3673.88025 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.212787 Y183.796047 Z4 E3678.03372 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X216.06993 Y183.282861 Z4 E3682.18719 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X216.927073 Y182.769674 Z4 E3686.34066 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X217.784216 Y182.256488 Z4 E3690.49413 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X218.641359 Y181.743301 Z4 E3694.6476 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.498502 Y181.230115 Z4 E3698.80107 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.928976 Y180.972383 Z4 E3700.887024 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.905149 Y182.472951 Z4 E3707.126448 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.889288 Y183.471852 Z4 E3711.279918 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.873427 Y184.470752 Z4 E3715.433387 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.857566 Y185.469653 Z4 E3719.586857 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.841705 Y186.468554 Z4 E3723.740327 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.825844 Y187.467454 Z4 E3727.893797 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.809983 Y188.466355 Z4 E3732.047267 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.778261 Y190.464156 Z4 E3740.354207 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.7624 Y191.463057 Z4 E3744.507677 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.746539 Y192.461958 Z4 E3748.661147 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X219.719704 Y194.151961 Z4 E3755.688252 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X220.839465 Y196.091445 Z4 E3764.999107 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X223.189473 Y197.398922 Z4 E3776.179682 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X224.062477 Y197.884636 Z4 E3780.333152 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X224.935481 Y198.370351 Z4 E3784.486622 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X225.808484 Y198.856065 Z4 E3788.640092 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X226.681488 Y199.341779 Z4 E3792.793562 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X227.554492 Y199.827493 Z4 E3796.947032 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X228.427496 Y200.313208 Z4 E3801.100502 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X229.3005 Y200.798922 Z4 E3805.253972 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X230.173504 Y201.284636 Z4 E3809.407442 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X231.046508 Y201.770351 Z4 E3813.560912 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X231.919512 Y202.256065 Z4 E3817.714382 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X232.357951 Y202.5 Z4 E3819.800335 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X224.130673 Y202.5 Z4 E3854.005382 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X223.863734 Y202.648517 Z4 E3855.275392 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X222.117727 Y203.619946 Z4 E3863.582332 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X221.244723 Y204.10566 Z4 E3867.735802 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X220.371719 Y204.591374 Z4 E3871.889272 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X217.928316 Y205.950814 Z4 E3883.514192 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.70265 Y209.80578 Z4 E3902.020678 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.747043 Y212.601548 Z4 E3913.645598 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.762904 Y213.600449 Z4 E3917.799068 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.778765 Y214.59935 Z4 E3921.952538 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.794626 Y215.59825 Z4 E3926.106008 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.810487 Y216.597151 Z4 E3930.259478 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.815337 Y216.902586 Z4 E3931.529487 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.553247 Y216.745668 Z4 E3932.799497 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X214.696105 Y216.232482 Z4 E3936.952967 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X213.838962 Y215.719295 Z4 E3941.106437 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X212.981819 Y215.206109 Z4 E3945.259907 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X212.124676 Y214.692923 Z4 E3949.413377 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X209.725666 Y213.256593 Z4 E3961.038297 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X205.274334 Y213.256593 Z4 E3979.544783 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X202.875324 Y214.692923 Z4 E3991.169703 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X202.018181 Y215.206109 Z4 E3995.323173 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X201.161038 Y215.719295 Z4 E3999.476643 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X200.303895 Y216.232482 Z4 E4003.630113 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.446753 Y216.745668 Z4 E4007.783583 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.184663 Y216.902586 Z4 E4009.053593 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.189513 Y216.597151 Z4 E4010.323602 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.205374 Y215.59825 Z4 E4014.477072 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.221235 Y214.59935 Z4 E4018.630542 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.237096 Y213.600449 Z4 E4022.784012 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.252957 Y212.601548 Z4 E4026.937482 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.29735 Y209.80578 Z4 E4038.562402 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X197.071684 Y205.950814 Z4 E4057.068888 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X194.628281 Y204.591374 Z4 E4068.693808 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X193.755277 Y204.10566 Z4 E4072.847278 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X192.882273 Y203.619946 Z4 E4077.000748 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X192.00927 Y203.134231 Z4 E4081.154218 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X191.136266 Y202.648517 Z4 E4085.307688 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X190.869327 Y202.5 Z4 E4086.577698 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X191.136266 Y202.351483 Z4 E4087.847707 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X192.00927 Y201.865769 Z4 E4092.001177 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X192.882273 Y201.380054 Z4 E4096.154647 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X193.755277 Y200.89434 Z4 E4100.308117 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X197.071684 Y199.049186 Z4 E4116.086507 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.29735 Y195.19422 Z4 E4134.592993 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.221235 Y190.40065 Z4 E4154.524853 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.205374 Y189.40175 Z4 E4158.678323 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.189513 Y188.402849 Z4 E4162.831793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.184663 Y188.097414 Z4 E4164.101803 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.446753 Y188.254332 Z4 E4165.371812 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X200.303895 Y188.767518 Z4 E4169.525282 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X201.161038 Y189.280705 Z4 E4173.678752 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X202.875324 Y190.307077 Z4 E4181.985692 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X205.274334 Y191.743407 Z4 E4193.610612 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X209.725666 Y191.743407 Z4 E4212.117098 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X212.124676 Y190.307077 Z4 E4223.742018 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X212.981819 Y189.793891 Z4 E4227.895488 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X213.838962 Y189.280705 Z4 E4232.048958 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.553247 Y188.254332 Z4 E4240.355898 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.815337 Y188.097414 Z4 E4241.625908 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.810487 Y188.402849 Z4 E4242.895917 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.778765 Y190.40065 Z4 E4251.202857 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.762904 Y191.399551 Z4 E4255.356327 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.747043 Y192.398452 Z4 E4259.509797 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.70265 Y195.19422 Z4 E4271.134717 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X217.928316 Y199.049186 Z4 E4289.641203 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X221.244723 Y200.89434 Z4 E4305.419593 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X222.117727 Y201.380054 Z4 E4309.573063 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X222.99073 Y201.865769 Z4 E4313.726533 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X223.863734 Y202.351483 Z4 E4317.880003 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X224.130673 Y202.5 Z4 E4319.150013 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.903395 Y202.5 Z4 E4353.35506 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.017166 Y202.993072 Z4 E4357.571451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X211.685596 Y208.763521 Z4 E4385.273567 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X211.701698 Y209.777554 Z4 E4389.489958 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.83157 Y209.256593 Z4 E4393.706349 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X204.16843 Y209.256593 Z4 E4421.408466 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X203.298302 Y209.777554 Z4 E4425.624857 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X203.314404 Y208.763521 Z4 E4429.841248 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.982834 Y202.993072 Z4 E4457.543365 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.096605 Y202.5 Z4 E4461.759755 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X199.982834 Y202.006928 Z4 E4465.976146 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X203.314404 Y196.236479 Z4 E4493.678263 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X203.298302 Y195.222446 Z4 E4497.894654 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X204.16843 Y195.743407 Z4 E4502.111045 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.83157 Y195.743407 Z4 E4529.813162 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X211.701698 Y195.222446 Z4 E4534.029553 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X211.685596 Y196.236479 Z4 E4538.245943 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.017166 Y202.006928 Z4 E4565.94806 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X215.903395 Y202.5 Z4 E4570.164451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.68304 Y202.5 Z4 E4591.868168 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X209.09152 Y205.256593 Z4 E4605.101709 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X205.90848 Y205.256593 Z4 E4618.33525 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X204.31696 Y202.5 Z4 E4631.568791 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X205.90848 Y199.743407 Z4 E4644.802333 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X209.09152 Y199.743407 Z4 E4658.035874 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X210.68304 Y202.5 Z4 E4671.269415 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 3 · island 1 of 1
G1 X237.5 Y202.5 Z4 E4782.76138 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.093421 Y202.026688 Z4.009524 E4788.931586 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.760041 Y201.684939 Z4.019048 E4794.654462 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.561584 Y201.585698 Z4.028571 E4799.654275 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.555145 Y201.83158 Z4.038095 E4803.96181 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.748845 Y202.437185 Z4.047619 E4808.154451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.12226 Y203.365803 Z4.057143 E4812.81204 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.660326 Y204.590359 Z4.066667 E4818.253484 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.299202 Y205.996106 Z4.07619 E4824.287793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.968354 Y207.45627 Z4.085714 E4830.512457 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.59292 Y208.836297 Z4.095238 E4836.458602 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.105129 Y210.014377 Z4.104762 E4841.759892 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.438186 Y210.870459 Z4.114286 E4846.271857 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.588215 Y211.39757 Z4.12381 E4850.430183 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.547242 Y211.581384 Z4.133333 E4854.825177 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.317097 Y211.425188 Z4.142857 E4859.980738 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.963565 Y211.047218 Z4.152381 E4865.823496 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.50359 Y210.599313 Z4.161905 E4872.172714 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.9731 Y211.173243 Z4.171429 E4878.968552 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.050597 Y212.533214 Z4.180952 E4885.800839 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.474693 Y213.541511 Z4.190476 E4890.628607 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.278324 Y214.543782 Z4.2 E4894.874973 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.506415 Y215.539313 Z4.209524 E4899.121339 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.114041 Y216.528817 Z4.219048 E4903.949108 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.0268 Y217.513476 Z4.228571 E4909.531298 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.119963 Y218.495271 Z4.238095 E4915.640184 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.244917 Y219.476561 Z4.247619 E4921.846652 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.249015 Y220.45977 Z4.257143 E4927.689409 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.999357 Y221.447008 Z4.266667 E4932.844971 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.360657 Y222.440424 Z4.27619 E4937.239965 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.32915 Y223.440077 Z4.285714 E4941.39829 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.921233 Y224.445706 Z4.295238 E4945.910256 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.144881 Y225.457186 Z4.304762 E4951.211546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.137459 Y226.472335 Z4.314286 E4957.15769 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.038345 Y227.48894 Z4.32381 E4963.382354 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.750653 Y227.182855 Z4.333333 E4965.12923 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.847037 Y225.956311 Z4.342857 E4971.96902 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.25025 Y225.008268 Z4.352381 E4976.626609 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.463584 Y224.377369 Z4.361905 E4980.81925 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.465458 Y224.099656 Z4.371429 E4985.126785 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.264455 Y224.160798 Z4.380952 E4990.126598 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.920897 Y224.460041 Z4.390476 E4995.849473 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.5 Y224.888457 Z4.4 E5002.01968 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.079103 Y225.316873 Z4.409524 E5008.189886 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.735545 Y225.616117 Z4.419048 E5013.912762 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.534542 Y225.677258 Z4.428571 E5018.912575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.536416 Y225.399546 Z4.438095 E5023.22011 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.74975 Y224.768647 Z4.447619 E5027.412751 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.152963 Y223.820604 Z4.457143 E5032.07034 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.730141 Y222.581999 Z4.466667 E5037.511783 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.41383 Y221.165496 Z4.47619 E5043.546093 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.129507 Y219.695564 Z4.485714 E5049.770757 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.379634 Y218.125122 Z4.495238 E5057.006138 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.409231 Y217.361458 Z4.504762 E5065.791947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.720063 Y217.774074 Z4.514286 E5073.021283 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.838585 Y218.246615 Z4.52381 E5077.179609 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.158912 Y219.056218 Z4.533333 E5081.574603 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.67911 Y220.199652 Z4.542857 E5086.730164 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.329674 Y221.560831 Z4.552381 E5092.572921 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.04233 Y223.025715 Z4.561905 E5098.779389 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.738652 Y224.463319 Z4.571429 E5104.888275 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.342291 Y225.746121 Z4.580952 E5110.470465 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.789168 Y226.767093 Z4.590476 E5115.298234 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.041059 Y227.462391 Z4.6 E5119.5446 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.074883 Y227.793466 Z4.609524 E5123.790966 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.91372 Y227.798867 Z4.619048 E5128.618734 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.595795 Y227.542437 Z4.628571 E5134.200925 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.185187 Y227.131206 Z4.638095 E5140.30981 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.758246 Y226.692695 Z4.647619 E5146.516279 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.393395 Y226.357889 Z4.657143 E5152.359036 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.805357 Y226.219818 Z4.666667 E5158.257422 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.471684 Y227.528795 Z4.67619 E5167.067199 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.440178 Y226.529143 Z4.685714 E5171.225524 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.03226 Y225.523513 Z4.695238 E5175.73749 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.255908 Y224.512033 Z4.704762 E5181.03878 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.248487 Y223.496884 Z4.714286 E5186.984924 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.149372 Y222.480279 Z4.72381 E5193.209588 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.112522 Y221.464663 Z4.733333 E5199.243898 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.282992 Y220.452339 Z4.742857 E5204.685342 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.792078 Y219.445392 Z4.752381 E5209.342931 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.670758 Y218.444313 Z4.761905 E5213.535572 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.961037 Y217.449769 Z4.771429 E5217.843107 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.646211 Y216.461496 Z4.780952 E5222.84292 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.608865 Y215.477629 Z4.790476 E5228.565795 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z4.8 E5234.736002 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.835244 Y213.514676 Z4.809524 E5240.906208 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.797898 Y212.530809 Z4.819048 E5246.629083 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.396437 Y210.817905 Z4.828571 E5254.172862 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.437222 Y208.627439 Z4.838095 E5264.114741 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.854198 Y207.780043 Z4.847619 E5271.579929 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.734775 Y207.737232 Z4.857143 E5276.237519 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.450701 Y207.990359 Z4.866667 E5281.678962 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.065818 Y208.424677 Z4.87619 E5287.713272 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.650658 Y208.913412 Z4.885714 E5293.937936 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.280084 Y209.322011 Z4.895238 E5299.88408 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.021868 Y209.528663 Z4.904762 E5305.18537 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.942802 Y209.413316 Z4.914286 E5309.697336 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.046766 Y208.968999 Z4.92381 E5313.855662 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.341731 Y208.181384 Z4.933333 E5318.250655 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.825868 Y207.053759 Z4.942857 E5323.406217 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.433393 Y205.704361 Z4.952381 E5329.248974 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.099684 Y204.249338 Z4.961905 E5335.455442 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.750517 Y202.8221 Z4.971429 E5341.564328 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.313628 Y201.552529 Z4.980952 E5347.146518 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.72837 Y200.549633 Z4.990476 E5351.974287 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.5 Y202.5 Z5 E5360.694609 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.72837 Y204.450367 Z5.009524 E5369.414932 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.313628 Y203.447471 Z5.019048 E5374.2427 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.750517 Y202.1779 Z5.028571 E5379.824891 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.099684 Y200.750662 Z5.038095 E5385.933776 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.433393 Y199.295639 Z5.047619 E5392.140244 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.825868 Y197.946241 Z5.057143 E5397.983002 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.341731 Y196.818616 Z5.066667 E5403.138563 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.046766 Y196.031001 Z5.07619 E5407.533557 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.942802 Y195.586684 Z5.085714 E5411.691883 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.021868 Y195.471337 Z5.095238 E5416.203849 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.280084 Y195.677989 Z5.104762 E5421.505138 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.650658 Y196.086588 Z5.114286 E5427.451283 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.065818 Y196.575323 Z5.12381 E5433.675947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.450701 Y197.009641 Z5.133333 E5439.710257 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.734775 Y197.262768 Z5.142857 E5445.1517 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.854198 Y197.219957 Z5.152381 E5449.809289 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.437222 Y196.372561 Z5.161905 E5457.274478 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.396437 Y194.182095 Z5.171429 E5467.216356 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.797898 Y192.469191 Z5.180952 E5474.760135 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.835244 Y191.485324 Z5.190476 E5480.483011 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z5.2 E5486.653217 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.608865 Y189.522371 Z5.209524 E5492.823423 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.646211 Y188.538504 Z5.219048 E5498.546299 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.961037 Y187.550231 Z5.228571 E5503.546112 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.670758 Y186.555687 Z5.238095 E5507.853647 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.792078 Y185.554608 Z5.247619 E5512.046288 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.282992 Y184.547661 Z5.257143 E5516.703877 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.112522 Y183.535337 Z5.266667 E5522.145321 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.149372 Y182.519721 Z5.27619 E5528.17963 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.248487 Y181.503116 Z5.285714 E5534.404294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.255908 Y180.487967 Z5.295238 E5540.350439 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.03226 Y179.476487 Z5.304762 E5545.651729 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.440178 Y178.470857 Z5.314286 E5550.163695 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.471684 Y177.471205 Z5.32381 E5554.32202 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.805357 Y178.780182 Z5.333333 E5563.131796 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.393395 Y178.642111 Z5.342857 E5569.030183 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.758246 Y178.307305 Z5.352381 E5574.87294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.185187 Y177.868794 Z5.361905 E5581.079408 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.595795 Y177.457563 Z5.371429 E5587.188294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.91372 Y177.201133 Z5.380952 E5592.770484 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.074883 Y177.206534 Z5.390476 E5597.598253 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.041059 Y177.537609 Z5.4 E5601.844619 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.789168 Y178.232907 Z5.409524 E5606.090985 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.342291 Y179.253879 Z5.419048 E5610.918753 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.738652 Y180.536681 Z5.428571 E5616.500944 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.04233 Y181.974285 Z5.438095 E5622.609829 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.329674 Y183.439169 Z5.447619 E5628.816297 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.67911 Y184.800348 Z5.457143 E5634.659055 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.158912 Y185.943782 Z5.466667 E5639.814616 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.838585 Y186.753385 Z5.47619 E5644.20961 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.720063 Y187.225926 Z5.485714 E5648.367936 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.409231 Y187.638542 Z5.495238 E5655.597271 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.379634 Y186.874878 Z5.504762 E5664.383081 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.129507 Y185.304436 Z5.514286 E5671.618462 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.41383 Y183.834504 Z5.52381 E5677.843126 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.730141 Y182.418001 Z5.533333 E5683.877435 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.152963 Y181.179396 Z5.542857 E5689.318879 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.74975 Y180.231353 Z5.552381 E5693.976468 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.536416 Y179.600454 Z5.561905 E5698.169109 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.534542 Y179.322742 Z5.571429 E5702.476644 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.735545 Y179.383883 Z5.580952 E5707.476457 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.079103 Y179.683127 Z5.590476 E5713.199333 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.5 Y180.111543 Z5.6 E5719.369539 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.920897 Y180.539959 Z5.609524 E5725.539745 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.264455 Y180.839202 Z5.619048 E5731.262621 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.465458 Y180.900344 Z5.628571 E5736.262434 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.463584 Y180.622631 Z5.638095 E5740.569969 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.25025 Y179.991732 Z5.647619 E5744.76261 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.847037 Y179.043689 Z5.657143 E5749.420199 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.750653 Y177.817145 Z5.666667 E5756.259988 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.038345 Y177.51106 Z5.67619 E5758.006864 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.137459 Y178.527665 Z5.685714 E5764.231528 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.144881 Y179.542814 Z5.695238 E5770.177673 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.921233 Y180.554294 Z5.704762 E5775.478963 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.32915 Y181.559923 Z5.714286 E5779.990929 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.360657 Y182.559576 Z5.72381 E5784.149254 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.999357 Y183.552992 Z5.733333 E5788.544248 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.249015 Y184.54023 Z5.742857 E5793.699809 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.244917 Y185.523439 Z5.752381 E5799.542567 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.119963 Y186.504729 Z5.761905 E5805.749035 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.0268 Y187.486524 Z5.771429 E5811.85792 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.114041 Y188.471183 Z5.780952 E5817.440111 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.506415 Y189.460687 Z5.790476 E5822.26788 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.278324 Y190.456218 Z5.8 E5826.514246 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.474693 Y191.458489 Z5.809524 E5830.760611 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.050597 Y192.466786 Z5.819048 E5835.58838 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.9731 Y193.826757 Z5.828571 E5842.420667 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.50359 Y194.400687 Z5.838095 E5849.216505 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.963565 Y193.952782 Z5.847619 E5855.565723 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.317097 Y193.574812 Z5.857143 E5861.40848 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.547242 Y193.418616 Z5.866667 E5866.564042 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.588215 Y193.60243 Z5.87619 E5870.959036 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.438186 Y194.129541 Z5.885714 E5875.117361 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.105129 Y194.985623 Z5.895238 E5879.629327 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.59292 Y196.163703 Z5.904762 E5884.930617 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.968354 Y197.54373 Z5.914286 E5890.876762 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.299202 Y199.003894 Z5.92381 E5897.101425 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.660326 Y200.409641 Z5.933333 E5903.135735 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.12226 Y201.634197 Z5.942857 E5908.577179 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.748845 Y202.562815 Z5.952381 E5913.234768 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.555145 Y203.16842 Z5.961905 E5917.427409 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.561584 Y203.414302 Z5.971429 E5921.734944 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.760041 Y203.315061 Z5.980952 E5926.734757 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.093421 Y202.973312 Z5.990476 E5932.457632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
; CLAYLINE_STROKE_END page=0 layer=1 id=weave-00001-zblend-wall-layer-001
G0 X236.093421 Y202.973312 Z8 F2400 ; clayline kind=travel_lift page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave paste-safe lift
G0 X232.357951 Y202.5 Z8 F2400 ; clayline kind=travel_xy page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave paste-safe traverse
G0 X232.357951 Y202.5 Z6 F2400 ; clayline kind=travel_approach page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=2 id=weave-00002-zblend-wall-layer-002
G1 X231.919512 Y202.743935 Z6 E5934.543586 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X231.046508 Y203.229649 Z6 E5938.697056 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X230.173504 Y203.715364 Z6 E5942.850526 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X229.3005 Y204.201078 Z6 E5947.003996 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X227.554492 Y205.172507 Z6 E5955.310936 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X226.681488 Y205.658221 Z6 E5959.464406 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X224.935481 Y206.629649 Z6 E5967.771346 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X224.062477 Y207.115364 Z6 E5971.924816 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X222.316469 Y208.086792 Z6 E5980.231756 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X220.839465 Y208.908555 Z6 E5987.258861 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.719704 Y210.848039 Z6 E5996.569716 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.746539 Y212.538042 Z6 E6003.59682 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.7624 Y213.536943 Z6 E6007.75029 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.778261 Y214.535844 Z6 E6011.90376 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.794122 Y215.534744 Z6 E6016.05723 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.809983 Y216.533645 Z6 E6020.2107 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.825844 Y217.532546 Z6 E6024.36417 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.841705 Y218.531446 Z6 E6028.51764 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.857566 Y219.530347 Z6 E6032.67111 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.889288 Y221.528148 Z6 E6040.97805 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.905149 Y222.527049 Z6 E6045.13152 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.92101 Y223.52595 Z6 E6049.28499 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.928976 Y224.027617 Z6 E6051.370944 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.498502 Y223.769885 Z6 E6053.456898 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X218.641359 Y223.256699 Z6 E6057.610368 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X217.784216 Y222.743512 Z6 E6061.763838 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X216.927073 Y222.230326 Z6 E6065.917308 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X216.06993 Y221.717139 Z6 E6070.070778 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.212787 Y221.203953 Z6 E6074.224248 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X214.355645 Y220.690767 Z6 E6078.377718 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X213.498502 Y220.17758 Z6 E6082.531188 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X212.641359 Y219.664394 Z6 E6086.684658 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X211.784216 Y219.151207 Z6 E6090.838128 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.927073 Y218.638021 Z6 E6094.991597 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.06993 Y218.124835 Z6 E6099.145067 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X208.619762 Y217.256593 Z6 E6106.172172 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X206.380238 Y217.256593 Z6 E6115.483027 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X204.93007 Y218.124835 Z6 E6122.510132 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X204.072927 Y218.638021 Z6 E6126.663602 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X203.215784 Y219.151207 Z6 E6130.817072 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X202.358641 Y219.664394 Z6 E6134.970542 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X201.501498 Y220.17758 Z6 E6139.124012 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X200.644355 Y220.690767 Z6 E6143.277482 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.787213 Y221.203953 Z6 E6147.430952 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X198.93007 Y221.717139 Z6 E6151.584422 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X198.072927 Y222.230326 Z6 E6155.737892 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X197.215784 Y222.743512 Z6 E6159.891362 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X196.358641 Y223.256699 Z6 E6164.044832 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.501498 Y223.769885 Z6 E6168.198302 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.071024 Y224.027617 Z6 E6170.284255 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.07899 Y223.52595 Z6 E6172.370209 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.094851 Y222.527049 Z6 E6176.523679 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.126573 Y220.529248 Z6 E6184.830619 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.142434 Y219.530347 Z6 E6188.984089 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.158295 Y218.531446 Z6 E6193.137559 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.174156 Y217.532546 Z6 E6197.291029 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.190017 Y216.533645 Z6 E6201.444499 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.205878 Y215.534744 Z6 E6205.597969 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.221739 Y214.535844 Z6 E6209.751439 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.2376 Y213.536943 Z6 E6213.904909 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.253461 Y212.538042 Z6 E6218.058379 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.280296 Y210.848039 Z6 E6225.085484 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X194.160535 Y208.908555 Z6 E6234.396339 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X191.810527 Y207.601078 Z6 E6245.576913 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X190.937523 Y207.115364 Z6 E6249.730383 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X190.064519 Y206.629649 Z6 E6253.883853 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X188.318512 Y205.658221 Z6 E6262.190793 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X187.445508 Y205.172507 Z6 E6266.344263 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X184.826496 Y203.715364 Z6 E6278.804673 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X183.953492 Y203.229649 Z6 E6282.958143 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X183.080488 Y202.743935 Z6 E6287.111613 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X182.642049 Y202.5 Z6 E6289.197567 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X183.080488 Y202.256065 Z6 E6291.283521 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X183.953492 Y201.770351 Z6 E6295.436991 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X185.6995 Y200.798922 Z6 E6303.743931 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X186.572504 Y200.313208 Z6 E6307.897401 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X188.318512 Y199.341779 Z6 E6316.204341 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X189.191516 Y198.856065 Z6 E6320.357811 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X190.064519 Y198.370351 Z6 E6324.511281 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X190.937523 Y197.884636 Z6 E6328.664751 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X191.810527 Y197.398922 Z6 E6332.818221 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X192.683531 Y196.913208 Z6 E6336.971691 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X194.160535 Y196.091445 Z6 E6343.998795 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.280296 Y194.151961 Z6 E6353.30965 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.253461 Y192.461958 Z6 E6360.336755 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.2376 Y191.463057 Z6 E6364.490225 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.221739 Y190.464156 Z6 E6368.643695 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.205878 Y189.465256 Z6 E6372.797165 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.190017 Y188.466355 Z6 E6376.950635 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.174156 Y187.467454 Z6 E6381.104105 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.126573 Y184.470752 Z6 E6393.564515 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.110712 Y183.471852 Z6 E6397.717985 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.094851 Y182.472951 Z6 E6401.871455 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.07899 Y181.47405 Z6 E6406.024925 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.071024 Y180.972383 Z6 E6408.110879 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X195.501498 Y181.230115 Z6 E6410.196832 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X196.358641 Y181.743301 Z6 E6414.350302 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X197.215784 Y182.256488 Z6 E6418.503772 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X198.072927 Y182.769674 Z6 E6422.657242 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X198.93007 Y183.282861 Z6 E6426.810712 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.787213 Y183.796047 Z6 E6430.964182 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X200.644355 Y184.309233 Z6 E6435.117652 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X202.358641 Y185.335606 Z6 E6443.424592 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X203.215784 Y185.848793 Z6 E6447.578062 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X204.072927 Y186.361979 Z6 E6451.731532 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X204.93007 Y186.875165 Z6 E6455.885002 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X206.380238 Y187.743407 Z6 E6462.912107 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X208.619762 Y187.743407 Z6 E6472.222962 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.06993 Y186.875165 Z6 E6479.250067 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.927073 Y186.361979 Z6 E6483.403537 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X211.784216 Y185.848793 Z6 E6487.557007 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X212.641359 Y185.335606 Z6 E6491.710477 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X213.498502 Y184.82242 Z6 E6495.863947 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.212787 Y183.796047 Z6 E6504.170886 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X216.06993 Y183.282861 Z6 E6508.324356 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X216.927073 Y182.769674 Z6 E6512.477826 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X217.784216 Y182.256488 Z6 E6516.631296 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.498502 Y181.230115 Z6 E6524.938236 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.928976 Y180.972383 Z6 E6527.02419 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.92101 Y181.47405 Z6 E6529.110144 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.905149 Y182.472951 Z6 E6533.263614 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.857566 Y185.469653 Z6 E6545.724024 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.841705 Y186.468554 Z6 E6549.877494 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.809983 Y188.466355 Z6 E6558.184434 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.794122 Y189.465256 Z6 E6562.337904 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.778261 Y190.464156 Z6 E6566.491374 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.7624 Y191.463057 Z6 E6570.644844 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.746539 Y192.461958 Z6 E6574.798314 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X219.719704 Y194.151961 Z6 E6581.825418 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X220.839465 Y196.091445 Z6 E6591.136273 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X222.316469 Y196.913208 Z6 E6598.163378 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X223.189473 Y197.398922 Z6 E6602.316848 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X224.062477 Y197.884636 Z6 E6606.470318 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X224.935481 Y198.370351 Z6 E6610.623788 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X225.808484 Y198.856065 Z6 E6614.777258 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X226.681488 Y199.341779 Z6 E6618.930728 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X227.554492 Y199.827493 Z6 E6623.084198 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X228.427496 Y200.313208 Z6 E6627.237668 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X229.3005 Y200.798922 Z6 E6631.391138 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X230.173504 Y201.284636 Z6 E6635.544608 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X231.046508 Y201.770351 Z6 E6639.698078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X231.919512 Y202.256065 Z6 E6643.851548 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X232.357951 Y202.5 Z6 E6645.937502 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X224.130673 Y202.5 Z6 E6680.142549 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X222.99073 Y203.134231 Z6 E6685.566028 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X222.117727 Y203.619946 Z6 E6689.719498 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X220.371719 Y204.591374 Z6 E6698.026438 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X217.928316 Y205.950814 Z6 E6709.651358 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.70265 Y209.80578 Z6 E6728.157844 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.747043 Y212.601548 Z6 E6739.782764 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.762904 Y213.600449 Z6 E6743.936234 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.778765 Y214.59935 Z6 E6748.089704 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.794626 Y215.59825 Z6 E6752.243174 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.810487 Y216.597151 Z6 E6756.396644 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.815337 Y216.902586 Z6 E6757.666654 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.553247 Y216.745668 Z6 E6758.936663 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X214.696105 Y216.232482 Z6 E6763.090133 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X213.838962 Y215.719295 Z6 E6767.243603 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X212.981819 Y215.206109 Z6 E6771.397073 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X212.124676 Y214.692923 Z6 E6775.550543 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X209.725666 Y213.256593 Z6 E6787.175463 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X205.274334 Y213.256593 Z6 E6805.681949 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X202.875324 Y214.692923 Z6 E6817.306869 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X202.018181 Y215.206109 Z6 E6821.460339 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X201.161038 Y215.719295 Z6 E6825.613809 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X200.303895 Y216.232482 Z6 E6829.767279 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.446753 Y216.745668 Z6 E6833.920749 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.184663 Y216.902586 Z6 E6835.190759 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.189513 Y216.597151 Z6 E6836.460768 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.205374 Y215.59825 Z6 E6840.614238 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.221235 Y214.59935 Z6 E6844.767708 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.237096 Y213.600449 Z6 E6848.921178 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.252957 Y212.601548 Z6 E6853.074648 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.29735 Y209.80578 Z6 E6864.699568 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X197.071684 Y205.950814 Z6 E6883.206054 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X193.755277 Y204.10566 Z6 E6898.984444 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X192.882273 Y203.619946 Z6 E6903.137914 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X192.00927 Y203.134231 Z6 E6907.291384 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X190.869327 Y202.5 Z6 E6912.714864 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X191.136266 Y202.351483 Z6 E6913.984873 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X192.00927 Y201.865769 Z6 E6918.138343 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X192.882273 Y201.380054 Z6 E6922.291813 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X193.755277 Y200.89434 Z6 E6926.445283 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X194.628281 Y200.408626 Z6 E6930.598753 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X197.071684 Y199.049186 Z6 E6942.223673 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.29735 Y195.19422 Z6 E6960.730159 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.252957 Y192.398452 Z6 E6972.355079 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.237096 Y191.399551 Z6 E6976.508549 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.221235 Y190.40065 Z6 E6980.662019 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.205374 Y189.40175 Z6 E6984.815489 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.189513 Y188.402849 Z6 E6988.968959 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.184663 Y188.097414 Z6 E6990.238969 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X200.303895 Y188.767518 Z6 E6995.662448 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X201.161038 Y189.280705 Z6 E6999.815918 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X202.018181 Y189.793891 Z6 E7003.969388 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X202.875324 Y190.307077 Z6 E7008.122858 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X205.274334 Y191.743407 Z6 E7019.747778 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X209.725666 Y191.743407 Z6 E7038.254264 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X212.124676 Y190.307077 Z6 E7049.879184 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X212.981819 Y189.793891 Z6 E7054.032654 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X213.838962 Y189.280705 Z6 E7058.186124 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X214.696105 Y188.767518 Z6 E7062.339594 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.553247 Y188.254332 Z6 E7066.493064 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.815337 Y188.097414 Z6 E7067.763074 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.810487 Y188.402849 Z6 E7069.033083 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.794626 Y189.40175 Z6 E7073.186553 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.778765 Y190.40065 Z6 E7077.340023 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.762904 Y191.399551 Z6 E7081.493493 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.747043 Y192.398452 Z6 E7085.646963 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.70265 Y195.19422 Z6 E7097.271883 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X217.928316 Y199.049186 Z6 E7115.778369 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X220.371719 Y200.408626 Z6 E7127.403289 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X221.244723 Y200.89434 Z6 E7131.556759 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X222.117727 Y201.380054 Z6 E7135.710229 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X222.99073 Y201.865769 Z6 E7139.863699 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X223.863734 Y202.351483 Z6 E7144.017169 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X224.130673 Y202.5 Z6 E7145.287179 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.903395 Y202.5 Z6 E7179.492226 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.017166 Y202.993072 Z6 E7183.708617 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X211.685596 Y208.763521 Z6 E7211.410734 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X211.701698 Y209.777554 Z6 E7215.627124 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.83157 Y209.256593 Z6 E7219.843515 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X204.16843 Y209.256593 Z6 E7247.545632 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X203.298302 Y209.777554 Z6 E7251.762023 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X203.314404 Y208.763521 Z6 E7255.978414 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.982834 Y202.993072 Z6 E7283.680531 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.096605 Y202.5 Z6 E7287.896922 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X199.982834 Y202.006928 Z6 E7292.113312 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X203.314404 Y196.236479 Z6 E7319.815429 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X203.298302 Y195.222446 Z6 E7324.03182 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X204.16843 Y195.743407 Z6 E7328.248211 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.83157 Y195.743407 Z6 E7355.950328 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X211.701698 Y195.222446 Z6 E7360.166719 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X211.685596 Y196.236479 Z6 E7364.38311 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.017166 Y202.006928 Z6 E7392.085226 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X215.903395 Y202.5 Z6 E7396.301617 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.68304 Y202.5 Z6 E7418.005334 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X209.09152 Y205.256593 Z6 E7431.238875 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X205.90848 Y205.256593 Z6 E7444.472417 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X204.31696 Y202.5 Z6 E7457.705958 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X205.90848 Y199.743407 Z6 E7470.939499 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X209.09152 Y199.743407 Z6 E7484.17304 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X210.68304 Y202.5 Z6 E7497.406581 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=bottom 3 of 3 · island 1 of 1
G1 X237.5 Y202.5 Z6 E7608.898546 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y203.944741 Z6.009524 E7615.068753 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y205.257918 Z6.019048 E7620.791628 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y206.328588 Z6.028571 E7625.791441 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y207.054134 Z6.038095 E7630.098976 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y207.419957 Z6.047619 E7634.291617 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y207.462768 Z6.057143 E7638.949206 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y207.209641 Z6.066667 E7644.39065 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y206.775323 Z6.07619 E7650.42496 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y206.286588 Z6.085714 E7656.649623 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y205.877989 Z6.095238 E7662.595768 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y205.671337 Z6.104762 E7667.897058 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y205.786684 Z6.114286 E7672.409024 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y206.231001 Z6.12381 E7676.567349 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y207.018616 Z6.133333 E7680.962343 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y208.146241 Z6.142857 E7686.117905 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y209.495639 Z6.152381 E7691.960662 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y210.914973 Z6.161905 E7697.98033 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y211.825658 Z6.171429 E7702.689228 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y212.463488 Z6.180952 E7707.461258 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y213.452992 Z6.190476 E7712.289027 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y214.448523 Z6.2 E7716.535393 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y215.450794 Z6.209524 E7720.781759 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y216.459091 Z6.219048 E7725.609528 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y217.472233 Z6.228571 E7731.191718 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y218.488239 Z6.238095 E7737.300604 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y219.504751 Z6.247619 E7743.507072 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y220.519343 Z6.257143 E7749.349829 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y221.529906 Z6.266667 E7754.50539 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y222.534292 Z6.27619 E7758.900384 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y223.532441 Z6.285714 E7763.05871 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y224.524612 Z6.295238 E7767.570676 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y225.510934 Z6.304762 E7772.871965 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y226.493586 Z6.314286 E7778.81811 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y227.474783 Z6.32381 E7785.042774 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y229.778669 Z6.333333 E7794.712919 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y229.978841 Z6.342857 E7806.427988 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y229.900511 Z6.352381 E7811.085577 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y229.505037 Z6.361905 E7815.278219 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y228.756377 Z6.371429 E7819.585753 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y227.668862 Z6.380952 E7824.585567 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y226.343246 Z6.390476 E7830.308442 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z6.4 E7836.478648 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y223.433669 Z6.409524 E7842.648855 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y222.108052 Z6.419048 E7848.37173 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y221.020538 Z6.428571 E7853.371543 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y220.271877 Z6.438095 E7857.679078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y219.876404 Z6.447619 E7861.871719 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y219.798074 Z6.457143 E7866.529308 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y220.010306 Z6.466667 E7871.970752 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y220.400436 Z6.47619 E7878.005062 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y220.843995 Z6.485714 E7884.229726 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y221.388065 Z6.495238 E7888.833497 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y222.151728 Z6.504762 E7892.182476 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y222.765485 Z6.514286 E7894.736623 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y223.319317 Z6.52381 E7898.894949 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y223.536087 Z6.533333 E7903.289943 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y223.419026 Z6.542857 E7908.445504 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y223.08422 Z6.552381 E7914.288262 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y222.645709 Z6.561905 E7920.49473 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y222.234477 Z6.571429 E7926.603615 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y221.978048 Z6.580952 E7932.185806 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y221.983449 Z6.590476 E7937.013575 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y222.314523 Z6.6 E7941.25994 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y223.009822 Z6.609524 E7945.506306 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y224.030794 Z6.619048 E7950.334075 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y225.313596 Z6.628571 E7955.916266 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y226.7512 Z6.638095 E7962.025151 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y228.216084 Z6.647619 E7968.231619 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y229.577262 Z6.657143 E7974.074377 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y230.741706 Z6.666667 E7987.944193 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y227.434927 Z6.67619 E8003.280197 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y226.436779 Z6.685714 E8007.438522 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y225.444607 Z6.695238 E8011.950488 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y224.458286 Z6.704762 E8017.251778 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y223.475633 Z6.714286 E8023.197923 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y222.494437 Z6.72381 E8029.422586 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y221.512251 Z6.733333 E8035.456896 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y220.526774 Z6.742857 E8040.89834 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y219.53592 Z6.752381 E8045.555929 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y218.539198 Z6.761905 E8049.74857 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y217.53594 Z6.771429 E8054.056105 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y216.526411 Z6.780952 E8059.055918 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y215.512477 Z6.790476 E8064.778793 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z6.8 E8070.949 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y213.479828 Z6.809524 E8077.119206 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y212.465893 Z6.819048 E8082.842081 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y212.180996 Z6.828571 E8085.479858 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y212.886847 Z6.838095 E8088.445235 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y212.762815 Z6.847619 E8089.297661 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y211.834197 Z6.857143 E8093.95525 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y210.609641 Z6.866667 E8099.396694 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y209.203894 Z6.87619 E8105.431003 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y207.74373 Z6.885714 E8111.655667 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y206.363703 Z6.895238 E8117.601812 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y205.185623 Z6.904762 E8122.903102 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y204.329541 Z6.914286 E8127.415068 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y203.80243 Z6.92381 E8131.573393 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y203.618616 Z6.933333 E8135.968387 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y203.774812 Z6.942857 E8141.123948 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y204.152782 Z6.952381 E8146.966706 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y204.636376 Z6.961905 E8153.173174 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y205.092185 Z6.971429 E8159.282059 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y205.390328 Z6.980952 E8164.86425 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y205.421796 Z6.990476 E8169.692019 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X174.5 Y202.5 Z7 E8185.727041 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y199.578204 Z7.009524 E8201.762063 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y199.609672 Z7.019048 E8206.589831 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y199.907815 Z7.028571 E8212.172022 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y200.363624 Z7.038095 E8218.280907 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y200.847218 Z7.047619 E8224.487376 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y201.225188 Z7.057143 E8230.330133 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y201.381384 Z7.066667 E8235.485694 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y201.19757 Z7.07619 E8239.880688 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y200.670459 Z7.085714 E8244.039014 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y199.814377 Z7.095238 E8248.55098 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y198.636297 Z7.104762 E8253.852269 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y197.25627 Z7.114286 E8259.798414 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y195.796106 Z7.12381 E8266.023078 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y194.390359 Z7.133333 E8272.057388 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y193.165803 Z7.142857 E8277.498831 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y192.237185 Z7.152381 E8282.15642 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y192.113153 Z7.161905 E8283.008847 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y192.819004 Z7.171429 E8285.974223 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y192.534107 Z7.180952 E8288.612 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y191.520172 Z7.190476 E8294.334875 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z7.2 E8300.505082 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y189.487523 Z7.209524 E8306.675288 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y188.473589 Z7.219048 E8312.398164 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y187.46406 Z7.228571 E8317.397977 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y186.460802 Z7.238095 E8321.705512 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y185.46408 Z7.247619 E8325.898153 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y184.473226 Z7.257143 E8330.555742 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y183.487749 Z7.266667 E8335.997185 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y182.505563 Z7.27619 E8342.031495 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y181.524367 Z7.285714 E8348.256159 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y180.541714 Z7.295238 E8354.202304 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y179.555393 Z7.304762 E8359.503594 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y178.563221 Z7.314286 E8364.015559 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y177.565073 Z7.32381 E8368.173885 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y174.258294 Z7.333333 E8383.509888 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y175.422738 Z7.342857 E8397.379705 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y176.783916 Z7.352381 E8403.222463 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y178.2488 Z7.361905 E8409.428931 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y179.686404 Z7.371429 E8415.537816 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y180.969206 Z7.380952 E8421.120007 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y181.990178 Z7.390476 E8425.947775 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y182.685477 Z7.4 E8430.194141 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y183.016551 Z7.409524 E8434.440507 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y183.021952 Z7.419048 E8439.268276 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y182.765523 Z7.428571 E8444.850466 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y182.354291 Z7.438095 E8450.959352 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y181.91578 Z7.447619 E8457.16582 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y181.580974 Z7.457143 E8463.008577 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y181.463913 Z7.466667 E8468.164139 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y181.680683 Z7.47619 E8472.559133 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y182.234515 Z7.485714 E8476.717458 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y182.848272 Z7.495238 E8479.271606 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y183.611935 Z7.504762 E8482.620585 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y184.156005 Z7.514286 E8487.224356 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y184.599564 Z7.52381 E8493.44902 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y184.989694 Z7.533333 E8499.48333 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y185.201926 Z7.542857 E8504.924773 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y185.123596 Z7.552381 E8509.582362 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y184.728123 Z7.561905 E8513.775003 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y183.979462 Z7.571429 E8518.082538 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y182.891948 Z7.580952 E8523.082351 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y181.566331 Z7.590476 E8528.805227 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z7.6 E8534.975433 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y178.656754 Z7.609524 E8541.145639 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y177.331138 Z7.619048 E8546.868515 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y176.243623 Z7.628571 E8551.868328 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y175.494963 Z7.638095 E8556.175863 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y175.099489 Z7.647619 E8560.368504 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y175.021159 Z7.657143 E8565.026093 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y175.221331 Z7.666667 E8576.741162 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y177.525217 Z7.67619 E8586.411307 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y178.506414 Z7.685714 E8592.635971 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y179.489066 Z7.695238 E8598.582116 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y180.475388 Z7.704762 E8603.883406 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y181.467559 Z7.714286 E8608.395372 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y182.465708 Z7.72381 E8612.553697 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y183.470094 Z7.733333 E8616.948691 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y184.480657 Z7.742857 E8622.104252 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y185.495249 Z7.752381 E8627.94701 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y186.511761 Z7.761905 E8634.153478 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y187.527767 Z7.771429 E8640.262363 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y188.540909 Z7.780952 E8645.844554 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y189.549206 Z7.790476 E8650.672323 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y190.551477 Z7.8 E8654.918688 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y191.547008 Z7.809524 E8659.165054 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y192.536512 Z7.819048 E8663.992823 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y193.174342 Z7.828571 E8668.764854 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y194.085027 Z7.838095 E8673.473751 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y195.504361 Z7.847619 E8679.493419 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y196.853759 Z7.857143 E8685.336177 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y197.981384 Z7.866667 E8690.491738 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y198.768999 Z7.87619 E8694.886732 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y199.213316 Z7.885714 E8699.045058 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y199.328663 Z7.895238 E8703.557023 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y199.122011 Z7.904762 E8708.858313 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y198.713412 Z7.914286 E8714.804458 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y198.224677 Z7.92381 E8721.029122 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y197.790359 Z7.933333 E8727.063432 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y197.537232 Z7.942857 E8732.504875 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y197.580043 Z7.952381 E8737.162464 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y197.945866 Z7.961905 E8741.355105 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y198.671412 Z7.971429 E8745.66264 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y199.742082 Z7.980952 E8750.662454 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y201.055259 Z7.990476 E8756.385329 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z8 E8762.555535 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.026688 Z8.009524 E8768.725742 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y201.684939 Z8.019048 E8774.448617 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y201.585698 Z8.028571 E8779.44843 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y201.83158 Z8.038095 E8783.755965 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.437185 Z8.047619 E8787.948606 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y203.365803 Z8.057143 E8792.606195 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y204.590359 Z8.066667 E8798.047639 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y205.996106 Z8.07619 E8804.081949 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y207.45627 Z8.085714 E8810.306612 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y208.836297 Z8.095238 E8816.252757 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y210.014377 Z8.104762 E8821.554047 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y210.870459 Z8.114286 E8826.066013 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y211.39757 Z8.12381 E8830.224338 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y211.581384 Z8.133333 E8834.619332 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y211.425188 Z8.142857 E8839.774894 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y211.047218 Z8.152381 E8845.617651 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y210.599313 Z8.161905 E8851.966869 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y211.173243 Z8.171429 E8858.762707 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y212.533214 Z8.180952 E8865.594994 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y213.541511 Z8.190476 E8870.422763 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y214.543782 Z8.2 E8874.669128 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y215.539313 Z8.209524 E8878.915494 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y216.528817 Z8.219048 E8883.743263 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y217.513476 Z8.228571 E8889.325454 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y218.495271 Z8.238095 E8895.434339 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y219.476561 Z8.247619 E8901.640807 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y220.45977 Z8.257143 E8907.483565 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y221.447008 Z8.266667 E8912.639126 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y222.440424 Z8.27619 E8917.03412 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y223.440077 Z8.285714 E8921.192445 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y224.445706 Z8.295238 E8925.704411 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y225.457186 Z8.304762 E8931.005701 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y226.472335 Z8.314286 E8936.951846 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y227.48894 Z8.32381 E8943.17651 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y227.182855 Z8.333333 E8944.923386 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y225.956311 Z8.342857 E8951.763175 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y225.008268 Z8.352381 E8956.420764 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y224.377369 Z8.361905 E8960.613405 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y224.099656 Z8.371429 E8964.92094 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y224.160798 Z8.380952 E8969.920753 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y224.460041 Z8.390476 E8975.643629 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z8.4 E8981.813835 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y225.316873 Z8.409524 E8987.984041 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y225.616117 Z8.419048 E8993.706917 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y225.677258 Z8.428571 E8998.70673 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y225.399546 Z8.438095 E9003.014265 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y224.768647 Z8.447619 E9007.206906 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y223.820604 Z8.457143 E9011.864495 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y222.581999 Z8.466667 E9017.305939 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y221.165496 Z8.47619 E9023.340248 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y219.695564 Z8.485714 E9029.564912 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y218.125122 Z8.495238 E9036.800293 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y217.361458 Z8.504762 E9045.586103 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y217.774074 Z8.514286 E9052.815438 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y218.246615 Z8.52381 E9056.973764 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y219.056218 Z8.533333 E9061.368758 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y220.199652 Z8.542857 E9066.524319 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y221.560831 Z8.552381 E9072.367077 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y223.025715 Z8.561905 E9078.573545 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y224.463319 Z8.571429 E9084.68243 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y225.746121 Z8.580952 E9090.264621 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y226.767093 Z8.590476 E9095.092389 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y227.462391 Z8.6 E9099.338755 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y227.793466 Z8.609524 E9103.585121 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y227.798867 Z8.619048 E9108.41289 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y227.542437 Z8.628571 E9113.99508 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y227.131206 Z8.638095 E9120.103966 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y226.692695 Z8.647619 E9126.310434 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y226.357889 Z8.657143 E9132.153191 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y226.219818 Z8.666667 E9138.051578 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y227.528795 Z8.67619 E9146.861354 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y226.529143 Z8.685714 E9151.019679 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y225.523513 Z8.695238 E9155.531645 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y224.512033 Z8.704762 E9160.832935 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y223.496884 Z8.714286 E9166.77908 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y222.480279 Z8.72381 E9173.003744 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y221.464663 Z8.733333 E9179.038053 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y220.452339 Z8.742857 E9184.479497 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y219.445392 Z8.752381 E9189.137086 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y218.444313 Z8.761905 E9193.329727 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y217.449769 Z8.771429 E9197.637262 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y216.461496 Z8.780952 E9202.637075 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y215.477629 Z8.790476 E9208.35995 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z8.8 E9214.530157 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y213.514676 Z8.809524 E9220.700363 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y212.530809 Z8.819048 E9226.423239 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y210.817905 Z8.828571 E9233.967018 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y208.627439 Z8.838095 E9243.908896 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y207.780043 Z8.847619 E9251.374085 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y207.737232 Z8.857143 E9256.031674 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y207.990359 Z8.866667 E9261.473117 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y208.424677 Z8.87619 E9267.507427 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y208.913412 Z8.885714 E9273.732091 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y209.322011 Z8.895238 E9279.678236 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y209.528663 Z8.904762 E9284.979525 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y209.413316 Z8.914286 E9289.491491 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y208.968999 Z8.92381 E9293.649817 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y208.181384 Z8.933333 E9298.044811 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y207.053759 Z8.942857 E9303.200372 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y205.704361 Z8.952381 E9309.04313 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y204.249338 Z8.961905 E9315.249598 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.8221 Z8.971429 E9321.358483 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y201.552529 Z8.980952 E9326.940674 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y200.549633 Z8.990476 E9331.768442 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.5 Y202.5 Z9 E9340.488765 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y204.450367 Z9.009524 E9349.209087 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y203.447471 Z9.019048 E9354.036856 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.1779 Z9.028571 E9359.619046 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y200.750662 Z9.038095 E9365.727932 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y199.295639 Z9.047619 E9371.9344 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y197.946241 Z9.057143 E9377.777157 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y196.818616 Z9.066667 E9382.932719 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y196.031001 Z9.07619 E9387.327712 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y195.586684 Z9.085714 E9391.486038 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y195.471337 Z9.095238 E9395.998004 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y195.677989 Z9.104762 E9401.299294 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y196.086588 Z9.114286 E9407.245438 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y196.575323 Z9.12381 E9413.470102 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y197.009641 Z9.133333 E9419.504412 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y197.262768 Z9.142857 E9424.945855 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y197.219957 Z9.152381 E9429.603445 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y196.372561 Z9.161905 E9437.068633 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y194.182095 Z9.171429 E9447.010512 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y192.469191 Z9.180952 E9454.554291 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y191.485324 Z9.190476 E9460.277166 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z9.2 E9466.447372 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y189.522371 Z9.209524 E9472.617579 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y188.538504 Z9.219048 E9478.340454 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y187.550231 Z9.228571 E9483.340267 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y186.555687 Z9.238095 E9487.647802 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y185.554608 Z9.247619 E9491.840443 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y184.547661 Z9.257143 E9496.498032 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y183.535337 Z9.266667 E9501.939476 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y182.519721 Z9.27619 E9507.973786 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y181.503116 Z9.285714 E9514.19845 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y180.487967 Z9.295238 E9520.144594 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y179.476487 Z9.304762 E9525.445884 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y178.470857 Z9.314286 E9529.95785 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y177.471205 Z9.32381 E9534.116175 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y178.780182 Z9.333333 E9542.925952 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y178.642111 Z9.342857 E9548.824338 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y178.307305 Z9.352381 E9554.667095 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y177.868794 Z9.361905 E9560.873564 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y177.457563 Z9.371429 E9566.982449 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y177.201133 Z9.380952 E9572.56464 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y177.206534 Z9.390476 E9577.392408 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y177.537609 Z9.4 E9581.638774 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y178.232907 Z9.409524 E9585.88514 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y179.253879 Z9.419048 E9590.712909 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y180.536681 Z9.428571 E9596.295099 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y181.974285 Z9.438095 E9602.403985 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y183.439169 Z9.447619 E9608.610453 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y184.800348 Z9.457143 E9614.45321 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y185.943782 Z9.466667 E9619.608771 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y186.753385 Z9.47619 E9624.003765 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y187.225926 Z9.485714 E9628.162091 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y187.638542 Z9.495238 E9635.391427 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y186.874878 Z9.504762 E9644.177236 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y185.304436 Z9.514286 E9651.412617 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y183.834504 Z9.52381 E9657.637281 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y182.418001 Z9.533333 E9663.671591 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y181.179396 Z9.542857 E9669.113034 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y180.231353 Z9.552381 E9673.770623 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y179.600454 Z9.561905 E9677.963264 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y179.322742 Z9.571429 E9682.270799 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y179.383883 Z9.580952 E9687.270612 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y179.683127 Z9.590476 E9692.993488 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z9.6 E9699.163694 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y180.539959 Z9.609524 E9705.333901 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y180.839202 Z9.619048 E9711.056776 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y180.900344 Z9.628571 E9716.056589 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y180.622631 Z9.638095 E9720.364124 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y179.991732 Z9.647619 E9724.556765 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y179.043689 Z9.657143 E9729.214354 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y177.817145 Z9.666667 E9736.054144 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y177.51106 Z9.67619 E9737.80102 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y178.527665 Z9.685714 E9744.025684 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y179.542814 Z9.695238 E9749.971828 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y180.554294 Z9.704762 E9755.273118 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y181.559923 Z9.714286 E9759.785084 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y182.559576 Z9.72381 E9763.943409 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y183.552992 Z9.733333 E9768.338403 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y184.54023 Z9.742857 E9773.493965 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y185.523439 Z9.752381 E9779.336722 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y186.504729 Z9.761905 E9785.54319 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y187.486524 Z9.771429 E9791.652076 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y188.471183 Z9.780952 E9797.234266 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y189.460687 Z9.790476 E9802.062035 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y190.456218 Z9.8 E9806.308401 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y191.458489 Z9.809524 E9810.554767 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y192.466786 Z9.819048 E9815.382535 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y193.826757 Z9.828571 E9822.214822 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y194.400687 Z9.838095 E9829.01066 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y193.952782 Z9.847619 E9835.359878 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y193.574812 Z9.857143 E9841.202636 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y193.418616 Z9.866667 E9846.358197 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y193.60243 Z9.87619 E9850.753191 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y194.129541 Z9.885714 E9854.911516 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y194.985623 Z9.895238 E9859.423482 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y196.163703 Z9.904762 E9864.724772 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y197.54373 Z9.914286 E9870.670917 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y199.003894 Z9.92381 E9876.895581 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y200.409641 Z9.933333 E9882.92989 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y201.634197 Z9.942857 E9888.371334 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.562815 Z9.952381 E9893.028923 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y203.16842 Z9.961905 E9897.221564 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y203.414302 Z9.971429 E9901.529099 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y203.315061 Z9.980952 E9906.528912 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.973312 Z9.990476 E9912.251788 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z10 E9918.421994 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y203.944741 Z10.009524 E9924.5922 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y205.257918 Z10.019048 E9930.315076 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y206.328588 Z10.028571 E9935.314889 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y207.054134 Z10.038095 E9939.622424 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y207.419957 Z10.047619 E9943.815065 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y207.462768 Z10.057143 E9948.472654 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y207.209641 Z10.066667 E9953.914098 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y206.775323 Z10.07619 E9959.948407 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y206.286588 Z10.085714 E9966.173071 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y205.877989 Z10.095238 E9972.119216 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y205.671337 Z10.104762 E9977.420506 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y205.786684 Z10.114286 E9981.932471 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y206.231001 Z10.12381 E9986.090797 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y207.018616 Z10.133333 E9990.485791 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y208.146241 Z10.142857 E9995.641352 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y209.495639 Z10.152381 E10001.48411 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y210.914973 Z10.161905 E10007.503778 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y211.825658 Z10.171429 E10012.212675 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y212.463488 Z10.180952 E10016.984706 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y213.452992 Z10.190476 E10021.812475 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y214.448523 Z10.2 E10026.058841 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y215.450794 Z10.209524 E10030.305207 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y216.459091 Z10.219048 E10035.132975 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y217.472233 Z10.228571 E10040.715166 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y218.488239 Z10.238095 E10046.824051 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y219.504751 Z10.247619 E10053.030519 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y220.519343 Z10.257143 E10058.873277 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y221.529906 Z10.266667 E10064.028838 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y222.534292 Z10.27619 E10068.423832 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y223.532441 Z10.285714 E10072.582158 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y224.524612 Z10.295238 E10077.094123 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y225.510934 Z10.304762 E10082.395413 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y226.493586 Z10.314286 E10088.341558 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y227.474783 Z10.32381 E10094.566222 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y229.778669 Z10.333333 E10104.236367 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y229.978841 Z10.342857 E10115.951436 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y229.900511 Z10.352381 E10120.609025 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y229.505037 Z10.361905 E10124.801666 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y228.756377 Z10.371429 E10129.109201 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y227.668862 Z10.380952 E10134.109014 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y226.343246 Z10.390476 E10139.83189 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z10.4 E10146.002096 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y223.433669 Z10.409524 E10152.172302 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y222.108052 Z10.419048 E10157.895178 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y221.020538 Z10.428571 E10162.894991 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y220.271877 Z10.438095 E10167.202526 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y219.876404 Z10.447619 E10171.395167 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y219.798074 Z10.457143 E10176.052756 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y220.010306 Z10.466667 E10181.4942 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y220.400436 Z10.47619 E10187.528509 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y220.843995 Z10.485714 E10193.753173 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y221.388065 Z10.495238 E10198.356945 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y222.151728 Z10.504762 E10201.705924 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y222.765485 Z10.514286 E10204.260071 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y223.319317 Z10.52381 E10208.418397 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y223.536087 Z10.533333 E10212.813391 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y223.419026 Z10.542857 E10217.968952 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y223.08422 Z10.552381 E10223.811709 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y222.645709 Z10.561905 E10230.018178 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y222.234477 Z10.571429 E10236.127063 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y221.978048 Z10.580952 E10241.709254 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y221.983449 Z10.590476 E10246.537022 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y222.314523 Z10.6 E10250.783388 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y223.009822 Z10.609524 E10255.029754 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y224.030794 Z10.619048 E10259.857523 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y225.313596 Z10.628571 E10265.439713 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y226.7512 Z10.638095 E10271.548599 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y228.216084 Z10.647619 E10277.755067 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y229.577262 Z10.657143 E10283.597824 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y230.741706 Z10.666667 E10297.467641 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y227.434927 Z10.67619 E10312.803644 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y226.436779 Z10.685714 E10316.96197 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y225.444607 Z10.695238 E10321.473936 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y224.458286 Z10.704762 E10326.775225 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y223.475633 Z10.714286 E10332.72137 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y222.494437 Z10.72381 E10338.946034 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y221.512251 Z10.733333 E10344.980344 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y220.526774 Z10.742857 E10350.421787 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y219.53592 Z10.752381 E10355.079377 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y218.539198 Z10.761905 E10359.272018 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y217.53594 Z10.771429 E10363.579552 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y216.526411 Z10.780952 E10368.579366 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y215.512477 Z10.790476 E10374.302241 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z10.8 E10380.472447 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y213.479828 Z10.809524 E10386.642654 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y212.465893 Z10.819048 E10392.365529 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y212.180996 Z10.828571 E10395.003306 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y212.886847 Z10.838095 E10397.968683 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y212.762815 Z10.847619 E10398.821109 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y211.834197 Z10.857143 E10403.478698 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y210.609641 Z10.866667 E10408.920141 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y209.203894 Z10.87619 E10414.954451 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y207.74373 Z10.885714 E10421.179115 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y206.363703 Z10.895238 E10427.12526 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y205.185623 Z10.904762 E10432.42655 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y204.329541 Z10.914286 E10436.938515 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y203.80243 Z10.92381 E10441.096841 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y203.618616 Z10.933333 E10445.491835 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y203.774812 Z10.942857 E10450.647396 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y204.152782 Z10.952381 E10456.490154 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y204.636376 Z10.961905 E10462.696622 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y205.092185 Z10.971429 E10468.805507 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y205.390328 Z10.980952 E10474.387698 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y205.421796 Z10.990476 E10479.215467 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X174.5 Y202.5 Z11 E10495.250488 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y199.578204 Z11.009524 E10511.28551 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y199.609672 Z11.019048 E10516.113279 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y199.907815 Z11.028571 E10521.69547 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y200.363624 Z11.038095 E10527.804355 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y200.847218 Z11.047619 E10534.010823 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y201.225188 Z11.057143 E10539.853581 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y201.381384 Z11.066667 E10545.009142 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y201.19757 Z11.07619 E10549.404136 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y200.670459 Z11.085714 E10553.562462 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y199.814377 Z11.095238 E10558.074427 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y198.636297 Z11.104762 E10563.375717 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y197.25627 Z11.114286 E10569.321862 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y195.796106 Z11.12381 E10575.546526 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y194.390359 Z11.133333 E10581.580835 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y193.165803 Z11.142857 E10587.022279 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y192.237185 Z11.152381 E10591.679868 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y192.113153 Z11.161905 E10592.532294 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y192.819004 Z11.171429 E10595.497671 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y192.534107 Z11.180952 E10598.135448 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y191.520172 Z11.190476 E10603.858323 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z11.2 E10610.02853 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y189.487523 Z11.209524 E10616.198736 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y188.473589 Z11.219048 E10621.921611 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y187.46406 Z11.228571 E10626.921425 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y186.460802 Z11.238095 E10631.228959 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y185.46408 Z11.247619 E10635.4216 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y184.473226 Z11.257143 E10640.07919 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y183.487749 Z11.266667 E10645.520633 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y182.505563 Z11.27619 E10651.554943 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y181.524367 Z11.285714 E10657.779607 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y180.541714 Z11.295238 E10663.725751 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y179.555393 Z11.304762 E10669.027041 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y178.563221 Z11.314286 E10673.539007 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y177.565073 Z11.32381 E10677.697333 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y174.258294 Z11.333333 E10693.033336 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y175.422738 Z11.342857 E10706.903153 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y176.783916 Z11.352381 E10712.74591 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y178.2488 Z11.361905 E10718.952378 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y179.686404 Z11.371429 E10725.061264 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y180.969206 Z11.380952 E10730.643454 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y181.990178 Z11.390476 E10735.471223 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y182.685477 Z11.4 E10739.717589 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y183.016551 Z11.409524 E10743.963955 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y183.021952 Z11.419048 E10748.791723 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y182.765523 Z11.428571 E10754.373914 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y182.354291 Z11.438095 E10760.482799 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y181.91578 Z11.447619 E10766.689267 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y181.580974 Z11.457143 E10772.532025 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y181.463913 Z11.466667 E10777.687586 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y181.680683 Z11.47619 E10782.08258 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y182.234515 Z11.485714 E10786.240906 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y182.848272 Z11.495238 E10788.795053 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y183.611935 Z11.504762 E10792.144032 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y184.156005 Z11.514286 E10796.747804 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y184.599564 Z11.52381 E10802.972468 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y184.989694 Z11.533333 E10809.006777 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y185.201926 Z11.542857 E10814.448221 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y185.123596 Z11.552381 E10819.10581 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y184.728123 Z11.561905 E10823.298451 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y183.979462 Z11.571429 E10827.605986 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y182.891948 Z11.580952 E10832.605799 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y181.566331 Z11.590476 E10838.328674 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z11.6 E10844.498881 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y178.656754 Z11.609524 E10850.669087 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y177.331138 Z11.619048 E10856.391963 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y176.243623 Z11.628571 E10861.391776 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y175.494963 Z11.638095 E10865.699311 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y175.099489 Z11.647619 E10869.891952 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y175.021159 Z11.657143 E10874.549541 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y175.221331 Z11.666667 E10886.26461 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y177.525217 Z11.67619 E10895.934755 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y178.506414 Z11.685714 E10902.159419 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y179.489066 Z11.695238 E10908.105564 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y180.475388 Z11.704762 E10913.406854 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y181.467559 Z11.714286 E10917.918819 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y182.465708 Z11.72381 E10922.077145 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y183.470094 Z11.733333 E10926.472139 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y184.480657 Z11.742857 E10931.6277 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y185.495249 Z11.752381 E10937.470458 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y186.511761 Z11.761905 E10943.676926 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y187.527767 Z11.771429 E10949.785811 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y188.540909 Z11.780952 E10955.368002 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y189.549206 Z11.790476 E10960.19577 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y190.551477 Z11.8 E10964.442136 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y191.547008 Z11.809524 E10968.688502 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y192.536512 Z11.819048 E10973.516271 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y193.174342 Z11.828571 E10978.288302 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y194.085027 Z11.838095 E10982.997199 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y195.504361 Z11.847619 E10989.016867 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y196.853759 Z11.857143 E10994.859625 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y197.981384 Z11.866667 E11000.015186 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y198.768999 Z11.87619 E11004.41018 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y199.213316 Z11.885714 E11008.568506 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y199.328663 Z11.895238 E11013.080471 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y199.122011 Z11.904762 E11018.381761 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y198.713412 Z11.914286 E11024.327906 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y198.224677 Z11.92381 E11030.55257 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y197.790359 Z11.933333 E11036.586879 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y197.537232 Z11.942857 E11042.028323 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y197.580043 Z11.952381 E11046.685912 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y197.945866 Z11.961905 E11050.878553 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y198.671412 Z11.971429 E11055.186088 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y199.742082 Z11.980952 E11060.185901 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y201.055259 Z11.990476 E11065.908777 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z12 E11072.078983 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.026688 Z12.009524 E11078.249189 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y201.684939 Z12.019048 E11083.972065 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y201.585698 Z12.028571 E11088.971878 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y201.83158 Z12.038095 E11093.279413 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.437185 Z12.047619 E11097.472054 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y203.365803 Z12.057143 E11102.129643 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y204.590359 Z12.066667 E11107.571087 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y205.996106 Z12.07619 E11113.605396 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y207.45627 Z12.085714 E11119.83006 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y208.836297 Z12.095238 E11125.776205 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y210.014377 Z12.104762 E11131.077495 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y210.870459 Z12.114286 E11135.58946 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y211.39757 Z12.12381 E11139.747786 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y211.581384 Z12.133333 E11144.14278 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y211.425188 Z12.142857 E11149.298341 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y211.047218 Z12.152381 E11155.141099 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y210.599313 Z12.161905 E11161.490317 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y211.173243 Z12.171429 E11168.286154 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y212.533214 Z12.180952 E11175.118442 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y213.541511 Z12.190476 E11179.94621 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y214.543782 Z12.2 E11184.192576 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y215.539313 Z12.209524 E11188.438942 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y216.528817 Z12.219048 E11193.266711 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y217.513476 Z12.228571 E11198.848901 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y218.495271 Z12.238095 E11204.957787 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y219.476561 Z12.247619 E11211.164255 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y220.45977 Z12.257143 E11217.007012 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y221.447008 Z12.266667 E11222.162574 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y222.440424 Z12.27619 E11226.557568 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y223.440077 Z12.285714 E11230.715893 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y224.445706 Z12.295238 E11235.227859 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y225.457186 Z12.304762 E11240.529149 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y226.472335 Z12.314286 E11246.475293 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y227.48894 Z12.32381 E11252.699957 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y227.182855 Z12.333333 E11254.446833 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y225.956311 Z12.342857 E11261.286623 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y225.008268 Z12.352381 E11265.944212 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y224.377369 Z12.361905 E11270.136853 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y224.099656 Z12.371429 E11274.444388 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y224.160798 Z12.380952 E11279.444201 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y224.460041 Z12.390476 E11285.167076 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z12.4 E11291.337283 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y225.316873 Z12.409524 E11297.507489 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y225.616117 Z12.419048 E11303.230365 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y225.677258 Z12.428571 E11308.230178 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y225.399546 Z12.438095 E11312.537713 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y224.768647 Z12.447619 E11316.730354 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y223.820604 Z12.457143 E11321.387943 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y222.581999 Z12.466667 E11326.829386 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y221.165496 Z12.47619 E11332.863696 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y219.695564 Z12.485714 E11339.08836 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y218.125122 Z12.495238 E11346.323741 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y217.361458 Z12.504762 E11355.10955 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y217.774074 Z12.514286 E11362.338886 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y218.246615 Z12.52381 E11366.497212 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y219.056218 Z12.533333 E11370.892205 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y220.199652 Z12.542857 E11376.047767 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y221.560831 Z12.552381 E11381.890524 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y223.025715 Z12.561905 E11388.096992 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y224.463319 Z12.571429 E11394.205878 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y225.746121 Z12.580952 E11399.788068 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y226.767093 Z12.590476 E11404.615837 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y227.462391 Z12.6 E11408.862203 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y227.793466 Z12.609524 E11413.108569 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y227.798867 Z12.619048 E11417.936337 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y227.542437 Z12.628571 E11423.518528 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y227.131206 Z12.638095 E11429.627413 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y226.692695 Z12.647619 E11435.833881 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y226.357889 Z12.657143 E11441.676639 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y226.219818 Z12.666667 E11447.575025 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y227.528795 Z12.67619 E11456.384801 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y226.529143 Z12.685714 E11460.543127 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y225.523513 Z12.695238 E11465.055093 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y224.512033 Z12.704762 E11470.356383 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y223.496884 Z12.714286 E11476.302527 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y222.480279 Z12.72381 E11482.527191 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y221.464663 Z12.733333 E11488.561501 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y220.452339 Z12.742857 E11494.002944 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y219.445392 Z12.752381 E11498.660534 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y218.444313 Z12.761905 E11502.853175 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y217.449769 Z12.771429 E11507.16071 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y216.461496 Z12.780952 E11512.160523 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y215.477629 Z12.790476 E11517.883398 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z12.8 E11524.053605 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y213.514676 Z12.809524 E11530.223811 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y212.530809 Z12.819048 E11535.946686 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y210.817905 Z12.828571 E11543.490465 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y208.627439 Z12.838095 E11553.432344 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y207.780043 Z12.847619 E11560.897532 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y207.737232 Z12.857143 E11565.555121 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y207.990359 Z12.866667 E11570.996565 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y208.424677 Z12.87619 E11577.030875 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y208.913412 Z12.885714 E11583.255539 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y209.322011 Z12.895238 E11589.201683 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y209.528663 Z12.904762 E11594.502973 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y209.413316 Z12.914286 E11599.014939 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y208.968999 Z12.92381 E11603.173264 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y208.181384 Z12.933333 E11607.568258 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y207.053759 Z12.942857 E11612.72382 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y205.704361 Z12.952381 E11618.566577 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y204.249338 Z12.961905 E11624.773045 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.8221 Z12.971429 E11630.881931 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y201.552529 Z12.980952 E11636.464121 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y200.549633 Z12.990476 E11641.29189 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.5 Y202.5 Z13 E11650.012212 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y204.450367 Z13.009524 E11658.732535 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y203.447471 Z13.019048 E11663.560303 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.1779 Z13.028571 E11669.142494 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y200.750662 Z13.038095 E11675.251379 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y199.295639 Z13.047619 E11681.457847 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y197.946241 Z13.057143 E11687.300605 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y196.818616 Z13.066667 E11692.456166 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y196.031001 Z13.07619 E11696.85116 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y195.586684 Z13.085714 E11701.009486 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y195.471337 Z13.095238 E11705.521452 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y195.677989 Z13.104762 E11710.822741 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y196.086588 Z13.114286 E11716.768886 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y196.575323 Z13.12381 E11722.99355 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y197.009641 Z13.133333 E11729.02786 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y197.262768 Z13.142857 E11734.469303 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y197.219957 Z13.152381 E11739.126892 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y196.372561 Z13.161905 E11746.592081 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y194.182095 Z13.171429 E11756.533959 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y192.469191 Z13.180952 E11764.077738 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y191.485324 Z13.190476 E11769.800614 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z13.2 E11775.97082 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y189.522371 Z13.209524 E11782.141026 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y188.538504 Z13.219048 E11787.863902 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y187.550231 Z13.228571 E11792.863715 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y186.555687 Z13.238095 E11797.17125 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y185.554608 Z13.247619 E11801.363891 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y184.547661 Z13.257143 E11806.02148 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y183.535337 Z13.266667 E11811.462924 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y182.519721 Z13.27619 E11817.497233 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y181.503116 Z13.285714 E11823.721897 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y180.487967 Z13.295238 E11829.668042 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y179.476487 Z13.304762 E11834.969332 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y178.470857 Z13.314286 E11839.481298 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y177.471205 Z13.32381 E11843.639623 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y178.780182 Z13.333333 E11852.449399 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y178.642111 Z13.342857 E11858.347786 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y178.307305 Z13.352381 E11864.190543 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y177.868794 Z13.361905 E11870.397011 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y177.457563 Z13.371429 E11876.505897 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y177.201133 Z13.380952 E11882.088087 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y177.206534 Z13.390476 E11886.915856 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y177.537609 Z13.4 E11891.162222 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y178.232907 Z13.409524 E11895.408588 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y179.253879 Z13.419048 E11900.236356 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y180.536681 Z13.428571 E11905.818547 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y181.974285 Z13.438095 E11911.927432 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y183.439169 Z13.447619 E11918.1339 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y184.800348 Z13.457143 E11923.976658 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y185.943782 Z13.466667 E11929.132219 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y186.753385 Z13.47619 E11933.527213 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y187.225926 Z13.485714 E11937.685539 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y187.638542 Z13.495238 E11944.914874 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y186.874878 Z13.504762 E11953.700684 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y185.304436 Z13.514286 E11960.936065 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y183.834504 Z13.52381 E11967.160729 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y182.418001 Z13.533333 E11973.195038 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y181.179396 Z13.542857 E11978.636482 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y180.231353 Z13.552381 E11983.294071 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y179.600454 Z13.561905 E11987.486712 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y179.322742 Z13.571429 E11991.794247 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y179.383883 Z13.580952 E11996.79406 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y179.683127 Z13.590476 E12002.516936 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z13.6 E12008.687142 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y180.539959 Z13.609524 E12014.857348 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y180.839202 Z13.619048 E12020.580224 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y180.900344 Z13.628571 E12025.580037 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y180.622631 Z13.638095 E12029.887572 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y179.991732 Z13.647619 E12034.080213 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y179.043689 Z13.657143 E12038.737802 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y177.817145 Z13.666667 E12045.577591 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y177.51106 Z13.67619 E12047.324467 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y178.527665 Z13.685714 E12053.549131 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y179.542814 Z13.695238 E12059.495276 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y180.554294 Z13.704762 E12064.796566 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y181.559923 Z13.714286 E12069.308531 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y182.559576 Z13.72381 E12073.466857 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y183.552992 Z13.733333 E12077.861851 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y184.54023 Z13.742857 E12083.017412 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y185.523439 Z13.752381 E12088.86017 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y186.504729 Z13.761905 E12095.066638 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y187.486524 Z13.771429 E12101.175523 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y188.471183 Z13.780952 E12106.757714 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y189.460687 Z13.790476 E12111.585483 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y190.456218 Z13.8 E12115.831848 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y191.458489 Z13.809524 E12120.078214 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y192.466786 Z13.819048 E12124.905983 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y193.826757 Z13.828571 E12131.73827 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y194.400687 Z13.838095 E12138.534107 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y193.952782 Z13.847619 E12144.883326 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y193.574812 Z13.857143 E12150.726083 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y193.418616 Z13.866667 E12155.881645 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y193.60243 Z13.87619 E12160.276639 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y194.129541 Z13.885714 E12164.434964 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y194.985623 Z13.895238 E12168.94693 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y196.163703 Z13.904762 E12174.24822 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y197.54373 Z13.914286 E12180.194364 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y199.003894 Z13.92381 E12186.419028 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y200.409641 Z13.933333 E12192.453338 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y201.634197 Z13.942857 E12197.894782 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.562815 Z13.952381 E12202.552371 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y203.16842 Z13.961905 E12206.745012 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y203.414302 Z13.971429 E12211.052547 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y203.315061 Z13.980952 E12216.05236 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.973312 Z13.990476 E12221.775235 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z14 E12227.945442 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y203.944741 Z14.009524 E12234.115648 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y205.257918 Z14.019048 E12239.838523 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y206.328588 Z14.028571 E12244.838337 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y207.054134 Z14.038095 E12249.145871 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y207.419957 Z14.047619 E12253.338513 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y207.462768 Z14.057143 E12257.996102 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y207.209641 Z14.066667 E12263.437545 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y206.775323 Z14.07619 E12269.471855 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y206.286588 Z14.085714 E12275.696519 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y205.877989 Z14.095238 E12281.642664 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y205.671337 Z14.104762 E12286.943953 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y205.786684 Z14.114286 E12291.455919 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y206.231001 Z14.12381 E12295.614245 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y207.018616 Z14.133333 E12300.009239 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y208.146241 Z14.142857 E12305.1648 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y209.495639 Z14.152381 E12311.007558 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y210.914973 Z14.161905 E12317.027226 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y211.825658 Z14.171429 E12321.736123 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y212.463488 Z14.180952 E12326.508154 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y213.452992 Z14.190476 E12331.335923 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y214.448523 Z14.2 E12335.582288 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y215.450794 Z14.209524 E12339.828654 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y216.459091 Z14.219048 E12344.656423 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y217.472233 Z14.228571 E12350.238614 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y218.488239 Z14.238095 E12356.347499 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y219.504751 Z14.247619 E12362.553967 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y220.519343 Z14.257143 E12368.396725 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y221.529906 Z14.266667 E12373.552286 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y222.534292 Z14.27619 E12377.94728 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y223.532441 Z14.285714 E12382.105605 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y224.524612 Z14.295238 E12386.617571 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y225.510934 Z14.304762 E12391.918861 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y226.493586 Z14.314286 E12397.865006 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y227.474783 Z14.32381 E12404.08967 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y229.778669 Z14.333333 E12413.759815 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y229.978841 Z14.342857 E12425.474884 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y229.900511 Z14.352381 E12430.132473 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y229.505037 Z14.361905 E12434.325114 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y228.756377 Z14.371429 E12438.632649 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y227.668862 Z14.380952 E12443.632462 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y226.343246 Z14.390476 E12449.355337 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z14.4 E12455.525544 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y223.433669 Z14.409524 E12461.69575 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y222.108052 Z14.419048 E12467.418626 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y221.020538 Z14.428571 E12472.418439 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y220.271877 Z14.438095 E12476.725974 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y219.876404 Z14.447619 E12480.918615 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y219.798074 Z14.457143 E12485.576204 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y220.010306 Z14.466667 E12491.017647 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y220.400436 Z14.47619 E12497.051957 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y220.843995 Z14.485714 E12503.276621 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y221.388065 Z14.495238 E12507.880392 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y222.151728 Z14.504762 E12511.229371 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y222.765485 Z14.514286 E12513.783519 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y223.319317 Z14.52381 E12517.941844 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y223.536087 Z14.533333 E12522.336838 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y223.419026 Z14.542857 E12527.4924 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y223.08422 Z14.552381 E12533.335157 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y222.645709 Z14.561905 E12539.541625 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y222.234477 Z14.571429 E12545.650511 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y221.978048 Z14.580952 E12551.232701 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y221.983449 Z14.590476 E12556.06047 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y222.314523 Z14.6 E12560.306836 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y223.009822 Z14.609524 E12564.553202 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y224.030794 Z14.619048 E12569.38097 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y225.313596 Z14.628571 E12574.963161 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y226.7512 Z14.638095 E12581.072046 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y228.216084 Z14.647619 E12587.278514 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y229.577262 Z14.657143 E12593.121272 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y230.741706 Z14.666667 E12606.991089 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y227.434927 Z14.67619 E12622.327092 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y226.436779 Z14.685714 E12626.485418 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y225.444607 Z14.695238 E12630.997383 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y224.458286 Z14.704762 E12636.298673 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y223.475633 Z14.714286 E12642.244818 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y222.494437 Z14.72381 E12648.469482 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y221.512251 Z14.733333 E12654.503792 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y220.526774 Z14.742857 E12659.945235 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y219.53592 Z14.752381 E12664.602824 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y218.539198 Z14.761905 E12668.795465 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y217.53594 Z14.771429 E12673.103 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y216.526411 Z14.780952 E12678.102813 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y215.512477 Z14.790476 E12683.825689 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z14.8 E12689.995895 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y213.479828 Z14.809524 E12696.166102 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y212.465893 Z14.819048 E12701.888977 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y212.180996 Z14.828571 E12704.526754 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y212.886847 Z14.838095 E12707.49213 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y212.762815 Z14.847619 E12708.344556 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y211.834197 Z14.857143 E12713.002146 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y210.609641 Z14.866667 E12718.443589 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y209.203894 Z14.87619 E12724.477899 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y207.74373 Z14.885714 E12730.702563 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y206.363703 Z14.895238 E12736.648708 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y205.185623 Z14.904762 E12741.949997 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y204.329541 Z14.914286 E12746.461963 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y203.80243 Z14.92381 E12750.620289 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y203.618616 Z14.933333 E12755.015283 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y203.774812 Z14.942857 E12760.170844 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y204.152782 Z14.952381 E12766.013601 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y204.636376 Z14.961905 E12772.22007 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y205.092185 Z14.971429 E12778.328955 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y205.390328 Z14.980952 E12783.911146 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y205.421796 Z14.990476 E12788.738914 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X174.5 Y202.5 Z15 E12804.773936 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y199.578204 Z15.009524 E12820.808958 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y199.609672 Z15.019048 E12825.636727 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y199.907815 Z15.028571 E12831.218918 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y200.363624 Z15.038095 E12837.327803 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y200.847218 Z15.047619 E12843.534271 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y201.225188 Z15.057143 E12849.377029 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y201.381384 Z15.066667 E12854.53259 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y201.19757 Z15.07619 E12858.927584 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y200.670459 Z15.085714 E12863.085909 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y199.814377 Z15.095238 E12867.597875 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y198.636297 Z15.104762 E12872.899165 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y197.25627 Z15.114286 E12878.84531 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y195.796106 Z15.12381 E12885.069974 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y194.390359 Z15.133333 E12891.104283 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y193.165803 Z15.142857 E12896.545727 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y192.237185 Z15.152381 E12901.203316 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y192.113153 Z15.161905 E12902.055742 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y192.819004 Z15.171429 E12905.021119 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y192.534107 Z15.180952 E12907.658895 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y191.520172 Z15.190476 E12913.381771 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z15.2 E12919.551977 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y189.487523 Z15.209524 E12925.722184 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y188.473589 Z15.219048 E12931.445059 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y187.46406 Z15.228571 E12936.444872 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y186.460802 Z15.238095 E12940.752407 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y185.46408 Z15.247619 E12944.945048 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y184.473226 Z15.257143 E12949.602637 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y183.487749 Z15.266667 E12955.044081 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y182.505563 Z15.27619 E12961.07839 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y181.524367 Z15.285714 E12967.303054 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y180.541714 Z15.295238 E12973.249199 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y179.555393 Z15.304762 E12978.550489 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y178.563221 Z15.314286 E12983.062455 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y177.565073 Z15.32381 E12987.22078 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y174.258294 Z15.333333 E13002.556784 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y175.422738 Z15.342857 E13016.4266 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y176.783916 Z15.352381 E13022.269358 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y178.2488 Z15.361905 E13028.475826 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y179.686404 Z15.371429 E13034.584711 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y180.969206 Z15.380952 E13040.166902 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y181.990178 Z15.390476 E13044.994671 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y182.685477 Z15.4 E13049.241037 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y183.016551 Z15.409524 E13053.487402 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y183.021952 Z15.419048 E13058.315171 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y182.765523 Z15.428571 E13063.897362 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y182.354291 Z15.438095 E13070.006247 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y181.91578 Z15.447619 E13076.212715 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y181.580974 Z15.457143 E13082.055473 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y181.463913 Z15.466667 E13087.211034 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y181.680683 Z15.47619 E13091.606028 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y182.234515 Z15.485714 E13095.764354 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y182.848272 Z15.495238 E13098.318501 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y183.611935 Z15.504762 E13101.66748 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y184.156005 Z15.514286 E13106.271251 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y184.599564 Z15.52381 E13112.495915 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y184.989694 Z15.533333 E13118.530225 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y185.201926 Z15.542857 E13123.971668 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y185.123596 Z15.552381 E13128.629258 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y184.728123 Z15.561905 E13132.821899 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y183.979462 Z15.571429 E13137.129434 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y182.891948 Z15.580952 E13142.129247 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y181.566331 Z15.590476 E13147.852122 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z15.6 E13154.022329 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y178.656754 Z15.609524 E13160.192535 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y177.331138 Z15.619048 E13165.91541 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y176.243623 Z15.628571 E13170.915224 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y175.494963 Z15.638095 E13175.222758 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y175.099489 Z15.647619 E13179.415399 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y175.021159 Z15.657143 E13184.072989 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y175.221331 Z15.666667 E13195.788058 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y177.525217 Z15.67619 E13205.458203 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y178.506414 Z15.685714 E13211.682867 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y179.489066 Z15.695238 E13217.629011 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y180.475388 Z15.704762 E13222.930301 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y181.467559 Z15.714286 E13227.442267 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y182.465708 Z15.72381 E13231.600593 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y183.470094 Z15.733333 E13235.995587 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y184.480657 Z15.742857 E13241.151148 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y185.495249 Z15.752381 E13246.993905 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y186.511761 Z15.761905 E13253.200373 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y187.527767 Z15.771429 E13259.309259 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y188.540909 Z15.780952 E13264.891449 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y189.549206 Z15.790476 E13269.719218 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y190.551477 Z15.8 E13273.965584 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y191.547008 Z15.809524 E13278.21195 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y192.536512 Z15.819048 E13283.039718 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y193.174342 Z15.828571 E13287.811749 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y194.085027 Z15.838095 E13292.520647 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y195.504361 Z15.847619 E13298.540315 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y196.853759 Z15.857143 E13304.383072 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y197.981384 Z15.866667 E13309.538634 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y198.768999 Z15.87619 E13313.933628 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y199.213316 Z15.885714 E13318.091953 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y199.328663 Z15.895238 E13322.603919 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y199.122011 Z15.904762 E13327.905209 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y198.713412 Z15.914286 E13333.851353 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y198.224677 Z15.92381 E13340.076017 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y197.790359 Z15.933333 E13346.110327 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y197.537232 Z15.942857 E13351.551771 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y197.580043 Z15.952381 E13356.20936 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y197.945866 Z15.961905 E13360.402001 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y198.671412 Z15.971429 E13364.709536 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y199.742082 Z15.980952 E13369.709349 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y201.055259 Z15.990476 E13375.432224 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z16 E13381.602431 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.026688 Z16.009524 E13387.772637 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y201.684939 Z16.019048 E13393.495512 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y201.585698 Z16.028571 E13398.495326 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y201.83158 Z16.038095 E13402.80286 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.437185 Z16.047619 E13406.995502 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y203.365803 Z16.057143 E13411.653091 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y204.590359 Z16.066667 E13417.094534 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y205.996106 Z16.07619 E13423.128844 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y207.45627 Z16.085714 E13429.353508 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y208.836297 Z16.095238 E13435.299653 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y210.014377 Z16.104762 E13440.600942 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y210.870459 Z16.114286 E13445.112908 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y211.39757 Z16.12381 E13449.271234 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y211.581384 Z16.133333 E13453.666228 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y211.425188 Z16.142857 E13458.821789 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y211.047218 Z16.152381 E13464.664547 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y210.599313 Z16.161905 E13471.013765 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y211.173243 Z16.171429 E13477.809602 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y212.533214 Z16.180952 E13484.641889 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y213.541511 Z16.190476 E13489.469658 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y214.543782 Z16.2 E13493.716024 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y215.539313 Z16.209524 E13497.96239 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y216.528817 Z16.219048 E13502.790158 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y217.513476 Z16.228571 E13508.372349 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y218.495271 Z16.238095 E13514.481234 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y219.476561 Z16.247619 E13520.687703 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y220.45977 Z16.257143 E13526.53046 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y221.447008 Z16.266667 E13531.686021 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y222.440424 Z16.27619 E13536.081015 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y223.440077 Z16.285714 E13540.239341 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y224.445706 Z16.295238 E13544.751307 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y225.457186 Z16.304762 E13550.052596 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y226.472335 Z16.314286 E13555.998741 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y227.48894 Z16.32381 E13562.223405 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y227.182855 Z16.333333 E13563.970281 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y225.956311 Z16.342857 E13570.81007 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y225.008268 Z16.352381 E13575.46766 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y224.377369 Z16.361905 E13579.660301 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y224.099656 Z16.371429 E13583.967835 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y224.160798 Z16.380952 E13588.967649 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y224.460041 Z16.390476 E13594.690524 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z16.4 E13600.86073 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y225.316873 Z16.409524 E13607.030937 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y225.616117 Z16.419048 E13612.753812 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y225.677258 Z16.428571 E13617.753625 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y225.399546 Z16.438095 E13622.06116 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y224.768647 Z16.447619 E13626.253801 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y223.820604 Z16.457143 E13630.911391 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y222.581999 Z16.466667 E13636.352834 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y221.165496 Z16.47619 E13642.387144 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y219.695564 Z16.485714 E13648.611808 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y218.125122 Z16.495238 E13655.847189 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y217.361458 Z16.504762 E13664.632998 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y217.774074 Z16.514286 E13671.862334 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y218.246615 Z16.52381 E13676.020659 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y219.056218 Z16.533333 E13680.415653 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y220.199652 Z16.542857 E13685.571214 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y221.560831 Z16.552381 E13691.413972 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y223.025715 Z16.561905 E13697.62044 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y224.463319 Z16.571429 E13703.729325 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y225.746121 Z16.580952 E13709.311516 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y226.767093 Z16.590476 E13714.139285 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y227.462391 Z16.6 E13718.385651 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y227.793466 Z16.609524 E13722.632016 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y227.798867 Z16.619048 E13727.459785 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y227.542437 Z16.628571 E13733.041976 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y227.131206 Z16.638095 E13739.150861 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y226.692695 Z16.647619 E13745.357329 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y226.357889 Z16.657143 E13751.200087 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y226.219818 Z16.666667 E13757.098473 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y227.528795 Z16.67619 E13765.908249 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y226.529143 Z16.685714 E13770.066575 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y225.523513 Z16.695238 E13774.578541 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y224.512033 Z16.704762 E13779.87983 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y223.496884 Z16.714286 E13785.825975 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y222.480279 Z16.72381 E13792.050639 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y221.464663 Z16.733333 E13798.084949 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y220.452339 Z16.742857 E13803.526392 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y219.445392 Z16.752381 E13808.183981 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y218.444313 Z16.761905 E13812.376622 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y217.449769 Z16.771429 E13816.684157 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y216.461496 Z16.780952 E13821.683971 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y215.477629 Z16.790476 E13827.406846 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z16.8 E13833.577052 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y213.514676 Z16.809524 E13839.747259 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y212.530809 Z16.819048 E13845.470134 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y210.817905 Z16.828571 E13853.013913 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y208.627439 Z16.838095 E13862.955792 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y207.780043 Z16.847619 E13870.42098 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y207.737232 Z16.857143 E13875.078569 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y207.990359 Z16.866667 E13880.520013 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y208.424677 Z16.87619 E13886.554322 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y208.913412 Z16.885714 E13892.778986 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y209.322011 Z16.895238 E13898.725131 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y209.528663 Z16.904762 E13904.026421 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y209.413316 Z16.914286 E13908.538387 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y208.968999 Z16.92381 E13912.696712 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y208.181384 Z16.933333 E13917.091706 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y207.053759 Z16.942857 E13922.247267 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y205.704361 Z16.952381 E13928.090025 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y204.249338 Z16.961905 E13934.296493 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.8221 Z16.971429 E13940.405378 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y201.552529 Z16.980952 E13945.987569 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y200.549633 Z16.990476 E13950.815338 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.5 Y202.5 Z17 E13959.53566 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y204.450367 Z17.009524 E13968.255982 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y203.447471 Z17.019048 E13973.083751 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.1779 Z17.028571 E13978.665942 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y200.750662 Z17.038095 E13984.774827 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y199.295639 Z17.047619 E13990.981295 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y197.946241 Z17.057143 E13996.824053 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y196.818616 Z17.066667 E14001.979614 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y196.031001 Z17.07619 E14006.374608 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y195.586684 Z17.085714 E14010.532934 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y195.471337 Z17.095238 E14015.044899 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y195.677989 Z17.104762 E14020.346189 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y196.086588 Z17.114286 E14026.292334 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y196.575323 Z17.12381 E14032.516998 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y197.009641 Z17.133333 E14038.551307 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y197.262768 Z17.142857 E14043.992751 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y197.219957 Z17.152381 E14048.65034 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y196.372561 Z17.161905 E14056.115529 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y194.182095 Z17.171429 E14066.057407 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y192.469191 Z17.180952 E14073.601186 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y191.485324 Z17.190476 E14079.324061 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z17.2 E14085.494268 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y189.522371 Z17.209524 E14091.664474 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y188.538504 Z17.219048 E14097.38735 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y187.550231 Z17.228571 E14102.387163 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y186.555687 Z17.238095 E14106.694698 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y185.554608 Z17.247619 E14110.887339 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y184.547661 Z17.257143 E14115.544928 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y183.535337 Z17.266667 E14120.986371 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y182.519721 Z17.27619 E14127.020681 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y181.503116 Z17.285714 E14133.245345 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y180.487967 Z17.295238 E14139.19149 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y179.476487 Z17.304762 E14144.49278 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y178.470857 Z17.314286 E14149.004745 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y177.471205 Z17.32381 E14153.163071 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y178.780182 Z17.333333 E14161.972847 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y178.642111 Z17.342857 E14167.871233 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y178.307305 Z17.352381 E14173.713991 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y177.868794 Z17.361905 E14179.920459 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y177.457563 Z17.371429 E14186.029344 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y177.201133 Z17.380952 E14191.611535 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y177.206534 Z17.390476 E14196.439304 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y177.537609 Z17.4 E14200.68567 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y178.232907 Z17.409524 E14204.932035 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y179.253879 Z17.419048 E14209.759804 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y180.536681 Z17.428571 E14215.341995 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y181.974285 Z17.438095 E14221.45088 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y183.439169 Z17.447619 E14227.657348 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y184.800348 Z17.457143 E14233.500106 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y185.943782 Z17.466667 E14238.655667 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y186.753385 Z17.47619 E14243.050661 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y187.225926 Z17.485714 E14247.208986 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y187.638542 Z17.495238 E14254.438322 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y186.874878 Z17.504762 E14263.224131 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y185.304436 Z17.514286 E14270.459512 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y183.834504 Z17.52381 E14276.684176 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y182.418001 Z17.533333 E14282.718486 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y181.179396 Z17.542857 E14288.15993 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y180.231353 Z17.552381 E14292.817519 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y179.600454 Z17.561905 E14297.01016 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y179.322742 Z17.571429 E14301.317695 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y179.383883 Z17.580952 E14306.317508 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y179.683127 Z17.590476 E14312.040383 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z17.6 E14318.21059 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y180.539959 Z17.609524 E14324.380796 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y180.839202 Z17.619048 E14330.103671 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y180.900344 Z17.628571 E14335.103485 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y180.622631 Z17.638095 E14339.411019 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y179.991732 Z17.647619 E14343.603661 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y179.043689 Z17.657143 E14348.26125 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y177.817145 Z17.666667 E14355.101039 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y177.51106 Z17.67619 E14356.847915 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y178.527665 Z17.685714 E14363.072579 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y179.542814 Z17.695238 E14369.018724 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y180.554294 Z17.704762 E14374.320014 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y181.559923 Z17.714286 E14378.831979 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y182.559576 Z17.72381 E14382.990305 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y183.552992 Z17.733333 E14387.385299 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y184.54023 Z17.742857 E14392.54086 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y185.523439 Z17.752381 E14398.383618 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y186.504729 Z17.761905 E14404.590086 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y187.486524 Z17.771429 E14410.698971 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y188.471183 Z17.780952 E14416.281162 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y189.460687 Z17.790476 E14421.10893 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y190.456218 Z17.8 E14425.355296 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y191.458489 Z17.809524 E14429.601662 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y192.466786 Z17.819048 E14434.429431 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y193.826757 Z17.828571 E14441.261718 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y194.400687 Z17.838095 E14448.057555 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y193.952782 Z17.847619 E14454.406774 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y193.574812 Z17.857143 E14460.249531 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y193.418616 Z17.866667 E14465.405092 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y193.60243 Z17.87619 E14469.800086 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y194.129541 Z17.885714 E14473.958412 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y194.985623 Z17.895238 E14478.470378 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y196.163703 Z17.904762 E14483.771667 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y197.54373 Z17.914286 E14489.717812 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y199.003894 Z17.92381 E14495.942476 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y200.409641 Z17.933333 E14501.976786 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y201.634197 Z17.942857 E14507.418229 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.562815 Z17.952381 E14512.075818 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y203.16842 Z17.961905 E14516.26846 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y203.414302 Z17.971429 E14520.575994 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y203.315061 Z17.980952 E14525.575808 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.973312 Z17.990476 E14531.298683 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z18 E14537.468889 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y203.944741 Z18.009524 E14543.639096 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y205.257918 Z18.019048 E14549.361971 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y206.328588 Z18.028571 E14554.361784 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y207.054134 Z18.038095 E14558.669319 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y207.419957 Z18.047619 E14562.86196 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y207.462768 Z18.057143 E14567.51955 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y207.209641 Z18.066667 E14572.960993 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y206.775323 Z18.07619 E14578.995303 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y206.286588 Z18.085714 E14585.219967 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y205.877989 Z18.095238 E14591.166111 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y205.671337 Z18.104762 E14596.467401 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y205.786684 Z18.114286 E14600.979367 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y206.231001 Z18.12381 E14605.137692 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y207.018616 Z18.133333 E14609.532686 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y208.146241 Z18.142857 E14614.688248 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y209.495639 Z18.152381 E14620.531005 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y210.914973 Z18.161905 E14626.550673 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y211.825658 Z18.171429 E14631.259571 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y212.463488 Z18.180952 E14636.031602 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y213.452992 Z18.190476 E14640.85937 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y214.448523 Z18.2 E14645.105736 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y215.450794 Z18.209524 E14649.352102 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y216.459091 Z18.219048 E14654.179871 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y217.472233 Z18.228571 E14659.762061 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y218.488239 Z18.238095 E14665.870947 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y219.504751 Z18.247619 E14672.077415 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y220.519343 Z18.257143 E14677.920172 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y221.529906 Z18.266667 E14683.075734 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y222.534292 Z18.27619 E14687.470728 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y223.532441 Z18.285714 E14691.629053 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y224.524612 Z18.295238 E14696.141019 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y225.510934 Z18.304762 E14701.442309 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y226.493586 Z18.314286 E14707.388453 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y227.474783 Z18.32381 E14713.613117 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y229.778669 Z18.333333 E14723.283262 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y229.978841 Z18.342857 E14734.998331 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y229.900511 Z18.352381 E14739.655921 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y229.505037 Z18.361905 E14743.848562 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y228.756377 Z18.371429 E14748.156097 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y227.668862 Z18.380952 E14753.15591 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y226.343246 Z18.390476 E14758.878785 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z18.4 E14765.048992 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y223.433669 Z18.409524 E14771.219198 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y222.108052 Z18.419048 E14776.942073 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y221.020538 Z18.428571 E14781.941887 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y220.271877 Z18.438095 E14786.249421 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y219.876404 Z18.447619 E14790.442062 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y219.798074 Z18.457143 E14795.099652 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y220.010306 Z18.466667 E14800.541095 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y220.400436 Z18.47619 E14806.575405 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y220.843995 Z18.485714 E14812.800069 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y221.388065 Z18.495238 E14817.40384 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y222.151728 Z18.504762 E14820.752819 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y222.765485 Z18.514286 E14823.306967 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y223.319317 Z18.52381 E14827.465292 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y223.536087 Z18.533333 E14831.860286 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y223.419026 Z18.542857 E14837.015847 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y223.08422 Z18.552381 E14842.858605 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y222.645709 Z18.561905 E14849.065073 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y222.234477 Z18.571429 E14855.173958 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y221.978048 Z18.580952 E14860.756149 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y221.983449 Z18.590476 E14865.583918 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y222.314523 Z18.6 E14869.830284 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y223.009822 Z18.609524 E14874.076649 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y224.030794 Z18.619048 E14878.904418 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y225.313596 Z18.628571 E14884.486609 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y226.7512 Z18.638095 E14890.595494 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y228.216084 Z18.647619 E14896.801962 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y229.577262 Z18.657143 E14902.64472 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y230.741706 Z18.666667 E14916.514536 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y227.434927 Z18.67619 E14931.85054 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y226.436779 Z18.685714 E14936.008865 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y225.444607 Z18.695238 E14940.520831 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y224.458286 Z18.704762 E14945.822121 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y223.475633 Z18.714286 E14951.768266 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y222.494437 Z18.72381 E14957.99293 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y221.512251 Z18.733333 E14964.027239 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y220.526774 Z18.742857 E14969.468683 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y219.53592 Z18.752381 E14974.126272 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y218.539198 Z18.761905 E14978.318913 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y217.53594 Z18.771429 E14982.626448 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y216.526411 Z18.780952 E14987.626261 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y215.512477 Z18.790476 E14993.349137 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z18.8 E14999.519343 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y213.479828 Z18.809524 E15005.689549 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y212.465893 Z18.819048 E15011.412425 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y212.180996 Z18.828571 E15014.050201 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y212.886847 Z18.838095 E15017.015578 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y212.762815 Z18.847619 E15017.868004 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y211.834197 Z18.857143 E15022.525593 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y210.609641 Z18.866667 E15027.967037 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y209.203894 Z18.87619 E15034.001347 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y207.74373 Z18.885714 E15040.22601 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y206.363703 Z18.895238 E15046.172155 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y205.185623 Z18.904762 E15051.473445 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y204.329541 Z18.914286 E15055.985411 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y203.80243 Z18.92381 E15060.143736 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y203.618616 Z18.933333 E15064.53873 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y203.774812 Z18.942857 E15069.694292 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y204.152782 Z18.952381 E15075.537049 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y204.636376 Z18.961905 E15081.743517 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y205.092185 Z18.971429 E15087.852403 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y205.390328 Z18.980952 E15093.434593 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y205.421796 Z18.990476 E15098.262362 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X174.5 Y202.5 Z19 E15114.297384 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y199.578204 Z19.009524 E15130.332406 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y199.609672 Z19.019048 E15135.160175 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y199.907815 Z19.028571 E15140.742365 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y200.363624 Z19.038095 E15146.851251 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y200.847218 Z19.047619 E15153.057719 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y201.225188 Z19.057143 E15158.900476 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y201.381384 Z19.066667 E15164.056037 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y201.19757 Z19.07619 E15168.451031 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y200.670459 Z19.085714 E15172.609357 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y199.814377 Z19.095238 E15177.121323 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y198.636297 Z19.104762 E15182.422613 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y197.25627 Z19.114286 E15188.368757 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y195.796106 Z19.12381 E15194.593421 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y194.390359 Z19.133333 E15200.627731 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y193.165803 Z19.142857 E15206.069174 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y192.237185 Z19.152381 E15210.726764 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y192.113153 Z19.161905 E15211.57919 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y192.819004 Z19.171429 E15214.544567 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y192.534107 Z19.180952 E15217.182343 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y191.520172 Z19.190476 E15222.905219 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z19.2 E15229.075425 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y189.487523 Z19.209524 E15235.245631 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y188.473589 Z19.219048 E15240.968507 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y187.46406 Z19.228571 E15245.96832 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y186.460802 Z19.238095 E15250.275855 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y185.46408 Z19.247619 E15254.468496 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y184.473226 Z19.257143 E15259.126085 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y183.487749 Z19.266667 E15264.567529 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y182.505563 Z19.27619 E15270.601838 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y181.524367 Z19.285714 E15276.826502 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y180.541714 Z19.295238 E15282.772647 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y179.555393 Z19.304762 E15288.073937 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y178.563221 Z19.314286 E15292.585902 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y177.565073 Z19.32381 E15296.744228 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y174.258294 Z19.333333 E15312.080232 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y175.422738 Z19.342857 E15325.950048 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y176.783916 Z19.352381 E15331.792806 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y178.2488 Z19.361905 E15337.999274 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y179.686404 Z19.371429 E15344.108159 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y180.969206 Z19.380952 E15349.69035 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y181.990178 Z19.390476 E15354.518118 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y182.685477 Z19.4 E15358.764484 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y183.016551 Z19.409524 E15363.01085 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y183.021952 Z19.419048 E15367.838619 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y182.765523 Z19.428571 E15373.420809 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y182.354291 Z19.438095 E15379.529695 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y181.91578 Z19.447619 E15385.736163 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y181.580974 Z19.457143 E15391.57892 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y181.463913 Z19.466667 E15396.734482 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y181.680683 Z19.47619 E15401.129476 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y182.234515 Z19.485714 E15405.287801 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y182.848272 Z19.495238 E15407.841949 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y183.611935 Z19.504762 E15411.190928 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y184.156005 Z19.514286 E15415.794699 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y184.599564 Z19.52381 E15422.019363 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y184.989694 Z19.533333 E15428.053673 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y185.201926 Z19.542857 E15433.495116 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y185.123596 Z19.552381 E15438.152705 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y184.728123 Z19.561905 E15442.345346 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y183.979462 Z19.571429 E15446.652881 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y182.891948 Z19.580952 E15451.652695 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y181.566331 Z19.590476 E15457.37557 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z19.6 E15463.545776 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y178.656754 Z19.609524 E15469.715983 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y177.331138 Z19.619048 E15475.438858 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y176.243623 Z19.628571 E15480.438671 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y175.494963 Z19.638095 E15484.746206 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y175.099489 Z19.647619 E15488.938847 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y175.021159 Z19.657143 E15493.596436 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y175.221331 Z19.666667 E15505.311506 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y177.525217 Z19.67619 E15514.98165 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y178.506414 Z19.685714 E15521.206314 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y179.489066 Z19.695238 E15527.152459 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y180.475388 Z19.704762 E15532.453749 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y181.467559 Z19.714286 E15536.965715 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y182.465708 Z19.72381 E15541.12404 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y183.470094 Z19.733333 E15545.519034 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y184.480657 Z19.742857 E15550.674595 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y185.495249 Z19.752381 E15556.517353 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y186.511761 Z19.761905 E15562.723821 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y187.527767 Z19.771429 E15568.832706 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y188.540909 Z19.780952 E15574.414897 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y189.549206 Z19.790476 E15579.242666 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y190.551477 Z19.8 E15583.489032 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y191.547008 Z19.809524 E15587.735397 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y192.536512 Z19.819048 E15592.563166 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y193.174342 Z19.828571 E15597.335197 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y194.085027 Z19.838095 E15602.044094 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y195.504361 Z19.847619 E15608.063763 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y196.853759 Z19.857143 E15613.90652 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y197.981384 Z19.866667 E15619.062081 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y198.768999 Z19.87619 E15623.457075 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y199.213316 Z19.885714 E15627.615401 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y199.328663 Z19.895238 E15632.127367 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y199.122011 Z19.904762 E15637.428656 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y198.713412 Z19.914286 E15643.374801 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y198.224677 Z19.92381 E15649.599465 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y197.790359 Z19.933333 E15655.633775 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y197.537232 Z19.942857 E15661.075218 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y197.580043 Z19.952381 E15665.732807 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y197.945866 Z19.961905 E15669.925449 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y198.671412 Z19.971429 E15674.232983 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y199.742082 Z19.980952 E15679.232797 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y201.055259 Z19.990476 E15684.955672 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z20 E15691.125878 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.026688 Z20.009524 E15697.296085 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y201.684939 Z20.019048 E15703.01896 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y201.585698 Z20.028571 E15708.018773 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y201.83158 Z20.038095 E15712.326308 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.437185 Z20.047619 E15716.518949 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y203.365803 Z20.057143 E15721.176539 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y204.590359 Z20.066667 E15726.617982 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y205.996106 Z20.07619 E15732.652292 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y207.45627 Z20.085714 E15738.876956 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y208.836297 Z20.095238 E15744.8231 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y210.014377 Z20.104762 E15750.12439 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y210.870459 Z20.114286 E15754.636356 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y211.39757 Z20.12381 E15758.794682 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y211.581384 Z20.133333 E15763.189675 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y211.425188 Z20.142857 E15768.345237 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y211.047218 Z20.152381 E15774.187994 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y210.599313 Z20.161905 E15780.537213 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y211.173243 Z20.171429 E15787.33305 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y212.533214 Z20.180952 E15794.165337 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y213.541511 Z20.190476 E15798.993106 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y214.543782 Z20.2 E15803.239472 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y215.539313 Z20.209524 E15807.485837 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y216.528817 Z20.219048 E15812.313606 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y217.513476 Z20.228571 E15817.895797 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y218.495271 Z20.238095 E15824.004682 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y219.476561 Z20.247619 E15830.21115 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y220.45977 Z20.257143 E15836.053908 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y221.447008 Z20.266667 E15841.209469 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y222.440424 Z20.27619 E15845.604463 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y223.440077 Z20.285714 E15849.762789 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y224.445706 Z20.295238 E15854.274754 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y225.457186 Z20.304762 E15859.576044 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y226.472335 Z20.314286 E15865.522189 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y227.48894 Z20.32381 E15871.746853 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y227.182855 Z20.333333 E15873.493729 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y225.956311 Z20.342857 E15880.333518 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y225.008268 Z20.352381 E15884.991107 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y224.377369 Z20.361905 E15889.183748 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y224.099656 Z20.371429 E15893.491283 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y224.160798 Z20.380952 E15898.491096 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y224.460041 Z20.390476 E15904.213972 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z20.4 E15910.384178 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y225.316873 Z20.409524 E15916.554385 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y225.616117 Z20.419048 E15922.27726 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y225.677258 Z20.428571 E15927.277073 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y225.399546 Z20.438095 E15931.584608 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y224.768647 Z20.447619 E15935.777249 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y223.820604 Z20.457143 E15940.434838 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y222.581999 Z20.466667 E15945.876282 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y221.165496 Z20.47619 E15951.910591 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y219.695564 Z20.485714 E15958.135255 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y218.125122 Z20.495238 E15965.370637 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y217.361458 Z20.504762 E15974.156446 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y217.774074 Z20.514286 E15981.385781 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y218.246615 Z20.52381 E15985.544107 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y219.056218 Z20.533333 E15989.939101 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y220.199652 Z20.542857 E15995.094662 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y221.560831 Z20.552381 E16000.93742 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y223.025715 Z20.561905 E16007.143888 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y224.463319 Z20.571429 E16013.252773 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y225.746121 Z20.580952 E16018.834964 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y226.767093 Z20.590476 E16023.662733 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y227.462391 Z20.6 E16027.909098 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y227.793466 Z20.609524 E16032.155464 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y227.798867 Z20.619048 E16036.983233 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y227.542437 Z20.628571 E16042.565423 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y227.131206 Z20.638095 E16048.674309 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y226.692695 Z20.647619 E16054.880777 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y226.357889 Z20.657143 E16060.723535 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y226.219818 Z20.666667 E16066.621921 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y227.528795 Z20.67619 E16075.431697 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y226.529143 Z20.685714 E16079.590023 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y225.523513 Z20.695238 E16084.101988 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y224.512033 Z20.704762 E16089.403278 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y223.496884 Z20.714286 E16095.349423 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y222.480279 Z20.72381 E16101.574087 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y221.464663 Z20.733333 E16107.608396 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y220.452339 Z20.742857 E16113.04984 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y219.445392 Z20.752381 E16117.707429 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y218.444313 Z20.761905 E16121.90007 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y217.449769 Z20.771429 E16126.207605 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y216.461496 Z20.780952 E16131.207418 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y215.477629 Z20.790476 E16136.930294 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z20.8 E16143.1005 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y213.514676 Z20.809524 E16149.270706 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y212.530809 Z20.819048 E16154.993582 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y210.817905 Z20.828571 E16162.537361 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y208.627439 Z20.838095 E16172.479239 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y207.780043 Z20.847619 E16179.944428 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y207.737232 Z20.857143 E16184.602017 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y207.990359 Z20.866667 E16190.04346 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y208.424677 Z20.87619 E16196.07777 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y208.913412 Z20.885714 E16202.302434 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y209.322011 Z20.895238 E16208.248579 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y209.528663 Z20.904762 E16213.549869 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y209.413316 Z20.914286 E16218.061834 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y208.968999 Z20.92381 E16222.22016 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y208.181384 Z20.933333 E16226.615154 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y207.053759 Z20.942857 E16231.770715 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y205.704361 Z20.952381 E16237.613473 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y204.249338 Z20.961905 E16243.819941 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.8221 Z20.971429 E16249.928826 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y201.552529 Z20.980952 E16255.511017 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y200.549633 Z20.990476 E16260.338785 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.5 Y202.5 Z21 E16269.059108 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y204.450367 Z21.009524 E16277.77943 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y203.447471 Z21.019048 E16282.607199 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.1779 Z21.028571 E16288.189389 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y200.750662 Z21.038095 E16294.298275 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y199.295639 Z21.047619 E16300.504743 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y197.946241 Z21.057143 E16306.3475 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y196.818616 Z21.066667 E16311.503062 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y196.031001 Z21.07619 E16315.898056 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y195.586684 Z21.085714 E16320.056381 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y195.471337 Z21.095238 E16324.568347 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y195.677989 Z21.104762 E16329.869637 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y196.086588 Z21.114286 E16335.815782 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y196.575323 Z21.12381 E16342.040445 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y197.009641 Z21.133333 E16348.074755 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y197.262768 Z21.142857 E16353.516199 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y197.219957 Z21.152381 E16358.173788 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y196.372561 Z21.161905 E16365.638976 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y194.182095 Z21.171429 E16375.580855 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y192.469191 Z21.180952 E16383.124634 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y191.485324 Z21.190476 E16388.847509 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z21.2 E16395.017716 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y189.522371 Z21.209524 E16401.187922 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y188.538504 Z21.219048 E16406.910797 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y187.550231 Z21.228571 E16411.910611 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y186.555687 Z21.238095 E16416.218145 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y185.554608 Z21.247619 E16420.410786 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y184.547661 Z21.257143 E16425.068376 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y183.535337 Z21.266667 E16430.509819 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y182.519721 Z21.27619 E16436.544129 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y181.503116 Z21.285714 E16442.768793 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y180.487967 Z21.295238 E16448.714938 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y179.476487 Z21.304762 E16454.016227 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y178.470857 Z21.314286 E16458.528193 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y177.471205 Z21.32381 E16462.686519 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y178.780182 Z21.333333 E16471.496295 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y178.642111 Z21.342857 E16477.394681 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y178.307305 Z21.352381 E16483.237439 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y177.868794 Z21.361905 E16489.443907 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y177.457563 Z21.371429 E16495.552792 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y177.201133 Z21.380952 E16501.134983 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y177.206534 Z21.390476 E16505.962751 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y177.537609 Z21.4 E16510.209117 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y178.232907 Z21.409524 E16514.455483 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y179.253879 Z21.419048 E16519.283252 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y180.536681 Z21.428571 E16524.865442 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y181.974285 Z21.438095 E16530.974328 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y183.439169 Z21.447619 E16537.180796 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y184.800348 Z21.457143 E16543.023553 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y185.943782 Z21.466667 E16548.179115 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y186.753385 Z21.47619 E16552.574109 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y187.225926 Z21.485714 E16556.732434 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y187.638542 Z21.495238 E16563.96177 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y186.874878 Z21.504762 E16572.747579 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y185.304436 Z21.514286 E16579.98296 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y183.834504 Z21.52381 E16586.207624 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y182.418001 Z21.533333 E16592.241934 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y181.179396 Z21.542857 E16597.683377 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y180.231353 Z21.552381 E16602.340966 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y179.600454 Z21.561905 E16606.533608 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y179.322742 Z21.571429 E16610.841142 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y179.383883 Z21.580952 E16615.840956 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y179.683127 Z21.590476 E16621.563831 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z21.6 E16627.734037 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y180.539959 Z21.609524 E16633.904244 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y180.839202 Z21.619048 E16639.627119 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y180.900344 Z21.628571 E16644.626932 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y180.622631 Z21.638095 E16648.934467 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y179.991732 Z21.647619 E16653.127108 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y179.043689 Z21.657143 E16657.784697 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y177.817145 Z21.666667 E16664.624487 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y177.51106 Z21.67619 E16666.371363 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y178.527665 Z21.685714 E16672.596027 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y179.542814 Z21.695238 E16678.542171 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y180.554294 Z21.704762 E16683.843461 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y181.559923 Z21.714286 E16688.355427 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y182.559576 Z21.72381 E16692.513753 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y183.552992 Z21.733333 E16696.908747 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y184.54023 Z21.742857 E16702.064308 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y185.523439 Z21.752381 E16707.907065 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y186.504729 Z21.761905 E16714.113533 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y187.486524 Z21.771429 E16720.222419 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y188.471183 Z21.780952 E16725.804609 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y189.460687 Z21.790476 E16730.632378 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y190.456218 Z21.8 E16734.878744 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y191.458489 Z21.809524 E16739.12511 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y192.466786 Z21.819048 E16743.952878 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y193.826757 Z21.828571 E16750.785166 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y194.400687 Z21.838095 E16757.581003 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y193.952782 Z21.847619 E16763.930221 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y193.574812 Z21.857143 E16769.772979 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y193.418616 Z21.866667 E16774.92854 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y193.60243 Z21.87619 E16779.323534 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y194.129541 Z21.885714 E16783.48186 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y194.985623 Z21.895238 E16787.993825 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y196.163703 Z21.904762 E16793.295115 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y197.54373 Z21.914286 E16799.24126 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y199.003894 Z21.92381 E16805.465924 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y200.409641 Z21.933333 E16811.500234 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y201.634197 Z21.942857 E16816.941677 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.562815 Z21.952381 E16821.599266 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y203.16842 Z21.961905 E16825.791907 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y203.414302 Z21.971429 E16830.099442 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y203.315061 Z21.980952 E16835.099255 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.973312 Z21.990476 E16840.822131 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z22 E16846.992337 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y203.944741 Z22.009524 E16853.162543 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y205.257918 Z22.019048 E16858.885419 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y206.328588 Z22.028571 E16863.885232 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y207.054134 Z22.038095 E16868.192767 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y207.419957 Z22.047619 E16872.385408 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y207.462768 Z22.057143 E16877.042997 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y207.209641 Z22.066667 E16882.484441 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y206.775323 Z22.07619 E16888.51875 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y206.286588 Z22.085714 E16894.743414 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y205.877989 Z22.095238 E16900.689559 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y205.671337 Z22.104762 E16905.990849 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y205.786684 Z22.114286 E16910.502815 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y206.231001 Z22.12381 E16914.66114 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y207.018616 Z22.133333 E16919.056134 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y208.146241 Z22.142857 E16924.211695 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y209.495639 Z22.152381 E16930.054453 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y210.914973 Z22.161905 E16936.074121 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y211.825658 Z22.171429 E16940.783018 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y212.463488 Z22.180952 E16945.555049 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y213.452992 Z22.190476 E16950.382818 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y214.448523 Z22.2 E16954.629184 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y215.450794 Z22.209524 E16958.87555 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y216.459091 Z22.219048 E16963.703318 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y217.472233 Z22.228571 E16969.285509 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y218.488239 Z22.238095 E16975.394394 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y219.504751 Z22.247619 E16981.600862 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y220.519343 Z22.257143 E16987.44362 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y221.529906 Z22.266667 E16992.599181 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y222.534292 Z22.27619 E16996.994175 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y223.532441 Z22.285714 E17001.152501 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y224.524612 Z22.295238 E17005.664467 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y225.510934 Z22.304762 E17010.965756 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y226.493586 Z22.314286 E17016.911901 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y227.474783 Z22.32381 E17023.136565 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y229.778669 Z22.333333 E17032.80671 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y229.978841 Z22.342857 E17044.521779 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y229.900511 Z22.352381 E17049.179368 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y229.505037 Z22.361905 E17053.372009 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y228.756377 Z22.371429 E17057.679544 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y227.668862 Z22.380952 E17062.679358 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y226.343246 Z22.390476 E17068.402233 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z22.4 E17074.572439 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y223.433669 Z22.409524 E17080.742646 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y222.108052 Z22.419048 E17086.465521 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y221.020538 Z22.428571 E17091.465334 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y220.271877 Z22.438095 E17095.772869 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y219.876404 Z22.447619 E17099.96551 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y219.798074 Z22.457143 E17104.623099 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y220.010306 Z22.466667 E17110.064543 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y220.400436 Z22.47619 E17116.098853 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y220.843995 Z22.485714 E17122.323516 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y221.388065 Z22.495238 E17126.927288 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y222.151728 Z22.504762 E17130.276267 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y222.765485 Z22.514286 E17132.830414 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y223.319317 Z22.52381 E17136.98874 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y223.536087 Z22.533333 E17141.383734 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y223.419026 Z22.542857 E17146.539295 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y223.08422 Z22.552381 E17152.382053 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y222.645709 Z22.561905 E17158.588521 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y222.234477 Z22.571429 E17164.697406 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y221.978048 Z22.580952 E17170.279597 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y221.983449 Z22.590476 E17175.107365 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y222.314523 Z22.6 E17179.353731 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y223.009822 Z22.609524 E17183.600097 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y224.030794 Z22.619048 E17188.427866 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y225.313596 Z22.628571 E17194.010056 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y226.7512 Z22.638095 E17200.118942 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y228.216084 Z22.647619 E17206.32541 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y229.577262 Z22.657143 E17212.168167 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y230.741706 Z22.666667 E17226.037984 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y227.434927 Z22.67619 E17241.373988 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y226.436779 Z22.685714 E17245.532313 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y225.444607 Z22.695238 E17250.044279 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y224.458286 Z22.704762 E17255.345569 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y223.475633 Z22.714286 E17261.291713 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y222.494437 Z22.72381 E17267.516377 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y221.512251 Z22.733333 E17273.550687 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y220.526774 Z22.742857 E17278.99213 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y219.53592 Z22.752381 E17283.64972 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y218.539198 Z22.761905 E17287.842361 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y217.53594 Z22.771429 E17292.149896 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y216.526411 Z22.780952 E17297.149709 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y215.512477 Z22.790476 E17302.872584 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z22.8 E17309.042791 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y213.479828 Z22.809524 E17315.212997 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y212.465893 Z22.819048 E17320.935872 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y212.180996 Z22.828571 E17323.573649 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y212.886847 Z22.838095 E17326.539026 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y212.762815 Z22.847619 E17327.391452 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y211.834197 Z22.857143 E17332.049041 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y210.609641 Z22.866667 E17337.490485 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y209.203894 Z22.87619 E17343.524794 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y207.74373 Z22.885714 E17349.749458 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y206.363703 Z22.895238 E17355.695603 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y205.185623 Z22.904762 E17360.996893 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y204.329541 Z22.914286 E17365.508858 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y203.80243 Z22.92381 E17369.667184 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y203.618616 Z22.933333 E17374.062178 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y203.774812 Z22.942857 E17379.217739 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y204.152782 Z22.952381 E17385.060497 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y204.636376 Z22.961905 E17391.266965 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y205.092185 Z22.971429 E17397.37585 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y205.390328 Z22.980952 E17402.958041 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y205.421796 Z22.990476 E17407.78581 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X174.5 Y202.5 Z23 E17423.820832 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y199.578204 Z23.009524 E17439.855854 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y199.609672 Z23.019048 E17444.683622 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y199.907815 Z23.028571 E17450.265813 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y200.363624 Z23.038095 E17456.374698 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y200.847218 Z23.047619 E17462.581166 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y201.225188 Z23.057143 E17468.423924 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y201.381384 Z23.066667 E17473.579485 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y201.19757 Z23.07619 E17477.974479 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y200.670459 Z23.085714 E17482.132805 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y199.814377 Z23.095238 E17486.64477 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y198.636297 Z23.104762 E17491.94606 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y197.25627 Z23.114286 E17497.892205 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y195.796106 Z23.12381 E17504.116869 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y194.390359 Z23.133333 E17510.151179 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y193.165803 Z23.142857 E17515.592622 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y192.237185 Z23.152381 E17520.250211 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y192.113153 Z23.161905 E17521.102637 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y192.819004 Z23.171429 E17524.068014 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y192.534107 Z23.180952 E17526.705791 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y191.520172 Z23.190476 E17532.428666 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z23.2 E17538.598873 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y189.487523 Z23.209524 E17544.769079 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y188.473589 Z23.219048 E17550.491954 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y187.46406 Z23.228571 E17555.491768 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y186.460802 Z23.238095 E17559.799302 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y185.46408 Z23.247619 E17563.991944 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y184.473226 Z23.257143 E17568.649533 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y183.487749 Z23.266667 E17574.090976 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y182.505563 Z23.27619 E17580.125286 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y181.524367 Z23.285714 E17586.34995 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y180.541714 Z23.295238 E17592.296095 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y179.555393 Z23.304762 E17597.597384 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y178.563221 Z23.314286 E17602.10935 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y177.565073 Z23.32381 E17606.267676 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y174.258294 Z23.333333 E17621.603679 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y175.422738 Z23.342857 E17635.473496 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y176.783916 Z23.352381 E17641.316253 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y178.2488 Z23.361905 E17647.522722 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y179.686404 Z23.371429 E17653.631607 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y180.969206 Z23.380952 E17659.213798 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y181.990178 Z23.390476 E17664.041566 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y182.685477 Z23.4 E17668.287932 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y183.016551 Z23.409524 E17672.534298 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y183.021952 Z23.419048 E17677.362067 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y182.765523 Z23.428571 E17682.944257 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y182.354291 Z23.438095 E17689.053143 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y181.91578 Z23.447619 E17695.259611 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y181.580974 Z23.457143 E17701.102368 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y181.463913 Z23.466667 E17706.257929 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y181.680683 Z23.47619 E17710.652923 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y182.234515 Z23.485714 E17714.811249 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y182.848272 Z23.495238 E17717.365396 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y183.611935 Z23.504762 E17720.714375 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y184.156005 Z23.514286 E17725.318147 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y184.599564 Z23.52381 E17731.542811 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y184.989694 Z23.533333 E17737.57712 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y185.201926 Z23.542857 E17743.018564 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y185.123596 Z23.552381 E17747.676153 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y184.728123 Z23.561905 E17751.868794 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y183.979462 Z23.571429 E17756.176329 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y182.891948 Z23.580952 E17761.176142 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y181.566331 Z23.590476 E17766.899018 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z23.6 E17773.069224 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y178.656754 Z23.609524 E17779.23943 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y177.331138 Z23.619048 E17784.962306 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y176.243623 Z23.628571 E17789.962119 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y175.494963 Z23.638095 E17794.269654 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y175.099489 Z23.647619 E17798.462295 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y175.021159 Z23.657143 E17803.119884 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y175.221331 Z23.666667 E17814.834953 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y177.525217 Z23.67619 E17824.505098 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y178.506414 Z23.685714 E17830.729762 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y179.489066 Z23.695238 E17836.675907 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y180.475388 Z23.704762 E17841.977197 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y181.467559 Z23.714286 E17846.489162 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y182.465708 Z23.72381 E17850.647488 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y183.470094 Z23.733333 E17855.042482 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y184.480657 Z23.742857 E17860.198043 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y185.495249 Z23.752381 E17866.040801 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y186.511761 Z23.761905 E17872.247269 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y187.527767 Z23.771429 E17878.356154 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y188.540909 Z23.780952 E17883.938345 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y189.549206 Z23.790476 E17888.766114 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y190.551477 Z23.8 E17893.012479 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y191.547008 Z23.809524 E17897.258845 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y192.536512 Z23.819048 E17902.086614 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y193.174342 Z23.828571 E17906.858645 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y194.085027 Z23.838095 E17911.567542 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y195.504361 Z23.847619 E17917.58721 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y196.853759 Z23.857143 E17923.429968 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y197.981384 Z23.866667 E17928.585529 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y198.768999 Z23.87619 E17932.980523 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y199.213316 Z23.885714 E17937.138849 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y199.328663 Z23.895238 E17941.650814 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y199.122011 Z23.904762 E17946.952104 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y198.713412 Z23.914286 E17952.898249 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y198.224677 Z23.92381 E17959.122913 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y197.790359 Z23.933333 E17965.157223 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y197.537232 Z23.942857 E17970.598666 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y197.580043 Z23.952381 E17975.256255 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y197.945866 Z23.961905 E17979.448896 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y198.671412 Z23.971429 E17983.756431 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y199.742082 Z23.980952 E17988.756244 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y201.055259 Z23.990476 E17994.47912 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z24 E18000.649326 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.026688 Z24.009524 E18006.819532 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y201.684939 Z24.019048 E18012.542408 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y201.585698 Z24.028571 E18017.542221 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y201.83158 Z24.038095 E18021.849756 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.437185 Z24.047619 E18026.042397 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y203.365803 Z24.057143 E18030.699986 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y204.590359 Z24.066667 E18036.14143 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y205.996106 Z24.07619 E18042.175739 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y207.45627 Z24.085714 E18048.400403 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y208.836297 Z24.095238 E18054.346548 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y210.014377 Z24.104762 E18059.647838 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y210.870459 Z24.114286 E18064.159804 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y211.39757 Z24.12381 E18068.318129 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y211.581384 Z24.133333 E18072.713123 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y211.425188 Z24.142857 E18077.868684 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y211.047218 Z24.152381 E18083.711442 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y210.599313 Z24.161905 E18090.06066 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y211.173243 Z24.171429 E18096.856498 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y212.533214 Z24.180952 E18103.688785 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y213.541511 Z24.190476 E18108.516554 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y214.543782 Z24.2 E18112.762919 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y215.539313 Z24.209524 E18117.009285 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y216.528817 Z24.219048 E18121.837054 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y217.513476 Z24.228571 E18127.419244 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y218.495271 Z24.238095 E18133.52813 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y219.476561 Z24.247619 E18139.734598 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y220.45977 Z24.257143 E18145.577356 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y221.447008 Z24.266667 E18150.732917 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y222.440424 Z24.27619 E18155.127911 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y223.440077 Z24.285714 E18159.286236 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y224.445706 Z24.295238 E18163.798202 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y225.457186 Z24.304762 E18169.099492 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y226.472335 Z24.314286 E18175.045637 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y227.48894 Z24.32381 E18181.270301 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y227.182855 Z24.333333 E18183.017176 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y225.956311 Z24.342857 E18189.856966 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y225.008268 Z24.352381 E18194.514555 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y224.377369 Z24.361905 E18198.707196 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y224.099656 Z24.371429 E18203.014731 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y224.160798 Z24.380952 E18208.014544 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y224.460041 Z24.390476 E18213.73742 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z24.4 E18219.907626 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y225.316873 Z24.409524 E18226.077832 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y225.616117 Z24.419048 E18231.800708 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y225.677258 Z24.428571 E18236.800521 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y225.399546 Z24.438095 E18241.108056 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y224.768647 Z24.447619 E18245.300697 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y223.820604 Z24.457143 E18249.958286 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y222.581999 Z24.466667 E18255.39973 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y221.165496 Z24.47619 E18261.434039 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y219.695564 Z24.485714 E18267.658703 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y218.125122 Z24.495238 E18274.894084 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y217.361458 Z24.504762 E18283.679893 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y217.774074 Z24.514286 E18290.909229 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y218.246615 Z24.52381 E18295.067555 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y219.056218 Z24.533333 E18299.462549 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y220.199652 Z24.542857 E18304.61811 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y221.560831 Z24.552381 E18310.460867 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y223.025715 Z24.561905 E18316.667336 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y224.463319 Z24.571429 E18322.776221 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y225.746121 Z24.580952 E18328.358412 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y226.767093 Z24.590476 E18333.18618 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y227.462391 Z24.6 E18337.432546 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y227.793466 Z24.609524 E18341.678912 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y227.798867 Z24.619048 E18346.506681 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y227.542437 Z24.628571 E18352.088871 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y227.131206 Z24.638095 E18358.197757 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y226.692695 Z24.647619 E18364.404225 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y226.357889 Z24.657143 E18370.246982 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y226.219818 Z24.666667 E18376.145369 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y227.528795 Z24.67619 E18384.955145 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y226.529143 Z24.685714 E18389.11347 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y225.523513 Z24.695238 E18393.625436 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y224.512033 Z24.704762 E18398.926726 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y223.496884 Z24.714286 E18404.872871 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y222.480279 Z24.72381 E18411.097534 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y221.464663 Z24.733333 E18417.131844 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y220.452339 Z24.742857 E18422.573288 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y219.445392 Z24.752381 E18427.230877 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y218.444313 Z24.761905 E18431.423518 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y217.449769 Z24.771429 E18435.731053 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y216.461496 Z24.780952 E18440.730866 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y215.477629 Z24.790476 E18446.453741 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z24.8 E18452.623948 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y213.514676 Z24.809524 E18458.794154 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y212.530809 Z24.819048 E18464.517029 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y210.817905 Z24.828571 E18472.060808 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y208.627439 Z24.838095 E18482.002687 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y207.780043 Z24.847619 E18489.467875 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y207.737232 Z24.857143 E18494.125465 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y207.990359 Z24.866667 E18499.566908 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y208.424677 Z24.87619 E18505.601218 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y208.913412 Z24.885714 E18511.825882 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y209.322011 Z24.895238 E18517.772027 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y209.528663 Z24.904762 E18523.073316 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y209.413316 Z24.914286 E18527.585282 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y208.968999 Z24.92381 E18531.743608 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y208.181384 Z24.933333 E18536.138602 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y207.053759 Z24.942857 E18541.294163 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y205.704361 Z24.952381 E18547.13692 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y204.249338 Z24.961905 E18553.343388 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.8221 Z24.971429 E18559.452274 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y201.552529 Z24.980952 E18565.034464 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y200.549633 Z24.990476 E18569.862233 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.5 Y202.5 Z25 E18578.582555 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.72837 Y204.450367 Z25.009524 E18587.302878 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.313628 Y203.447471 Z25.019048 E18592.130646 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.750517 Y202.1779 Z25.028571 E18597.712837 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.099684 Y200.750662 Z25.038095 E18603.821722 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.433393 Y199.295639 Z25.047619 E18610.028191 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X181.825868 Y197.946241 Z25.057143 E18615.870948 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.341731 Y196.818616 Z25.066667 E18621.026509 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.046766 Y196.031001 Z25.07619 E18625.421503 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.942802 Y195.586684 Z25.085714 E18629.579829 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.021868 Y195.471337 Z25.095238 E18634.091795 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.280084 Y195.677989 Z25.104762 E18639.393084 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.650658 Y196.086588 Z25.114286 E18645.339229 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.065818 Y196.575323 Z25.12381 E18651.563893 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.450701 Y197.009641 Z25.133333 E18657.598203 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.734775 Y197.262768 Z25.142857 E18663.039646 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.854198 Y197.219957 Z25.152381 E18667.697236 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.437222 Y196.372561 Z25.161905 E18675.162424 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.396437 Y194.182095 Z25.171429 E18685.104303 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.797898 Y192.469191 Z25.180952 E18692.648082 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.835244 Y191.485324 Z25.190476 E18698.370957 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z25.2 E18704.541163 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.608865 Y189.522371 Z25.209524 E18710.71137 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.646211 Y188.538504 Z25.219048 E18716.434245 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.961037 Y187.550231 Z25.228571 E18721.434058 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.670758 Y186.555687 Z25.238095 E18725.741593 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.792078 Y185.554608 Z25.247619 E18729.934234 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.282992 Y184.547661 Z25.257143 E18734.591823 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.112522 Y183.535337 Z25.266667 E18740.033267 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.149372 Y182.519721 Z25.27619 E18746.067577 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.248487 Y181.503116 Z25.285714 E18752.29224 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.255908 Y180.487967 Z25.295238 E18758.238385 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.03226 Y179.476487 Z25.304762 E18763.539675 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.440178 Y178.470857 Z25.314286 E18768.051641 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.471684 Y177.471205 Z25.32381 E18772.209966 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.805357 Y178.780182 Z25.333333 E18781.019742 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.393395 Y178.642111 Z25.342857 E18786.918129 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.758246 Y178.307305 Z25.352381 E18792.760886 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.185187 Y177.868794 Z25.361905 E18798.967354 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.595795 Y177.457563 Z25.371429 E18805.07624 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.91372 Y177.201133 Z25.380952 E18810.65843 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.074883 Y177.206534 Z25.390476 E18815.486199 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.041059 Y177.537609 Z25.4 E18819.732565 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.789168 Y178.232907 Z25.409524 E18823.978931 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.342291 Y179.253879 Z25.419048 E18828.806699 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.738652 Y180.536681 Z25.428571 E18834.38889 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.04233 Y181.974285 Z25.438095 E18840.497775 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.329674 Y183.439169 Z25.447619 E18846.704244 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X202.67911 Y184.800348 Z25.457143 E18852.547001 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.158912 Y185.943782 Z25.466667 E18857.702562 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.838585 Y186.753385 Z25.47619 E18862.097556 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.720063 Y187.225926 Z25.485714 E18866.255882 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.409231 Y187.638542 Z25.495238 E18873.485218 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.379634 Y186.874878 Z25.504762 E18882.271027 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.129507 Y185.304436 Z25.514286 E18889.506408 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.41383 Y183.834504 Z25.52381 E18895.731072 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.730141 Y182.418001 Z25.533333 E18901.765381 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.152963 Y181.179396 Z25.542857 E18907.206825 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X210.74975 Y180.231353 Z25.552381 E18911.864414 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.536416 Y179.600454 Z25.561905 E18916.057055 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.534542 Y179.322742 Z25.571429 E18920.36459 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.735545 Y179.383883 Z25.580952 E18925.364403 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.079103 Y179.683127 Z25.590476 E18931.087279 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z25.6 E18937.257485 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.920897 Y180.539959 Z25.609524 E18943.427691 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.264455 Y180.839202 Z25.619048 E18949.150567 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.465458 Y180.900344 Z25.628571 E18954.15038 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.463584 Y180.622631 Z25.638095 E18958.457915 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.25025 Y179.991732 Z25.647619 E18962.650556 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.847037 Y179.043689 Z25.657143 E18967.308145 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.750653 Y177.817145 Z25.666667 E18974.147935 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.038345 Y177.51106 Z25.67619 E18975.89481 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.137459 Y178.527665 Z25.685714 E18982.119474 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.144881 Y179.542814 Z25.695238 E18988.065619 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.921233 Y180.554294 Z25.704762 E18993.366909 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.32915 Y181.559923 Z25.714286 E18997.878875 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.360657 Y182.559576 Z25.72381 E19002.0372 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.999357 Y183.552992 Z25.733333 E19006.432194 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.249015 Y184.54023 Z25.742857 E19011.587755 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.244917 Y185.523439 Z25.752381 E19017.430513 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.119963 Y186.504729 Z25.761905 E19023.636981 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.0268 Y187.486524 Z25.771429 E19029.745866 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.114041 Y188.471183 Z25.780952 E19035.328057 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.506415 Y189.460687 Z25.790476 E19040.155826 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.278324 Y190.456218 Z25.8 E19044.402192 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.474693 Y191.458489 Z25.809524 E19048.648557 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.050597 Y192.466786 Z25.819048 E19053.476326 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.9731 Y193.826757 Z25.828571 E19060.308613 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.50359 Y194.400687 Z25.838095 E19067.104451 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.963565 Y193.952782 Z25.847619 E19073.453669 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.317097 Y193.574812 Z25.857143 E19079.296427 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.547242 Y193.418616 Z25.866667 E19084.451988 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.588215 Y193.60243 Z25.87619 E19088.846982 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X228.438186 Y194.129541 Z25.885714 E19093.005307 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.105129 Y194.985623 Z25.895238 E19097.517273 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.59292 Y196.163703 Z25.904762 E19102.818563 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.968354 Y197.54373 Z25.914286 E19108.764708 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.299202 Y199.003894 Z25.92381 E19114.989372 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.660326 Y200.409641 Z25.933333 E19121.023681 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.12226 Y201.634197 Z25.942857 E19126.465125 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X231.748845 Y202.562815 Z25.952381 E19131.122714 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.555145 Y203.16842 Z25.961905 E19135.315355 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.561584 Y203.414302 Z25.971429 E19139.62289 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.760041 Y203.315061 Z25.980952 E19144.622703 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.093421 Y202.973312 Z25.990476 E19150.345579 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z26 E19156.515785 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y203.944741 Z26.009524 E19162.685991 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y205.257918 Z26.019048 E19168.408867 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y206.328588 Z26.028571 E19173.40868 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y207.054134 Z26.038095 E19177.716215 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y207.419957 Z26.047619 E19181.908856 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y207.462768 Z26.057143 E19186.566445 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y207.209641 Z26.066667 E19192.007888 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y206.775323 Z26.07619 E19198.042198 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y206.286588 Z26.085714 E19204.266862 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y205.877989 Z26.095238 E19210.213007 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y205.671337 Z26.104762 E19215.514297 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y205.786684 Z26.114286 E19220.026262 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y206.231001 Z26.12381 E19224.184588 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y207.018616 Z26.133333 E19228.579582 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y208.146241 Z26.142857 E19233.735143 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y209.495639 Z26.152381 E19239.577901 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y210.914973 Z26.161905 E19245.597569 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y211.825658 Z26.171429 E19250.306466 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y212.463488 Z26.180952 E19255.078497 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y213.452992 Z26.190476 E19259.906266 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y214.448523 Z26.2 E19264.152632 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y215.450794 Z26.209524 E19268.398997 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y216.459091 Z26.219048 E19273.226766 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y217.472233 Z26.228571 E19278.808957 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y218.488239 Z26.238095 E19284.917842 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y219.504751 Z26.247619 E19291.12431 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y220.519343 Z26.257143 E19296.967068 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y221.529906 Z26.266667 E19302.122629 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y222.534292 Z26.27619 E19306.517623 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y223.532441 Z26.285714 E19310.675949 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y224.524612 Z26.295238 E19315.187914 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y225.510934 Z26.304762 E19320.489204 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y226.493586 Z26.314286 E19326.435349 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y227.474783 Z26.32381 E19332.660013 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y229.778669 Z26.333333 E19342.330158 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y229.978841 Z26.342857 E19354.045227 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y229.900511 Z26.352381 E19358.702816 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y229.505037 Z26.361905 E19362.895457 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y228.756377 Z26.371429 E19367.202992 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y227.668862 Z26.380952 E19372.202805 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y226.343246 Z26.390476 E19377.925681 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y224.888457 Z26.4 E19384.095887 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y223.433669 Z26.409524 E19390.266093 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y222.108052 Z26.419048 E19395.988969 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y221.020538 Z26.428571 E19400.988782 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y220.271877 Z26.438095 E19405.296317 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y219.876404 Z26.447619 E19409.488958 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y219.798074 Z26.457143 E19414.146547 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y220.010306 Z26.466667 E19419.587991 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y220.400436 Z26.47619 E19425.6223 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y220.843995 Z26.485714 E19431.846964 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y221.388065 Z26.495238 E19436.450736 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y222.151728 Z26.504762 E19439.799715 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y222.765485 Z26.514286 E19442.353862 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y223.319317 Z26.52381 E19446.512188 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y223.536087 Z26.533333 E19450.907182 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y223.419026 Z26.542857 E19456.062743 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y223.08422 Z26.552381 E19461.9055 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y222.645709 Z26.561905 E19468.111968 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y222.234477 Z26.571429 E19474.220854 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y221.978048 Z26.580952 E19479.803044 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y221.983449 Z26.590476 E19484.630813 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y222.314523 Z26.6 E19488.877179 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y223.009822 Z26.609524 E19493.123545 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y224.030794 Z26.619048 E19497.951313 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y225.313596 Z26.628571 E19503.533504 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y226.7512 Z26.638095 E19509.642389 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y228.216084 Z26.647619 E19515.848858 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y229.577262 Z26.657143 E19521.691615 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y230.741706 Z26.666667 E19535.561432 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y227.434927 Z26.67619 E19550.897435 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y226.436779 Z26.685714 E19555.055761 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y225.444607 Z26.695238 E19559.567727 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y224.458286 Z26.704762 E19564.869016 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y223.475633 Z26.714286 E19570.815161 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y222.494437 Z26.72381 E19577.039825 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y221.512251 Z26.733333 E19583.074135 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y220.526774 Z26.742857 E19588.515578 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y219.53592 Z26.752381 E19593.173167 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y218.539198 Z26.761905 E19597.365809 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y217.53594 Z26.771429 E19601.673343 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y216.526411 Z26.780952 E19606.673157 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y215.512477 Z26.790476 E19612.396032 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y214.496152 Z26.8 E19618.566238 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y213.479828 Z26.809524 E19624.736445 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y212.465893 Z26.819048 E19630.45932 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y212.180996 Z26.828571 E19633.097097 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y212.886847 Z26.838095 E19636.062474 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y212.762815 Z26.847619 E19636.9149 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y211.834197 Z26.857143 E19641.572489 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y210.609641 Z26.866667 E19647.013932 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y209.203894 Z26.87619 E19653.048242 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y207.74373 Z26.885714 E19659.272906 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y206.363703 Z26.895238 E19665.219051 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y205.185623 Z26.904762 E19670.52034 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y204.329541 Z26.914286 E19675.032306 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y203.80243 Z26.92381 E19679.190632 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y203.618616 Z26.933333 E19683.585626 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y203.774812 Z26.942857 E19688.741187 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y204.152782 Z26.952381 E19694.583945 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y204.636376 Z26.961905 E19700.790413 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y205.092185 Z26.971429 E19706.899298 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y205.390328 Z26.980952 E19712.481489 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y205.421796 Z26.990476 E19717.309257 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X174.5 Y202.5 Z27 E19733.344279 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X177.017638 Y199.578204 Z27.009524 E19749.379301 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X178.178387 Y199.609672 Z27.019048 E19754.20707 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X179.487507 Y199.907815 Z27.028571 E19759.789261 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X180.884347 Y200.363624 Z27.038095 E19765.898146 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X182.296646 Y200.847218 Z27.047619 E19772.104614 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X183.650179 Y201.225188 Z27.057143 E19777.947372 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X184.880324 Y201.381384 Z27.066667 E19783.102933 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X185.921296 Y201.19757 Z27.07619 E19787.497927 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X186.771268 Y200.670459 Z27.085714 E19791.656252 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.43821 Y199.814377 Z27.095238 E19796.168218 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X187.926002 Y198.636297 Z27.104762 E19801.469508 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.301435 Y197.25627 Z27.114286 E19807.415653 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.632284 Y195.796106 Z27.12381 E19813.640317 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X188.993408 Y194.390359 Z27.133333 E19819.674626 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.455342 Y193.165803 Z27.142857 E19825.11607 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.081927 Y192.237185 Z27.152381 E19829.773659 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.24491 Y192.113153 Z27.161905 E19830.626085 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.142838 Y192.819004 Z27.171429 E19833.591462 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.709655 Y192.534107 Z27.180952 E19836.229239 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.640587 Y191.520172 Z27.190476 E19841.952114 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X192.722055 Y190.503848 Z27.2 E19848.12232 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.803522 Y189.487523 Z27.209524 E19854.292527 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.734454 Y188.473589 Z27.219048 E19860.015402 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.387905 Y187.46406 Z27.228571 E19865.015215 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.646462 Y186.460802 Z27.238095 E19869.32275 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.493421 Y185.46408 Z27.247619 E19873.515391 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.970785 Y184.473226 Z27.257143 E19878.17298 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.109532 Y183.487749 Z27.266667 E19883.614424 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X193.04096 Y182.505563 Z27.27619 E19889.648734 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.910124 Y181.524367 Z27.285714 E19895.873398 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.87098 Y180.541714 Z27.295238 E19901.819542 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X190.062906 Y179.555393 Z27.304762 E19907.120832 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.623267 Y178.563221 Z27.314286 E19911.632798 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X189.560038 Y177.565073 Z27.32381 E19915.791123 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X191.194643 Y174.258294 Z27.333333 E19931.127127 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.32089 Y175.422738 Z27.342857 E19944.996944 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.670326 Y176.783916 Z27.352381 E19950.839701 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X194.95767 Y178.2488 Z27.361905 E19957.046169 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.261348 Y179.686404 Z27.371429 E19963.155055 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X195.657709 Y180.969206 Z27.380952 E19968.737245 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.210832 Y181.990178 Z27.390476 E19973.565014 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X196.958941 Y182.685477 Z27.4 E19977.81138 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X197.925117 Y183.016551 Z27.409524 E19982.057746 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X199.08628 Y183.021952 Z27.419048 E19986.885514 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X200.404205 Y182.765523 Z27.428571 E19992.467705 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X201.814813 Y182.354291 Z27.438095 E19998.57659 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X203.241754 Y181.91578 Z27.447619 E20004.783058 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X204.606605 Y181.580974 Z27.457143 E20010.625816 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X205.841088 Y181.463913 Z27.466667 E20015.781377 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X206.8757 Y181.680683 Z27.47619 E20020.176371 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.708508 Y182.234515 Z27.485714 E20024.334697 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.733626 Y182.848272 Z27.495238 E20026.888844 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X207.477509 Y183.611935 Z27.504762 E20030.237823 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X208.441921 Y184.156005 Z27.514286 E20034.841595 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X209.871884 Y184.599564 Z27.52381 E20041.066258 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X211.269859 Y184.989694 Z27.533333 E20047.100568 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X212.561322 Y185.201926 Z27.542857 E20052.542012 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X213.678821 Y185.123596 Z27.552381 E20057.199601 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X214.606441 Y184.728123 Z27.561905 E20061.392242 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.322601 Y183.979462 Z27.571429 E20065.699777 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X215.835884 Y182.891948 Z27.580952 E20070.69959 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.206611 Y181.566331 Z27.590476 E20076.422465 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.5 Y180.111543 Z27.6 E20082.592672 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X216.793389 Y178.656754 Z27.609524 E20088.762878 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.164116 Y177.331138 Z27.619048 E20094.485753 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X217.677399 Y176.243623 Z27.628571 E20099.485567 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X218.393559 Y175.494963 Z27.638095 E20103.793101 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.321179 Y175.099489 Z27.647619 E20107.985743 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.438678 Y175.021159 Z27.657143 E20112.643332 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.249347 Y175.221331 Z27.666667 E20124.358401 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.929933 Y177.525217 Z27.67619 E20134.028546 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.799096 Y178.506414 Z27.685714 E20140.25321 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.759953 Y179.489066 Z27.695238 E20146.199355 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.951879 Y180.475388 Z27.704762 E20151.500644 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.512239 Y181.467559 Z27.714286 E20156.01261 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.449011 Y182.465708 Z27.72381 E20160.170936 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X219.778588 Y183.470094 Z27.733333 E20164.56593 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X220.497208 Y184.480657 Z27.742857 E20169.721491 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X221.469584 Y185.495249 Z27.752381 E20175.564248 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.562816 Y186.511761 Z27.761905 E20181.770717 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.624257 Y187.527767 Z27.771429 E20187.879602 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.505294 Y188.540909 Z27.780952 E20193.461793 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.081198 Y189.549206 Z27.790476 E20198.289561 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.277567 Y190.551477 Z27.8 E20202.535927 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.049476 Y191.547008 Z27.809524 E20206.782293 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.44185 Y192.536512 Z27.819048 E20211.610062 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.487625 Y193.174342 Z27.828571 E20216.382092 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X222.814278 Y194.085027 Z27.838095 E20221.09099 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.100311 Y195.504361 Z27.847619 E20227.110658 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X223.492786 Y196.853759 Z27.857143 E20232.953416 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.008649 Y197.981384 Z27.866667 E20238.108977 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X224.713684 Y198.768999 Z27.87619 E20242.503971 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X225.60972 Y199.213316 Z27.885714 E20246.662296 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X226.688786 Y199.328663 Z27.895238 E20251.174262 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X227.947002 Y199.122011 Z27.904762 E20256.475552 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X229.317576 Y198.713412 Z27.914286 E20262.421697 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X230.732736 Y198.224677 Z27.92381 E20268.646361 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X232.117619 Y197.790359 Z27.933333 E20274.68067 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X233.401693 Y197.537232 Z27.942857 E20280.122114 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X234.521116 Y197.580043 Z27.952381 E20284.779703 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X235.460824 Y197.945866 Z27.961905 E20288.972344 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.200392 Y198.671412 Z27.971429 E20293.279879 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.747944 Y199.742082 Z27.980952 E20298.279692 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.160571 Y201.055259 Z27.990476 E20304.002568 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X237.5 Y202.5 Z28 E20310.172774 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave z-blend wall
G1 X236.095962 Y202.031255 Z28 E20316.326803 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X234.769507 Y201.701953 Z28 E20322.008965 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X233.580433 Y201.619575 Z28 E20326.964409 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X232.582818 Y201.881319 Z28 E20331.25239 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X231.781848 Y202.496504 Z28 E20335.451288 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X231.154823 Y203.424331 Z28 E20340.107008 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X230.684615 Y204.634014 Z28 E20345.502864 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X230.30746 Y206.010948 Z28 E20351.438355 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X229.954408 Y207.431205 Z28 E20357.522799 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X229.553731 Y208.765861 Z28 E20363.316308 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X229.041843 Y209.900631 Z28 E20368.491928 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X228.357373 Y210.725208 Z28 E20372.947318 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X227.499241 Y211.237653 Z28 E20377.102735 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X226.462622 Y211.429292 Z28 E20381.485524 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X225.251943 Y211.308082 Z28 E20386.544104 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X223.930679 Y210.98811 Z28 E20392.196068 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.516165 Y210.612089 Z28 E20398.281172 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.080865 Y211.201204 Z28 E20404.731545 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X220.249249 Y212.53006 Z28 E20411.248969 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X219.740159 Y213.537296 Z28 E20415.941068 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X219.578286 Y214.539019 Z28 E20420.159773 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X219.798428 Y215.534676 Z28 E20424.399207 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X220.354515 Y216.524999 Z28 E20429.121187 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.175227 Y217.51112 Z28 E20434.455141 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.146323 Y218.494853 Z28 E20440.202086 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X223.135016 Y219.478306 Z28 E20445.999838 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X224.007828 Y220.4636 Z28 E20451.472312 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X224.651306 Y221.452535 Z28 E20456.377577 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X224.952471 Y222.446905 Z28 E20460.697142 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X224.913657 Y223.446674 Z28 E20464.856829 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X224.554447 Y224.45153 Z28 E20469.293442 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X223.886982 Y225.461281 Z28 E20474.325768 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X223.032302 Y226.474005 Z28 E20479.8352 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.110521 Y227.487794 Z28 E20485.531832 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.875544 Y227.399173 Z28 E20486.575922 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.640606 Y226.301099 Z28 E20492.139986 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.992213 Y225.439251 Z28 E20496.623933 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.18582 Y224.8413 Z28 E20500.797663 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X220.206567 Y224.532066 Z28 E20505.067093 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X219.064423 Y224.494899 Z28 E20509.81809 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X217.81083 Y224.643878 Z28 E20515.066598 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X216.5 Y224.888457 Z28 E20520.610449 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X215.194539 Y225.124069 Z28 E20526.125614 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X213.95558 Y225.248605 Z28 E20531.302562 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X212.833262 Y225.178324 Z28 E20535.977757 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X211.872657 Y224.837944 Z28 E20540.214797 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X211.077527 Y224.221182 Z28 E20544.398482 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X210.428204 Y223.360886 Z28 E20548.879598 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X209.909775 Y222.281968 Z28 E20553.856188 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X209.46836 Y221.074417 Z28 E20559.20151 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X209.046015 Y219.835017 Z28 E20564.645302 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X208.267942 Y218.529105 Z28 E20570.965275 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X206.576357 Y217.965945 Z28 E20578.37757 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X205.104292 Y218.415827 Z28 E20584.777136 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X204.236303 Y218.910898 Z28 E20588.931533 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X203.516535 Y219.653534 Z28 E20593.231244 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X202.940698 Y220.636567 Z28 E20597.967792 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X202.455628 Y221.771203 Z28 E20603.098061 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X202.010369 Y222.972333 Z28 E20608.423851 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X201.548016 Y224.144913 Z28 E20613.664159 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X201.014633 Y225.198853 Z28 E20618.575115 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X200.36638 Y226.060936 Z28 E20623.05949 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X199.578741 Y226.690211 Z28 E20627.250881 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X198.638456 Y227.064529 Z28 E20631.458508 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X197.564575 Y227.215712 Z28 E20635.967212 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X196.386096 Y227.192191 Z28 E20640.867736 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X195.148892 Y227.070586 Z28 E20646.036216 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.905916 Y226.939339 Z28 E20651.232641 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.710055 Y226.886786 Z28 E20656.209251 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.370238 Y226.973466 Z28 E20658.977528 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X194.472334 Y227.512927 Z28 E20664.078981 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X194.442993 Y226.513309 Z28 E20668.236701 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X194.168539 Y225.509798 Z28 E20672.562034 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.659516 Y224.502563 Z28 E20677.254003 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.009493 Y223.493089 Z28 E20682.245737 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.310707 Y222.482841 Z28 E20687.352724 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.661974 Y221.473388 Z28 E20692.341486 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.153582 Y220.466163 Z28 E20697.032235 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X190.864473 Y219.46242 Z28 E20701.374968 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X190.808988 Y218.462386 Z28 E20705.539019 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.007648 Y217.466388 Z28 E20709.761465 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.444392 Y216.47417 Z28 E20714.268568 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.042571 Y215.484516 Z28 E20719.076273 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.722055 Y214.496152 Z28 E20724.062798 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.391087 Y213.507623 Z28 E20729.025408 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.960782 Y212.517516 Z28 E20733.774565 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X194.308192 Y211.100259 Z28 E20739.84128 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.558833 Y209.519886 Z28 E20747.112915 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.26674 Y208.835916 Z28 E20753.191027 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.246325 Y208.615153 Z28 E20757.53157 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X190.134954 Y208.55787 Z28 E20762.158247 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X188.970853 Y208.595363 Z28 E20767.000527 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X187.794759 Y208.654411 Z28 E20771.896317 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X186.648456 Y208.659914 Z28 E20776.662145 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X185.568421 Y208.546309 Z28 E20781.17718 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X184.589309 Y208.25131 Z28 E20785.428606 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X183.710646 Y207.775767 Z28 E20789.582358 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X182.934069 Y207.116738 Z28 E20793.816887 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X182.255884 Y206.280864 Z28 E20798.292006 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X181.638929 Y205.334937 Z28 E20802.98726 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X181.047901 Y204.342412 Z28 E20807.789907 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X180.443786 Y203.373407 Z28 E20812.537356 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X179.789986 Y202.493703 Z28 E20817.094215 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X179.057141 Y201.756073 Z28 E20821.417154 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X179 Y202.5 Z28 E20824.519152 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X179.044233 Y203.220726 Z28 E20827.521221 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X179.76965 Y202.469746 Z28 E20831.862197 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X180.425743 Y201.594163 Z28 E20836.411026 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X181.043799 Y200.650216 Z28 E20841.101896 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X181.659483 Y199.702005 Z28 E20845.802228 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X182.308007 Y198.81282 Z28 E20850.377828 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X183.018689 Y198.035354 Z28 E20854.757099 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X183.820151 Y197.421054 Z28 E20858.955381 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X184.710528 Y196.966566 Z28 E20863.111508 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X185.683485 Y196.660503 Z28 E20867.35201 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X186.734671 Y196.495045 Z28 E20871.776138 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X187.831946 Y196.412428 Z28 E20876.350991 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X188.944015 Y196.3564 Z28 E20880.980302 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X190.037801 Y196.267511 Z28 E20885.542728 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.083508 Y196.092207 Z28 E20889.950941 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.05552 Y195.784445 Z28 E20894.189821 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.219455 Y195.135305 Z28 E20899.730606 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.857883 Y193.782904 Z28 E20905.948251 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.590893 Y192.488357 Z28 E20911.443628 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.182072 Y191.495696 Z28 E20915.906931 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.722055 Y190.503848 Z28 E20920.452486 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.272487 Y189.511833 Z28 E20924.980559 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.892152 Y188.51872 Z28 E20929.401877 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.627861 Y187.523764 Z28 E20933.681873 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.520381 Y186.526318 Z28 E20937.852777 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.570354 Y185.526372 Z28 E20942.015257 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X191.756298 Y184.524267 Z28 E20946.252642 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.061575 Y183.520267 Z28 E20950.61548 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.433831 Y182.515204 Z28 E20955.071451 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.818299 Y181.509946 Z28 E20959.546062 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.159836 Y180.505371 Z28 E20963.957382 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.411304 Y179.502225 Z28 E20968.257021 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.528907 Y178.501205 Z28 E20972.4474 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.515211 Y177.50227 Z28 E20976.60088 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X192.935119 Y177.272886 Z28 E20979.194329 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X193.040483 Y177.561321 Z28 E20980.471009 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X194.066616 Y177.792255 Z28 E20984.843876 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X195.107723 Y177.998177 Z28 E20989.256152 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X196.13827 Y178.221737 Z28 E20993.640325 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X197.134859 Y178.502016 Z28 E20997.9444 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X198.079284 Y178.86942 Z28 E21002.157515 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X198.962318 Y179.339363 Z28 E21006.316268 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X199.779931 Y179.918572 Z28 E21010.482041 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X200.541944 Y180.590648 Z28 E21014.70627 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X201.262064 Y181.332696 Z28 E21019.005246 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X201.960532 Y182.110907 Z28 E21023.352723 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X202.65976 Y182.887848 Z28 E21027.698388 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X203.381269 Y183.627576 Z28 E21031.994478 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X204.142377 Y184.301164 Z28 E21036.220048 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X204.959425 Y184.881316 Z28 E21040.386175 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X205.830057 Y185.371973 Z28 E21044.541079 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X206.904303 Y185.847893 Z28 E21049.425946 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X208.040263 Y185.64739 Z28 E21054.221724 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X208.869207 Y184.869673 Z28 E21058.9474 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X209.588327 Y184.125955 Z28 E21063.248469 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X210.320366 Y183.403817 Z28 E21067.523574 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X211.081902 Y182.730943 Z28 E21071.748509 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X211.886509 Y182.130009 Z28 E21075.923686 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X212.735188 Y181.602687 Z28 E21080.077721 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X213.629851 Y181.152168 Z28 E21084.242277 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X214.565679 Y180.770404 Z28 E21088.444286 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X215.527422 Y180.431925 Z28 E21092.683155 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X216.5 Y180.111543 Z28 E21096.940405 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X217.467209 Y179.782193 Z28 E21101.188331 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X218.414318 Y179.419271 Z28 E21105.405143 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X219.33032 Y179.004393 Z28 E21109.585842 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X220.206336 Y178.522729 Z28 E21113.74212 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.043752 Y177.976594 Z28 E21117.898657 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.849288 Y177.377213 Z28 E21122.073075 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.375109 Y176.735556 Z28 E21125.522089 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.411963 Y177.516993 Z28 E21128.774536 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.573435 Y178.518709 Z28 E21132.99295 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.710316 Y179.520035 Z28 E21137.194697 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.803342 Y180.520665 Z28 E21141.37277 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.836188 Y181.520339 Z28 E21145.531175 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.813019 Y182.519123 Z28 E21149.684756 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.737024 Y183.517069 Z28 E21153.845746 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.614299 Y184.514273 Z28 E21158.022916 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.467152 Y185.511089 Z28 E21162.212106 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.315029 Y186.507826 Z28 E21166.404042 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.177103 Y187.504789 Z28 E21170.588409 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.069194 Y188.502228 Z28 E21174.759476 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.001794 Y189.50031 Z28 E21178.918471 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.977983 Y190.499085 Z28 E21183.072072 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X221.996619 Y191.498533 Z28 E21187.228018 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.047572 Y192.498495 Z28 E21191.390769 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.122597 Y193.52851 Z28 E21195.684421 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X222.646358 Y194.255634 Z28 E21199.410064 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X223.564824 Y194.669464 Z28 E21203.598302 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X224.470096 Y195.09718 Z28 E21207.760928 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X225.362565 Y195.547908 Z28 E21211.917732 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X226.239923 Y196.025797 Z28 E21216.071369 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X227.104767 Y196.526178 Z28 E21220.225425 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X227.960242 Y197.043397 Z28 E21224.381599 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X228.80915 Y197.572421 Z28 E21228.540177 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X229.65691 Y198.103507 Z28 E21232.699252 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X230.507711 Y198.629128 Z28 E21236.85706 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X231.364685 Y199.143655 Z28 E21241.012791 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X232.229413 Y199.644242 Z28 E21245.166864 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X233.101977 Y200.130747 Z28 E21249.320335 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X233.980311 Y200.606881 Z28 E21253.474055 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X234.86214 Y201.076735 Z28 E21257.628211 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X235.744526 Y201.545586 Z28 E21261.782456 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X236.624455 Y202.018853 Z28 E21265.936348 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
G1 X237.5 Y202.5 Z28 E21270.089875 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00002-zblend-wall-layer-002 note=weave level rim
; CLAYLINE_STROKE_END page=0 layer=2 id=weave-00002-zblend-wall-layer-002
; CLAYLINE_BODY_END
; CLAYLINE_PROFILE_END_BEGIN
M83 ;Set to Relative Extrusion Mode
G91 ;Set to Relative Positioning
G1 Z150 E-100 F40000 ;Move Z Axis up and relieve Extruder pressure (v1.3.0: was E-3000, which left the next job dry)
G90 ;Set to Absolute Positioning
G28 Z ;Home Z
G1 X207.5 Y0 F500 ;Move X and Y slow to home position
M82 ;absolute extrusion mode
; CLAYLINE_PROFILE_END_END
