; CLAYLINE_HEADER_BEGIN
; clayline_version=0.13.4
; generated_utc=2026-11-11T17:39:46.862379+00:00
; job_id=weave-slice-34d898a025d440304cea
; prepared_trace_sha256=dc727d55d14a5401cfb59c53f40cec2b596337fbf00f015c314b0340776a14d7
; body_sha256=ef0119b3f06a9777cfb8c62639075f7e561a5145dced3487f0e1c62d76b61538
; profile_name=potterbot-xl
; profile_version=1.4.0
; profile_verified=true
; profile_flavor=marlin
; extrusion_mode=absolute
; bead_width_mm=5
; layer_height_mm=2
; flow_multiplier=1
; wet_density_g_cm3=1.8
; prime_mm=15
; end_early_mm=5
; first_layer_z_mm=2
; speed_default_mm_s=40
; speed_first_layer_mm_s=30
; speed_travel_mm_s=40
; virtual_filament_diameter_mm=1.75
; work_bounds=17,398,12,393,0,710
; machine_envelope=0,490,0,490,0,710
; stats.motion_count=4863
; stats.print_motion_count=4858
; stats.travel_motion_count=5
; stats.stroke_count=2
; stats.page_count=1
; stats.print_path_mm=3007.547386
; stats.deposited_path_mm=2997.547386
; stats.travel_path_mm=35.366367
; stats.total_motion_path_mm=3042.913753
; stats.motion_time_seconds=78.029706
; stats.pause_time_seconds=0
; stats.pressure_time_seconds=0
; stats.estimated_print_time_seconds=78.029706
; stats.body_volume_mm3=30047.797294
; stats.wet_weight_g=54.086035
; stats.body_e=12492.422448
; stats.pressure_e_excluded=0
; stats.warning_count=0
; nominal_label=Weave mesh — bowl.obj
; parameter.bottom_layers=2
; parameter.first_layer_flow_factor=1.1
; parameter.first_layer_height_mm=2.0
; parameter.layer_count=18
; parameter.layer_range_from=1
; parameter.layer_range_semantics=one_based_inclusive
; parameter.layer_range_to=16
; parameter.layer_range_total=16
; parameter.level_rim=true
; parameter.mode=weave
; parameter.pattern_part_0001={"extrusion":[{"u":0.0,"value":1.0},{"u":0.5,"value":1.0}],"interpolation":"monotone_cubic_periodic","name":"flat","schema":"cla
; parameter.pattern_part_0002=yline.weave-pattern","seed":null,"settings":{"amplitude":0.0,"bottom_layers":2,"extrusion_phase_offset":0.0,"level_rim":true,"ov
; parameter.pattern_part_0003=erlap_fraction":0.2,"pinned_seam_angle":0.0,"seam":"chained","twist":0.0,"wavelength":18.0,"z_blend":true},"version":1,"wave":[{
; parameter.pattern_part_0004="u":0.0,"value":0.0},{"u":0.5,"value":0.0}]}
; parameter.pattern_part_count=4
; parameter.print_range=printing layers 1–16 of 16, rebased to the bed
; parameter.range_rebased_to_bed=true
; parameter.reproducible=false
; parameter.restore_capsule_v1_b64_part_0001=eyJlbWlzc2lvbiI6eyJlbmRfZWFybHlfbW1faGV4IjoiMHgxLjQwMDAwMDAwMDAwMDBwKzIiLCJmbG93X211bHRpcGxpZXJfaGV4IjoiMHgxLjAwMDAwMDAwMDAwMDBw
; parameter.restore_capsule_v1_b64_part_0002=KzAiLCJwcmltZV9tbV9oZXgiOiIweDEuZTAwMDAwMDAwMDAwMHArMyIsInJlcHJvZHVjaWJsZSI6ZmFsc2UsIndldF9kZW5zaXR5X2dfY20zX2hleCI6IjB4MS5jY2Nj
; parameter.restore_capsule_v1_b64_part_0003=Y2NjY2NjY2NkcCswIn0sImpvYl9pZCI6eyJlbmNvZGluZyI6InV0Zi04L2Jhc2U2NCIsInByZXNlbnQiOnRydWUsInV0ZjhfYjY0IjoiZDJWaGRtVXRjMnhwWTJVdE16
; parameter.restore_capsule_v1_b64_part_0004=UmtPRGs0WVRBeU5XUTBOREF6TURSalpXRT0ifSwicGF0dGVybl9qc29uX3V0ZjhfYjY0IjoiZXlKbGVIUnlkWE5wYjI0aU9sdDdJblVpT2pBdU1Dd2lkbUZzZFdVaU9q
; parameter.restore_capsule_v1_b64_part_0005=RXVNSDBzZXlKMUlqb3dMalVzSW5aaGJIVmxJam94TGpCOVhTd2lhVzUwWlhKd2IyeGhkR2x2YmlJNkltMXZibTkwYjI1bFgyTjFZbWxqWDNCbGNtbHZaR2xqSWl3aWJt
; parameter.restore_capsule_v1_b64_part_0006=RnRaU0k2SW1ac1lYUWlMQ0p6WTJobGJXRWlPaUpqYkdGNWJHbHVaUzUzWldGMlpTMXdZWFIwWlhKdUlpd2ljMlZsWkNJNmJuVnNiQ3dpYzJWMGRHbHVaM01pT25zaVlX
; parameter.restore_capsule_v1_b64_part_0007=MXdiR2wwZFdSbElqb3dMakFzSW1KdmRIUnZiVjlzWVhsbGNuTWlPaklzSW1WNGRISjFjMmx2Ymw5d2FHRnpaVjl2Wm1aelpYUWlPakF1TUN3aWJHVjJaV3hmY21sdElq
; parameter.restore_capsule_v1_b64_part_0008=cDBjblZsTENKdmRtVnliR0Z3WDJaeVlXTjBhVzl1SWpvd0xqSXNJbkJwYm01bFpGOXpaV0Z0WDJGdVoyeGxJam93TGpBc0luTmxZVzBpT2lKamFHRnBibVZrSWl3aWRI
; parameter.restore_capsule_v1_b64_part_0009=ZHBjM1FpT2pBdU1Dd2lkMkYyWld4bGJtZDBhQ0k2TVRndU1Dd2llbDlpYkdWdVpDSTZkSEoxWlgwc0luWmxjbk5wYjI0aU9qRXNJbmRoZG1VaU9sdDdJblVpT2pBdU1D
; parameter.restore_capsule_v1_b64_part_0010=d2lkbUZzZFdVaU9qQXVNSDBzZXlKMUlqb3dMalVzSW5aaGJIVmxJam93TGpCOVhYMD0iLCJwcm9maWxlIjp7ImNlbnRlciI6eyJ4IjoiMHgxLjlmMDAwMDAwMDAwMDBw
; parameter.restore_capsule_v1_b64_part_0011=KzciLCJ5IjoiMHgxLjk1MDAwMDAwMDAwMDBwKzcifSwiZGVmYXVsdF9ub3p6bGVfZGlhbWV0ZXJfaGV4IjoiMHgxLjQwMDAwMDAwMDAwMDBwKzIiLCJkZXNjcmlwdGlv
; parameter.restore_capsule_v1_b64_part_0012=biI6IlZlcmlmaWVkIGZyb20gUGV0ZSdzIHN1Y2Nlc3NmdWwgSmFudWFyeSAyMDI2IFBvdHRlckJvdCAxMCBYTCBwcmludC4gMTAgbW0gbm96emxlIGFkZGVkIHBlciBQ
; parameter.restore_capsule_v1_b64_part_0013=ZXRlIDIwMjYtMDctMTUuIHYxLjIuMDogdHJhdmVsIHNwZWVkIGNvcnJlY3RlZCB0byBwcmludCBzcGVlZCBcdTIwMTQgdGhlIHJlZmVyZW5jZSBDdXJhIHByb2ZpbGUg
; parameter.restore_capsule_v1_b64_part_0014=b25seSB1c2VkIDEyMCBvdXRzaWRlIHNwaXJhbGl6ZSBtb2RlIGFuZCB0aGUgZmlyc3QgY2xheSBwcmludCAoMjAyNi0wNy0xNykgc2hvd2VkIGZhc3QgdHJhdmVscyB0
; parameter.restore_capsule_v1_b64_part_0015=ZWFyIHRoZSB0aHJlYWQuIHYxLjMuMDogZW5kLW9mLWpvYiBkZXByZXNzdXJpemUgYW5kIG1hdGNoaW5nIHN0YXJ0IHByaW1lIHJlZHVjZWQgMzAwMC0+MTAwIFx1MjAx
; parameter.restore_capsule_v1_b64_part_0016=NCB0aGUgQ3VyYS1pbmhlcml0ZWQgZnVsbCBkZXByZXNzdXJpemUgbGVmdCBiYWNrLXRvLWJhY2sgam9icyBwcmludGluZyBkcnkgZm9yIDMwLTQwcyAoUGV0ZSwgMjAy
; parameter.restore_capsule_v1_b64_part_0017=Ni0wOC0wMikuIHYxLjQuMDogdGhlIHN0YXJ0IHByaW1lIGdvZXMgYmFjayB0byB0aGUgcmVmZXJlbmNlIDMwMDAgXHUyMDE0IGN1dHRpbmcgaXQgdG9vIHdhcyB1bnN1
; parameter.restore_capsule_v1_b64_part_0018=cHBvcnRlZC4gUGV0ZSdzIG93biBkaWFnbm9zdGljIHdhcyB0aGF0IGNhbmNlbGxpbmcgYW5kIHJlcHJpbnRpbmcgZml4ZWQgdGhlIGRyeSBzdGFydCwgYW5kIGEgY2Fu
; parameter.restore_capsule_v1_b64_part_0019=Y2VsIHNraXBzIHRoZSBmb290ZXIsIHNvIHRoZSB3b3JraW5nIGNhc2Ugd2FzIG5vIHJlbGllZiBwbHVzIGEgZnVsbCAzMDAwIGNoYXJnZTsgRTEwMCBpcyAwLjI0IGNj
; parameter.restore_capsule_v1_b64_part_0020=IGludG8gYSBiYXJyZWwgdGhlIHJlZmVyZW5jZSBjaGFyZ2VzIHdpdGggNy4yIGNjLCBzbyBqb2JzIGJlZ2FuIHdpdGggbm90aGluZyBhdCB0aGUgbm96emxlIChQZXRl
; parameter.restore_capsule_v1_b64_part_0021=LCAyMDI2LTA4LTE1KS4gVGhlIGVuZCByZWxpZWYgc3RheXMgYXQgMTAwOiBlbm91Z2ggdG8gc3RvcCBvb3plIGR1cmluZyB0aGUgaG9taW5nIG1vdmVzIHdpdGhvdXQg
; parameter.restore_capsule_v1_b64_part_0022=ZW1wdHlpbmcgdGhlIGJhcnJlbC4iLCJlbWlzc2lvbl9kZWZhdWx0cyI6eyJlbmRfZWFybHlfbW1faGV4IjoiMHgxLjQwMDAwMDAwMDAwMDBwKzIiLCJwcmltZV9tbV9o
; parameter.restore_capsule_v1_b64_part_0023=ZXgiOiIweDEuZTAwMDAwMDAwMDAwMHArMyJ9LCJlbmRfZ2NvZGUiOlsiTTgzIDtTZXQgdG8gUmVsYXRpdmUgRXh0cnVzaW9uIE1vZGUiLCJHOTEgO1NldCB0byBSZWxh
; parameter.restore_capsule_v1_b64_part_0024=dGl2ZSBQb3NpdGlvbmluZyIsIkcxIFoxNTAgRS0xMDAgRjQwMDAwIDtNb3ZlIFogQXhpcyB1cCBhbmQgcmVsaWV2ZSBFeHRydWRlciBwcmVzc3VyZSAodjEuMy4wOiB3
; parameter.restore_capsule_v1_b64_part_0025=YXMgRS0zMDAwLCB3aGljaCBsZWZ0IHRoZSBuZXh0IGpvYiBkcnkpIiwiRzkwIDtTZXQgdG8gQWJzb2x1dGUgUG9zaXRpb25pbmciLCJHMjggWiA7SG9tZSBaIiwiRzEg
; parameter.restore_capsule_v1_b64_part_0026=WDIwNy41IFkwIEY1MDAgO01vdmUgWCBhbmQgWSBzbG93IHRvIGhvbWUgcG9zaXRpb24iLCJNODIgO2Fic29sdXRlIGV4dHJ1c2lvbiBtb2RlIl0sImV4dHJ1c2lvbl9t
; parameter.restore_capsule_v1_b64_part_0027=b2RlIjoiYWJzb2x1dGUiLCJmbGF2b3IiOiJtYXJsaW4iLCJnY29kZV93aGl0ZWxpc3QiOlsiRzAiLCJHMSIsIkc0IiwiRzIxIiwiRzI4IiwiRzkwIiwiRzkxIiwiRzky
; parameter.restore_capsule_v1_b64_part_0028=IiwiTTgyIiwiTTgzIiwiTTEwNSIsIk0xMDciLCJNMTA5Il0sIm1hY2hpbmVfZW52ZWxvcGUiOnsibWF4X3giOiIweDEuZWEwMDAwMDAwMDAwMHArOCIsIm1heF95Ijoi
; parameter.restore_capsule_v1_b64_part_0029=MHgxLmVhMDAwMDAwMDAwMDBwKzgiLCJtYXhfeiI6IjB4MS42MzAwMDAwMDAwMDAwcCs5IiwibWluX3giOiIweDAuMHArMCIsIm1pbl95IjoiMHgwLjBwKzAiLCJtaW5f
; parameter.restore_capsule_v1_b64_part_0030=eiI6IjB4MC4wcCswIn0sIm5hbWUiOiJwb3R0ZXJib3QteGwiLCJub3p6bGVfZGlhbWV0ZXJzX2hleCI6WyIweDEuYzAwMDAwMDAwMDAwMHArMSIsIjB4MS4wODUxZWI4
; parameter.restore_capsule_v1_b64_part_0031=NTFlYjg1cCsyIiwiMHgxLjQwMDAwMDAwMDAwMDBwKzIiLCIweDEuOTk5OTk5OTk5OTk5YXArMiIsIjB4MS40MDAwMDAwMDAwMDAwcCszIl0sInNwZWVkX2RlZmF1bHRf
; parameter.restore_capsule_v1_b64_part_0032=aGV4IjoiMHgxLjQwMDAwMDAwMDAwMDBwKzUiLCJzcGVlZF9maXJzdF9sYXllcl9oZXgiOiIweDEuZTAwMDAwMDAwMDAwMHArNCIsInNwZWVkX3RyYXZlbF9oZXgiOiIw
; parameter.restore_capsule_v1_b64_part_0033=eDEuNDAwMDAwMDAwMDAwMHArNSIsInN0YXJ0X2djb2RlIjpbIk0xMDUiLCJNMTA5IFMwIiwiTTgyIDthYnNvbHV0ZSBleHRydXNpb24gbW9kZSIsIkcyOCA7SG9tZSIs
; parameter.restore_capsule_v1_b64_part_0034=IkcxIFgyMDcuNSBZMjAyLjUgWjIwIEYxMDAwMCA7TW92ZSBYIGFuZCBZIHRvIGNlbnRlciwgWiB0byAyMG1tIGhpZ2giLCJHOTIgRTAiLCJHMSBFMzAwMCBGNDAwMDAg
; parameter.restore_capsule_v1_b64_part_0035=OyBQcmltZSBFeHRydWRlciAodjEuNC4wOiBiYWNrIHRvIHRoZSByZWZlcmVuY2UgY2hhcmdlOyBFMTAwIHN0YXJ0ZWQgZXZlcnkgam9iIGRyeSkiLCJHOTIgRTAiLCJH
; parameter.restore_capsule_v1_b64_part_0036=OTIgRTAiLCJHOTIgRTAiLCJNMTA3Il0sInRyYXZlbF9wb2xpY3kiOnsiZHdlbGxfc2Vjb25kc19oZXgiOiIweDAuMHArMCIsImxpZnRfaGV4IjoiMHgxLjAwMDAwMDAw
; parameter.restore_capsule_v1_b64_part_0037=MDAwMDBwKzEiLCJwYWdlX3BhdXNlX2NvbW1hbmQiOiJHNCBTe3NlY29uZHN9IiwicmVwcmltZV9lX2hleCI6IjB4MC4wcCswIn0sInZlcmlmaWNhdGlvbl9zb3VyY2Ui
; parameter.restore_capsule_v1_b64_part_0038=OiJkb2NzL3JlZmVyZW5jZS9wb3R0ZXJib3QtMTB4bC1yZWZlcmVuY2UtaGVhZGVyLWZvb3Rlci5nY29kZSIsInZlcmlmaWVkIjp0cnVlLCJ2ZXJzaW9uIjoiMS40LjAi
; parameter.restore_capsule_v1_b64_part_0039=LCJ2aXJ0dWFsX2ZpbGFtZW50X2RpYW1ldGVyX2hleCI6IjB4MS5jMDAwMDAwMDAwMDAwcCswIiwid29ya19ib3VuZHMiOnsibWF4X3giOiIweDEuOGUwMDAwMDAwMDAw
; parameter.restore_capsule_v1_b64_part_0040=MHArOCIsIm1heF95IjoiMHgxLjg5MDAwMDAwMDAwMDBwKzgiLCJtYXhfeiI6IjB4MS42MzAwMDAwMDAwMDAwcCs5IiwibWluX3giOiIweDEuMTAwMDAwMDAwMDAwMHAr
; parameter.restore_capsule_v1_b64_part_0041=NCIsIm1pbl95IjoiMHgxLjgwMDAwMDAwMDAwMDBwKzMiLCJtaW5feiI6IjB4MC4wcCswIn19LCJzY2hlbWEiOiJjbGF5bGluZS53ZWF2ZS1yZXN0b3JlIiwic2xpY2Ui
; parameter.restore_capsule_v1_b64_part_0042=OnsiYmVhZF93aWR0aF9tbV9oZXgiOiIweDEuNDAwMDAwMDAwMDAwMHArMiIsImZpcnN0X2xheWVyX2hlaWdodF9tbV9oZXgiOiIweDEuMDAwMDAwMDAwMDAwMHArMSIs
; parameter.restore_capsule_v1_b64_part_0043=ImxheWVyX2hlaWdodF9tbV9oZXgiOiIweDEuMDAwMDAwMDAwMDAwMHArMSIsInJhbmdlX2Zyb20iOjEsInJhbmdlX3RvIjoxNiwic2FtcGxlX3NwYWNpbmdfbW1faGV4
; parameter.restore_capsule_v1_b64_part_0044=IjoiMHgxLjAwMDAwMDAwMDAwMDBwKzAiLCJ0b3BfbGF5ZXIiOiJuZWFyZXN0In0sInNvdXJjZSI6eyJsYXllcl90b3RhbCI6MTYsIm1lc2hfbmFtZSI6ImJvd2wub2Jq
; parameter.restore_capsule_v1_b64_part_0045=IiwibWVzaF9zaGEyNTYiOiJhNjkwMTc3ZWUxMTEwMTk2ZTZiZTM2NzM2ZmVhYzUxOGFjNTA1ZWI3ZjQ4OTg1NTM3OTZiNTQwNzJiMjUwN2I3Iiwib2Zmc2V0X3hfbW1f
; parameter.restore_capsule_v1_b64_part_0046=aGV4IjoiMHgwLjBwKzAiLCJvZmZzZXRfeV9tbV9oZXgiOiIweDAuMHArMCIsInNjYWxlX2hleCI6IjB4MS4wMDAwMDAwMDAwMDAwcCswIiwidXBfYXhpcyI6InoifSwi
; parameter.restore_capsule_v1_b64_part_0047=dmVyc2lvbiI6MX0=
; parameter.restore_capsule_v1_b64_part_count=47
; parameter.sample_spacing_mm=1.0
; parameter.seam=chained
; parameter.source_mesh=bowl.obj
; parameter.source_mesh_sha256=a690177ee1110196e6be36736feac518ac505eb7f4898553796b54072b2507b7
; parameter.source_offset_x_mm=0.0
; parameter.source_offset_y_mm=0.0
; parameter.source_scale=1.0
; parameter.source_up_axis=z
; parameter.z_blend=true
; pressure_management=profile and marked pressure blocks excluded from body volume
; thermal_policy=no heater or fan commands outside verbatim profile blocks
; CLAYLINE_HEADER_END
; CLAYLINE_PROFILE_START_BEGIN
M105
M109 S0
M82 ;absolute extrusion mode
G28 ;Home
G1 X207.5 Y202.5 Z20 F10000 ;Move X and Y to center, Z to 20mm high
G92 E0
G1 E3000 F40000 ; Prime Extruder (v1.4.0: back to the reference charge; E100 started every job dry)
G92 E0
G92 E0
G92 E0
M107
; CLAYLINE_PROFILE_START_END
; CLAYLINE_BODY_BEGIN
G21 ; clayline units: millimeters
G90 ; clayline absolute XYZ
M82 ; clayline absolute extrusion
G92 E0 ; clayline body extrusion origin
; CLAYLINE_PAGE index=0
; CLAYLINE_STROKE_BEGIN page=0 layer=0 id=weave-00000-zblend-wall-layer-000
G0 X218.332999 Y202.5 Z20 F2400 ; clayline kind=travel_xy page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=stroke start XY at safe Z
G0 X218.332999 Y202.5 Z2 F2400 ; clayline kind=travel_approach page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=stroke start vertical approach
G1 X218.327856 Y202.814284 Z2 E0.015061 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.313398 Y203.13295 Z2 E0.061144 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.289716 Y203.451048 Z2 E0.138246 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.256828 Y203.768316 Z2 E0.246365 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.226663 Y203.995052 Z2 E0.342995 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X218.214764 Y204.084494 Z2 E0.385501 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.163557 Y204.399322 Z2 E0.555656 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.10325 Y204.712539 Z2 E0.756833 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.033892 Y205.023889 Z2 E0.989039 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.955852 Y205.331876 Z2 E1.251165 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.918746 Y205.461814 Z2 E1.371981 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X217.869541 Y205.63412 Z2 E1.540776 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.773306 Y205.934688 Z2 E1.861865 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.667276 Y206.235539 Z2 E2.217261 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.55258 Y206.53318 Z2 E2.603664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.429312 Y206.827365 Z2 E3.021076 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.409373 Y206.871332 Z2 E3.086956 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X217.297575 Y207.117852 Z2 E3.469502 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.157476 Y207.404403 Z2 E3.94895 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.009131 Y207.686782 Z2 E4.459428 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.852661 Y207.964755 Z2 E5.000949 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.712227 Y208.198152 Z2 E5.487922 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X216.689512 Y208.235903 Z2 E5.568813 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.519182 Y208.500078 Z2 E6.163096 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.339383 Y208.760999 Z2 E6.792681 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.150852 Y209.018307 Z2 E7.457383 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.954953 Y209.270035 Z2 E8.153081 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.836014 Y209.41406 Z2 E8.574879 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X215.751848 Y209.515976 Z2 E8.879783 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.541705 Y209.755929 Z2 E9.637499 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.324695 Y209.989696 Z2 E10.426243 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.100998 Y210.217084 Z2 E11.246028 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.870797 Y210.437905 Z2 E12.096873 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.802642 Y210.499592 Z2 E12.347825 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X214.637124 Y210.649404 Z2 E12.968009 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.397441 Y210.85276 Z2 E13.866964 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.148851 Y211.051301 Z2 E14.807513 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.893945 Y211.24306 Z2 E15.781514 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.633599 Y211.427347 Z2 E16.786503 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.628328 Y211.430853 Z2 E16.806762 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X213.368027 Y211.604011 Z2 E17.822494 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.09745 Y211.772907 Z2 E18.889502 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.822089 Y211.933896 Z2 E19.987546 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.54217 Y212.086845 Z2 E21.116646 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.33682 Y212.191441 Z2 E21.951689 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X212.258303 Y212.231434 Z2 E22.275254 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.974156 Y212.365825 Z2 E23.448759 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.685417 Y212.491115 Z2 E24.654031 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.389231 Y212.609562 Z2 E25.906361 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.089752 Y212.719374 Z2 E27.189656 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.952379 Y212.765275 Z2 E27.782607 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X210.787225 Y212.82046 Z2 E28.503933 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.481901 Y212.912738 Z2 E29.849212 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.174031 Y212.996132 Z2 E31.225515 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.863868 Y213.070573 Z2 E32.632865 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.551667 Y213.136 Z2 E34.071288 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.502465 Y213.144831 Z2 E34.299514 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=prime ramp
G1 X209.239362 Y213.192056 Z2 E35.521984 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.928438 Y213.238178 Z2 E36.959483 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.614536 Y213.274723 Z2 E38.40474 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.296753 Y213.302416 Z2 E39.863554 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.978314 Y213.32089 Z2 E41.322308 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.659482 Y213.330131 Z2 E42.781026 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.340518 Y213.330131 Z2 E44.239732 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.021686 Y213.32089 Z2 E45.698451 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.703247 Y213.302416 Z2 E47.157205 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.385464 Y213.274723 Z2 E48.616019 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.071562 Y213.238178 Z2 E50.061276 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.760638 Y213.192056 Z2 E51.498774 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.448333 Y213.136 Z2 E52.949852 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.136132 Y213.070573 Z2 E54.408647 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.825969 Y212.996132 Z2 E55.867389 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.518099 Y212.912738 Z2 E57.326102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.212775 Y212.82046 Z2 E58.784809 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.910248 Y212.719374 Z2 E60.243534 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.610769 Y212.609562 Z2 E61.702302 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.314583 Y212.491115 Z2 E63.161137 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.025844 Y212.365825 Z2 E64.600575 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.741697 Y212.231434 Z2 E66.038074 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.45783 Y212.086845 Z2 E67.494974 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.177911 Y211.933896 Z2 E68.953752 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.90255 Y211.772907 Z2 E70.412484 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.631973 Y211.604011 Z2 E71.871193 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.366401 Y211.427347 Z2 E73.329902 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.106055 Y211.24306 Z2 E74.788637 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.851149 Y211.051301 Z2 E76.247421 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.602559 Y210.85276 Z2 E77.70238 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.362876 Y210.649404 Z2 E79.139879 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.129203 Y210.437905 Z2 E80.581256 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.899002 Y210.217084 Z2 E82.040084 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.675305 Y209.989696 Z2 E83.498847 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.458295 Y209.755929 Z2 E84.95757 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.248152 Y209.515976 Z2 E86.416277 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.045047 Y209.270035 Z2 E87.874991 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.849148 Y209.018307 Z2 E89.333737 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.660617 Y208.760999 Z2 E90.792538 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.480818 Y208.500078 Z2 E92.241675 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.310488 Y208.235903 Z2 E93.679174 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.147339 Y207.964755 Z2 E95.126371 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.990869 Y207.686782 Z2 E96.585178 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.842524 Y207.404403 Z2 E98.043928 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.702425 Y207.117852 Z2 E99.502644 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.570688 Y206.827365 Z2 E100.96135 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.44742 Y206.53318 Z2 E102.420071 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.332724 Y206.235539 Z2 E103.87883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.226694 Y205.934688 Z2 E105.33765 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.130459 Y205.63412 Z2 E106.780967 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.044148 Y205.331876 Z2 E108.218466 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.966108 Y205.023889 Z2 E109.671484 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.89675 Y204.712539 Z2 E111.130274 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.836443 Y204.399322 Z2 E112.589012 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.785236 Y204.084494 Z2 E114.047723 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.743172 Y203.768316 Z2 E115.506431 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.710284 Y203.451048 Z2 E116.965159 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.686602 Y203.13295 Z2 E118.423932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.672144 Y202.814284 Z2 E119.882774 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.667001 Y202.5 Z2 E121.320273 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.672144 Y202.185716 Z2 E122.757772 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.686602 Y201.86705 Z2 E124.216613 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.710284 Y201.548952 Z2 E125.675387 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.743172 Y201.231684 Z2 E127.134115 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.785236 Y200.915506 Z2 E128.592823 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.836443 Y200.600678 Z2 E130.051534 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.89675 Y200.287461 Z2 E131.510272 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X196.966108 Y199.976111 Z2 E132.969062 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.044148 Y199.668124 Z2 E134.42208 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.130459 Y199.36588 Z2 E135.859579 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.226694 Y199.065312 Z2 E137.302896 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.332724 Y198.764461 Z2 E138.761716 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.44742 Y198.46682 Z2 E140.220475 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.570688 Y198.172635 Z2 E141.679195 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.702425 Y197.882148 Z2 E143.137902 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.842524 Y197.595597 Z2 E144.596618 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X197.990869 Y197.313218 Z2 E146.055368 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.147339 Y197.035245 Z2 E147.514175 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.310488 Y196.764097 Z2 E148.961372 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.480818 Y196.499922 Z2 E150.398871 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.660617 Y196.239001 Z2 E151.848008 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X198.849148 Y195.981693 Z2 E153.306809 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.045047 Y195.729965 Z2 E154.765555 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.248152 Y195.484024 Z2 E156.224269 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.458295 Y195.244071 Z2 E157.682976 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.675305 Y195.010304 Z2 E159.141699 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X199.899002 Y194.782916 Z2 E160.600462 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.129203 Y194.562095 Z2 E162.059289 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.362876 Y194.350596 Z2 E163.500667 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.602559 Y194.14724 Z2 E164.938166 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.851149 Y193.948699 Z2 E166.393125 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.106055 Y193.75694 Z2 E167.851909 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.366401 Y193.572653 Z2 E169.310643 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.631973 Y193.395989 Z2 E170.769353 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.90255 Y193.227093 Z2 E172.228062 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.177911 Y193.066104 Z2 E173.686793 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.45783 Y192.913155 Z2 E175.145572 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.741697 Y192.768566 Z2 E176.602472 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.025844 Y192.634175 Z2 E178.039971 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.314583 Y192.508885 Z2 E179.479409 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.610769 Y192.390438 Z2 E180.938243 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.910248 Y192.280626 Z2 E182.397012 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.212775 Y192.17954 Z2 E183.855737 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.518099 Y192.087262 Z2 E185.314444 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.825969 Y192.003868 Z2 E186.773157 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.136132 Y191.929427 Z2 E188.231899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.448333 Y191.864 Z2 E189.690694 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.760638 Y191.807944 Z2 E191.141772 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.071562 Y191.761822 Z2 E192.57927 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.385464 Y191.725277 Z2 E194.024527 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.703247 Y191.697584 Z2 E195.483341 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.021686 Y191.67911 Z2 E196.942095 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.340518 Y191.669869 Z2 E198.400813 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.659482 Y191.669869 Z2 E199.85952 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.978314 Y191.67911 Z2 E201.318238 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.296753 Y191.697584 Z2 E202.776992 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.614536 Y191.725277 Z2 E204.235806 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.928438 Y191.761822 Z2 E205.681063 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.239362 Y191.807944 Z2 E207.118561 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.551667 Y191.864 Z2 E208.569639 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.863868 Y191.929427 Z2 E210.028434 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.174031 Y192.003868 Z2 E211.487176 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.481901 Y192.087262 Z2 E212.945889 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.787225 Y192.17954 Z2 E214.404596 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.089752 Y192.280626 Z2 E215.863321 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.389231 Y192.390438 Z2 E217.32209 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.685417 Y192.508885 Z2 E218.780924 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.974156 Y192.634175 Z2 E220.220362 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.258303 Y192.768566 Z2 E221.657861 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.54217 Y192.913155 Z2 E223.114761 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.822089 Y193.066104 Z2 E224.57354 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.09745 Y193.227093 Z2 E226.032271 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.368027 Y193.395989 Z2 E227.49098 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.633599 Y193.572653 Z2 E228.94969 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.893945 Y193.75694 Z2 E230.408424 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.148851 Y193.948699 Z2 E231.867208 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.397441 Y194.14724 Z2 E233.322167 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.637124 Y194.350596 Z2 E234.759666 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.870797 Y194.562095 Z2 E236.201044 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.100998 Y194.782916 Z2 E237.659871 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.324695 Y195.010304 Z2 E239.118634 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.541705 Y195.244071 Z2 E240.577357 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.751848 Y195.484024 Z2 E242.036064 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X215.954953 Y195.729965 Z2 E243.494778 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.150852 Y195.981693 Z2 E244.953524 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.339383 Y196.239001 Z2 E246.412325 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.519182 Y196.499922 Z2 E247.861462 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.689512 Y196.764097 Z2 E249.298961 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X216.852661 Y197.035245 Z2 E250.746158 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.009131 Y197.313218 Z2 E252.204965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.157476 Y197.595597 Z2 E253.663715 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.297575 Y197.882148 Z2 E255.122431 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.429312 Y198.172635 Z2 E256.581138 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.55258 Y198.46682 Z2 E258.039858 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.667276 Y198.764461 Z2 E259.498617 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.773306 Y199.065312 Z2 E260.957437 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.869541 Y199.36588 Z2 E262.400754 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X217.955852 Y199.668124 Z2 E263.838253 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.033892 Y199.976111 Z2 E265.291271 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.10325 Y200.287461 Z2 E266.750061 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.163557 Y200.600678 Z2 E268.208799 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.214764 Y200.915506 Z2 E269.66751 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.256828 Y201.231684 Z2 E271.126218 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.289716 Y201.548952 Z2 E272.584946 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.313398 Y201.86705 Z2 E274.04372 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.327856 Y202.185716 Z2 E275.502561 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X218.332999 Y202.5 Z2 E276.94006 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.332463 Y202.5 Z2 E295.235583 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.329339 Y202.69089 Z2 E296.10869 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.320135 Y202.893764 Z2 E297.037445 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.305058 Y203.096273 Z2 E297.966136 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.284122 Y203.298252 Z2 E298.894786 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.257343 Y203.499534 Z2 E299.823417 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.224744 Y203.699957 Z2 E300.752051 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.186352 Y203.899357 Z2 E301.68071 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.142196 Y204.097572 Z2 E302.609416 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.093129 Y204.291216 Z2 E303.522991 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.040706 Y204.474793 Z2 E304.396097 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.981478 Y204.659776 Z2 E305.284378 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.913976 Y204.851308 Z2 E306.213113 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.840958 Y205.040792 Z2 E307.141791 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.762484 Y205.228075 Z2 E308.070433 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.678618 Y205.413002 Z2 E308.999063 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.58943 Y205.595425 Z2 E309.927702 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.49499 Y205.775192 Z2 E310.856371 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.395376 Y205.952159 Z2 E311.785094 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.294096 Y206.120484 Z2 E312.683492 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.190641 Y206.280938 Z2 E313.556598 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.078547 Y206.443608 Z2 E314.460055 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.958522 Y206.607418 Z2 E315.388772 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.833809 Y206.767672 Z2 E316.317438 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.70451 Y206.924242 Z2 E317.246075 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.57073 Y207.076999 Z2 E318.174705 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.432578 Y207.225818 Z2 E319.10335 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.290167 Y207.370579 Z2 E320.032032 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.143613 Y207.511162 Z2 E320.960773 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.000427 Y207.64076 Z2 E321.843996 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.854849 Y207.764274 Z2 E322.717102 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.697894 Y207.889629 Z2 E323.635737 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.535613 Y208.011708 Z2 E324.564438 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.369873 Y208.129028 Z2 E325.493094 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.200807 Y208.241495 Z2 E326.421726 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.028554 Y208.349016 Z2 E327.350358 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.853254 Y208.451505 Z2 E328.279011 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.675051 Y208.548876 Z2 E329.207707 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.495075 Y208.640547 Z2 E330.131401 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.32249 Y208.722174 Z2 E331.004508 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.146338 Y208.79861 Z2 E331.882673 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.957775 Y208.874018 Z2 E332.81142 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.767119 Y208.943926 Z2 E333.740107 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.574527 Y209.008279 Z2 E334.668754 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.380154 Y209.067024 Z2 E335.597384 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.18416 Y209.120114 Z2 E336.52602 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.986704 Y209.167505 Z2 E337.454682 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.787947 Y209.209158 Z2 E338.383394 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.592414 Y209.244254 Z2 E339.291909 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.403566 Y209.272267 Z2 E340.165016 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.209537 Y209.294857 Z2 E341.058355 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.007226 Y209.312487 Z2 E341.987084 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.804501 Y209.324248 Z2 E342.915757 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.601528 Y209.330131 Z2 E343.844398 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.398472 Y209.330131 Z2 E344.773027 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.195499 Y209.324248 Z2 E345.701668 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.992774 Y209.312487 Z2 E346.630342 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.790463 Y209.294857 Z2 E347.55907 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.596434 Y209.272267 Z2 E348.45241 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.407586 Y209.244254 Z2 E349.325516 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.212053 Y209.209158 Z2 E350.234032 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.013296 Y209.167505 Z2 E351.162743 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.81584 Y209.120114 Z2 E352.091406 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.619846 Y209.067024 Z2 E353.020041 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.425473 Y209.008279 Z2 E353.948671 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.232881 Y208.943926 Z2 E354.877319 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.042225 Y208.874018 Z2 E355.806005 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.853662 Y208.79861 Z2 E356.734753 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.67751 Y208.722174 Z2 E357.612918 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.504925 Y208.640547 Z2 E358.486024 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.324949 Y208.548876 Z2 E359.409719 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.146746 Y208.451505 Z2 E360.338414 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.971446 Y208.349016 Z2 E361.267067 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.799193 Y208.241495 Z2 E362.195699 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.630127 Y208.129028 Z2 E363.124332 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.464387 Y208.011708 Z2 E364.052988 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.302106 Y207.889629 Z2 E364.981689 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.145151 Y207.764274 Z2 E365.900323 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.999573 Y207.64076 Z2 E366.77343 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.856387 Y207.511162 Z2 E367.656652 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.709833 Y207.370579 Z2 E368.585394 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.567422 Y207.225818 Z2 E369.514076 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.42927 Y207.076999 Z2 E370.442721 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.29549 Y206.924242 Z2 E371.37135 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.166191 Y206.767672 Z2 E372.299987 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.041478 Y206.607418 Z2 E373.228653 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.921453 Y206.443608 Z2 E374.15737 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.809359 Y206.280938 Z2 E375.060827 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.705904 Y206.120484 Z2 E375.933933 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.604624 Y205.952159 Z2 E376.832331 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.50501 Y205.775192 Z2 E377.761054 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.41057 Y205.595425 Z2 E378.689724 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.321382 Y205.413002 Z2 E379.618362 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.237516 Y205.228075 Z2 E380.546992 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.159042 Y205.040792 Z2 E381.475635 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.086024 Y204.851308 Z2 E382.404312 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.018522 Y204.659776 Z2 E383.333047 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.959294 Y204.474793 Z2 E384.221328 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.906871 Y204.291216 Z2 E385.094434 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.857804 Y204.097572 Z2 E386.00801 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.813648 Y203.899357 Z2 E386.936716 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.775256 Y203.699957 Z2 E387.865375 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.742657 Y203.499534 Z2 E388.794009 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.715878 Y203.298252 Z2 E389.72264 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.694942 Y203.096273 Z2 E390.65129 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.679865 Y202.893764 Z2 E391.579981 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.670661 Y202.69089 Z2 E392.508735 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.667537 Y202.5 Z2 E393.381842 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.670661 Y202.30911 Z2 E394.254949 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.679865 Y202.106236 Z2 E395.183703 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.694942 Y201.903727 Z2 E396.112394 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.715878 Y201.701748 Z2 E397.041044 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.742657 Y201.500466 Z2 E397.969675 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.775256 Y201.300043 Z2 E398.898309 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.813648 Y201.100643 Z2 E399.826968 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.857804 Y200.902428 Z2 E400.755674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.906871 Y200.708784 Z2 E401.66925 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X200.959294 Y200.525207 Z2 E402.542356 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.018522 Y200.340224 Z2 E403.430637 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.086024 Y200.148692 Z2 E404.359372 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.159042 Y199.959208 Z2 E405.288049 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.237516 Y199.771925 Z2 E406.216692 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.321382 Y199.586998 Z2 E407.145322 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.41057 Y199.404575 Z2 E408.07396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.50501 Y199.224808 Z2 E409.00263 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.604624 Y199.047841 Z2 E409.931353 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.705904 Y198.879516 Z2 E410.829751 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.809359 Y198.719062 Z2 E411.702857 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X201.921453 Y198.556392 Z2 E412.606314 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.041478 Y198.392582 Z2 E413.535031 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.166191 Y198.232328 Z2 E414.463697 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.29549 Y198.075758 Z2 E415.392334 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.42927 Y197.923001 Z2 E416.320963 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.567422 Y197.774182 Z2 E417.249608 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.709833 Y197.629421 Z2 E418.17829 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.856387 Y197.488838 Z2 E419.107032 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X202.999573 Y197.35924 Z2 E419.990254 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.145151 Y197.235726 Z2 E420.863361 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.302106 Y197.110371 Z2 E421.781995 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.464387 Y196.988292 Z2 E422.710696 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.630127 Y196.870972 Z2 E423.639352 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.799193 Y196.758505 Z2 E424.567985 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X203.971446 Y196.650984 Z2 E425.496617 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.146746 Y196.548495 Z2 E426.42527 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.324949 Y196.451124 Z2 E427.353965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.504925 Y196.359453 Z2 E428.27766 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.67751 Y196.277826 Z2 E429.150766 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.853662 Y196.20139 Z2 E430.028931 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.042225 Y196.125982 Z2 E430.957679 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.232881 Y196.056074 Z2 E431.886365 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.425473 Y195.991721 Z2 E432.815013 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.619846 Y195.932976 Z2 E433.743643 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.81584 Y195.879886 Z2 E434.672278 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.013296 Y195.832495 Z2 E435.600941 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.212053 Y195.790842 Z2 E436.529652 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.407586 Y195.755746 Z2 E437.438168 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.596434 Y195.727733 Z2 E438.311274 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.790463 Y195.705143 Z2 E439.204614 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.992774 Y195.687513 Z2 E440.133342 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.195499 Y195.675752 Z2 E441.062016 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.398472 Y195.669869 Z2 E441.990657 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.601528 Y195.669869 Z2 E442.919286 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.804501 Y195.675752 Z2 E443.847927 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.007226 Y195.687513 Z2 E444.7766 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.209537 Y195.705143 Z2 E445.705329 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.403566 Y195.727733 Z2 E446.598668 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.592414 Y195.755746 Z2 E447.471775 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.787947 Y195.790842 Z2 E448.38029 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.986704 Y195.832495 Z2 E449.309002 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.18416 Y195.879886 Z2 E450.237664 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.380154 Y195.932976 Z2 E451.1663 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.574527 Y195.991721 Z2 E452.09493 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.767119 Y196.056074 Z2 E453.023577 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.957775 Y196.125982 Z2 E453.952264 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.146338 Y196.20139 Z2 E454.881011 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.32249 Y196.277826 Z2 E455.759176 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.495075 Y196.359453 Z2 E456.632283 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.675051 Y196.451124 Z2 E457.555977 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.853254 Y196.548495 Z2 E458.484673 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.028554 Y196.650984 Z2 E459.413326 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.200807 Y196.758505 Z2 E460.341958 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.369873 Y196.870972 Z2 E461.27059 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.535613 Y196.988292 Z2 E462.199246 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.697894 Y197.110371 Z2 E463.127947 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X211.854849 Y197.235726 Z2 E464.046582 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.000427 Y197.35924 Z2 E464.919688 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.143613 Y197.488838 Z2 E465.802911 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.290167 Y197.629421 Z2 E466.731652 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.432578 Y197.774182 Z2 E467.660334 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.57073 Y197.923001 Z2 E468.588979 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.70451 Y198.075758 Z2 E469.517609 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.833809 Y198.232328 Z2 E470.446246 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X212.958522 Y198.392582 Z2 E471.374912 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.078547 Y198.556392 Z2 E472.303629 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.190641 Y198.719062 Z2 E473.207086 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.294096 Y198.879516 Z2 E474.080192 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.395376 Y199.047841 Z2 E474.97859 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.49499 Y199.224808 Z2 E475.907313 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.58943 Y199.404575 Z2 E476.835982 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.678618 Y199.586998 Z2 E477.764621 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.762484 Y199.771925 Z2 E478.693251 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.840958 Y199.959208 Z2 E479.621893 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.913976 Y200.148692 Z2 E480.550571 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X213.981478 Y200.340224 Z2 E481.479306 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.040706 Y200.525207 Z2 E482.367587 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.093129 Y200.708784 Z2 E483.240693 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.142196 Y200.902428 Z2 E484.154268 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.186352 Y201.100643 Z2 E485.082974 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.224744 Y201.300043 Z2 E486.011633 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.257343 Y201.500466 Z2 E486.940267 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.284122 Y201.701748 Z2 E487.868898 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.305058 Y201.903727 Z2 E488.797548 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.320135 Y202.106236 Z2 E489.726239 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.329339 Y202.30911 Z2 E490.654994 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X214.332463 Y202.5 Z2 E491.528101 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.331928 Y202.5 Z2 E509.823624 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.330823 Y202.567495 Z2 E510.132339 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.326872 Y202.654579 Z2 E510.531006 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.320401 Y202.741499 Z2 E510.929615 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.311415 Y202.828187 Z2 E511.328186 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.299922 Y202.914574 Z2 E511.726741 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.285931 Y203.000593 Z2 E512.125298 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.269453 Y203.086176 Z2 E512.523877 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.2505 Y203.171254 Z2 E512.9225 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.230406 Y203.250556 Z2 E513.296632 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.21187 Y203.315465 Z2 E513.605346 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.189651 Y203.384863 Z2 E513.938591 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.160676 Y203.467076 Z2 E514.33724 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.129336 Y203.548404 Z2 E514.735837 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.095656 Y203.628784 Z2 E515.134401 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.059662 Y203.708152 Z2 E515.532954 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.021383 Y203.786446 Z2 E515.931516 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.980849 Y203.863603 Z2 E516.330105 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.938092 Y203.939563 Z2 E516.728743 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.89868 Y204.005064 Z2 E517.078342 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.8621 Y204.061798 Z2 E517.387056 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.81771 Y204.126216 Z2 E517.744832 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.766192 Y204.196528 Z2 E518.143465 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.712665 Y204.26531 Z2 E518.542051 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.657171 Y204.332508 Z2 E518.940611 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.599755 Y204.398069 Z2 E519.339164 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.540461 Y204.461941 Z2 E519.737731 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.479337 Y204.524074 Z2 E520.136332 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.41643 Y204.584418 Z2 E520.534986 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.36373 Y204.632116 Z2 E520.860054 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.312257 Y204.675788 Z2 E521.168769 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.246936 Y204.727958 Z2 E521.551079 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.177282 Y204.780357 Z2 E521.949697 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.106147 Y204.83071 Z2 E522.348274 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.033586 Y204.878979 Z2 E522.746829 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.959658 Y204.925126 Z2 E523.145384 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.88442 Y204.969113 Z2 E523.543959 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.807931 Y205.010907 Z2 E523.942572 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.731848 Y205.04966 Z2 E524.33306 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.670825 Y205.078522 Z2 E524.641775 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.607259 Y205.106105 Z2 E524.958666 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.526319 Y205.138473 Z2 E525.357327 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.444487 Y205.168479 Z2 E525.755932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.361828 Y205.196099 Z2 E526.154501 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.278406 Y205.221311 Z2 E526.553055 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.194288 Y205.244097 Z2 E526.951613 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.10954 Y205.264437 Z2 E527.350196 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.024228 Y205.282315 Z2 E527.748823 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.945467 Y205.296452 Z2 E528.114777 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.878693 Y205.306357 Z2 E528.423491 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.804538 Y205.314991 Z2 E528.764913 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.717699 Y205.322558 Z2 E529.163556 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.630688 Y205.327606 Z2 E529.562149 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.543574 Y205.330131 Z2 E529.960712 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.456426 Y205.330131 Z2 E530.359265 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.369312 Y205.327606 Z2 E530.757828 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.282301 Y205.322558 Z2 E531.156421 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.195462 Y205.314991 Z2 E531.555065 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.121307 Y205.306357 Z2 E531.896486 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.054533 Y205.296452 Z2 E532.2052 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.975772 Y205.282315 Z2 E532.571154 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.89046 Y205.264437 Z2 E532.969782 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.805712 Y205.244097 Z2 E533.368365 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.721594 Y205.221311 Z2 E533.766923 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.638172 Y205.196099 Z2 E534.165477 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.555513 Y205.168479 Z2 E534.564046 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.473681 Y205.138473 Z2 E534.962651 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.392741 Y205.106105 Z2 E535.361311 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.329175 Y205.078522 Z2 E535.678203 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.268152 Y205.04966 Z2 E535.986918 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.192069 Y205.010907 Z2 E536.377406 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.11558 Y204.969113 Z2 E536.776019 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.040342 Y204.925126 Z2 E537.174593 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.966414 Y204.878979 Z2 E537.573148 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.893853 Y204.83071 Z2 E537.971704 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.822718 Y204.780357 Z2 E538.370281 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.753064 Y204.727958 Z2 E538.768899 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.687743 Y204.675788 Z2 E539.151209 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.63627 Y204.632116 Z2 E539.459923 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.58357 Y204.584418 Z2 E539.784991 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.520663 Y204.524074 Z2 E540.183646 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.459539 Y204.461941 Z2 E540.582247 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.400245 Y204.398069 Z2 E540.980814 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.342829 Y204.332508 Z2 E541.379367 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.287335 Y204.26531 Z2 E541.777927 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.233808 Y204.196528 Z2 E542.176513 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.18229 Y204.126216 Z2 E542.575146 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.1379 Y204.061798 Z2 E542.932922 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.10132 Y204.005064 Z2 E543.241636 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.061908 Y203.939563 Z2 E543.591235 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.019151 Y203.863603 Z2 E543.989873 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.978617 Y203.786446 Z2 E544.388462 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.940338 Y203.708152 Z2 E544.787023 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.904344 Y203.628784 Z2 E545.185576 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.870664 Y203.548404 Z2 E545.584141 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.839324 Y203.467076 Z2 E545.982738 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.810349 Y203.384863 Z2 E546.381387 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.78813 Y203.315465 Z2 E546.714632 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.769594 Y203.250556 Z2 E547.023346 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.7495 Y203.171254 Z2 E547.397478 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.730547 Y203.086176 Z2 E547.7961 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.714069 Y203.000593 Z2 E548.19468 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.700078 Y202.914574 Z2 E548.593237 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.688585 Y202.828187 Z2 E548.991791 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.679599 Y202.741499 Z2 E549.390363 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.673128 Y202.654579 Z2 E549.788972 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.669177 Y202.567495 Z2 E550.187639 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.668072 Y202.5 Z2 E550.496354 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.669177 Y202.432505 Z2 E550.805069 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.673128 Y202.345421 Z2 E551.203736 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.679599 Y202.258501 Z2 E551.602345 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.688585 Y202.171813 Z2 E552.000916 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.700078 Y202.085426 Z2 E552.399471 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.714069 Y201.999407 Z2 E552.798028 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.730547 Y201.913824 Z2 E553.196607 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.7495 Y201.828746 Z2 E553.59523 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.769594 Y201.749444 Z2 E553.969362 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.78813 Y201.684535 Z2 E554.278076 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.810349 Y201.615137 Z2 E554.611321 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.839324 Y201.532924 Z2 E555.00997 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.870664 Y201.451596 Z2 E555.408567 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.904344 Y201.371216 Z2 E555.807131 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.940338 Y201.291848 Z2 E556.205684 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X204.978617 Y201.213554 Z2 E556.604246 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.019151 Y201.136397 Z2 E557.002835 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.061908 Y201.060437 Z2 E557.401473 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.10132 Y200.994936 Z2 E557.751072 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.1379 Y200.938202 Z2 E558.059786 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.18229 Y200.873784 Z2 E558.417562 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.233808 Y200.803472 Z2 E558.816195 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.287335 Y200.73469 Z2 E559.214781 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.342829 Y200.667492 Z2 E559.613341 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.400245 Y200.601931 Z2 E560.011894 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.459539 Y200.538059 Z2 E560.410461 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.520663 Y200.475926 Z2 E560.809062 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.58357 Y200.415582 Z2 E561.207716 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.63627 Y200.367884 Z2 E561.532784 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.687743 Y200.324212 Z2 E561.841499 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.753064 Y200.272042 Z2 E562.223808 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.822718 Y200.219643 Z2 E562.622427 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.893853 Y200.16929 Z2 E563.021003 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X205.966414 Y200.121021 Z2 E563.419559 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.040342 Y200.074874 Z2 E563.818114 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.11558 Y200.030887 Z2 E564.216689 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.192069 Y199.989093 Z2 E564.615302 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.268152 Y199.95034 Z2 E565.00579 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.329175 Y199.921478 Z2 E565.314505 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.392741 Y199.893895 Z2 E565.631396 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.473681 Y199.861527 Z2 E566.030057 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.555513 Y199.831521 Z2 E566.428662 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.638172 Y199.803901 Z2 E566.827231 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.721594 Y199.778689 Z2 E567.225785 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.805712 Y199.755903 Z2 E567.624343 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.89046 Y199.735563 Z2 E568.022926 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X206.975772 Y199.717685 Z2 E568.421553 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.054533 Y199.703548 Z2 E568.787507 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.121307 Y199.693643 Z2 E569.096221 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.195462 Y199.685009 Z2 E569.437643 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.282301 Y199.677442 Z2 E569.836286 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.369312 Y199.672394 Z2 E570.234879 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.456426 Y199.669869 Z2 E570.633442 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.543574 Y199.669869 Z2 E571.031995 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.630688 Y199.672394 Z2 E571.430558 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.717699 Y199.677442 Z2 E571.829151 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.804538 Y199.685009 Z2 E572.227795 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.878693 Y199.693643 Z2 E572.569216 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X207.945467 Y199.703548 Z2 E572.87793 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.024228 Y199.717685 Z2 E573.243884 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.10954 Y199.735563 Z2 E573.642512 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.194288 Y199.755903 Z2 E574.041095 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.278406 Y199.778689 Z2 E574.439653 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.361828 Y199.803901 Z2 E574.838207 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.444487 Y199.831521 Z2 E575.236776 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.526319 Y199.861527 Z2 E575.635381 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.607259 Y199.893895 Z2 E576.034041 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.670825 Y199.921478 Z2 E576.350933 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.731848 Y199.95034 Z2 E576.659648 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.807931 Y199.989093 Z2 E577.050136 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.88442 Y200.030887 Z2 E577.448749 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X208.959658 Y200.074874 Z2 E577.847323 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.033586 Y200.121021 Z2 E578.245878 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.106147 Y200.16929 Z2 E578.644434 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.177282 Y200.219643 Z2 E579.043011 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.246936 Y200.272042 Z2 E579.441629 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.312257 Y200.324212 Z2 E579.823939 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.36373 Y200.367884 Z2 E580.132653 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.41643 Y200.415582 Z2 E580.457721 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.479337 Y200.475926 Z2 E580.856376 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.540461 Y200.538059 Z2 E581.254977 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.599755 Y200.601931 Z2 E581.653544 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.657171 Y200.667492 Z2 E582.052097 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.712665 Y200.73469 Z2 E582.450657 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.766192 Y200.803472 Z2 E582.849243 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.81771 Y200.873784 Z2 E583.247875 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.8621 Y200.938202 Z2 E583.605652 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.89868 Y200.994936 Z2 E583.914366 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.938092 Y201.060437 Z2 E584.263965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X209.980849 Y201.136397 Z2 E584.662603 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.021383 Y201.213554 Z2 E585.061192 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.059662 Y201.291848 Z2 E585.459753 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.095656 Y201.371216 Z2 E585.858306 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.129336 Y201.451596 Z2 E586.256871 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.160676 Y201.532924 Z2 E586.655468 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.189651 Y201.615137 Z2 E587.054117 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.21187 Y201.684535 Z2 E587.387362 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.230406 Y201.749444 Z2 E587.696076 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.2505 Y201.828746 Z2 E588.070208 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.269453 Y201.913824 Z2 E588.46883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.285931 Y201.999407 Z2 E588.86741 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.299922 Y202.085426 Z2 E589.265967 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.311415 Y202.171813 Z2 E589.664521 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.320401 Y202.258501 Z2 E590.063093 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.326872 Y202.345421 Z2 E590.461702 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.330823 Y202.432505 Z2 E590.860369 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X210.331928 Y202.5 Z2 E591.169084 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=bottom 1 of 2 · island 1 of 1
G1 X220.833333 Y202.5 Z2 E639.194833 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.833156 Y202.891589 Z2.009346 E640.986183 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.821626 Y203.283172 Z2.018692 E642.778284 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.798743 Y203.674426 Z2.028037 E644.571159 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.764517 Y204.065026 Z2.037383 E646.364835 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.718966 Y204.45465 Z2.046729 E648.159336 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.662115 Y204.842975 Z2.056075 E649.954688 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.594003 Y205.229678 Z2.065421 E651.750915 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.514673 Y205.614437 Z2.074766 E653.548043 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.42418 Y205.996933 Z2.084112 E655.346098 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.322202 Y206.376731 Z2.093458 E657.145045 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.208187 Y206.753259 Z2.102804 E658.944731 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.083256 Y207.126482 Z2.11215 E660.745174 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.947503 Y207.496089 Z2.121495 E662.546399 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.801031 Y207.86177 Z2.130841 E664.34843 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.643951 Y208.22322 Z2.140187 E666.151294 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.476383 Y208.580137 Z2.149533 E667.955015 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.298456 Y208.932219 Z2.158879 E669.759619 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.110306 Y209.279173 Z2.168224 E671.565131 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.912078 Y209.620705 Z2.17757 E673.371577 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.703253 Y209.956078 Z2.186916 E675.178859 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.484147 Y210.285022 Z2.196262 E676.986883 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.255504 Y210.607614 Z2.205607 E678.795671 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.017505 Y210.923582 Z2.214953 E680.605246 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.770339 Y211.23266 Z2.224299 E682.415635 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.514201 Y211.534586 Z2.233645 E684.226863 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.249296 Y211.829103 Z2.242991 E686.038956 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.975832 Y212.115961 Z2.252336 E687.851938 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.694028 Y212.394914 Z2.261682 E689.665836 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.404109 Y212.665725 Z2.271028 E691.480675 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.105532 Y212.927218 Z2.280374 E693.296293 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.799205 Y213.179845 Z2.28972 E695.112657 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.485552 Y213.423591 Z2.299065 E696.92979 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.164828 Y213.658249 Z2.308411 E698.747718 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.837291 Y213.883616 Z2.317757 E700.566467 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.503205 Y214.099497 Z2.327103 E702.386061 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.162841 Y214.305706 Z2.336449 E704.206527 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.816473 Y214.502061 Z2.345794 E706.02789 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.464382 Y214.688391 Z2.35514 E707.850176 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.106798 Y214.864407 Z2.364486 E709.67339 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X212.743553 Y215.028818 Z2.373832 E711.497344 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X212.375545 Y215.182696 Z2.383178 E713.322049 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X212.003074 Y215.325906 Z2.392523 E715.14753 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X211.626443 Y215.458321 Z2.401869 E716.973813 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X211.245962 Y215.579821 Z2.411215 E718.800922 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X210.86194 Y215.690297 Z2.420561 E720.628885 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X210.474692 Y215.789645 Z2.429907 E722.457726 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X210.084535 Y215.877773 Z2.439252 E724.287472 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X209.691788 Y215.954598 Z2.448598 E726.118148 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X209.296702 Y216.019501 Z2.457944 E727.949699 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.899614 Y216.072002 Z2.46729 E729.781989 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.501008 Y216.112992 Z2.476636 E731.615037 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.10121 Y216.142426 Z2.485981 E733.448867 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.70055 Y216.16027 Z2.495327 E735.283506 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.299359 Y216.166499 Z2.504673 E737.118979 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.897968 Y216.161097 Z2.514019 E738.955312 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.496708 Y216.144057 Z2.523364 E740.792531 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.095912 Y216.115383 Z2.53271 E742.630661 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X205.695911 Y216.075086 Z2.542056 E744.46973 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X205.297193 Y216.022239 Z2.551402 E746.309616 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X204.900102 Y215.957294 Z2.560748 E748.150245 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X204.504896 Y215.880837 Z2.570093 E749.991637 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X204.111903 Y215.792921 Z2.579439 E751.833819 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X203.72145 Y215.693611 Z2.588785 E753.676816 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X203.333861 Y215.582977 Z2.598131 E755.520654 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X202.949461 Y215.461101 Z2.607477 E757.365359 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X202.568569 Y215.328073 Z2.616822 E759.210958 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X202.191504 Y215.183991 Z2.626168 E761.057475 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.818582 Y215.028963 Z2.635514 E762.904938 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.450725 Y214.861871 Z2.64486 E764.753161 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.087779 Y214.683994 Z2.654206 E766.602129 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.72999 Y214.495595 Z2.663551 E768.451867 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.37766 Y214.296822 Z2.672897 E770.302402 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.031083 Y214.08783 Z2.682243 E772.153759 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.690552 Y213.868782 Z2.691589 E774.005965 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.356354 Y213.63985 Z2.700935 E775.859044 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.028771 Y213.401214 Z2.71028 E777.713025 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X198.708081 Y213.153061 Z2.719626 E779.567931 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X198.394738 Y212.895379 Z2.728972 E781.42375 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X198.089692 Y212.627682 Z2.738318 E783.280308 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.79241 Y212.351146 Z2.747664 E785.137618 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.503146 Y212.065992 Z2.757009 E786.995705 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.222145 Y211.772448 Z2.766355 E788.854594 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.949647 Y211.47075 Z2.775701 E790.714314 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.685885 Y211.161141 Z2.785047 E792.574888 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.431084 Y210.843867 Z2.794393 E794.436344 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.185464 Y210.519185 Z2.803738 E796.298708 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.949238 Y210.187355 Z2.813084 E798.162006 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.723201 Y209.848277 Z2.82243 E800.026161 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.507705 Y209.502213 Z2.831776 E801.891056 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.302245 Y209.149907 Z2.841121 E803.756709 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.106998 Y208.791644 Z2.850467 E805.623145 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.922135 Y208.427716 Z2.859813 E807.490392 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.747817 Y208.058418 Z2.869159 E809.358475 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.584198 Y207.684051 Z2.878505 E811.227421 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.431423 Y207.30492 Z2.88785 E813.097256 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.28963 Y206.921333 Z2.897196 E814.968006 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.158946 Y206.533603 Z2.906542 E816.839697 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.04057 Y206.141757 Z2.915888 E818.712189 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.93396 Y205.74638 Z2.925234 E820.585422 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.838814 Y205.347917 Z2.934579 E822.459419 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.755219 Y204.946695 Z2.943925 E824.334208 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.683254 Y204.543043 Z2.953271 E826.209813 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.622989 Y204.137292 Z2.962617 E828.086262 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.574484 Y203.729777 Z2.971963 E829.963581 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.537792 Y203.320831 Z2.981308 E831.841797 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.512953 Y202.910793 Z2.990654 E833.720935 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.5 Y202.5 Z3 E835.601022 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.500498 Y202.088841 Z3.009346 E837.48185 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.512915 Y201.677706 Z3.018692 E839.363423 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.53725 Y201.266935 Z3.028037 E841.245767 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.573494 Y200.856868 Z3.037383 E843.128909 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.621627 Y200.447845 Z3.046729 E845.012876 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.681619 Y200.040204 Z3.056075 E846.897693 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.753432 Y199.634283 Z3.065421 E848.783387 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.837017 Y199.230421 Z3.074766 E850.669985 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X193.932317 Y198.828952 Z3.084112 E852.557514 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.03967 Y198.430334 Z3.093458 E854.445938 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.159653 Y198.035165 Z3.102804 E856.3351 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.29109 Y197.643483 Z3.11215 E858.225015 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.43388 Y197.255615 Z3.121495 E860.115708 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.587915 Y196.871884 Z3.130841 E862.007205 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.753078 Y196.49261 Z3.140187 E863.899535 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X194.929241 Y196.118113 Z3.149533 E865.792722 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.11627 Y195.748704 Z3.158879 E867.686794 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.314021 Y195.384696 Z3.168224 E869.581777 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.52234 Y195.026393 Z3.17757 E871.477698 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.741771 Y194.67457 Z3.186916 E873.374458 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X195.971983 Y194.32951 Z3.196262 E875.271957 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.212193 Y193.991131 Z3.205607 E877.170215 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.462211 Y193.659717 Z3.214953 E879.069259 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.721839 Y193.335549 Z3.224299 E880.969114 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X196.99087 Y193.018901 Z3.233645 E882.869808 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.269091 Y192.710041 Z3.242991 E884.771367 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.55628 Y192.409232 Z3.252336 E886.673818 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X197.852207 Y192.11673 Z3.261682 E888.577189 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X198.156638 Y191.832785 Z3.271028 E890.481505 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X198.47014 Y191.558628 Z3.280374 E892.386601 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X198.791761 Y191.293788 Z3.28972 E894.292439 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.121053 Y191.038276 Z3.299065 E896.199042 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.45775 Y190.792311 Z3.308411 E898.106438 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X199.801582 Y190.556105 Z3.317757 E900.014653 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.152269 Y190.329861 Z3.327103 E901.923714 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.509529 Y190.113775 Z3.336449 E903.833647 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X200.873071 Y189.908035 Z3.345794 E905.74448 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.242602 Y189.712822 Z3.35514 E907.65624 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.61788 Y189.528437 Z3.364486 E909.568932 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X201.99908 Y189.356236 Z3.373832 E911.482365 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X202.385261 Y189.19509 Z3.383178 E913.396543 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X202.776107 Y189.045142 Z3.392523 E915.311493 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X203.171298 Y188.906525 Z3.401869 E917.227243 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X203.570513 Y188.779363 Z3.411215 E919.143819 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X203.973425 Y188.663771 Z3.420561 E921.061249 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X204.379703 Y188.559855 Z3.429907 E922.979559 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X204.789016 Y188.467713 Z3.439252 E924.898776 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X205.201027 Y188.387431 Z3.448598 E926.818927 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X205.615474 Y188.319656 Z3.457944 E928.739956 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.032003 Y188.264891 Z3.46729 E930.661723 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.450107 Y188.222202 Z3.476636 E932.584243 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X206.869443 Y188.191635 Z3.485981 E934.507543 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.289665 Y188.173224 Z3.495327 E936.431649 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X207.710426 Y188.166995 Z3.504673 E938.356589 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.13138 Y188.172964 Z3.514019 E940.282389 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.552177 Y188.191136 Z3.523364 E942.209078 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X208.972471 Y188.22151 Z3.53271 E944.136681 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X209.391913 Y188.264071 Z3.542056 E946.065226 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X209.809992 Y188.319789 Z3.551402 E947.994591 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X210.226347 Y188.388192 Z3.560748 E949.924696 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X210.640709 Y188.468664 Z3.570093 E951.855559 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X211.052732 Y188.561146 Z3.579439 E953.78721 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X211.462075 Y188.665574 Z3.588785 E955.719674 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X211.868397 Y188.781869 Z3.598131 E957.65298 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X212.271359 Y188.909947 Z3.607477 E959.587153 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X212.670626 Y189.049713 Z3.616822 E961.522222 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.065863 Y189.201062 Z3.626168 E963.458214 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.45674 Y189.363881 Z3.635514 E965.395155 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X213.842291 Y189.539342 Z3.64486 E967.332857 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.222677 Y189.726102 Z3.654206 E969.2713 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.59764 Y189.923885 Z3.663551 E971.210509 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X214.966866 Y190.132536 Z3.672897 E973.150513 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.330044 Y190.351891 Z3.682243 E975.091338 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X215.686869 Y190.581778 Z3.691589 E977.03301 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.037041 Y190.822017 Z3.700935 E978.975559 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.380264 Y191.072419 Z3.71028 E980.919011 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X216.716247 Y191.332786 Z3.719626 E982.863393 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.044515 Y191.60313 Z3.728972 E984.808691 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.364073 Y191.883962 Z3.738318 E986.754728 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.675478 Y192.174047 Z3.747664 E988.701511 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X217.978467 Y192.473152 Z3.757009 E990.649069 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.272783 Y192.781039 Z3.766355 E992.597427 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.558175 Y193.097459 Z3.775701 E994.546614 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X218.834399 Y193.422159 Z3.785047 E996.496656 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.101219 Y193.754877 Z3.794393 E998.447582 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.358406 Y194.095347 Z3.803738 E1000.399419 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.605738 Y194.443293 Z3.813084 E1002.352194 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X219.842382 Y194.798821 Z3.82243 E1004.305829 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.067968 Y195.161655 Z3.831776 E1006.260201 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.283028 Y195.531017 Z3.841121 E1008.215327 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.487377 Y195.906605 Z3.850467 E1010.171234 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.680836 Y196.288115 Z3.859813 E1012.127949 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X220.863237 Y196.675236 Z3.869159 E1014.0855 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X221.034419 Y197.067652 Z3.878505 E1016.043914 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=weave z-blend wall
G1 X221.091584 Y197.209801 Z3.881848 E1016.74476 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000
G1 X221.194231 Y197.465046 Z3.88785 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X221.34253 Y197.867091 Z3.897196 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X221.479182 Y198.273462 Z3.906542 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X221.602932 Y198.684128 Z3.915888 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X221.71435 Y199.098478 Z3.925234 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X221.813752 Y199.516044 Z3.934579 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X221.901047 Y199.936484 Z3.943925 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X221.976154 Y200.359453 Z3.953271 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X222.039 Y200.784603 Z3.962617 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X222.089522 Y201.211584 Z3.971963 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X222.127668 Y201.640047 Z3.981308 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
G1 X222.153394 Y202.069636 Z3.990654 F1800 ; clayline kind=print page=0 layer=0 stroke=weave-00000-zblend-wall-layer-000 note=end-early tail
; CLAYLINE_STROKE_END page=0 layer=0 id=weave-00000-zblend-wall-layer-000
G0 X222.153394 Y202.069636 Z6 F2400 ; clayline kind=travel_lift page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave paste-safe lift
G0 X219.666332 Y202.5 Z6 F2400 ; clayline kind=travel_xy page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave paste-safe traverse
G0 X219.666332 Y202.5 Z4 F2400 ; clayline kind=travel_approach page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave paste-safe approach
; CLAYLINE_STROKE_BEGIN page=0 layer=1 id=weave-00001-zblend-wall-layer-001
G1 X219.660549 Y202.853425 Z4 E1016.762075 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.644317 Y203.211194 Z4 E1016.814938 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.617728 Y203.568326 Z4 E1016.903345 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.580805 Y203.924527 Z4 E1017.027295 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.571289 Y203.996057 Z4 E1017.056574 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X219.533579 Y204.279504 Z4 E1017.186787 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.476089 Y204.632964 Z4 E1017.381823 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.408381 Y204.984617 Z4 E1017.612408 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.330512 Y205.334173 Z4 E1017.878547 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.296194 Y205.469608 Z4 E1017.992016 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X219.242857 Y205.680105 Z4 E1018.179111 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.145798 Y206.01999 Z4 E1018.511613 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.037626 Y206.357839 Z4 E1018.880129 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.918585 Y206.695608 Z4 E1019.287546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.840736 Y206.89763 Z4 E1019.551084 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X218.789815 Y207.029772 Z4 E1019.730492 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.65142 Y207.360057 Z4 E1020.208972 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.503517 Y207.686191 Z4 E1020.722991 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.346226 Y208.007905 Z4 E1021.272557 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.214115 Y208.259382 Z4 E1021.733781 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X218.179678 Y208.324934 Z4 E1021.857681 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.004007 Y208.637018 Z4 E1022.478376 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.820677 Y208.941707 Z4 E1023.129845 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.629134 Y209.238782 Z4 E1023.812165 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.427124 Y209.531936 Z4 E1024.5344 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.425502 Y209.53415 Z4 E1024.540105 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X217.215458 Y209.820818 Z4 E1025.296362 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.99552 Y210.103436 Z4 E1026.093841 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.767492 Y210.379557 Z4 E1026.926847 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.531561 Y210.648955 Z4 E1027.795393 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.483737 Y210.700472 Z4 E1027.970056 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X216.287922 Y210.911408 Z4 E1028.699493 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.036774 Y211.166699 Z4 E1029.639163 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.778325 Y211.414617 Z4 E1030.614423 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.515629 Y211.652385 Z4 E1031.614281 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.407645 Y211.744003 Z4 E1032.023635 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X215.246097 Y211.881066 Z4 E1032.646419 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.966921 Y212.104036 Z4 E1033.724892 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.680735 Y212.319325 Z4 E1034.841391 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.388441 Y212.526226 Z4 E1035.993398 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.209748 Y212.645097 Z4 E1036.700841 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X214.090281 Y212.724569 Z4 E1037.18093 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.786501 Y212.914191 Z4 E1038.404005 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.47735 Y213.094935 Z4 E1039.662644 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.163082 Y213.266652 Z4 E1040.956868 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.911642 Y213.394724 Z4 E1042.001676 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X212.844335 Y213.429007 Z4 E1042.285101 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.5248 Y213.580136 Z4 E1043.632426 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.200151 Y213.721008 Z4 E1045.016059 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.86762 Y213.85399 Z4 E1046.451605 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.531391 Y213.977276 Z4 E1047.922635 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.530592 Y213.977543 Z4 E1047.926137 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=prime ramp
G1 X211.191742 Y214.090767 Z4 E1049.411478 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.848951 Y214.194369 Z4 E1050.900303 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.503301 Y214.287996 Z4 E1052.389134 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.155078 Y214.371572 Z4 E1053.877994 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.804566 Y214.445028 Z4 E1055.366908 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.453733 Y214.508 Z4 E1056.848813 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.104086 Y214.559865 Z4 E1058.318379 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.751302 Y214.600937 Z4 E1059.794995 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.394523 Y214.632028 Z4 E1061.283928 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.037009 Y214.652769 Z4 E1062.7728 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.679052 Y214.663144 Z4 E1064.261636 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.320948 Y214.663144 Z4 E1065.75046 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.962991 Y214.652769 Z4 E1067.239296 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.605477 Y214.632028 Z4 E1068.728169 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.248698 Y214.600937 Z4 E1070.217101 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.895914 Y214.559865 Z4 E1071.693717 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.546267 Y214.508 Z4 E1073.163283 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.195434 Y214.445028 Z4 E1074.645189 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.844922 Y214.371572 Z4 E1076.134102 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.496699 Y214.287996 Z4 E1077.622962 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.151049 Y214.194369 Z4 E1079.111793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.808258 Y214.090767 Z4 E1080.600618 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.468609 Y213.977276 Z4 E1082.089462 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.13238 Y213.85399 Z4 E1083.578348 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.799849 Y213.721008 Z4 E1085.067301 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.4752 Y213.580136 Z4 E1086.53863 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.155665 Y213.429007 Z4 E1088.008196 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.836918 Y213.266652 Z4 E1089.495392 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.52265 Y213.094935 Z4 E1090.984289 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.213499 Y212.914191 Z4 E1092.473139 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.909719 Y212.724569 Z4 E1093.961965 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.611559 Y212.526226 Z4 E1095.450793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.319265 Y212.319325 Z4 E1096.939646 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.033079 Y212.104036 Z4 E1098.428548 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.753903 Y211.881066 Z4 E1099.91398 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.484371 Y211.652385 Z4 E1101.383547 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.221675 Y211.414617 Z4 E1102.856638 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.963226 Y211.166699 Z4 E1104.345584 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.712078 Y210.911408 Z4 E1105.834465 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.468439 Y210.648955 Z4 E1107.323306 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.232508 Y210.379557 Z4 E1108.812131 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.00448 Y210.103436 Z4 E1110.300963 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.784542 Y209.820818 Z4 E1111.789827 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.572876 Y209.531936 Z4 E1113.278747 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.370866 Y209.238782 Z4 E1114.758888 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.179323 Y208.941707 Z4 E1116.228455 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.995993 Y208.637018 Z4 E1117.706833 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.820322 Y208.324934 Z4 E1119.195759 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.653774 Y208.007905 Z4 E1120.684628 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.496483 Y207.686191 Z4 E1122.173462 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.34858 Y207.360057 Z4 E1123.662286 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.210185 Y207.029772 Z4 E1125.151124 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.081415 Y206.695608 Z4 E1126.640001 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.962374 Y206.357839 Z4 E1128.12894 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.854202 Y206.01999 Z4 E1129.603794 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.757143 Y205.680105 Z4 E1131.07336 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.669488 Y205.334173 Z4 E1132.557029 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.591619 Y204.984617 Z4 E1134.045936 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.523911 Y204.632964 Z4 E1135.534793 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.466421 Y204.279504 Z4 E1137.023622 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.419195 Y203.924527 Z4 E1138.512448 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.382272 Y203.568326 Z4 E1140.001294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.355683 Y203.211194 Z4 E1141.490186 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.339451 Y202.853425 Z4 E1142.979146 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.333668 Y202.5 Z4 E1144.448712 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.339451 Y202.146575 Z4 E1145.918279 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.355683 Y201.788806 Z4 E1147.407239 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.382272 Y201.431674 Z4 E1148.896131 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.419195 Y201.075473 Z4 E1150.384977 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.466421 Y200.720496 Z4 E1151.873803 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.523911 Y200.367036 Z4 E1153.362632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.591619 Y200.015383 Z4 E1154.851489 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.669488 Y199.665827 Z4 E1156.340396 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.757143 Y199.319895 Z4 E1157.824065 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.854202 Y198.98001 Z4 E1159.293631 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X195.962374 Y198.642161 Z4 E1160.768485 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.081415 Y198.304392 Z4 E1162.257424 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.210185 Y197.970228 Z4 E1163.7463 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.34858 Y197.639943 Z4 E1165.235139 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.496483 Y197.313809 Z4 E1166.723963 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.653774 Y196.992095 Z4 E1168.212797 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.820322 Y196.675066 Z4 E1169.701665 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X196.995993 Y196.362982 Z4 E1171.190591 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.179323 Y196.058293 Z4 E1172.66897 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.370866 Y195.761218 Z4 E1174.138536 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.572876 Y195.468064 Z4 E1175.618678 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X197.784542 Y195.179182 Z4 E1177.107598 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.00448 Y194.896564 Z4 E1178.596462 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.232508 Y194.620443 Z4 E1180.085294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.468439 Y194.351045 Z4 E1181.574119 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.712078 Y194.088592 Z4 E1183.06296 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X198.963226 Y193.833301 Z4 E1184.551841 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.221675 Y193.585383 Z4 E1186.040787 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.484371 Y193.347615 Z4 E1187.513878 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.753903 Y193.118934 Z4 E1188.983444 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.033079 Y192.895964 Z4 E1190.468877 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.319265 Y192.680675 Z4 E1191.957779 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.611559 Y192.473774 Z4 E1193.446632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.909719 Y192.275431 Z4 E1194.93546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.213499 Y192.085809 Z4 E1196.424286 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.52265 Y191.905065 Z4 E1197.913136 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.836918 Y191.733348 Z4 E1199.402033 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.155665 Y191.570993 Z4 E1200.889229 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.4752 Y191.419864 Z4 E1202.358795 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.799849 Y191.278992 Z4 E1203.830124 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.13238 Y191.14601 Z4 E1205.319077 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.468609 Y191.022724 Z4 E1206.807963 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.808258 Y190.909233 Z4 E1208.296807 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.151049 Y190.805631 Z4 E1209.785632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.496699 Y190.712004 Z4 E1211.274463 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.844922 Y190.628428 Z4 E1212.763323 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.195434 Y190.554972 Z4 E1214.252236 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.546267 Y190.492 Z4 E1215.734141 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.895914 Y190.440135 Z4 E1217.203708 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.248698 Y190.399063 Z4 E1218.680324 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.605477 Y190.367972 Z4 E1220.169256 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.962991 Y190.347231 Z4 E1221.658128 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.320948 Y190.336856 Z4 E1223.146965 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.679052 Y190.336856 Z4 E1224.635789 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.037009 Y190.347231 Z4 E1226.124625 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.394523 Y190.367972 Z4 E1227.613497 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.751302 Y190.399063 Z4 E1229.10243 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.104086 Y190.440135 Z4 E1230.579046 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.453733 Y190.492 Z4 E1232.048612 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.804566 Y190.554972 Z4 E1233.530517 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.155078 Y190.628428 Z4 E1235.019431 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.503301 Y190.712004 Z4 E1236.508291 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.848951 Y190.805631 Z4 E1237.997121 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.191742 Y190.909233 Z4 E1239.485947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.531391 Y191.022724 Z4 E1240.97479 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.86762 Y191.14601 Z4 E1242.463677 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.200151 Y191.278992 Z4 E1243.95263 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.5248 Y191.419864 Z4 E1245.423958 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.844335 Y191.570993 Z4 E1246.893525 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.163082 Y191.733348 Z4 E1248.380721 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.47735 Y191.905065 Z4 E1249.869618 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.786501 Y192.085809 Z4 E1251.358467 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.090281 Y192.275431 Z4 E1252.847294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.388441 Y192.473774 Z4 E1254.336122 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.680735 Y192.680675 Z4 E1255.824975 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.966921 Y192.895964 Z4 E1257.313877 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.246097 Y193.118934 Z4 E1258.799309 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.515629 Y193.347615 Z4 E1260.268875 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.778325 Y193.585383 Z4 E1261.741966 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.036774 Y193.833301 Z4 E1263.230912 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.287922 Y194.088592 Z4 E1264.719794 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.531561 Y194.351045 Z4 E1266.208635 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.767492 Y194.620443 Z4 E1267.697459 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X216.99552 Y194.896564 Z4 E1269.186291 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.215458 Y195.179182 Z4 E1270.675155 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.427124 Y195.468064 Z4 E1272.164075 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.629134 Y195.761218 Z4 E1273.644217 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X217.820677 Y196.058293 Z4 E1275.113783 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.004007 Y196.362982 Z4 E1276.592162 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.179678 Y196.675066 Z4 E1278.081088 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.346226 Y196.992095 Z4 E1279.569956 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.503517 Y197.313809 Z4 E1281.05879 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.65142 Y197.639943 Z4 E1282.547614 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.789815 Y197.970228 Z4 E1284.036453 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X218.918585 Y198.304392 Z4 E1285.52533 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.037626 Y198.642161 Z4 E1287.014269 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.145798 Y198.98001 Z4 E1288.489122 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.242857 Y199.319895 Z4 E1289.958688 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.330512 Y199.665827 Z4 E1291.442357 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.408381 Y200.015383 Z4 E1292.931265 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.476089 Y200.367036 Z4 E1294.420121 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.533579 Y200.720496 Z4 E1295.90895 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.580805 Y201.075473 Z4 E1297.397776 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.617728 Y201.431674 Z4 E1298.886623 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.644317 Y201.788806 Z4 E1300.375514 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.660549 Y202.146575 Z4 E1301.864474 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X219.666332 Y202.5 Z4 E1303.334041 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.665796 Y202.5 Z4 E1319.966335 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.662032 Y202.73003 Z4 E1320.922818 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.651054 Y202.972008 Z4 E1321.929881 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.633071 Y203.213551 Z4 E1322.936879 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.608099 Y203.454462 Z4 E1323.943836 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.576158 Y203.694544 Z4 E1324.950774 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.537276 Y203.9336 Z4 E1325.957715 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.491483 Y204.171435 Z4 E1326.964681 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.438816 Y204.407855 Z4 E1327.971695 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.380134 Y204.639445 Z4 E1328.964961 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.316962 Y204.860663 Z4 E1329.921443 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.245798 Y205.082926 Z4 E1330.891718 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.165285 Y205.311376 Z4 E1331.898761 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.078193 Y205.537384 Z4 E1332.905746 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.984592 Y205.760767 Z4 E1333.912696 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.884561 Y205.981341 Z4 E1334.919632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.77818 Y206.198926 Z4 E1335.926578 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.665537 Y206.413345 Z4 E1336.933555 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.546723 Y206.624422 Z4 E1337.940585 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.425261 Y206.826288 Z4 E1338.920056 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.300593 Y207.019642 Z4 E1339.876538 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.166287 Y207.214545 Z4 E1340.860607 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.023128 Y207.409929 Z4 E1341.867632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.874376 Y207.601074 Z4 E1342.874605 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.720153 Y207.787823 Z4 E1343.881549 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.560586 Y207.970025 Z4 E1344.888485 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.395805 Y208.14753 Z4 E1345.895437 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.225944 Y208.320194 Z4 E1346.902427 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.051142 Y208.487874 Z4 E1347.909476 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.878933 Y208.643741 Z4 E1348.875154 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.703505 Y208.79258 Z4 E1349.831636 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.515963 Y208.942364 Z4 E1350.829501 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.322404 Y209.087974 Z4 E1351.836509 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.124715 Y209.227908 Z4 E1352.843472 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.923061 Y209.362053 Z4 E1353.850412 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.717605 Y209.4903 Z4 E1354.85735 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.508515 Y209.612544 Z4 E1355.86431 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.295963 Y209.728683 Z4 E1356.871314 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.081108 Y209.838121 Z4 E1357.873777 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.873135 Y209.936485 Z4 E1358.83026 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.661072 Y210.028503 Z4 E1359.79134 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.436164 Y210.118445 Z4 E1360.798396 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.208759 Y210.201829 Z4 E1361.80539 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.979043 Y210.278586 Z4 E1362.812344 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.747203 Y210.348655 Z4 E1363.819282 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.51343 Y210.411979 Z4 E1364.826224 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.277913 Y210.468504 Z4 E1365.833193 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.040847 Y210.518185 Z4 E1366.840213 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.806785 Y210.560198 Z4 E1367.82888 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.579214 Y210.593955 Z4 E1368.785362 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.346303 Y210.621071 Z4 E1369.760235 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.104997 Y210.642099 Z4 E1370.767271 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.863196 Y210.656127 Z4 E1371.774252 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.621098 Y210.663144 Z4 E1372.7812 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.378902 Y210.663144 Z4 E1373.788136 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.136804 Y210.656127 Z4 E1374.795084 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.895003 Y210.642099 Z4 E1375.802065 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.653697 Y210.621071 Z4 E1376.809101 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.420786 Y210.593955 Z4 E1377.783974 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.193215 Y210.560198 Z4 E1378.740456 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.959153 Y210.518185 Z4 E1379.729123 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.722087 Y210.468504 Z4 E1380.736143 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.48657 Y210.411979 Z4 E1381.743112 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.252797 Y210.348655 Z4 E1382.750055 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.020957 Y210.278586 Z4 E1383.756992 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.791241 Y210.201829 Z4 E1384.763946 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.563836 Y210.118445 Z4 E1385.77094 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.338928 Y210.028503 Z4 E1386.777996 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.126865 Y209.936485 Z4 E1387.739076 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.918892 Y209.838121 Z4 E1388.695559 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.704037 Y209.728683 Z4 E1389.698022 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.491485 Y209.612544 Z4 E1390.705026 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.282395 Y209.4903 Z4 E1391.711986 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.076939 Y209.362053 Z4 E1392.718924 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.875285 Y209.227908 Z4 E1393.725864 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.677596 Y209.087974 Z4 E1394.732827 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.484037 Y208.942364 Z4 E1395.739836 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.296495 Y208.79258 Z4 E1396.7377 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.121067 Y208.643741 Z4 E1397.694183 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.948858 Y208.487874 Z4 E1398.65986 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.774056 Y208.320194 Z4 E1399.666909 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.604195 Y208.14753 Z4 E1400.673899 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.439414 Y207.970025 Z4 E1401.680851 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.279847 Y207.787823 Z4 E1402.687787 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.125624 Y207.601074 Z4 E1403.694731 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.976872 Y207.409929 Z4 E1404.701704 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.833713 Y207.214545 Z4 E1405.708729 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.699407 Y207.019642 Z4 E1406.692798 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.574739 Y206.826288 Z4 E1407.64928 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.453277 Y206.624422 Z4 E1408.628751 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.334463 Y206.413345 Z4 E1409.635782 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.22182 Y206.198926 Z4 E1410.642759 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.115439 Y205.981341 Z4 E1411.649704 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.015408 Y205.760767 Z4 E1412.65664 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.921807 Y205.537384 Z4 E1413.66359 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.834715 Y205.311376 Z4 E1414.670575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.754202 Y205.082926 Z4 E1415.677618 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.683038 Y204.860663 Z4 E1416.647893 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.619866 Y204.639445 Z4 E1417.604375 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.561184 Y204.407855 Z4 E1418.597641 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.508517 Y204.171435 Z4 E1419.604655 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.462724 Y203.9336 Z4 E1420.611621 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.423842 Y203.694544 Z4 E1421.618562 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.391901 Y203.454462 Z4 E1422.6255 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.366929 Y203.213551 Z4 E1423.632457 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.348946 Y202.972008 Z4 E1424.639456 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.337968 Y202.73003 Z4 E1425.646518 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.334204 Y202.5 Z4 E1426.603001 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.337968 Y202.26997 Z4 E1427.559484 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.348946 Y202.027992 Z4 E1428.566547 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.366929 Y201.786449 Z4 E1429.573545 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.391901 Y201.545538 Z4 E1430.580503 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.423842 Y201.305456 Z4 E1431.58744 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.462724 Y201.0664 Z4 E1432.594381 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.508517 Y200.828565 Z4 E1433.601347 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.561184 Y200.592145 Z4 E1434.608361 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.619866 Y200.360555 Z4 E1435.601627 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.683038 Y200.139337 Z4 E1436.558109 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.754202 Y199.917074 Z4 E1437.528384 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.834715 Y199.688624 Z4 E1438.535427 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X199.921807 Y199.462616 Z4 E1439.542412 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.015408 Y199.239233 Z4 E1440.549362 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.115439 Y199.018659 Z4 E1441.556298 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.22182 Y198.801074 Z4 E1442.563244 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.334463 Y198.586655 Z4 E1443.570221 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.453277 Y198.375578 Z4 E1444.577252 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.574739 Y198.173712 Z4 E1445.556722 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.699407 Y197.980358 Z4 E1446.513204 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.833713 Y197.785455 Z4 E1447.497273 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X200.976872 Y197.590071 Z4 E1448.504298 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.125624 Y197.398926 Z4 E1449.511271 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.279847 Y197.212177 Z4 E1450.518215 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.439414 Y197.029975 Z4 E1451.525152 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.604195 Y196.85247 Z4 E1452.532104 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.774056 Y196.679806 Z4 E1453.539093 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X201.948858 Y196.512126 Z4 E1454.546142 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.121067 Y196.356259 Z4 E1455.51182 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.296495 Y196.20742 Z4 E1456.468302 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.484037 Y196.057636 Z4 E1457.466167 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.677596 Y195.912026 Z4 E1458.473175 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X202.875285 Y195.772092 Z4 E1459.480138 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.076939 Y195.637947 Z4 E1460.487078 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.282395 Y195.5097 Z4 E1461.494017 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.491485 Y195.387456 Z4 E1462.500977 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.704037 Y195.271317 Z4 E1463.50798 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.918892 Y195.161879 Z4 E1464.510443 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.126865 Y195.063515 Z4 E1465.466926 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.338928 Y194.971497 Z4 E1466.428006 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.563836 Y194.881555 Z4 E1467.435062 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.791241 Y194.798171 Z4 E1468.442056 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.020957 Y194.721414 Z4 E1469.449011 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.252797 Y194.651345 Z4 E1470.455948 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.48657 Y194.588021 Z4 E1471.46289 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.722087 Y194.531496 Z4 E1472.46986 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.959153 Y194.481815 Z4 E1473.476879 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.193215 Y194.439802 Z4 E1474.465546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.420786 Y194.406045 Z4 E1475.422028 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.653697 Y194.378929 Z4 E1476.396901 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.895003 Y194.357901 Z4 E1477.403938 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.136804 Y194.343873 Z4 E1478.410919 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.378902 Y194.336856 Z4 E1479.417866 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.621098 Y194.336856 Z4 E1480.424802 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.863196 Y194.343873 Z4 E1481.43175 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.104997 Y194.357901 Z4 E1482.438731 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.346303 Y194.378929 Z4 E1483.445768 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.579214 Y194.406045 Z4 E1484.42064 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.806785 Y194.439802 Z4 E1485.377123 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.040847 Y194.481815 Z4 E1486.36579 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.277913 Y194.531496 Z4 E1487.372809 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.51343 Y194.588021 Z4 E1488.379779 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.747203 Y194.651345 Z4 E1489.386721 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.979043 Y194.721414 Z4 E1490.393658 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.208759 Y194.798171 Z4 E1491.400612 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.436164 Y194.881555 Z4 E1492.407606 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.661072 Y194.971497 Z4 E1493.414662 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.873135 Y195.063515 Z4 E1494.375742 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.081108 Y195.161879 Z4 E1495.332225 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.295963 Y195.271317 Z4 E1496.334688 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.508515 Y195.387456 Z4 E1497.341692 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.717605 Y195.5097 Z4 E1498.348652 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.923061 Y195.637947 Z4 E1499.355591 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.124715 Y195.772092 Z4 E1500.36253 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.322404 Y195.912026 Z4 E1501.369493 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.515963 Y196.057636 Z4 E1502.376502 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.703505 Y196.20742 Z4 E1503.374366 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X212.878933 Y196.356259 Z4 E1504.330849 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.051142 Y196.512126 Z4 E1505.296526 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.225944 Y196.679806 Z4 E1506.303575 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.395805 Y196.85247 Z4 E1507.310565 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.560586 Y197.029975 Z4 E1508.317517 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.720153 Y197.212177 Z4 E1509.324453 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X213.874376 Y197.398926 Z4 E1510.331397 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.023128 Y197.590071 Z4 E1511.33837 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.166287 Y197.785455 Z4 E1512.345395 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.300593 Y197.980358 Z4 E1513.329464 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.425261 Y198.173712 Z4 E1514.285946 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.546723 Y198.375578 Z4 E1515.265417 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.665537 Y198.586655 Z4 E1516.272448 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.77818 Y198.801074 Z4 E1517.279425 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.884561 Y199.018659 Z4 E1518.28637 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X214.984592 Y199.239233 Z4 E1519.293307 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.078193 Y199.462616 Z4 E1520.300256 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.165285 Y199.688624 Z4 E1521.307241 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.245798 Y199.917074 Z4 E1522.314284 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.316962 Y200.139337 Z4 E1523.284559 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.380134 Y200.360555 Z4 E1524.241042 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.438816 Y200.592145 Z4 E1525.234307 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.491483 Y200.828565 Z4 E1526.241321 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.537276 Y201.0664 Z4 E1527.248287 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.576158 Y201.305456 Z4 E1528.255228 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.608099 Y201.545538 Z4 E1529.262166 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.633071 Y201.786449 Z4 E1530.269123 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.651054 Y202.027992 Z4 E1531.276122 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.662032 Y202.26997 Z4 E1532.283184 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X215.665796 Y202.5 Z4 E1533.239667 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.665261 Y202.5 Z4 E1549.871961 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.663516 Y202.606636 Z4 E1550.315361 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.657791 Y202.732823 Z4 E1550.840526 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.648414 Y202.858777 Z4 E1551.365632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.635392 Y202.984398 Z4 E1551.890699 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.618737 Y203.109584 Z4 E1552.415749 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.598463 Y203.234236 Z4 E1552.940802 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.574584 Y203.358253 Z4 E1553.465878 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.547121 Y203.481538 Z4 E1553.990998 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.517412 Y203.598785 Z4 E1554.49386 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.488127 Y203.701335 Z4 E1554.937259 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.453971 Y203.808014 Z4 E1555.402955 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.411985 Y203.927144 Z4 E1555.928102 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.366571 Y204.044997 Z4 E1556.453195 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.317764 Y204.161476 Z4 E1556.978256 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.265604 Y204.276491 Z4 E1557.503305 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.210134 Y204.389947 Z4 E1558.028362 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.151396 Y204.501756 Z4 E1558.553448 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.089438 Y204.611826 Z4 E1559.078583 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.029845 Y204.710868 Z4 E1559.559145 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.972052 Y204.800502 Z4 E1560.002544 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.905451 Y204.897153 Z4 E1560.490539 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.830798 Y204.99904 Z4 E1561.015669 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.753232 Y205.098711 Z4 E1561.540752 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.672815 Y205.196089 Z4 E1562.065807 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.589611 Y205.291095 Z4 E1562.590856 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.503688 Y205.383653 Z4 E1563.115919 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.415114 Y205.473689 Z4 E1563.641016 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.323958 Y205.56113 Z4 E1564.166169 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.242236 Y205.635097 Z4 E1564.624433 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.160913 Y205.704095 Z4 E1565.067832 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.065006 Y205.780692 Z4 E1565.578128 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.964072 Y205.856622 Z4 E1566.103243 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.860989 Y205.92959 Z4 E1566.628316 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.75584 Y205.999538 Z4 E1567.153368 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.648709 Y206.06641 Z4 E1567.678418 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.539681 Y206.130152 Z4 E1568.203489 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.428843 Y206.190714 Z4 E1568.728599 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.31788 Y206.247234 Z4 E1569.24633 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.221469 Y206.292833 Z4 E1569.689729 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.121993 Y206.335998 Z4 E1570.14056 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.004708 Y206.382901 Z4 E1570.665719 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.886127 Y206.426382 Z4 E1571.190821 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.766344 Y206.466406 Z4 E1571.715886 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.645455 Y206.502942 Z4 E1572.240935 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.523558 Y206.535961 Z4 E1572.765989 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.400749 Y206.565436 Z4 E1573.291068 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.277127 Y206.591343 Z4 E1573.816193 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.159837 Y206.612396 Z4 E1574.311622 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.054341 Y206.628044 Z4 E1574.75502 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.941304 Y206.641204 Z4 E1575.22815 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.81547 Y206.65217 Z4 E1575.753291 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.689383 Y206.659485 Z4 E1576.27838 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.563144 Y206.663144 Z4 E1576.803439 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.436856 Y206.663144 Z4 E1577.328487 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.310617 Y206.659485 Z4 E1577.853546 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.18453 Y206.65217 Z4 E1578.378636 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.058696 Y206.641204 Z4 E1578.903777 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.945659 Y206.628044 Z4 E1579.376906 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.840163 Y206.612396 Z4 E1579.820305 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.722873 Y206.591343 Z4 E1580.315734 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.599251 Y206.565436 Z4 E1580.840858 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.476442 Y206.535961 Z4 E1581.365938 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.354545 Y206.502942 Z4 E1581.890992 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.233656 Y206.466406 Z4 E1582.416041 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.113873 Y206.426382 Z4 E1582.941106 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.995292 Y206.382901 Z4 E1583.466207 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.878007 Y206.335998 Z4 E1583.991366 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.778531 Y206.292833 Z4 E1584.442198 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.68212 Y206.247234 Z4 E1584.885597 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.571157 Y206.190714 Z4 E1585.403327 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.460319 Y206.130152 Z4 E1585.928438 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.351291 Y206.06641 Z4 E1586.453508 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.24416 Y205.999538 Z4 E1586.978559 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.139011 Y205.92959 Z4 E1587.50361 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.035928 Y205.856622 Z4 E1588.028683 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.934994 Y205.780692 Z4 E1588.553798 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.839087 Y205.704095 Z4 E1589.064095 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.757764 Y205.635097 Z4 E1589.507494 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.676042 Y205.56113 Z4 E1589.965758 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.584886 Y205.473689 Z4 E1590.49091 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.496312 Y205.383653 Z4 E1591.016008 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.410389 Y205.291095 Z4 E1591.54107 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.327185 Y205.196089 Z4 E1592.066119 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.246768 Y205.098711 Z4 E1592.591175 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.169202 Y204.99904 Z4 E1593.116257 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.094549 Y204.897153 Z4 E1593.641387 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.027948 Y204.800502 Z4 E1594.129383 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.970155 Y204.710868 Z4 E1594.572781 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.910562 Y204.611826 Z4 E1595.053343 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.848604 Y204.501756 Z4 E1595.578479 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.789866 Y204.389947 Z4 E1596.103565 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.734396 Y204.276491 Z4 E1596.628622 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.682236 Y204.161476 Z4 E1597.15367 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.633429 Y204.044997 Z4 E1597.678731 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.588015 Y203.927144 Z4 E1598.203824 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.546029 Y203.808014 Z4 E1598.728971 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.511873 Y203.701335 Z4 E1599.194668 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.482588 Y203.598785 Z4 E1599.638066 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.452879 Y203.481538 Z4 E1600.140929 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.425416 Y203.358253 Z4 E1600.666049 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.401537 Y203.234236 Z4 E1601.191125 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.381263 Y203.109584 Z4 E1601.716177 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.364608 Y202.984398 Z4 E1602.241227 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.351586 Y202.858777 Z4 E1602.766295 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.342209 Y202.732823 Z4 E1603.291401 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.336484 Y202.606636 Z4 E1603.816566 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.334739 Y202.5 Z4 E1604.259965 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.336484 Y202.393364 Z4 E1604.703365 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.342209 Y202.267177 Z4 E1605.228529 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.351586 Y202.141223 Z4 E1605.753635 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.364608 Y202.015602 Z4 E1606.278703 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.381263 Y201.890416 Z4 E1606.803753 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.401537 Y201.765764 Z4 E1607.328805 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.425416 Y201.641747 Z4 E1607.853881 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.452879 Y201.518462 Z4 E1608.379001 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.482588 Y201.401215 Z4 E1608.881864 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.511873 Y201.298665 Z4 E1609.325263 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.546029 Y201.191986 Z4 E1609.790959 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.588015 Y201.072856 Z4 E1610.316106 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.633429 Y200.955003 Z4 E1610.841199 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.682236 Y200.838524 Z4 E1611.36626 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.734396 Y200.723509 Z4 E1611.891309 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.789866 Y200.610053 Z4 E1612.416365 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.848604 Y200.498244 Z4 E1612.941451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.910562 Y200.388174 Z4 E1613.466587 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X203.970155 Y200.289132 Z4 E1613.947149 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.027948 Y200.199498 Z4 E1614.390548 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.094549 Y200.102847 Z4 E1614.878543 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.169202 Y200.00096 Z4 E1615.403673 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.246768 Y199.901289 Z4 E1615.928756 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.327185 Y199.803911 Z4 E1616.453811 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.410389 Y199.708905 Z4 E1616.97886 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.496312 Y199.616347 Z4 E1617.503923 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.584886 Y199.526311 Z4 E1618.02902 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.676042 Y199.43887 Z4 E1618.554173 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.757764 Y199.364903 Z4 E1619.012437 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.839087 Y199.295905 Z4 E1619.455836 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X204.934994 Y199.219308 Z4 E1619.966132 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.035928 Y199.143378 Z4 E1620.491247 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.139011 Y199.07041 Z4 E1621.01632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.24416 Y199.000462 Z4 E1621.541372 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.351291 Y198.93359 Z4 E1622.066422 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.460319 Y198.869848 Z4 E1622.591492 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.571157 Y198.809286 Z4 E1623.116603 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.68212 Y198.752766 Z4 E1623.634333 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.778531 Y198.707167 Z4 E1624.077733 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.878007 Y198.664002 Z4 E1624.528564 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X205.995292 Y198.617099 Z4 E1625.053723 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.113873 Y198.573618 Z4 E1625.578824 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.233656 Y198.533594 Z4 E1626.10389 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.354545 Y198.497058 Z4 E1626.628939 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.476442 Y198.464039 Z4 E1627.153993 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.599251 Y198.434564 Z4 E1627.679072 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.722873 Y198.408657 Z4 E1628.204197 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.840163 Y198.387604 Z4 E1628.699626 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X206.945659 Y198.371956 Z4 E1629.143024 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.058696 Y198.358796 Z4 E1629.616153 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.18453 Y198.34783 Z4 E1630.141294 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.310617 Y198.340515 Z4 E1630.666384 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.436856 Y198.336856 Z4 E1631.191443 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.563144 Y198.336856 Z4 E1631.716491 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.689383 Y198.340515 Z4 E1632.24155 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.81547 Y198.34783 Z4 E1632.76664 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.941304 Y198.358796 Z4 E1633.291781 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.054341 Y198.371956 Z4 E1633.76491 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.159837 Y198.387604 Z4 E1634.208308 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.277127 Y198.408657 Z4 E1634.703737 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.400749 Y198.434564 Z4 E1635.228862 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.523558 Y198.464039 Z4 E1635.753941 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.645455 Y198.497058 Z4 E1636.278995 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.766344 Y198.533594 Z4 E1636.804045 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X208.886127 Y198.573618 Z4 E1637.32911 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.004708 Y198.617099 Z4 E1637.854211 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.121993 Y198.664002 Z4 E1638.37937 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.221469 Y198.707167 Z4 E1638.830202 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.31788 Y198.752766 Z4 E1639.273601 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.428843 Y198.809286 Z4 E1639.791331 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.539681 Y198.869848 Z4 E1640.316442 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.648709 Y198.93359 Z4 E1640.841512 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.75584 Y199.000462 Z4 E1641.366562 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.860989 Y199.07041 Z4 E1641.891614 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X209.964072 Y199.143378 Z4 E1642.416687 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.065006 Y199.219308 Z4 E1642.941802 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.160913 Y199.295905 Z4 E1643.452099 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.242236 Y199.364903 Z4 E1643.895497 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.323958 Y199.43887 Z4 E1644.353761 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.415114 Y199.526311 Z4 E1644.878914 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.503688 Y199.616347 Z4 E1645.404011 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.589611 Y199.708905 Z4 E1645.929074 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.672815 Y199.803911 Z4 E1646.454123 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.753232 Y199.901289 Z4 E1646.979178 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.830798 Y200.00096 Z4 E1647.504261 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.905451 Y200.102847 Z4 E1648.029391 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X210.972052 Y200.199498 Z4 E1648.517386 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.029845 Y200.289132 Z4 E1648.960785 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.089438 Y200.388174 Z4 E1649.441347 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.151396 Y200.498244 Z4 E1649.966483 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.210134 Y200.610053 Z4 E1650.491569 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.265604 Y200.723509 Z4 E1651.016626 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.317764 Y200.838524 Z4 E1651.541674 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.366571 Y200.955003 Z4 E1652.066735 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.411985 Y201.072856 Z4 E1652.591828 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.453971 Y201.191986 Z4 E1653.116975 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.488127 Y201.298665 Z4 E1653.582671 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.517412 Y201.401215 Z4 E1654.02607 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.547121 Y201.518462 Z4 E1654.528933 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.574584 Y201.641747 Z4 E1655.054053 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.598463 Y201.765764 Z4 E1655.579129 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.618737 Y201.890416 Z4 E1656.104181 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.635392 Y202.015602 Z4 E1656.629231 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.648414 Y202.141223 Z4 E1657.154299 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.657791 Y202.267177 Z4 E1657.679405 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.663516 Y202.393364 Z4 E1658.204569 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X211.665261 Y202.5 Z4 E1658.647969 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.664054 Y202.5 Z4 E1675.283053 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.663756 Y202.504003 Z4 E1675.299741 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.662685 Y202.514333 Z4 E1675.342919 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.661316 Y202.524624 Z4 E1675.386081 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.65965 Y202.534872 Z4 E1675.429245 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.657686 Y202.545072 Z4 E1675.472431 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.657456 Y202.546102 Z4 E1675.476821 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.654949 Y202.552609 Z4 E1675.505812 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.650936 Y202.562186 Z4 E1675.548984 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.646648 Y202.571641 Z4 E1675.592144 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.642087 Y202.580969 Z4 E1675.635313 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.637997 Y202.588756 Z4 E1675.671883 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.632087 Y202.596349 Z4 E1675.711885 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.625476 Y202.604355 Z4 E1675.755052 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.618636 Y202.612165 Z4 E1675.798213 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.611571 Y202.619775 Z4 E1675.841386 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.607373 Y202.624043 Z4 E1675.866275 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.605741 Y202.62527 Z4 E1675.874764 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.597264 Y202.631271 Z4 E1675.917947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.588619 Y202.637022 Z4 E1675.961111 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.579813 Y202.642519 Z4 E1676.004273 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.570846 Y202.647761 Z4 E1676.047454 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.568189 Y202.649213 Z4 E1676.060042 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.563495 Y202.650934 Z4 E1676.08083 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.553645 Y202.654225 Z4 E1676.124006 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.543708 Y202.657229 Z4 E1676.167167 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.533686 Y202.659943 Z4 E1676.210333 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.523585 Y202.662368 Z4 E1676.253522 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.523516 Y202.662382 Z4 E1676.253813 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.51557 Y202.662843 Z4 E1676.286906 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.505191 Y202.663144 Z4 E1676.330076 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.494809 Y202.663144 Z4 E1676.373236 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.48443 Y202.662843 Z4 E1676.416406 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.476484 Y202.662382 Z4 E1676.449496 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.476415 Y202.662368 Z4 E1676.44979 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.466314 Y202.659943 Z4 E1676.492979 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.456292 Y202.657229 Z4 E1676.536145 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.446355 Y202.654225 Z4 E1676.579306 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.436505 Y202.650934 Z4 E1676.622482 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.431811 Y202.649213 Z4 E1676.64327 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.429154 Y202.647761 Z4 E1676.655858 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.420187 Y202.642519 Z4 E1676.699039 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.411381 Y202.637022 Z4 E1676.742201 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.402736 Y202.631271 Z4 E1676.785365 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.394259 Y202.62527 Z4 E1676.828548 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.392627 Y202.624043 Z4 E1676.837037 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.388429 Y202.619775 Z4 E1676.861926 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.381364 Y202.612165 Z4 E1676.905099 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.374524 Y202.604355 Z4 E1676.94826 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.367913 Y202.596349 Z4 E1676.991427 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.362003 Y202.588756 Z4 E1677.031429 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.357913 Y202.580969 Z4 E1677.067999 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.353352 Y202.571641 Z4 E1677.111168 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.349064 Y202.562186 Z4 E1677.154329 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.345051 Y202.552609 Z4 E1677.1975 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.342544 Y202.546102 Z4 E1677.226491 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.342314 Y202.545072 Z4 E1677.230881 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.34035 Y202.534872 Z4 E1677.274067 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.338684 Y202.524624 Z4 E1677.317231 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.337315 Y202.514333 Z4 E1677.360393 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.336244 Y202.504003 Z4 E1677.403571 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.335946 Y202.5 Z4 E1677.420259 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.336244 Y202.495997 Z4 E1677.436947 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.337315 Y202.485667 Z4 E1677.480125 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.338684 Y202.475376 Z4 E1677.523287 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.34035 Y202.465128 Z4 E1677.566451 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.342314 Y202.454928 Z4 E1677.609637 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.342544 Y202.453898 Z4 E1677.614027 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.345051 Y202.447391 Z4 E1677.643018 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.349064 Y202.437814 Z4 E1677.686189 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.353352 Y202.428359 Z4 E1677.72935 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.357913 Y202.419031 Z4 E1677.772518 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.362003 Y202.411244 Z4 E1677.809089 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.367913 Y202.403651 Z4 E1677.849091 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.374524 Y202.395645 Z4 E1677.892258 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.381364 Y202.387835 Z4 E1677.935418 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.388429 Y202.380225 Z4 E1677.978592 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.392627 Y202.375957 Z4 E1678.003481 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.394259 Y202.37473 Z4 E1678.01197 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.402736 Y202.368729 Z4 E1678.055153 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.411381 Y202.362978 Z4 E1678.098317 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.420187 Y202.357481 Z4 E1678.141479 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.429154 Y202.352239 Z4 E1678.18466 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.431811 Y202.350787 Z4 E1678.197248 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.436505 Y202.349066 Z4 E1678.218036 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.446355 Y202.345775 Z4 E1678.261212 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.456292 Y202.342771 Z4 E1678.304373 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.466314 Y202.340057 Z4 E1678.347539 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.476415 Y202.337632 Z4 E1678.390727 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.476484 Y202.337618 Z4 E1678.391019 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.48443 Y202.337157 Z4 E1678.424112 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.494809 Y202.336856 Z4 E1678.467282 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.505191 Y202.336856 Z4 E1678.510442 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.51557 Y202.337157 Z4 E1678.553612 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.523516 Y202.337618 Z4 E1678.586702 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.523585 Y202.337632 Z4 E1678.586996 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.533686 Y202.340057 Z4 E1678.630185 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.543708 Y202.342771 Z4 E1678.673351 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.553645 Y202.345775 Z4 E1678.716512 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.563495 Y202.349066 Z4 E1678.759688 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.568189 Y202.350787 Z4 E1678.780476 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.570846 Y202.352239 Z4 E1678.793064 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.579813 Y202.357481 Z4 E1678.836245 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.588619 Y202.362978 Z4 E1678.879407 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.597264 Y202.368729 Z4 E1678.922571 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.605741 Y202.37473 Z4 E1678.965754 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.607373 Y202.375957 Z4 E1678.974242 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.611571 Y202.380225 Z4 E1678.999132 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.618636 Y202.387835 Z4 E1679.042305 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.625476 Y202.395645 Z4 E1679.085466 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.632087 Y202.403651 Z4 E1679.128633 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.637997 Y202.411244 Z4 E1679.168635 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.642087 Y202.419031 Z4 E1679.205205 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.646648 Y202.428359 Z4 E1679.248374 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.650936 Y202.437814 Z4 E1679.291534 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.654949 Y202.447391 Z4 E1679.334706 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.657456 Y202.453898 Z4 E1679.363697 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.657686 Y202.454928 Z4 E1679.368087 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.65965 Y202.465128 Z4 E1679.411273 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.661316 Y202.475376 Z4 E1679.454437 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.662685 Y202.485667 Z4 E1679.497599 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.663756 Y202.495997 Z4 E1679.540777 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X207.664054 Y202.5 Z4 E1679.557465 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=bottom 2 of 2 · island 1 of 1
G1 X222.166667 Y202.5 Z4 E1739.852321 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.165849 Y202.930729 Z4.009346 E1741.64351 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.152545 Y203.361416 Z4.018692 E1743.435372 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.126756 Y203.791704 Z4.028037 E1745.227932 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.088494 Y204.221237 Z4.037383 E1747.021215 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.037781 Y204.64966 Z4.046729 E1748.815247 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.974647 Y205.076617 Z4.056075 E1750.610053 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.899134 Y205.501755 Z4.065421 E1752.405657 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.811293 Y205.924721 Z4.074766 E1754.202085 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.711185 Y206.345162 Z4.084112 E1755.999362 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.598458 Y206.762601 Z4.093458 E1757.797457 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.472507 Y207.17641 Z4.102804 E1759.596223 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.334565 Y207.586551 Z4.11215 E1761.395667 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.184737 Y207.992681 Z4.121495 E1763.195817 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.023139 Y208.394462 Z4.130841 E1764.996696 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.849893 Y208.791559 Z4.140187 E1766.79833 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.665134 Y209.183638 Z4.149533 E1768.600745 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.469003 Y209.570372 Z4.158879 E1770.403966 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.261652 Y209.951436 Z4.168224 E1772.208018 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.043243 Y210.326509 Z4.17757 E1774.012927 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.813205 Y210.694782 Z4.186916 E1775.8186 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.571888 Y211.055959 Z4.196262 E1777.624944 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.32011 Y211.410125 Z4.205607 E1779.431973 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.058072 Y211.756983 Z4.214953 E1781.239713 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.785983 Y212.096241 Z4.224299 E1783.04819 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.504058 Y212.427612 Z4.233645 E1784.857429 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.212522 Y212.750815 Z4.242991 E1786.667455 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.911609 Y213.065576 Z4.252336 E1788.478295 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.601557 Y213.371626 Z4.261682 E1790.289973 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.282615 Y213.668706 Z4.271028 E1792.102515 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.954188 Y213.955525 Z4.280374 E1793.915767 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.617274 Y214.232579 Z4.28972 E1795.72969 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.272342 Y214.499857 Z4.299065 E1797.544305 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.919671 Y214.757129 Z4.308411 E1799.359638 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.559545 Y215.004174 Z4.317757 E1801.175714 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.192256 Y215.240781 Z4.327103 E1802.99256 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.818102 Y215.466745 Z4.336449 E1804.8102 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.437385 Y215.681869 Z4.345794 E1806.62866 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.050414 Y215.885965 Z4.35514 E1808.447966 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.657442 Y216.078718 Z4.364486 E1810.268124 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.258287 Y216.258711 Z4.373832 E1812.088954 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.853934 Y216.427124 Z4.383178 E1813.910458 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.444713 Y216.583809 Z4.392523 E1815.732661 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.03096 Y216.728628 Z4.401869 E1817.555589 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.613011 Y216.861452 Z4.411215 E1819.379267 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.19121 Y216.982161 Z4.420561 E1821.203721 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.765902 Y217.090644 Z4.429907 E1823.028976 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.337434 Y217.186801 Z4.439252 E1824.855059 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.906158 Y217.270541 Z4.448598 E1826.681995 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.47235 Y217.341188 Z4.457944 E1828.509732 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.03638 Y217.398216 Z4.46729 E1830.338139 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.598778 Y217.442604 Z4.476636 E1832.167225 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.159904 Y217.474305 Z4.485981 E1833.997018 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.72012 Y217.493283 Z4.495327 E1835.827542 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.279788 Y217.499512 Z4.504673 E1837.658823 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.839273 Y217.492976 Z4.514019 E1839.490888 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.398937 Y217.47367 Z4.523364 E1841.323761 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.959146 Y217.441597 Z4.53271 E1843.157469 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.520263 Y217.396773 Z4.542056 E1844.992037 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.082823 Y217.338183 Z4.551402 E1846.827353 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.647203 Y217.266321 Z4.560748 E1848.663337 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.213686 Y217.181836 Z4.570093 E1850.500009 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.782633 Y217.084786 Z4.579439 E1852.337393 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.3544 Y216.975242 Z4.588785 E1854.175515 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.929345 Y216.853285 Z4.598131 E1856.014402 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.507821 Y216.719004 Z4.607477 E1857.854079 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.09018 Y216.572501 Z4.616822 E1859.694572 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.67677 Y216.413884 Z4.626168 E1861.535906 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.267938 Y216.243274 Z4.635514 E1863.378109 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.864693 Y216.059445 Z4.64486 E1865.221004 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.466867 Y215.863801 Z4.654206 E1867.064568 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.074729 Y215.656634 Z4.663551 E1868.908826 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.688609 Y215.438106 Z4.672897 E1870.753803 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.308829 Y215.208388 Z4.682243 E1872.599526 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.93571 Y214.967662 Z4.691589 E1874.44602 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.569564 Y214.716116 Z4.700935 E1876.293311 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.210702 Y214.453949 Z4.71028 E1878.141426 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.859425 Y214.181368 Z4.719626 E1879.990389 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.516232 Y213.89836 Z4.728972 E1881.84019 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.182163 Y213.604394 Z4.738318 E1883.690661 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.856634 Y213.300761 Z4.747664 E1885.541807 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.539919 Y212.987704 Z4.757009 E1887.393653 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.232289 Y212.665474 Z4.766355 E1889.246225 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.934004 Y212.334331 Z4.775701 E1891.09955 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.645318 Y211.994542 Z4.785047 E1892.953653 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.366478 Y211.646378 Z4.794393 E1894.808561 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.097724 Y211.290122 Z4.803738 E1896.6643 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.839286 Y210.926059 Z4.813084 E1898.520895 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.592036 Y210.554081 Z4.82243 E1900.378274 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.356359 Y210.174476 Z4.831776 E1902.236322 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.131698 Y209.78806 Z4.841121 E1904.095051 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.918248 Y209.395146 Z4.850467 E1905.954487 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.716193 Y208.996054 Z4.859813 E1907.814656 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.525709 Y208.59111 Z4.869159 E1909.675585 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.346964 Y208.180644 Z4.878505 E1911.5373 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.180115 Y207.764989 Z4.88785 E1913.399826 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.02531 Y207.344484 Z4.897196 E1915.26319 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.88269 Y206.919473 Z4.906542 E1917.127419 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.753565 Y206.489986 Z4.915888 E1918.992378 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.63734 Y206.056664 Z4.925234 E1920.858004 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.533683 Y205.619995 Z4.934579 E1922.724317 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.442687 Y205.180337 Z4.943925 E1924.591346 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.364439 Y204.738052 Z4.953271 E1926.459114 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.299012 Y204.293503 Z4.962617 E1928.327649 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.246472 Y203.847055 Z4.971963 E1930.196977 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.206873 Y203.399075 Z4.981308 E1932.067124 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.18026 Y202.949934 Z4.990654 E1933.938116 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.166667 Y202.5 Z5 E1935.80998 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.167805 Y202.0497 Z5.009346 E1937.682518 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.181996 Y201.599462 Z5.018692 E1939.555724 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.209238 Y201.149657 Z5.028037 E1941.429625 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.249517 Y200.700658 Z5.037383 E1943.304246 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.302812 Y200.252835 Z5.046729 E1945.179616 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.369087 Y199.806561 Z5.056075 E1947.055759 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.4483 Y199.362206 Z5.065421 E1948.932702 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.540397 Y198.920137 Z5.074766 E1950.810472 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.645312 Y198.480723 Z5.084112 E1952.689094 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.763414 Y198.044464 Z5.093458 E1954.568538 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.895333 Y197.612014 Z5.102804 E1956.44865 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.039781 Y197.183415 Z5.11215 E1958.329438 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.196645 Y196.759023 Z5.121495 E1960.210927 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.365807 Y196.339192 Z5.130841 E1962.093145 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.547135 Y195.924272 Z5.140187 E1963.976117 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.740491 Y195.514611 Z5.149533 E1965.85987 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.945724 Y195.110552 Z5.158879 E1967.744431 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.162674 Y194.712433 Z5.168224 E1969.629825 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.391175 Y194.320589 Z5.17757 E1971.516081 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.631819 Y193.935866 Z5.186916 E1973.403103 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.884242 Y193.558573 Z5.196262 E1975.290792 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.147587 Y193.188619 Z5.205607 E1977.179164 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.421644 Y192.826316 Z5.214953 E1979.068244 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.706196 Y192.471968 Z5.224299 E1980.958059 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.001014 Y192.125875 Z5.233645 E1982.848636 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.305864 Y191.788329 Z5.242991 E1984.740001 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.620503 Y191.459617 Z5.252336 E1986.632181 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.944679 Y191.140018 Z5.261682 E1988.525203 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.278132 Y190.829804 Z5.271028 E1990.419093 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.621484 Y190.530322 Z5.280374 E1992.313694 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.973691 Y190.241053 Z5.28972 E1994.208962 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.334262 Y189.962011 Z5.299065 E1996.104918 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.702908 Y189.693432 Z5.308411 E1998.001591 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.079328 Y189.435546 Z5.317757 E1999.899006 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.463218 Y189.188577 Z5.327103 E2001.79719 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.854268 Y188.952736 Z5.336449 E2003.696169 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.252159 Y188.728228 Z5.345794 E2005.595971 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.656569 Y188.515248 Z5.35514 E2007.496622 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.067235 Y188.314127 Z5.364486 E2009.398129 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.484346 Y188.126343 Z5.373832 E2011.300307 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.906872 Y187.950662 Z5.383178 E2013.203156 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.334467 Y187.787239 Z5.392523 E2015.1067 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.766782 Y187.636218 Z5.401869 E2017.010967 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.203464 Y187.497732 Z5.411215 E2018.915983 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.644155 Y187.371907 Z5.420561 E2020.821776 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.088494 Y187.258856 Z5.429907 E2022.728371 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.536116 Y187.158685 Z5.439252 E2024.635797 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.986656 Y187.071488 Z5.448598 E2026.544079 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.439825 Y186.997968 Z5.457944 E2028.453165 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.895237 Y186.938677 Z5.46729 E2030.362919 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.352336 Y186.89259 Z5.476636 E2032.27335 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.810748 Y186.859756 Z5.485981 E2034.184483 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.270095 Y186.840211 Z5.495327 E2036.096346 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.729997 Y186.833982 Z5.504673 E2038.008966 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.190074 Y186.841084 Z5.514019 E2039.922369 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.649948 Y186.861524 Z5.523364 E2041.836583 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.109237 Y186.895296 Z5.53271 E2043.751635 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.567562 Y186.942383 Z5.542056 E2045.667551 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.024363 Y187.003846 Z5.551402 E2047.584216 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.479247 Y187.079165 Z5.560748 E2049.501547 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.931918 Y187.167665 Z5.570093 E2051.419562 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.382002 Y187.269282 Z5.579439 E2053.338286 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.829125 Y187.383943 Z5.588785 E2055.257747 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.272913 Y187.511562 Z5.598131 E2057.177973 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.712999 Y187.652044 Z5.607477 E2059.098989 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.149015 Y187.805285 Z5.616822 E2061.020824 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.580597 Y187.971169 Z5.626168 E2062.943503 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.007385 Y188.149571 Z5.635514 E2064.867055 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.428323 Y188.341768 Z5.64486 E2066.7913 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.843589 Y188.546295 Z5.654206 E2068.71621 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.252901 Y188.762846 Z5.663551 E2070.64181 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.655917 Y188.991252 Z5.672897 E2072.568127 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.052298 Y189.231332 Z5.682243 E2074.495189 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.441712 Y189.482899 Z5.691589 E2076.423022 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.823831 Y189.745752 Z5.700935 E2078.351653 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.198333 Y190.019684 Z5.71028 E2080.281111 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.564903 Y190.304479 Z5.719626 E2082.211421 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.923021 Y190.60015 Z5.728972 E2084.142571 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.271601 Y190.90725 Z5.738318 E2086.074391 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.611255 Y191.224432 Z5.747664 E2088.006882 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.941694 Y191.55144 Z5.757009 E2089.94007 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.262639 Y191.888013 Z5.766355 E2091.873982 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.573818 Y192.233878 Z5.775701 E2093.808646 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.874966 Y192.588758 Z5.785047 E2095.744088 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.165825 Y192.952366 Z5.794393 E2097.680337 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.446147 Y193.32441 Z5.803738 E2099.617419 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.71569 Y193.704589 Z5.813084 E2101.555362 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.973546 Y194.093017 Z5.82243 E2103.494092 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.219314 Y194.489392 Z5.831776 E2105.433487 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.453575 Y194.892864 Z5.841121 E2107.37356 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.676127 Y195.303104 Z5.850467 E2109.314338 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.886778 Y195.719776 Z5.859813 E2111.255847 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.085345 Y196.142544 Z5.869159 E2113.198115 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.271654 Y196.57106 Z5.878505 E2115.141169 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.44554 Y197.004977 Z5.88785 E2117.085038 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.60685 Y197.443941 Z5.897196 E2119.029747 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.755438 Y197.887592 Z5.906542 E2120.975324 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.889938 Y198.335899 Z5.915888 E2122.921633 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.01097 Y198.788194 Z5.925234 E2124.868606 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.118883 Y199.243966 Z5.934579 E2126.816263 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.213579 Y199.702842 Z5.943925 E2128.764632 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.294969 Y200.164443 Z5.953271 E2130.71374 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.362977 Y200.628392 Z5.962617 E2132.663615 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.417535 Y201.094306 Z5.971963 E2134.614283 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.458586 Y201.561803 Z5.981308 E2136.565773 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.486087 Y202.030496 Z5.990654 E2138.518111 F2400 ; clayline kind=print page=0 layer=1 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.5 Y202.5 Z6 E2140.471326 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.504769 Y202.970053 Z6.009346 E2142.426065 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.495902 Y203.440391 Z6.018692 E2144.382239 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.473386 Y203.910626 Z6.028037 E2146.339873 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.437218 Y204.380367 Z6.037383 E2148.298997 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.387409 Y204.849226 Z6.046729 E2150.259636 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.323978 Y205.316811 Z6.056075 E2152.221819 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.246956 Y205.782733 Z6.065421 E2154.185573 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.156385 Y206.246604 Z6.074766 E2156.150927 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.052317 Y206.708036 Z6.084112 E2158.117907 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.934353 Y207.166502 Z6.093458 E2160.086455 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.801815 Y207.621312 Z6.102804 E2162.05637 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.656041 Y208.072417 Z6.11215 E2164.027725 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.497131 Y208.51944 Z6.121495 E2166.000549 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.325198 Y208.962004 Z6.130841 E2167.974868 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.140364 Y209.399734 Z6.140187 E2169.950711 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.942763 Y209.832261 Z6.149533 E2171.928106 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.732537 Y210.259219 Z6.158879 E2173.907079 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.509841 Y210.680244 Z6.168224 E2175.88766 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.274838 Y211.094978 Z6.17757 E2177.869876 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.026891 Y211.502524 Z6.186916 E2179.853578 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.766369 Y211.902548 Z6.196262 E2181.83867 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.494161 Y212.295137 Z6.205607 E2183.825209 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.210476 Y212.679956 Z6.214953 E2185.813224 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.91553 Y213.056672 Z6.224299 E2187.802742 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.609552 Y213.424964 Z6.233645 E2189.793791 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.292777 Y213.784511 Z6.242991 E2191.786399 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.965451 Y214.135002 Z6.252336 E2193.780594 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.627828 Y214.476133 Z6.261682 E2195.776405 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.28017 Y214.807604 Z6.271028 E2197.773859 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.921814 Y215.127986 Z6.280374 E2199.772716 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.55385 Y215.437813 Z6.28972 E2201.772986 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.176783 Y215.737059 Z6.299065 E2203.774712 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.790915 Y216.025462 Z6.308411 E2205.77792 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.39655 Y216.302765 Z6.317757 E2207.782638 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.994002 Y216.568724 Z6.327103 E2209.788895 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.583594 Y216.823099 Z6.336449 E2211.796719 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.165651 Y217.065661 Z6.345794 E2213.806138 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.740508 Y217.296192 Z6.35514 E2215.817181 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.308438 Y217.514328 Z6.364486 E2217.829847 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.869233 Y217.71849 Z6.373832 E2219.843865 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.423977 Y217.90997 Z6.383178 E2221.859317 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.97303 Y218.08859 Z6.392523 E2223.87623 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.516757 Y218.254184 Z6.401869 E2225.894633 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.055529 Y218.406596 Z6.411215 E2227.914554 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.589719 Y218.545679 Z6.420561 E2229.936021 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.119708 Y218.671297 Z6.429907 E2231.959064 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.645876 Y218.783325 Z6.439252 E2233.983709 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.168612 Y218.881649 Z6.448598 E2236.009987 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.688217 Y218.965504 Z6.457944 E2238.037808 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.205101 Y219.034293 Z6.46729 E2240.067002 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.719849 Y219.089086 Z6.476636 E2242.097636 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.232861 Y219.129818 Z6.485981 E2244.129739 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.744537 Y219.156435 Z6.495327 E2246.163339 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.25528 Y219.168893 Z6.504673 E2248.198465 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.765493 Y219.16716 Z6.514019 E2250.235145 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.275582 Y219.151218 Z6.523364 E2252.273408 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.785952 Y219.121055 Z6.53271 E2254.313283 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.297009 Y219.076674 Z6.542056 E2256.354798 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.80935 Y219.016933 Z6.551402 E2258.397774 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.323398 Y218.942366 Z6.560748 E2260.442145 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.839469 Y218.85368 Z6.570093 E2262.487964 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.357967 Y218.750928 Z6.579439 E2264.535259 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.879294 Y218.634175 Z6.588785 E2266.584058 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.403852 Y218.503497 Z6.598131 E2268.634391 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.932038 Y218.35898 Z6.607477 E2270.686286 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.46425 Y218.200724 Z6.616822 E2272.739773 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.000881 Y218.028837 Z6.626168 E2274.794879 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.542322 Y217.843441 Z6.635514 E2276.851635 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.089707 Y217.643152 Z6.64486 E2278.909766 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.642853 Y217.429527 Z6.654206 E2280.969316 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.202069 Y217.202878 Z6.663551 E2283.030321 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.767728 Y216.963373 Z6.672897 E2285.09281 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.340199 Y216.711193 Z6.682243 E2287.156811 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.919847 Y216.446528 Z6.691589 E2289.222353 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.50703 Y216.169577 Z6.700935 E2291.289465 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.102102 Y215.880552 Z6.71028 E2293.358178 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.705411 Y215.579672 Z6.719626 E2295.428519 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.317523 Y215.266913 Z6.728972 E2297.500458 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.939612 Y214.941668 Z6.738318 E2299.573757 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.571034 Y214.605372 Z6.747664 E2301.648489 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.212107 Y214.258288 Z6.757009 E2303.724682 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.863142 Y213.900688 Z6.766355 E2305.802367 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.524442 Y213.532853 Z6.775701 E2307.881571 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.196304 Y213.155072 Z6.785047 E2309.962325 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.879015 Y212.767644 Z6.794393 E2312.044658 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.572854 Y212.370874 Z6.803738 E2314.128598 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.278092 Y211.965077 Z6.813084 E2316.214176 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.995719 Y211.550122 Z6.82243 E2318.301271 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.726182 Y211.126325 Z6.831776 E2320.389746 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.468865 Y210.694594 Z6.841121 E2322.47966 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.224001 Y210.255276 Z6.850467 E2324.571044 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.991808 Y209.808725 Z6.859813 E2326.663927 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.772498 Y209.3553 Z6.869159 E2328.758337 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.566271 Y208.895365 Z6.878505 E2330.854305 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.373318 Y208.429293 Z6.88785 E2332.95186 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.193819 Y207.95746 Z6.897196 E2335.051032 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.027944 Y207.480247 Z6.906542 E2337.151849 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.877183 Y206.997684 Z6.915888 E2339.2541 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.740882 Y206.51049 Z6.925234 E2341.357752 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.618677 Y206.019212 Z6.934579 E2343.462852 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.51069 Y205.52425 Z6.943925 E2345.569428 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.417029 Y205.02601 Z6.953271 E2347.677511 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.337793 Y204.524899 Z6.962617 E2349.78713 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.27307 Y204.021328 Z6.971963 E2351.898314 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.222933 Y203.51571 Z6.981308 E2354.011094 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.187448 Y203.008462 Z6.990654 E2356.125499 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.166667 Y202.5 Z7 E2358.241559 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.162538 Y201.990807 Z7.009346 E2360.358966 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.173179 Y201.481365 Z7.018692 E2362.477797 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.198602 Y200.972096 Z7.028037 E2364.598083 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.238805 Y200.463422 Z7.037383 E2366.719854 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.293775 Y199.955765 Z7.046729 E2368.84314 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.36349 Y199.449547 Z7.056075 E2370.967969 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.447912 Y198.945189 Z7.065421 E2373.094372 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.546995 Y198.443112 Z7.074766 E2375.22238 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.660678 Y197.943735 Z7.084112 E2377.352021 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.789391 Y197.447628 Z7.093458 E2379.483237 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.933865 Y196.955537 Z7.102804 E2381.615817 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.092651 Y196.467514 Z7.11215 E2383.74983 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.265635 Y195.983968 Z7.121495 E2385.885306 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.452694 Y195.505304 Z7.130841 E2388.022273 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.653693 Y195.031928 Z7.140187 E2390.160763 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.868486 Y194.564237 Z7.149533 E2392.300806 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.096916 Y194.102629 Z7.158879 E2394.442431 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.338813 Y193.647493 Z7.168224 E2396.585668 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.593997 Y193.199218 Z7.17757 E2398.730549 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.863157 Y192.758772 Z7.186916 E2400.87692 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.14589 Y192.326515 Z7.196262 E2403.024677 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.441233 Y191.902351 Z7.205607 E2405.173873 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.748957 Y191.486643 Z7.214953 E2407.324539 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.068826 Y191.079747 Z7.224299 E2409.476706 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.400592 Y190.68201 Z7.233645 E2411.630403 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.743997 Y190.293777 Z7.242991 E2413.785661 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.098773 Y189.915383 Z7.252336 E2415.94251 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.464644 Y189.547155 Z7.261682 E2418.10098 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.841324 Y189.189415 Z7.271028 E2420.261103 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.229529 Y188.843708 Z7.280374 E2422.42263 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.62808 Y188.509453 Z7.28972 E2424.585564 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.036426 Y188.186676 Z7.299065 E2426.749946 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.454243 Y187.875659 Z7.308411 E2428.915805 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.881196 Y187.576676 Z7.317757 E2431.083173 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.316947 Y187.289992 Z7.327103 E2433.25208 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.761145 Y187.015862 Z7.336449 E2435.422555 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.213437 Y186.754531 Z7.345794 E2437.594631 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.67346 Y186.506235 Z7.35514 E2439.768337 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.140917 Y186.271361 Z7.364486 E2441.943674 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.616033 Y186.051617 Z7.373832 E2444.120363 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.097634 Y185.845602 Z7.383178 E2446.298477 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.585331 Y185.653507 Z7.392523 E2448.478046 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.078727 Y185.475508 Z7.401869 E2450.659101 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.577422 Y185.311773 Z7.411215 E2452.841672 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.08101 Y185.162457 Z7.420561 E2455.025791 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.589083 Y185.027704 Z7.429907 E2457.211487 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.101224 Y184.907647 Z7.439252 E2459.398792 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.617018 Y184.802408 Z7.448598 E2461.587736 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.136134 Y184.712808 Z7.457944 E2463.778229 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.658133 Y184.639493 Z7.46729 E2465.970093 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.18238 Y184.581302 Z7.476636 E2468.163388 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.708444 Y184.538303 Z7.485981 E2470.358147 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.235893 Y184.510552 Z7.495327 E2472.554399 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.76429 Y184.498094 Z7.504673 E2474.752176 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.293202 Y184.50096 Z7.514019 E2476.951509 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.822189 Y184.51917 Z7.523364 E2479.152428 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.350814 Y184.552731 Z7.53271 E2481.354965 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.87864 Y184.601638 Z7.542056 E2483.559151 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.40502 Y184.667124 Z7.551402 E2485.7648 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.929502 Y184.748606 Z7.560748 E2487.971839 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.451741 Y184.845321 Z7.570093 E2490.180319 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.971303 Y184.957207 Z7.579439 E2492.390269 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.487755 Y185.084194 Z7.588785 E2494.601721 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.000664 Y185.226196 Z7.598131 E2496.814707 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.509601 Y185.383117 Z7.607477 E2499.029256 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.014139 Y185.554848 Z7.616822 E2501.245401 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.513853 Y185.74127 Z7.626168 E2503.463173 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.008323 Y185.942249 Z7.635514 E2505.682602 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.496325 Y186.159274 Z7.64486 E2507.903408 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.978059 Y186.390665 Z7.654206 E2510.125625 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.453192 Y186.636083 Z7.663551 E2512.34929 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.921323 Y186.895343 Z7.672897 E2514.574435 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.382055 Y187.168248 Z7.682243 E2516.801089 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.834996 Y187.454593 Z7.691589 E2519.029285 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.27976 Y187.754158 Z7.700935 E2521.259054 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.715968 Y188.066714 Z7.71028 E2523.490428 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.143245 Y188.392022 Z7.719626 E2525.723437 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.560983 Y188.730106 Z7.728972 E2527.958052 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.967917 Y189.08162 Z7.738318 E2530.194025 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.364743 Y189.445013 Z7.747664 E2532.431422 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.75112 Y189.82 Z7.757009 E2534.670275 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.126715 Y190.206286 Z7.766355 E2536.910616 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.491201 Y190.603566 Z7.775701 E2539.152475 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.844263 Y191.011527 Z7.785047 E2541.395884 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.185591 Y191.429845 Z7.794393 E2543.640875 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.514887 Y191.858189 Z7.803738 E2545.88748 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.83186 Y192.296219 Z7.813084 E2548.135729 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.135445 Y192.744074 Z7.82243 E2550.385501 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.425165 Y193.201412 Z7.831776 E2552.636648 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.701682 Y193.667254 Z7.841121 E2554.889227 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.96475 Y194.141222 Z7.850467 E2557.143271 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.214134 Y194.622937 Z7.859813 E2559.39881 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.44961 Y195.112008 Z7.869159 E2561.655876 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.670963 Y195.608043 Z7.878505 E2563.9145 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.877991 Y196.110639 Z7.88785 E2566.174716 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.070501 Y196.61939 Z7.897196 E2568.436554 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.248313 Y197.133883 Z7.906542 E2570.700047 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.409822 Y197.654087 Z7.915888 E2572.964975 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.555738 Y198.179226 Z7.925234 E2575.231299 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.686454 Y198.70871 Z7.934579 E2577.499062 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.801842 Y199.242108 Z7.943925 E2579.768298 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.901786 Y199.778981 Z7.953271 E2582.039038 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.986184 Y200.318891 Z7.962617 E2584.311313 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.054943 Y200.861394 Z7.971963 E2586.585156 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.107985 Y201.406046 Z7.981308 E2588.860599 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.145245 Y201.952398 Z7.990654 E2591.137674 F2400 ; clayline kind=print page=0 layer=2 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.166667 Y202.5 Z8 E2593.416413 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.170155 Y203.048334 Z8.009346 E2595.696498 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.157739 Y203.596879 Z8.018692 E2597.977999 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.129411 Y204.145182 Z8.028037 E2600.260949 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.085172 Y204.692789 Z8.037383 E2602.545379 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.02504 Y205.239244 Z8.046729 E2604.831322 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.949042 Y205.784095 Z8.056075 E2607.11881 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.857219 Y206.326889 Z8.065421 E2609.407874 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.749625 Y206.867172 Z8.074766 E2611.698547 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.626328 Y207.404494 Z8.084112 E2613.990861 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.486865 Y207.938242 Z8.093458 E2616.284756 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.330454 Y208.467613 Z8.102804 E2618.580014 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.158658 Y208.992554 Z8.11215 E2620.876696 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.9716 Y209.512625 Z8.121495 E2623.174834 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.769414 Y210.027388 Z8.130841 E2625.474461 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.552249 Y210.536411 Z8.140187 E2627.77561 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.320264 Y211.039264 Z8.149533 E2630.078311 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.073631 Y211.535524 Z8.158879 E2632.382599 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.812534 Y212.024769 Z8.168224 E2634.688505 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.537167 Y212.506586 Z8.17757 E2636.996062 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.246795 Y212.979932 Z8.186916 E2639.305114 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.941851 Y213.444422 Z8.196262 E2641.615546 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.623373 Y213.90016 Z8.205607 E2643.92741 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.291609 Y214.346758 Z8.214953 E2646.240739 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.946817 Y214.783834 Z8.224299 E2648.555566 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.589264 Y215.211016 Z8.233645 E2650.871922 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.21923 Y215.627935 Z8.242991 E2653.189841 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.837004 Y216.034232 Z8.252336 E2655.509355 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.442885 Y216.429557 Z8.261682 E2657.830496 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.037182 Y216.813566 Z8.271028 E2660.153298 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.619127 Y217.184599 Z8.280374 E2662.477507 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.18999 Y217.543282 Z8.28972 E2664.803115 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.750364 Y217.88959 Z8.299065 E2667.130164 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.3006 Y218.223221 Z8.308411 E2669.458687 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.841058 Y218.543882 Z8.317757 E2671.788715 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.372104 Y218.851292 Z8.327103 E2674.120282 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.894116 Y219.145177 Z8.336449 E2676.45342 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.407475 Y219.425277 Z8.345794 E2678.788163 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.912572 Y219.691339 Z8.35514 E2681.124543 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.409727 Y219.94295 Z8.364486 E2683.462563 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.898701 Y220.178277 Z8.373832 E2685.801933 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.380755 Y220.398825 Z8.383178 E2688.14272 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.856309 Y220.604396 Z8.392523 E2690.484956 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.32579 Y220.794799 Z8.401869 E2692.828673 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.789628 Y220.969858 Z8.411215 E2695.173906 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.24826 Y221.129408 Z8.420561 E2697.520686 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.702127 Y221.273295 Z8.429907 E2699.869047 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.151675 Y221.401381 Z8.439252 E2702.219021 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.597353 Y221.513535 Z8.448598 E2704.570643 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.039514 Y221.608879 Z8.457944 E2706.923819 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.478633 Y221.686721 Z8.46729 E2709.278362 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.915391 Y221.748311 Z8.476636 E2711.63433 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.350251 Y221.793576 Z8.485981 E2713.991755 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.783678 Y221.822461 Z8.495327 E2716.35067 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.216139 Y221.834919 Z8.504673 E2718.711109 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.648104 Y221.830919 Z8.514019 E2721.073105 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.08004 Y221.810442 Z8.523364 E2723.436691 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.51242 Y221.773483 Z8.53271 E2725.8019 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.945712 Y221.720049 Z8.542056 E2728.168766 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.380609 Y221.648819 Z8.551402 E2730.5371 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.817599 Y221.560421 Z8.560748 E2732.906817 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.257049 Y221.455678 Z8.570093 E2735.277968 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.699426 Y221.334657 Z8.579439 E2737.650584 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.145195 Y221.197437 Z8.588785 E2740.0247 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.594819 Y221.044111 Z8.598131 E2742.400348 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.048759 Y220.874786 Z8.607477 E2744.777562 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.507472 Y220.689579 Z8.616822 E2747.156376 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.971413 Y220.488623 Z8.626168 E2749.536823 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.441032 Y220.272062 Z8.635514 E2751.918936 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.917643 Y220.0383 Z8.64486 E2754.302427 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.401029 Y219.789142 Z8.654206 E2756.687321 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.891547 Y219.524956 Z8.663551 E2759.073656 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.389626 Y219.245941 Z8.672897 E2761.461466 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.895691 Y218.95231 Z8.682243 E2763.850785 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.410161 Y218.644287 Z8.691589 E2766.241645 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.93345 Y218.322108 Z8.700935 E2768.63408 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.465962 Y217.986021 Z8.71028 E2771.028125 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.008099 Y217.636285 Z8.719626 E2773.423812 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.560511 Y217.272875 Z8.728972 E2775.821113 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.124555 Y216.895092 Z8.738318 E2778.21977 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.69948 Y216.504602 Z8.747664 E2780.619843 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.285653 Y216.101712 Z8.757009 E2783.021366 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.883429 Y215.68674 Z8.766355 E2785.424372 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.493155 Y215.260015 Z8.775701 E2787.828896 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.11517 Y214.821874 Z8.785047 E2790.23497 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.749803 Y214.372667 Z8.794393 E2792.642629 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.397372 Y213.912748 Z8.803738 E2795.051907 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.058188 Y213.442485 Z8.813084 E2797.462838 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.73339 Y212.96173 Z8.82243 E2799.875297 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.423489 Y212.47085 Z8.831776 E2802.289126 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.127772 Y211.970899 Z8.841121 E2804.70438 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.8465 Y211.462279 Z8.850467 E2807.121093 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.579923 Y210.945402 Z8.859813 E2809.539297 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.328282 Y210.420684 Z8.869159 E2811.959029 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.091802 Y209.88855 Z8.878505 E2814.38032 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.8707 Y209.34943 Z8.88785 E2816.803206 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.665179 Y208.803761 Z8.897196 E2819.227721 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.475431 Y208.251987 Z8.906542 E2821.653898 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.303173 Y207.694142 Z8.915888 E2824.081514 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.147642 Y207.131058 Z8.925234 E2826.510518 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.008415 Y206.563367 Z8.934579 E2828.940955 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.885627 Y205.991535 Z8.943925 E2831.37286 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.779399 Y205.416029 Z8.953271 E2833.806266 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.689839 Y204.83732 Z8.962617 E2836.241207 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.617044 Y204.255884 Z8.971963 E2838.677718 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.561096 Y203.672198 Z8.981308 E2841.115834 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.522062 Y203.086743 Z8.990654 E2843.555588 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.5 Y202.5 Z9 E2845.997015 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.497152 Y201.912525 Z9.009346 E2848.439788 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.511342 Y201.324877 Z9.018692 E2850.883969 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.542576 Y200.73754 Z9.028037 E2853.329592 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.590851 Y200.151001 Z9.037383 E2855.776691 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.656145 Y199.565746 Z9.046729 E2858.2253 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.738427 Y198.982262 Z9.056075 E2860.675455 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.83765 Y198.401034 Z9.065421 E2863.127189 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.953755 Y197.822545 Z9.074766 E2865.580537 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.086667 Y197.247277 Z9.084112 E2868.035533 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.236878 Y196.675888 Z9.093458 E2870.492118 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.405226 Y196.109236 Z9.102804 E2872.950061 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.590033 Y195.547377 Z9.11215 E2875.409421 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.791166 Y194.990783 Z9.121495 E2877.870232 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.008478 Y194.43992 Z9.130841 E2880.332528 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.241809 Y193.895251 Z9.140187 E2882.796344 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.490985 Y193.357234 Z9.149533 E2885.261714 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.755822 Y192.826324 Z9.158879 E2887.728674 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.03612 Y192.302968 Z9.168224 E2890.197257 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.331668 Y191.78761 Z9.17757 E2892.667499 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.643253 Y191.281364 Z9.186916 E2895.139241 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.970409 Y190.784641 Z9.196262 E2897.612357 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.312021 Y190.297329 Z9.205607 E2900.086898 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.667824 Y189.819841 Z9.214953 E2902.562899 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.037539 Y189.352585 Z9.224299 E2905.040395 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.420879 Y188.895958 Z9.233645 E2907.51942 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.817543 Y188.450354 Z9.242991 E2910.000008 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.227219 Y188.016153 Z9.252336 E2912.482196 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.649587 Y187.593731 Z9.261682 E2914.966018 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.084312 Y187.183454 Z9.271028 E2917.451508 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.532217 Y186.787095 Z9.280374 E2919.938407 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.99194 Y186.403984 Z9.28972 E2922.426699 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.462846 Y186.034145 Z9.299065 E2924.916424 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.944557 Y185.6779 Z9.308411 E2927.407618 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.436688 Y185.33556 Z9.317757 E2929.900315 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.938845 Y185.007425 Z9.327103 E2932.394551 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.450623 Y184.693784 Z9.336449 E2934.890361 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.971613 Y184.394916 Z9.345794 E2937.38778 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.501395 Y184.111087 Z9.35514 E2939.886843 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.039628 Y183.842739 Z9.364486 E2942.387554 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.586565 Y183.59183 Z9.373832 E2944.889614 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.140856 Y183.356747 Z9.383178 E2947.393083 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.702051 Y183.137702 Z9.392523 E2949.897994 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.269694 Y182.934894 Z9.401869 E2952.404383 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.843323 Y182.748511 Z9.411215 E2954.912285 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.42247 Y182.578728 Z9.420561 E2957.421736 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.006664 Y182.425706 Z9.429907 E2959.93277 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.595426 Y182.289592 Z9.439252 E2962.445423 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.188277 Y182.170521 Z9.448598 E2964.95973 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.784838 Y182.069434 Z9.457944 E2967.475598 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.384601 Y181.987065 Z9.46729 E2969.99283 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.986838 Y181.922077 Z9.476636 E2972.511478 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.591055 Y181.874544 Z9.485981 E2975.031577 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.196752 Y181.844526 Z9.495327 E2977.553164 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.803431 Y181.832068 Z9.504673 E2980.076274 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.410591 Y181.837202 Z9.514019 E2982.600941 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.01773 Y181.859946 Z9.523364 E2985.127202 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.624346 Y181.900303 Z9.53271 E2987.655092 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.229936 Y181.958264 Z9.542056 E2990.184647 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.833761 Y182.035237 Z9.551402 E2992.715673 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.4353 Y182.130551 Z9.560748 E2995.248077 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.03416 Y182.243322 Z9.570093 E2997.781907 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.629844 Y182.373479 Z9.579439 E3000.317198 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.221854 Y182.520932 Z9.588785 E3002.853985 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.809697 Y182.685581 Z9.598131 E3005.392304 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.392881 Y182.867311 Z9.607477 E3007.932191 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.970917 Y183.065993 Z9.616822 E3010.473682 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.543321 Y183.281483 Z9.626168 E3013.016813 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.109612 Y183.513627 Z9.635514 E3015.561618 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.66839 Y183.764126 Z9.64486 E3018.107802 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.219883 Y184.03105 Z9.654206 E3020.655382 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.763714 Y184.314005 Z9.663551 E3023.204395 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.299425 Y184.612775 Z9.672897 E3025.754879 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.826563 Y184.927132 Z9.682243 E3028.30687 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.344682 Y185.256834 Z9.691589 E3030.860402 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.853341 Y185.601627 Z9.700935 E3033.415512 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.352108 Y185.961245 Z9.71028 E3035.972236 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.840557 Y186.335409 Z9.719626 E3038.530609 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.317994 Y186.724145 Z9.728972 E3041.090604 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.782974 Y187.128196 Z9.738318 E3043.651953 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.236296 Y187.545783 Z9.747664 E3046.21471 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.677574 Y187.976576 Z9.757009 E3048.778911 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.106427 Y188.420234 Z9.766355 E3051.344591 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.522488 Y188.876404 Z9.775701 E3053.911787 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.925397 Y189.344725 Z9.785047 E3056.480534 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.314803 Y189.824822 Z9.794393 E3059.05087 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.690368 Y190.316315 Z9.803738 E3061.62283 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.051764 Y190.818811 Z9.813084 E3064.19645 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.397775 Y191.332465 Z9.82243 E3066.771603 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.727858 Y191.856887 Z9.831776 E3069.348122 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.042775 Y192.390949 Z9.841121 E3071.926059 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.342251 Y192.934219 Z9.850467 E3074.505448 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.626019 Y193.48626 Z9.859813 E3077.086327 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.893826 Y194.046624 Z9.869159 E3079.668731 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.145432 Y194.614858 Z9.878505 E3082.252697 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.380609 Y195.190502 Z9.88785 E3084.838262 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.599141 Y195.773088 Z9.897196 E3087.42546 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.800825 Y196.362143 Z9.906542 E3090.01433 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.983833 Y196.957629 Z9.915888 E3092.604641 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.148978 Y197.558658 Z9.925234 E3095.196334 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.296716 Y198.164555 Z9.934579 E3097.789452 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.426905 Y198.774823 Z9.943925 E3100.384034 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.539416 Y199.388962 Z9.953271 E3102.980114 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.634138 Y200.006469 Z9.962617 E3105.577729 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.710968 Y200.626838 Z9.971963 E3108.176916 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.769823 Y201.249558 Z9.981308 E3110.777712 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.81063 Y201.874116 Z9.990654 E3113.380153 F2400 ; clayline kind=print page=0 layer=3 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.833333 Y202.5 Z10 E3115.984276 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.835541 Y203.126615 Z10.009346 E3118.589745 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.819577 Y203.753367 Z10.018692 E3121.196612 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.785436 Y204.379739 Z10.028037 E3123.804916 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.733126 Y205.00521 Z10.037383 E3126.414691 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.66267 Y205.629263 Z10.046729 E3129.025975 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.574105 Y206.25138 Z10.056075 E3131.638805 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.467481 Y206.871044 Z10.065421 E3134.253216 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.342866 Y207.487739 Z10.074766 E3136.869246 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.200338 Y208.100951 Z10.084112 E3139.486933 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.039378 Y208.709982 Z10.093458 E3142.106213 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.859094 Y209.313915 Z10.102804 E3144.726851 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.661276 Y209.912691 Z10.11215 E3147.348896 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.446069 Y210.505809 Z10.121495 E3149.972387 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.21363 Y211.092772 Z10.130841 E3152.597359 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.964133 Y211.673087 Z10.140187 E3155.22385 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.697765 Y212.246267 Z10.149533 E3157.851896 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.414725 Y212.811829 Z10.158879 E3160.481535 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.115226 Y213.369295 Z10.168224 E3163.112803 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.799497 Y213.918194 Z10.17757 E3165.745737 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.466699 Y214.45734 Z10.186916 E3168.380176 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.117332 Y214.986296 Z10.196262 E3171.015985 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.752585 Y215.505182 Z10.205607 E3173.65321 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.372743 Y216.01356 Z10.214953 E3176.291891 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.978104 Y216.510996 Z10.224299 E3178.932062 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.568977 Y216.997068 Z10.233645 E3181.573763 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.145684 Y217.471358 Z10.242991 E3184.217029 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.708557 Y217.933462 Z10.252336 E3186.861897 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.257942 Y218.382981 Z10.261682 E3189.508406 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.794194 Y218.819527 Z10.271028 E3192.156593 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.316439 Y219.241211 Z10.280374 E3194.80619 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.826129 Y219.648751 Z10.28972 E3197.457171 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.323944 Y220.042121 Z10.299065 E3200.10958 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.810286 Y220.42098 Z10.308411 E3202.763452 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.285566 Y220.784999 Z10.317757 E3205.418826 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.750206 Y221.133859 Z10.327103 E3208.075739 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.204638 Y221.467255 Z10.336449 E3210.734227 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.649299 Y221.784892 Z10.345794 E3213.394329 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.084637 Y222.086487 Z10.35514 E3216.056082 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.511017 Y222.371571 Z10.364486 E3218.719491 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.928169 Y222.638063 Z10.373832 E3221.384249 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.337533 Y222.887681 Z10.383178 E3224.050406 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.739588 Y223.120201 Z10.392523 E3226.718 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.134822 Y223.335413 Z10.401869 E3229.387068 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.523726 Y223.533119 Z10.411215 E3232.057647 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.9068 Y223.713136 Z10.420561 E3234.729774 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.284546 Y223.875294 Z10.429907 E3237.403489 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.657473 Y224.019436 Z10.439252 E3240.078827 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.026094 Y224.145422 Z10.448598 E3242.755827 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.390811 Y224.252253 Z10.457944 E3245.434394 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.752165 Y224.339149 Z10.46729 E3248.114321 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.110932 Y224.407535 Z10.476636 E3250.795656 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.46764 Y224.457335 Z10.485981 E3253.478438 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.822818 Y224.488487 Z10.495327 E3256.162703 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.176999 Y224.500945 Z10.504673 E3258.84849 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.530714 Y224.494677 Z10.514019 E3261.535836 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.884499 Y224.469666 Z10.523364 E3264.224779 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.238888 Y224.425911 Z10.53271 E3266.915357 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.594415 Y224.363423 Z10.542056 E3269.607608 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.951868 Y224.280706 Z10.551402 E3272.301333 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.311801 Y224.178477 Z10.560748 E3274.996431 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.67463 Y224.057677 Z10.570093 E3277.692946 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.040886 Y223.918386 Z10.579439 E3280.390918 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.411097 Y223.760699 Z10.588785 E3283.090384 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.785787 Y223.584726 Z10.598131 E3285.791381 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.16548 Y223.390592 Z10.607477 E3288.493948 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.550694 Y223.178435 Z10.616822 E3291.198123 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.941944 Y222.94841 Z10.626168 E3293.903944 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.339743 Y222.700684 Z10.635514 E3296.611449 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.745578 Y222.433447 Z10.64486 E3299.320332 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.159205 Y222.148758 Z10.654206 E3302.030603 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.581025 Y221.847034 Z10.663551 E3304.742302 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.011524 Y221.528509 Z10.672897 E3307.455467 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.451183 Y221.193427 Z10.682243 E3310.170136 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.900476 Y220.842046 Z10.691589 E3312.886347 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.359869 Y220.474639 Z10.700935 E3315.604138 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.829822 Y220.09149 Z10.71028 E3318.323548 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.310787 Y219.692897 Z10.719626 E3321.044615 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.8035 Y219.278836 Z10.728972 E3323.76731 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.309498 Y218.848516 Z10.738318 E3326.491358 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.827927 Y218.403832 Z10.747664 E3329.216805 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.3592 Y217.945136 Z10.757009 E3331.94369 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.903716 Y217.472792 Z10.766355 E3334.672051 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.461868 Y216.987177 Z10.775701 E3337.401925 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.034037 Y216.488677 Z10.785047 E3340.133353 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.620591 Y215.977689 Z10.794393 E3342.866371 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.221891 Y215.454622 Z10.803738 E3345.601019 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.838285 Y214.919893 Z10.813084 E3348.337335 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.47106 Y214.373339 Z10.82243 E3351.075189 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.120796 Y213.815376 Z10.831776 E3353.814406 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.786678 Y213.247204 Z10.841121 E3356.555031 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.468999 Y212.669282 Z10.850467 E3359.297104 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.168039 Y212.082079 Z10.859813 E3362.040664 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.884066 Y211.486068 Z10.869159 E3364.785747 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.617333 Y210.881734 Z10.878505 E3367.532394 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.368082 Y210.269567 Z10.88785 E3370.280643 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.13654 Y209.650063 Z10.897196 E3373.030532 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.922918 Y209.023727 Z10.906542 E3375.782101 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.729162 Y208.3906 Z10.915888 E3378.535114 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.554401 Y207.751625 Z10.925234 E3381.289501 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.398153 Y207.107523 Z10.934579 E3384.045308 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.260564 Y206.45882 Z10.943925 E3386.802572 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.141768 Y205.806047 Z10.953271 E3389.561333 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.041885 Y205.149741 Z10.962617 E3392.321628 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.961019 Y204.49044 Z10.971963 E3395.083498 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.899258 Y203.828687 Z10.981308 E3397.84698 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.856677 Y203.165024 Z10.990654 E3400.612114 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.833333 Y202.5 Z11 E3403.378939 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.831767 Y201.834244 Z11.009346 E3406.14711 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.849504 Y201.168388 Z11.018692 E3408.916671 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.886551 Y200.502983 Z11.028037 E3411.687661 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.942897 Y199.838579 Z11.037383 E3414.460119 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.018515 Y199.175727 Z11.046729 E3417.234084 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.113364 Y198.514977 Z11.056075 E3420.009594 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.227388 Y197.856878 Z11.065421 E3422.78669 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.360514 Y197.201977 Z11.074766 E3425.565409 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.512656 Y196.55082 Z11.084112 E3428.345791 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.684366 Y195.904148 Z11.093458 E3431.127774 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.876586 Y195.262934 Z11.102804 E3433.911112 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.087415 Y194.62724 Z11.11215 E3436.695849 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.316697 Y193.997599 Z11.121495 E3439.482026 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.564262 Y193.374536 Z11.130841 E3442.26968 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.829924 Y192.758574 Z11.140187 E3445.058852 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.113485 Y192.150231 Z11.149533 E3447.84958 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.414728 Y191.550019 Z11.158879 E3450.641904 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.733427 Y190.958442 Z11.168224 E3453.435863 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.069338 Y190.376002 Z11.17757 E3456.231497 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.423349 Y189.803955 Z11.186916 E3459.028638 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.794928 Y189.242767 Z11.196262 E3461.827145 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.182809 Y188.692306 Z11.205607 E3464.627061 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.58669 Y188.153039 Z11.214953 E3467.428427 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.006252 Y187.625422 Z11.224299 E3470.231281 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.441166 Y187.109906 Z11.233645 E3473.035663 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.891089 Y186.60693 Z11.242991 E3475.841612 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.355666 Y186.116923 Z11.252336 E3478.649168 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.834529 Y185.640307 Z11.261682 E3481.45837 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.3273 Y185.177492 Z11.271028 E3484.269258 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.834905 Y184.730482 Z11.280374 E3487.081559 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.355801 Y184.298514 Z11.28972 E3489.895237 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.889266 Y183.881614 Z11.299065 E3492.710335 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.434872 Y183.480141 Z11.308411 E3495.526892 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.99218 Y183.094443 Z11.317757 E3498.344948 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.560743 Y182.724857 Z11.327103 E3501.164543 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.140101 Y182.371706 Z11.336449 E3503.985716 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.729789 Y182.035301 Z11.345794 E3506.808507 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.329331 Y181.71594 Z11.35514 E3509.632956 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.938339 Y181.414118 Z11.364486 E3512.459069 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.557097 Y181.132044 Z11.373832 E3515.28653 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.184078 Y180.867891 Z11.383178 E3518.115382 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.818772 Y180.621896 Z11.392523 E3520.945664 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.460662 Y180.394279 Z11.401869 E3523.777416 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.109224 Y180.18525 Z11.411215 E3526.610678 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.76393 Y179.995 Z11.420561 E3529.445489 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.424244 Y179.823707 Z11.429907 E3532.281889 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.089628 Y179.671536 Z11.439252 E3535.119919 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.759536 Y179.538635 Z11.448598 E3537.959618 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.433541 Y179.42606 Z11.457944 E3540.800889 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.111069 Y179.334637 Z11.46729 E3543.643517 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.791297 Y179.262853 Z11.476636 E3546.487546 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.473665 Y179.210786 Z11.485981 E3549.333015 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.157611 Y179.1785 Z11.495327 E3552.179964 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.842572 Y179.166042 Z11.504673 E3555.028434 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.52798 Y179.173444 Z11.514019 E3557.878464 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.213272 Y179.200722 Z11.523364 E3560.730095 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.897878 Y179.247875 Z11.53271 E3563.583366 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.581233 Y179.31489 Z11.542056 E3566.438319 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.262502 Y179.403351 Z11.551402 E3569.294749 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.941098 Y179.512496 Z11.560748 E3572.152546 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.616579 Y179.641324 Z11.570093 E3575.011754 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.288384 Y179.78975 Z11.579439 E3577.872412 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.955953 Y179.95767 Z11.588785 E3580.734562 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.618729 Y180.144967 Z11.598131 E3583.598243 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.27616 Y180.351506 Z11.607477 E3586.463496 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.927695 Y180.577137 Z11.616822 E3589.33036 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.57279 Y180.821697 Z11.626168 E3592.198877 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.210902 Y181.085006 Z11.635514 E3595.069086 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.840454 Y181.368979 Z11.64486 E3597.940675 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.461707 Y181.671435 Z11.654206 E3600.813644 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.074236 Y181.991927 Z11.663551 E3603.688034 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.677527 Y182.330207 Z11.672897 E3606.563885 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.271071 Y182.686015 Z11.682243 E3609.441238 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.854367 Y183.059075 Z11.691589 E3612.320133 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.426921 Y183.449096 Z11.700935 E3615.200611 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.988247 Y183.855776 Z11.71028 E3618.082712 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.537869 Y184.278796 Z11.719626 E3620.966478 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.075006 Y184.718183 Z11.728972 E3623.851879 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.598031 Y185.174772 Z11.738318 E3626.738631 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.10785 Y185.646553 Z11.747664 E3629.626774 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.604027 Y186.133152 Z11.757009 E3632.516349 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.08614 Y186.634182 Z11.766355 E3635.407395 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.553775 Y187.149242 Z11.775701 E3638.299955 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.00653 Y187.677922 Z11.785047 E3641.194067 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.444015 Y188.2198 Z11.794393 E3644.089774 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.865849 Y188.774441 Z11.803738 E3646.987116 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.271667 Y189.341402 Z11.813084 E3649.886133 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.660104 Y189.920857 Z11.82243 E3652.786694 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.03055 Y190.512361 Z11.831776 E3655.688612 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.383869 Y191.114644 Z11.841121 E3658.591932 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.719752 Y191.727216 Z11.850467 E3661.496694 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.037903 Y192.349583 Z11.859813 E3664.402939 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.338042 Y192.98124 Z11.869159 E3667.310708 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.619901 Y193.621674 Z11.878505 E3670.220041 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.883226 Y194.270365 Z11.88785 E3673.13098 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.12778 Y194.926786 Z11.897196 E3676.043565 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.353338 Y195.590403 Z11.906542 E3678.957838 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.557844 Y196.261171 Z11.915888 E3681.873558 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.742219 Y196.938091 Z11.925234 E3684.790646 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.906979 Y197.620399 Z11.934579 E3687.709145 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.051968 Y198.307538 Z11.943925 E3690.629098 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.177047 Y198.998943 Z11.953271 E3693.550544 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.282092 Y199.694048 Z11.962617 E3696.473525 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.366993 Y200.392281 Z11.971963 E3699.398082 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.43166 Y201.093069 Z11.981308 E3702.324257 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.476016 Y201.795835 Z11.990654 E3705.252089 F2400 ; clayline kind=print page=0 layer=4 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.5 Y202.5 Z12 E3708.181621 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.500926 Y203.204896 Z12.009346 E3711.1125 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.481414 Y203.909856 Z12.018692 E3714.044759 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.441461 Y204.614295 Z12.028037 E3716.978442 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.38108 Y205.317631 Z12.037383 E3719.913588 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.300301 Y206.019282 Z12.046729 E3722.850238 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.199168 Y206.718665 Z12.056075 E3725.788435 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.077743 Y207.4152 Z12.065421 E3728.728219 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.936106 Y208.108307 Z12.074766 E3731.669632 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.774349 Y208.797409 Z12.084112 E3734.612715 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.591891 Y209.481722 Z12.093458 E3737.557406 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.387734 Y210.160217 Z12.102804 E3740.503449 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.163894 Y210.832828 Z12.11215 E3743.450883 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.920537 Y211.498994 Z12.121495 E3746.399751 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.657846 Y212.158156 Z12.130841 E3749.350093 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.376018 Y212.809764 Z12.140187 E3752.301951 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.075266 Y213.45327 Z12.149533 E3755.255366 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.755819 Y214.088134 Z12.158879 E3758.210381 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.417919 Y214.71382 Z12.168224 E3761.167036 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.061826 Y215.329802 Z12.17757 E3764.125373 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.686603 Y215.934749 Z12.186916 E3767.085223 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.292813 Y216.52817 Z12.196262 E3770.046433 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.881797 Y217.110205 Z12.205607 E3773.009045 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.453877 Y217.680362 Z12.214953 E3775.973101 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.009391 Y218.238159 Z12.224299 E3778.938642 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.54869 Y218.78312 Z12.233645 E3781.905711 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.072137 Y219.314782 Z12.242991 E3784.874348 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.580111 Y219.832692 Z12.252336 E3787.844596 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.072999 Y220.336405 Z12.261682 E3790.816497 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.551206 Y220.825488 Z12.271028 E3793.790092 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.013751 Y221.297824 Z12.280374 E3796.765101 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.462269 Y221.75422 Z12.28972 E3799.74148 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.897524 Y222.194652 Z12.299065 E3802.719272 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.319971 Y222.618739 Z12.308411 E3805.698519 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.730074 Y223.026115 Z12.317757 E3808.679263 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.128308 Y223.416427 Z12.327103 E3811.661545 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.51516 Y223.789333 Z12.336449 E3814.645408 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.891122 Y224.144507 Z12.345794 E3817.630893 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.256701 Y224.481634 Z12.35514 E3820.618043 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.612306 Y224.800193 Z12.364486 E3823.606865 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.957638 Y225.097849 Z12.373832 E3826.597034 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.294311 Y225.376536 Z12.383178 E3829.588586 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.622868 Y225.636007 Z12.392523 E3832.581561 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.943854 Y225.876028 Z12.401869 E3835.576002 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.257825 Y226.096381 Z12.411215 E3838.571951 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.56534 Y226.296865 Z12.420561 E3841.569451 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.866965 Y226.477292 Z12.429907 E3844.568542 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.163271 Y226.637491 Z12.439252 E3847.569268 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.454835 Y226.777309 Z12.448598 E3850.57167 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.742107 Y226.895627 Z12.457944 E3853.575651 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.025697 Y226.991577 Z12.46729 E3856.580985 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.306474 Y227.066759 Z12.476636 E3859.587711 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.58503 Y227.121093 Z12.485981 E3862.595873 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.861959 Y227.154513 Z12.495327 E3865.605511 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.137858 Y227.166971 Z12.504673 E3868.616669 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.413325 Y227.158435 Z12.514019 E3871.629388 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.688958 Y227.128891 Z12.523364 E3874.643711 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.965356 Y227.078339 Z12.53271 E3877.659681 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.243119 Y227.006797 Z12.542056 E3880.67734 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.523127 Y226.912592 Z12.551402 E3883.69648 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.806003 Y226.796532 Z12.560748 E3886.716981 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.092211 Y226.659675 Z12.570093 E3889.738885 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.382346 Y226.502114 Z12.579439 E3892.762236 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.676998 Y226.32396 Z12.588785 E3895.787074 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.976755 Y226.12534 Z12.598131 E3898.813444 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.2822 Y225.906397 Z12.607477 E3901.841386 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.593916 Y225.66729 Z12.616822 E3904.870945 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.912476 Y225.408196 Z12.626168 E3907.902162 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.238454 Y225.129305 Z12.635514 E3910.935081 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.573514 Y224.828595 Z12.64486 E3913.96938 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.917381 Y224.508373 Z12.654206 E3917.005051 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.270503 Y224.169112 Z12.663551 E3920.042136 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.633422 Y223.811077 Z12.672897 E3923.080679 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.006675 Y223.434543 Z12.682243 E3926.120721 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.39079 Y223.039805 Z12.691589 E3929.162305 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.786289 Y222.62717 Z12.700935 E3932.205474 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.193683 Y222.196959 Z12.71028 E3935.250272 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.613475 Y221.74951 Z12.719626 E3938.29674 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.046488 Y221.284797 Z12.728972 E3941.344853 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.49444 Y220.80194 Z12.738318 E3944.394313 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.956374 Y220.303062 Z12.747664 E3947.445157 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.432746 Y219.788559 Z12.757009 E3950.497426 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.924003 Y219.258844 Z12.766355 E3953.551163 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.430581 Y218.714339 Z12.775701 E3956.606411 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.952903 Y218.155479 Z12.785047 E3959.663214 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.491379 Y217.582712 Z12.794393 E3962.721614 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.04641 Y216.996496 Z12.803738 E3965.781653 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.618381 Y216.397302 Z12.813084 E3968.843377 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.208731 Y215.784947 Z12.82243 E3971.906648 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.818103 Y215.159901 Z12.831776 E3974.971274 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.445584 Y214.523509 Z12.841121 E3978.037293 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.091498 Y213.876285 Z12.850467 E3981.104748 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.756154 Y213.218755 Z12.859813 E3984.173684 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.43985 Y212.551452 Z12.869159 E3987.244142 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.142865 Y211.874918 Z12.878505 E3990.316166 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.865465 Y211.189703 Z12.88785 E3993.389799 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.6079 Y210.496365 Z12.897196 E3996.465085 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.370406 Y209.795466 Z12.906542 E3999.542067 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.155151 Y209.087057 Z12.915888 E4002.620497 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.961161 Y208.372193 Z12.925234 E4005.70029 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.78789 Y207.651679 Z12.934579 E4008.781487 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.635501 Y206.926105 Z12.943925 E4011.864133 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.504138 Y206.196066 Z12.953271 E4014.948269 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.393931 Y205.462163 Z12.962617 E4018.03394 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.304994 Y204.724997 Z12.971963 E4021.121189 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.237421 Y203.985175 Z12.981308 E4024.21006 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.191291 Y203.243305 Z12.990654 E4027.300595 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.166667 Y202.5 Z13 E4030.392839 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.166381 Y201.755963 Z13.009346 E4033.486429 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.187667 Y201.0119 Z13.018692 E4036.581392 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.230526 Y200.268427 Z13.028037 E4039.677771 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.294943 Y199.526158 Z13.037383 E4042.775609 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.380884 Y198.785709 Z13.046729 E4045.87495 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.488301 Y198.047693 Z13.056075 E4048.975837 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.617125 Y197.312722 Z13.065421 E4052.078315 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.767274 Y196.581409 Z13.074766 E4055.182426 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.938646 Y195.854362 Z13.084112 E4058.288214 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.131853 Y195.132408 Z13.093458 E4061.395618 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.347946 Y194.416632 Z13.102804 E4064.50437 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.584797 Y193.707104 Z13.11215 E4067.614506 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.842228 Y193.004414 Z13.121495 E4070.726069 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.120046 Y192.309152 Z13.130841 E4073.839103 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.41804 Y191.621898 Z13.140187 E4076.953651 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.735984 Y190.943228 Z13.149533 E4080.069758 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.073635 Y190.273714 Z13.158879 E4083.187467 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.430734 Y189.613917 Z13.168224 E4086.306823 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.807009 Y188.964394 Z13.17757 E4089.427868 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.203445 Y188.326547 Z13.186916 E4092.550431 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.619446 Y187.700893 Z13.196262 E4095.674348 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.053598 Y187.087284 Z13.205607 E4098.79966 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.505556 Y186.486237 Z13.214953 E4101.92641 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.974965 Y185.89826 Z13.224299 E4105.054643 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.461454 Y185.323854 Z13.233645 E4108.184403 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.964636 Y184.763506 Z13.242991 E4111.315733 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.484113 Y184.217693 Z13.252336 E4114.448677 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.019472 Y183.686883 Z13.261682 E4117.58328 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.570288 Y183.171531 Z13.271028 E4120.719587 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.137593 Y182.67387 Z13.280374 E4123.857309 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.719661 Y182.193045 Z13.28972 E4126.996393 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.315685 Y181.729083 Z13.299065 E4130.136884 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.925186 Y181.282381 Z13.308411 E4133.278825 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.547672 Y180.853326 Z13.317757 E4136.42226 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.182641 Y180.442289 Z13.327103 E4139.567234 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.829579 Y180.049628 Z13.336449 E4142.71379 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.487966 Y179.675686 Z13.345794 E4145.861974 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.157267 Y179.320792 Z13.35514 E4149.011829 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.837049 Y178.985496 Z13.364486 E4152.163364 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.527628 Y178.672258 Z13.373832 E4155.316246 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.2273 Y178.379036 Z13.383178 E4158.470501 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.935493 Y178.10609 Z13.392523 E4161.626174 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.651629 Y177.853665 Z13.401869 E4164.783308 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.375125 Y177.621988 Z13.411215 E4167.941949 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.10539 Y177.411271 Z13.420561 E4171.10214 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.841825 Y177.221709 Z13.429907 E4174.263927 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.58383 Y177.053481 Z13.439252 E4177.427353 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.330795 Y176.906748 Z13.448598 E4180.592463 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.082244 Y176.782685 Z13.457944 E4183.759157 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.837537 Y176.682209 Z13.46729 E4186.927201 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.595756 Y176.603629 Z13.476636 E4190.09663 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.356276 Y176.547028 Z13.485981 E4193.267488 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.118471 Y176.512474 Z13.495327 E4196.439819 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.881712 Y176.500016 Z13.504673 E4199.613669 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.64537 Y176.509685 Z13.514019 E4202.789081 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.408813 Y176.541497 Z13.523364 E4205.966101 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.17141 Y176.595448 Z13.53271 E4209.144773 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.93253 Y176.671516 Z13.542056 E4212.325142 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.691243 Y176.771464 Z13.551402 E4215.506996 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.446897 Y176.89444 Z13.560748 E4218.690205 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.198998 Y177.039326 Z13.570093 E4221.87481 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.946924 Y177.206022 Z13.579439 E4225.060856 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.690052 Y177.394409 Z13.588785 E4228.248388 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.427762 Y177.604352 Z13.598131 E4231.43745 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.159439 Y177.8357 Z13.607477 E4234.628086 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.884473 Y178.088282 Z13.616822 E4237.820343 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.602258 Y178.361911 Z13.626168 E4241.014265 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.312191 Y178.656384 Z13.635514 E4244.209897 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.012518 Y178.973831 Z13.64486 E4247.406911 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.703531 Y179.31182 Z13.654206 E4250.605288 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.384758 Y179.669848 Z13.663551 E4253.805073 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.055629 Y180.047639 Z13.672897 E4257.00631 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.715579 Y180.444898 Z13.682243 E4260.209045 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.364052 Y180.861315 Z13.691589 E4263.413322 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.000501 Y181.296565 Z13.700935 E4266.619187 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.624387 Y181.750306 Z13.71028 E4269.826684 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.235182 Y182.222184 Z13.719626 E4273.03586 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.832018 Y182.712222 Z13.728972 E4276.246687 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.413088 Y183.221348 Z13.738318 E4279.45886 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.979403 Y183.747323 Z13.747664 E4282.672408 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.530481 Y184.289729 Z13.757009 E4285.887376 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.065853 Y184.84813 Z13.766355 E4289.103807 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.585062 Y185.42208 Z13.775701 E4292.321749 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.087664 Y186.01112 Z13.785047 E4295.541245 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.573226 Y186.614777 Z13.794393 E4298.762341 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.041331 Y187.232567 Z13.803738 E4301.985083 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.491571 Y187.863994 Z13.813084 E4305.209516 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.922434 Y188.509249 Z13.82243 E4308.435503 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.333243 Y189.167836 Z13.831776 E4311.662839 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.724963 Y189.838339 Z13.841121 E4314.891561 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.097253 Y190.520213 Z13.850467 E4318.121714 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.449788 Y191.212906 Z13.859813 E4321.353343 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.782258 Y191.915856 Z13.869159 E4324.586495 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.09437 Y192.628489 Z13.878505 E4327.821213 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.385844 Y193.350228 Z13.88785 E4331.057545 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.65642 Y194.080484 Z13.897196 E4334.295535 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.905851 Y194.818664 Z13.906542 E4337.535229 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.131854 Y195.564714 Z13.915888 E4340.776376 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.335459 Y196.317523 Z13.925234 E4344.018877 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.517241 Y197.076244 Z13.934579 E4347.262776 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.677031 Y197.840253 Z13.943925 E4350.508118 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.814677 Y198.608924 Z13.953271 E4353.754948 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.930046 Y199.381627 Z13.962617 E4357.003313 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.023019 Y200.157725 Z13.971963 E4360.253258 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.093498 Y200.936581 Z13.981308 E4363.504828 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.141402 Y201.717554 Z13.990654 E4366.75807 F2400 ; clayline kind=print page=0 layer=5 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.166667 Y202.5 Z14 E4370.01303 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.163198 Y203.283086 Z14.009346 E4373.268987 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.137033 Y204.065978 Z14.018692 E4376.525923 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.088178 Y204.848029 Z14.028037 E4379.783883 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.016661 Y205.628593 Z14.037383 E4383.042913 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.922524 Y206.407023 Z14.046729 E4386.30306 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.805831 Y207.182675 Z14.056075 E4389.564368 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.66666 Y207.954905 Z14.065421 E4392.826883 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.50511 Y208.723075 Z14.074766 E4396.090652 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.321297 Y209.486544 Z14.084112 E4399.35572 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.114584 Y210.244446 Z14.093458 E4402.622038 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.883879 Y210.995643 Z14.102804 E4405.889353 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.631428 Y211.740066 Z14.11215 E4409.157658 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.357427 Y212.477095 Z14.121495 E4412.426999 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.062087 Y213.206116 Z14.130841 E4415.697423 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.745638 Y213.926522 Z14.140187 E4418.968975 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.408328 Y214.637712 Z14.149533 E4422.241701 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.050419 Y215.339092 Z14.158879 E4425.515648 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.672191 Y216.030073 Z14.168224 E4428.79086 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.273941 Y216.710077 Z14.17757 E4432.067386 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.85464 Y217.377638 Z14.186916 E4435.345074 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.414924 Y218.032217 Z14.196262 E4438.623749 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.956286 Y218.673977 Z14.205607 E4441.903426 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.479092 Y219.302379 Z14.214953 E4445.184152 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.983726 Y219.916895 Z14.224299 E4448.465972 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.470584 Y220.517009 Z14.233645 E4451.748934 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.940077 Y221.102214 Z14.242991 E4455.033082 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.392631 Y221.672016 Z14.252336 E4458.318463 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.828686 Y222.225932 Z14.261682 E4461.605123 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.248692 Y222.763491 Z14.271028 E4464.89311 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.651578 Y223.282359 Z14.280374 E4468.182168 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.039156 Y223.78344 Z14.28972 E4471.472206 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.412279 Y224.266714 Z14.299065 E4474.763259 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.771456 Y224.731772 Z14.308411 E4478.055373 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.117207 Y225.178216 Z14.317757 E4481.348593 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.450063 Y225.605666 Z14.327103 E4484.642967 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.770566 Y226.013754 Z14.336449 E4487.93854 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.079269 Y226.402129 Z14.345794 E4491.23536 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.376734 Y226.770455 Z14.35514 E4494.533472 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.66342 Y227.118165 Z14.364486 E4497.832891 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.939 Y227.442692 Z14.373832 E4501.133315 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.205262 Y227.746183 Z14.383178 E4504.43472 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.462809 Y228.028373 Z14.392523 E4507.737151 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.712246 Y228.289018 Z14.401869 E4511.040656 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.95419 Y228.527886 Z14.411215 E4514.34528 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.189261 Y228.744766 Z14.420561 E4517.65107 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.418086 Y228.939463 Z14.429907 E4520.958072 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.641298 Y229.111798 Z14.439252 E4524.266334 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.859534 Y229.261613 Z14.448598 E4527.575901 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.073295 Y229.387687 Z14.457944 E4530.88669 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.283252 Y229.489073 Z14.46729 E4534.198472 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.490365 Y229.567548 Z14.476636 E4537.511246 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.695288 Y229.623034 Z14.485981 E4540.82506 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.898676 Y229.65547 Z14.495327 E4544.139958 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.101187 Y229.664813 Z14.504673 E4547.455989 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.303478 Y229.651041 Z14.514019 E4550.773199 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.506209 Y229.614147 Z14.523364 E4554.091634 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.710038 Y229.554144 Z14.53271 E4557.411341 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.915625 Y229.471064 Z14.542056 E4560.732368 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.123937 Y229.363076 Z14.551402 E4564.054528 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.335657 Y229.231079 Z14.560748 E4567.37767 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.551296 Y229.07625 Z14.570093 E4570.701817 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.771504 Y228.898704 Z14.579439 E4574.027016 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.996927 Y228.698571 Z14.588785 E4577.353312 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.228211 Y228.476002 Z14.598131 E4580.680753 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.465992 Y228.231166 Z14.607477 E4584.009386 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.710908 Y227.964248 Z14.616822 E4587.339258 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.963586 Y227.675452 Z14.626168 E4590.670414 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.22465 Y227.364999 Z14.635514 E4594.002903 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.495927 Y227.030676 Z14.64486 E4597.336434 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.777108 Y226.675029 Z14.654206 E4600.67094 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.06868 Y226.298588 Z14.663551 E4604.006463 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.371235 Y225.901653 Z14.672897 E4607.343051 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.685355 Y225.484537 Z14.682243 E4610.680748 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.011615 Y225.047571 Z14.691589 E4614.019603 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.350581 Y224.591103 Z14.700935 E4617.359663 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.702808 Y224.115494 Z14.71028 E4620.700975 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.068841 Y223.621124 Z14.719626 E4624.043585 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.449578 Y223.107972 Z14.728972 E4627.387476 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.846894 Y222.575083 Z14.738318 E4630.732367 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.259732 Y222.024794 Z14.747664 E4634.07824 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.688585 Y221.457547 Z14.757009 E4637.425143 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.133936 Y220.873802 Z14.766355 E4640.773122 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.596253 Y220.274031 Z14.775701 E4644.122224 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.075992 Y219.658716 Z14.785047 E4647.472497 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.573596 Y219.028357 Z14.794393 E4650.823987 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.089493 Y218.383462 Z14.803738 E4654.176742 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.624098 Y217.724553 Z14.813084 E4657.530809 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.178977 Y217.051436 Z14.82243 E4660.88607 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.754826 Y216.364634 Z14.831776 E4664.242319 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.350633 Y215.665623 Z14.841121 E4667.599563 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.966745 Y214.954974 Z14.850467 E4670.957848 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.603491 Y214.233266 Z14.859813 E4674.317223 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.261185 Y213.501088 Z14.869159 E4677.677733 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.940125 Y212.759038 Z14.878505 E4681.039427 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.640591 Y212.007722 Z14.88785 E4684.402351 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.362846 Y211.247754 Z14.897196 E4687.766554 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.107138 Y210.479755 Z14.906542 E4691.132082 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.875829 Y209.70378 Z14.915888 E4694.498714 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.66784 Y208.920989 Z14.925234 E4697.866324 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.482565 Y208.132265 Z14.934579 E4701.234941 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.32017 Y207.338254 Z14.943925 E4704.604613 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.180805 Y206.539611 Z14.953271 E4707.975386 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.064598 Y205.736991 Z14.962617 E4711.347308 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.971663 Y204.931056 Z14.971963 E4714.720426 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.902094 Y204.122467 Z14.981308 E4718.094789 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.855965 Y203.311893 Z14.990654 E4721.470443 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.833333 Y202.5 Z15 E4724.847435 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.837282 Y201.687559 Z15.009346 E4728.225438 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.864778 Y200.875339 Z15.018692 E4731.604412 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.915812 Y200.064012 Z15.028037 E4734.984406 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.990356 Y199.254249 Z15.037383 E4738.365467 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.088364 Y198.44672 Z15.046729 E4741.747643 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.209771 Y197.642094 Z15.056075 E4745.13098 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.354492 Y196.841036 Z15.065421 E4748.515527 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.522425 Y196.044213 Z15.074766 E4751.901331 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.713449 Y195.252284 Z15.084112 E4755.28844 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.928223 Y194.466152 Z15.093458 E4758.676803 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.167881 Y193.686994 Z15.102804 E4762.066161 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.43009 Y192.914883 Z15.11215 E4765.456503 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.714648 Y192.150461 Z15.121495 E4768.847877 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.021332 Y191.394365 Z15.130841 E4772.240331 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.349905 Y190.647224 Z15.140187 E4775.633912 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.700109 Y189.909661 Z15.149533 E4779.028669 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.071671 Y189.182294 Z15.158879 E4782.424647 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.464299 Y188.46573 Z15.168224 E4785.821897 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.877686 Y187.760569 Z15.17757 E4789.220464 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.312896 Y187.068334 Z15.186916 E4792.620198 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.769271 Y186.38958 Z15.196262 E4796.020915 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.24526 Y185.72414 Z15.205607 E4799.422628 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.740483 Y185.07257 Z15.214953 E4802.825386 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.254541 Y184.435419 Z15.224299 E4806.229236 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.787024 Y183.813221 Z15.233645 E4809.634226 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.337503 Y183.206502 Z15.242991 E4813.040405 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.905536 Y182.615773 Z15.252336 E4816.44782 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.490668 Y182.041534 Z15.261682 E4819.856518 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.092428 Y181.484274 Z15.271028 E4823.266549 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.71193 Y180.946411 Z15.280374 E4826.677653 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.347291 Y180.427009 Z15.28972 E4830.089731 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.997628 Y179.926087 Z15.299065 E4833.502819 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.662412 Y179.444069 Z15.308411 E4836.916964 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.341103 Y178.981365 Z15.317757 E4840.332214 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.033149 Y178.538371 Z15.327103 E4843.748617 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.737988 Y178.115467 Z15.336449 E4847.166222 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.455047 Y177.713015 Z15.345794 E4850.585076 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.183742 Y177.331365 Z15.35514 E4854.005228 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.923597 Y176.971102 Z15.364486 E4857.426693 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.67495 Y176.634888 Z15.373832 E4860.849162 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.435946 Y176.320497 Z15.383178 E4864.272605 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.205962 Y176.028199 Z15.392523 E4867.69707 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.984367 Y175.758252 Z15.401869 E4871.122605 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.770523 Y175.51089 Z15.411215 E4874.549259 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.563787 Y175.286335 Z15.420561 E4877.977079 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.363507 Y175.084788 Z15.429907 E4881.406113 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.169028 Y174.906431 Z15.439252 E4884.836411 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.979688 Y174.75143 Z15.448598 E4888.268019 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.794969 Y174.621048 Z15.457944 E4891.700855 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.614174 Y174.516266 Z15.46729 E4895.13468 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.436307 Y174.435242 Z15.476636 E4898.569491 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.260691 Y174.378056 Z15.485981 E4902.005338 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.086646 Y174.34477 Z15.495327 E4905.442267 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.913491 Y174.335427 Z15.504673 E4908.880327 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.740543 Y174.35005 Z15.514019 E4912.319567 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.567119 Y174.388644 Z15.523364 E4915.760036 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.392537 Y174.451195 Z15.53271 E4919.20178 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.216112 Y174.53767 Z15.542056 E4922.64485 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.036841 Y174.649967 Z15.551402 E4926.089056 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.854017 Y174.78715 Z15.560748 E4929.53424 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.667111 Y174.948 Z15.570093 E4932.980423 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.475449 Y175.132398 Z15.579439 E4936.427653 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.27836 Y175.340206 Z15.588785 E4939.87598 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.075177 Y175.571267 Z15.598131 E4943.325451 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.865237 Y175.825407 Z15.607477 E4946.776115 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.647884 Y176.102431 Z15.616822 E4950.228021 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.422465 Y176.402128 Z15.626168 E4953.681216 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.188333 Y176.724268 Z15.635514 E4957.135751 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.943597 Y177.071144 Z15.64486 E4960.591327 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.688575 Y177.440116 Z15.654206 E4964.047874 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.422765 Y177.830632 Z15.663551 E4967.505432 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.145554 Y178.242384 Z15.672897 E4970.96405 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.856336 Y178.675045 Z15.682243 E4974.423778 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.554517 Y179.128269 Z15.691589 E4977.884663 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.239512 Y179.601698 Z15.700935 E4981.346755 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.910745 Y180.094955 Z15.71028 E4984.810102 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.567651 Y180.607647 Z15.719626 E4988.274752 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.209302 Y181.139792 Z15.728972 E4991.74069 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.833752 Y181.692383 Z15.738318 E4995.207625 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.442101 Y182.262995 Z15.747664 E4998.675537 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.033835 Y182.851169 Z15.757009 E5002.144474 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.608456 Y183.456428 Z15.766355 E5005.614484 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.16548 Y184.078284 Z15.775701 E5009.085616 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.704433 Y184.716233 Z15.785047 E5012.557919 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.224858 Y185.36976 Z15.794393 E5016.031442 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.726312 Y186.038336 Z15.803738 E5019.506234 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.208366 Y186.721419 Z15.813084 E5022.982343 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.669396 Y187.419211 Z15.82243 E5026.459651 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.108684 Y188.131169 Z15.831776 E5029.937943 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.527277 Y188.855763 Z15.841121 E5033.417224 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.924818 Y189.5924 Z15.850467 E5036.897543 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.300966 Y190.34048 Z15.859813 E5040.378948 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.655396 Y191.099393 Z15.869159 E5043.861488 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.987801 Y191.868518 Z15.878505 E5047.345213 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.297891 Y192.647226 Z15.88785 E5050.830171 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.585394 Y193.434883 Z15.897196 E5054.316412 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.850054 Y194.230843 Z15.906542 E5057.803984 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.089425 Y195.035048 Z15.915888 E5061.292663 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.304625 Y195.846298 Z15.925234 E5064.782314 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.496283 Y196.663677 Z15.934579 E5068.272967 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.664228 Y197.486514 Z15.943925 E5071.764671 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.808307 Y198.314132 Z15.953271 E5075.257475 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.928385 Y199.145851 Z15.962617 E5078.751427 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.024346 Y199.980986 Z15.971963 E5082.246577 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.096095 Y200.81885 Z15.981308 E5085.742975 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.143555 Y201.658752 Z15.990654 E5089.240668 F2400 ; clayline kind=print page=0 layer=6 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.166667 Y202.5 Z16 E5092.739707 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.159124 Y203.341705 Z16.009346 E5096.239468 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.127192 Y204.182979 Z16.018692 E5099.739809 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.070889 Y205.023124 Z16.028037 E5103.24078 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.990253 Y205.861449 Z16.037383 E5106.742429 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.88534 Y206.697259 Z16.046729 E5110.244807 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.756228 Y207.529863 Z16.056075 E5113.747961 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.603011 Y208.358572 Z16.065421 E5117.251941 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.425804 Y209.182701 Z16.074766 E5120.756797 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.224741 Y210.001565 Z16.084112 E5124.262578 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.99915 Y210.814235 Z16.093458 E5127.769246 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.747865 Y211.619494 Z16.102804 E5131.276558 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.473308 Y212.417269 Z16.11215 E5134.784462 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.175699 Y213.206899 Z16.121495 E5138.293009 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.855273 Y213.98773 Z16.130841 E5141.802248 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.512287 Y214.759112 Z16.140187 E5145.312229 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.147014 Y215.520404 Z16.149533 E5148.822999 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.759745 Y216.270973 Z16.158879 E5152.33461 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.350789 Y217.010195 Z16.168224 E5155.84711 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.920472 Y217.737451 Z16.17757 E5159.360549 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.467701 Y218.451175 Z16.186916 E5162.874798 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.993164 Y219.150796 Z16.196262 E5166.389663 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.498472 Y219.836493 Z16.205607 E5169.905134 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.984024 Y220.507695 Z16.214953 E5173.421261 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.450239 Y221.163842 Z16.224299 E5176.938093 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.89755 Y221.804386 Z16.233645 E5180.45568 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.326404 Y222.42879 Z16.242991 E5183.974071 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.737264 Y223.036533 Z16.252336 E5187.493316 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.130607 Y223.627103 Z16.261682 E5191.013464 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.506926 Y224.200003 Z16.271028 E5194.534564 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.865077 Y224.752741 Z16.280374 E5198.056394 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.207008 Y225.286292 Z16.28972 E5201.578816 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.533639 Y225.800644 Z16.299065 E5205.101858 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.845519 Y226.295364 Z16.308411 E5208.625568 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.143212 Y226.770037 Z16.317757 E5212.149998 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.427292 Y227.224262 Z16.327103 E5215.675195 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.698342 Y227.657655 Z16.336449 E5219.20121 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.95696 Y228.069848 Z16.345794 E5222.728092 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.203751 Y228.460489 Z16.35514 E5226.255892 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.439211 Y228.828981 Z16.364486 E5229.784629 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.662995 Y229.172588 Z16.373832 E5233.314028 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.877019 Y229.493615 Z16.383178 E5236.844011 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.08193 Y229.791789 Z16.392523 E5240.374627 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.27838 Y230.066854 Z16.401869 E5243.905925 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.46703 Y230.318576 Z16.411215 E5247.437955 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.648546 Y230.546736 Z16.420561 E5250.970766 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.823602 Y230.751135 Z16.429907 E5254.504409 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.992875 Y230.931591 Z16.439252 E5258.038933 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.157048 Y231.087945 Z16.448598 E5261.574388 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.316658 Y231.218903 Z16.457944 E5265.110705 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.472423 Y231.323463 Z16.46729 E5268.647656 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.625371 Y231.403532 Z16.476636 E5272.185203 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.776199 Y231.459036 Z16.485981 E5275.723396 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.925608 Y231.48992 Z16.495327 E5279.262285 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.0743 Y231.496149 Z16.504673 E5282.801919 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.222978 Y231.477707 Z16.514019 E5286.342349 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.372345 Y231.434597 Z16.523364 E5289.883623 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.523103 Y231.366843 Z16.53271 E5293.425793 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.675955 Y231.274488 Z16.542056 E5296.968907 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.831933 Y231.155587 Z16.551402 E5300.512805 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.991762 Y231.011112 Z16.560748 E5304.05731 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.155986 Y230.842326 Z16.570093 E5307.602425 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.325297 Y230.649361 Z16.579439 E5311.148199 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.500382 Y230.432366 Z16.588785 E5314.694683 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.681925 Y230.191511 Z16.598131 E5318.241925 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.870604 Y229.926984 Z16.607477 E5321.789976 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.067094 Y229.638992 Z16.616822 E5325.338886 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.272062 Y229.327762 Z16.626168 E5328.888705 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.486169 Y228.993537 Z16.635514 E5332.439482 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.711356 Y228.633969 Z16.64486 E5335.990961 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.947292 Y228.251781 Z16.654206 E5339.543024 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.194489 Y227.847545 Z16.663551 E5343.09571 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.453573 Y227.421587 Z16.672897 E5346.649069 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.725162 Y226.974251 Z16.682243 E5350.203151 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.009861 Y226.505897 Z16.691589 E5353.758005 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.308268 Y226.016903 Z16.700935 E5357.313681 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.620968 Y225.507662 Z16.71028 E5360.87023 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.948536 Y224.978584 Z16.719626 E5364.427702 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.29192 Y224.429657 Z16.728972 E5367.986089 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.653112 Y223.859871 Z16.738318 E5371.545127 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.030978 Y223.271718 Z16.747664 E5375.104752 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.426038 Y222.665679 Z16.757009 E5378.665013 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.838797 Y222.042248 Z16.766355 E5382.22596 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.269747 Y221.401932 Z16.775701 E5385.787643 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.719366 Y220.745253 Z16.785047 E5389.350113 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.188116 Y220.072747 Z16.794393 E5392.913419 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.676447 Y219.384959 Z16.803738 E5396.477611 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.184791 Y218.682452 Z16.813084 E5400.04274 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.714806 Y217.965023 Z16.82243 E5403.608707 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.267222 Y217.233235 Z16.831776 E5407.175298 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.840956 Y216.488661 Z16.841121 E5410.742488 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.436368 Y215.731911 Z16.850467 E5414.310327 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.053799 Y214.963607 Z16.859813 E5417.878866 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.693575 Y214.184378 Z16.869159 E5421.448155 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.356002 Y213.394862 Z16.878505 E5425.018243 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.041371 Y212.595707 Z16.88785 E5428.589182 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.749952 Y211.787568 Z16.897196 E5432.161022 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.481998 Y210.971108 Z16.906542 E5435.733812 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.240009 Y210.146389 Z16.915888 E5439.30736 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.022829 Y209.314644 Z16.925234 E5442.881506 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.829806 Y208.476812 Z16.934579 E5446.456264 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.661106 Y207.633583 Z16.943925 E5450.031685 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.516879 Y206.785651 Z16.953271 E5453.60782 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.397253 Y205.933714 Z16.962617 E5457.184718 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.302339 Y205.078475 Z16.971963 E5460.76243 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.232226 Y204.220638 Z16.981308 E5464.341006 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.186985 Y203.36091 Z16.990654 E5467.920496 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.166667 Y202.5 Z17 E5471.500952 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.17453 Y201.638724 Z17.009346 E5475.08208 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.207349 Y200.777899 Z17.018692 E5478.663785 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.265105 Y199.918237 Z17.028037 E5482.246115 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.347759 Y199.060446 Z17.037383 E5485.829122 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.455252 Y198.205237 Z17.046729 E5489.412856 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.587506 Y197.353316 Z17.056075 E5492.997367 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.744423 Y196.505389 Z17.065421 E5496.582706 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.925886 Y195.662158 Z17.074766 E5500.168923 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.131756 Y194.824321 Z17.084112 E5503.756068 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.362722 Y193.99283 Z17.093458 E5507.344104 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.619975 Y193.168931 Z17.102804 E5510.932782 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.901037 Y192.352697 Z17.11215 E5514.522049 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.205684 Y191.544804 Z17.121495 E5518.111955 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.533673 Y190.745924 Z17.130841 E5521.702552 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.884742 Y189.956719 Z17.140187 E5525.293888 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.258611 Y189.177845 Z17.149533 E5528.886016 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.654981 Y188.40995 Z17.158879 E5532.478986 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.073538 Y187.653674 Z17.168224 E5536.072847 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.513945 Y186.909647 Z17.17757 E5539.667652 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.977323 Y186.179473 Z17.186916 E5543.263268 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.462965 Y185.463735 Z17.196262 E5546.859499 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.969225 Y184.762251 Z17.205607 E5550.456331 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.495692 Y184.075604 Z17.214953 E5554.053817 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.041939 Y183.404368 Z17.224299 E5557.652007 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.607522 Y182.749101 Z17.233645 E5561.250951 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.191983 Y182.110354 Z17.242991 E5564.850699 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.794848 Y181.48866 Z17.252336 E5568.451303 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.415628 Y180.884541 Z17.261682 E5572.052813 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.053821 Y180.298507 Z17.271028 E5575.655281 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.710595 Y179.733106 Z17.280374 E5579.258478 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.383957 Y179.18734 Z17.28972 E5582.862264 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.072966 Y178.661223 Z17.299065 E5586.466666 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.777059 Y178.155196 Z17.308411 E5590.071735 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.495661 Y177.669684 Z17.317757 E5593.677522 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.228183 Y177.205096 Z17.327103 E5597.284076 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.974027 Y176.761825 Z17.336449 E5600.891449 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.732584 Y176.340248 Z17.345794 E5604.499692 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.503233 Y175.940724 Z17.35514 E5608.108855 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.285466 Y175.563864 Z17.364486 E5611.71896 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.079638 Y175.212465 Z17.373832 E5615.329727 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.883786 Y174.884171 Z17.383178 E5618.941072 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.697251 Y174.57926 Z17.392523 E5622.553048 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.519362 Y174.297992 Z17.401869 E5626.165704 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.349445 Y174.040608 Z17.411215 E5629.779091 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.186818 Y173.807332 Z17.420561 E5633.393259 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.030793 Y173.598366 Z17.429907 E5637.008261 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.880675 Y173.413895 Z17.439252 E5640.624146 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.735766 Y173.254083 Z17.448598 E5644.240965 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.595518 Y173.120253 Z17.457944 E5647.858651 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.459194 Y173.013431 Z17.46729 E5651.476968 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.325744 Y172.931662 Z17.476636 E5655.095877 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.194454 Y172.875025 Z17.485981 E5658.715429 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.064607 Y172.843573 Z17.495327 E5662.335675 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.935485 Y172.837344 Z17.504673 E5665.956666 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.806369 Y172.856353 Z17.514019 E5669.578453 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.67654 Y172.900597 Z17.523364 E5673.201087 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.54528 Y172.97005 Z17.53271 E5676.824618 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.411869 Y173.064668 Z17.542056 E5680.449098 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.275253 Y173.186441 Z17.551402 E5684.074365 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.134688 Y173.334374 Z17.560748 E5687.700235 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.989619 Y173.507174 Z17.570093 E5691.326711 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.839338 Y173.704707 Z17.579439 E5694.953844 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.683143 Y173.926819 Z17.588785 E5698.581684 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.520333 Y174.173336 Z17.598131 E5702.210283 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.350215 Y174.444065 Z17.607477 E5705.839692 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.1721 Y174.738794 Z17.616822 E5709.469962 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.985305 Y175.057292 Z17.626168 E5713.101144 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.789154 Y175.399308 Z17.635514 E5716.733289 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.58166 Y175.767244 Z17.64486 E5720.366136 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.363164 Y176.158315 Z17.654206 E5723.999563 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.133142 Y176.571936 Z17.663551 E5727.633609 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.890952 Y177.007771 Z17.672897 E5731.268326 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.635965 Y177.46547 Z17.682243 E5734.903764 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.36756 Y177.944663 Z17.691589 E5738.539976 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.085127 Y178.444964 Z17.700935 E5742.177011 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.788067 Y178.965971 Z17.71028 E5745.81492 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.475792 Y179.507263 Z17.719626 E5749.453756 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.147333 Y180.068852 Z17.728972 E5753.093511 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.800652 Y180.651773 Z17.738318 E5756.733916 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.43691 Y181.253475 Z17.747664 E5760.374904 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.055575 Y181.873465 Z17.757009 E5764.016525 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.656131 Y182.511239 Z17.766355 E5767.658829 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.238075 Y183.166278 Z17.775701 E5771.30187 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.800918 Y183.838046 Z17.785047 E5774.945696 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.344187 Y184.525998 Z17.794393 E5778.590361 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.867423 Y185.229572 Z17.803738 E5782.235915 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.370185 Y185.948196 Z17.813084 E5785.88241 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.850776 Y186.682075 Z17.82243 E5789.529745 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.308451 Y187.430634 Z17.831776 E5793.177701 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.744317 Y188.192263 Z17.841121 E5796.826252 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.158008 Y188.966338 Z17.850467 E5800.475451 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.549172 Y189.752224 Z17.859813 E5804.125347 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.917479 Y190.549276 Z17.869159 E5807.775993 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.262615 Y191.356842 Z17.878505 E5811.42744 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.584283 Y192.174259 Z17.88785 E5815.079738 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.882208 Y193.000857 Z17.897196 E5818.73294 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.15613 Y193.835957 Z17.906542 E5822.387097 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.403494 Y194.679497 Z17.915888 E5826.042013 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.625481 Y195.530214 Z17.925234 E5829.697523 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.82276 Y196.387149 Z17.934579 E5833.353642 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.99516 Y197.249596 Z17.943925 E5837.010422 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.142529 Y198.116845 Z17.953271 E5840.667914 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.264735 Y198.98818 Z17.962617 E5844.326169 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.361667 Y199.862886 Z17.971963 E5847.985239 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.433233 Y200.74024 Z17.981308 E5851.645175 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.479361 Y201.61952 Z17.990654 E5855.306029 F2400 ; clayline kind=print page=0 layer=7 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.5 Y202.5 Z18 E5858.967853 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.491816 Y203.380846 Z18.009346 E5862.630349 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.45811 Y204.261223 Z18.018692 E5866.293417 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.398901 Y205.140402 Z18.028037 E5869.957108 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.31423 Y206.017659 Z18.037383 E5873.621473 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.204156 Y206.892268 Z18.046729 E5877.286564 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.06876 Y207.763505 Z18.056075 E5880.952433 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.908142 Y208.63065 Z18.065421 E5884.61913 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.722425 Y209.492984 Z18.074766 E5888.286708 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.511747 Y210.349794 Z18.084112 E5891.955218 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.275406 Y211.200105 Z18.093458 E5895.624622 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.012185 Y212.042645 Z18.102804 E5899.294666 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.724617 Y212.877338 Z18.11215 E5902.965295 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.412933 Y213.703492 Z18.121495 E5906.636561 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.077381 Y214.520422 Z18.130841 E5910.308516 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.718229 Y215.32745 Z18.140187 E5913.98121 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.335765 Y216.123905 Z18.149533 E5917.654695 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.930292 Y216.909126 Z18.158879 E5921.329024 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.502136 Y217.682457 Z18.168224 E5925.004248 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.051637 Y218.443255 Z18.17757 E5928.680418 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.577653 Y219.189879 Z18.186916 E5932.357402 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.080905 Y219.921733 Z18.196262 E5936.034998 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.563078 Y220.639004 Z18.205607 E5939.713192 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.024591 Y221.341096 Z18.214953 E5943.392037 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.465883 Y222.027423 Z18.224299 E5947.071584 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.887406 Y222.697412 Z18.233645 E5950.751885 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.289631 Y223.350502 Z18.242991 E5954.432992 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.67304 Y223.986148 Z18.252336 E5958.114956 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.038136 Y224.603815 Z18.261682 E5961.797829 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.385432 Y225.202984 Z18.271028 E5965.481663 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.713733 Y225.781047 Z18.280374 E5969.166228 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.025078 Y226.339027 Z18.28972 E5972.851379 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.320429 Y226.876909 Z18.299065 E5976.537142 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.600362 Y227.394244 Z18.308411 E5980.22357 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.865466 Y227.890595 Z18.317757 E5983.910713 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.116343 Y228.365546 Z18.327103 E5987.598625 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.353603 Y228.818694 Z18.336449 E5991.287356 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.577872 Y229.249655 Z18.345794 E5994.97696 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.789783 Y229.658063 Z18.35514 E5998.667486 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.989856 Y230.043292 Z18.364486 E6002.358959 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.177729 Y230.402481 Z18.373832 E6006.051094 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.355408 Y230.738043 Z18.383178 E6009.743803 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.523569 Y231.049691 Z18.392523 E6013.437139 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.682896 Y231.337162 Z18.401869 E6017.131153 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.834079 Y231.600207 Z18.411215 E6020.825897 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.977817 Y231.8386 Z18.420561 E6024.521423 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.114812 Y232.052134 Z18.429907 E6028.217783 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.245774 Y232.240619 Z18.439252 E6031.91503 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.371419 Y232.403888 Z18.448598 E6035.613214 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.492306 Y232.54059 Z18.457944 E6039.312268 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.609189 Y232.649676 Z18.46729 E6043.011951 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.723141 Y232.733144 Z18.476636 E6046.712223 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.834894 Y232.790915 Z18.485981 E6050.413134 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.945178 Y232.822933 Z18.495327 E6054.114738 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.05473 Y232.829162 Z18.504673 E6057.817087 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.164284 Y232.809586 Z18.514019 E6061.520231 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.274574 Y232.764209 Z18.523364 E6065.224225 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.386337 Y232.693057 Z18.53271 E6068.929118 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.500307 Y232.596175 Z18.542056 E6072.634965 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.617562 Y232.47153 Z18.551402 E6076.341599 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.738863 Y232.32014 Z18.560748 E6080.048834 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.864776 Y232.143325 Z18.570093 E6083.756672 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.996026 Y231.941225 Z18.579439 E6087.465164 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.133332 Y231.713997 Z18.588785 E6091.174362 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.277408 Y231.461818 Z18.598131 E6094.884318 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.428965 Y231.184887 Z18.607477 E6098.595085 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.588705 Y230.88342 Z18.616822 E6102.306715 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.757328 Y230.557655 Z18.626168 E6106.01926 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.935524 Y230.207848 Z18.635514 E6109.732773 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.125324 Y229.831543 Z18.64486 E6113.446988 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.32638 Y229.431588 Z18.654206 E6117.161779 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.539228 Y229.008584 Z18.663551 E6120.877186 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.764522 Y228.562871 Z18.672897 E6124.593262 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.002908 Y228.094809 Z18.682243 E6128.310057 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.255018 Y227.604777 Z18.691589 E6132.027626 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.521477 Y227.093168 Z18.700935 E6135.74602 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.802898 Y226.560396 Z18.71028 E6139.46529 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.09988 Y226.00689 Z18.719626 E6143.185491 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.413415 Y225.432638 Z18.728972 E6146.906614 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.745584 Y224.836583 Z18.738318 E6150.628386 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.095202 Y224.221333 Z18.747664 E6154.350737 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.462811 Y223.587391 Z18.757009 E6158.073718 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.84894 Y222.935274 Z18.766355 E6161.79738 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.254103 Y222.265513 Z18.775701 E6165.521778 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.678799 Y221.578654 Z18.785047 E6169.246963 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.12351 Y220.875258 Z18.794393 E6172.972986 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.588707 Y220.155896 Z18.803738 E6176.699902 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.074839 Y219.421156 Z18.813084 E6180.427762 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.583641 Y218.670827 Z18.82243 E6184.156466 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.115876 Y217.905498 Z18.831776 E6187.885788 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.670409 Y217.126813 Z18.841121 E6191.615702 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.247617 Y216.335413 Z18.850467 E6195.346259 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.847857 Y215.531946 Z18.859813 E6199.077514 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.471467 Y214.71707 Z18.869159 E6202.809517 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.118768 Y213.891454 Z18.878505 E6206.542321 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.790062 Y213.055775 Z18.88785 E6210.275979 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.485632 Y212.210719 Z18.897196 E6214.010544 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.205742 Y211.356978 Z18.906542 E6217.746068 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.953003 Y210.494618 Z18.915888 E6221.482352 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.726209 Y209.624927 Z18.925234 E6225.219227 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.524674 Y208.748889 Z18.934579 E6228.956708 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.348574 Y207.867225 Z18.943925 E6232.694847 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.198064 Y206.98066 Z18.953271 E6236.433696 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.073276 Y206.089925 Z18.962617 E6240.173309 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.974326 Y205.195753 Z18.971963 E6243.913737 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.901307 Y204.298882 Z18.981308 E6247.655034 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.854292 Y203.400051 Z18.990654 E6251.397251 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.833333 Y202.5 Z19 E6255.140443 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.841837 Y201.599584 Z19.009346 E6258.884308 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.87643 Y200.699655 Z19.018692 E6262.62874 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.937092 Y199.800958 Z19.028037 E6266.373791 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.023782 Y198.904235 Z19.037383 E6270.119515 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.136437 Y198.010227 Z19.046729 E6273.865963 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.274975 Y197.119674 Z19.056075 E6277.613189 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.439292 Y196.233311 Z19.065421 E6281.361245 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.629265 Y195.351874 Z19.074766 E6285.110185 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.844751 Y194.476092 Z19.084112 E6288.860059 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.086466 Y193.60696 Z19.093458 E6292.610832 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.355655 Y192.74578 Z19.102804 E6296.362243 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.649728 Y191.892628 Z19.11215 E6300.114235 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.96845 Y191.048212 Z19.121495 E6303.866861 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.311565 Y190.213232 Z19.130841 E6307.620173 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.678799 Y189.388381 Z19.140187 E6311.374225 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.06986 Y188.574344 Z19.149533 E6315.129068 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.484434 Y187.771798 Z19.158879 E6318.884756 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.922191 Y186.981411 Z19.168224 E6322.641342 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.38278 Y186.203843 Z19.17757 E6326.398878 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.867371 Y185.440769 Z19.186916 E6330.157231 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.375225 Y184.692798 Z19.196262 E6333.916193 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.90462 Y183.95974 Z19.205607 E6337.675749 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.455125 Y183.242203 Z19.214953 E6341.435953 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.026295 Y182.540787 Z19.224299 E6345.196858 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.617666 Y181.856075 Z19.233645 E6348.958516 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.228756 Y181.188642 Z19.242991 E6352.720981 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.859071 Y180.539045 Z19.252336 E6356.484305 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.5081 Y179.907829 Z19.261682 E6360.248542 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.175315 Y179.295526 Z19.271028 E6364.013743 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.861939 Y178.704799 Z19.280374 E6367.779677 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.565887 Y178.134606 Z19.28972 E6371.546192 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.286176 Y177.584958 Z19.299065 E6375.313317 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.022216 Y177.056316 Z19.308411 E6379.081103 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.773407 Y176.549125 Z19.317757 E6382.849604 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.539132 Y176.063812 Z19.327103 E6386.618873 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.318766 Y175.600786 Z19.336449 E6390.388963 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.111672 Y175.160441 Z19.345794 E6394.159927 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.917201 Y174.74315 Z19.35514 E6397.931819 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.734822 Y174.349553 Z19.364486 E6401.70466 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.564904 Y173.982572 Z19.373832 E6405.478162 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.405397 Y173.639743 Z19.383178 E6409.252235 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.255611 Y173.321357 Z19.392523 E6413.026931 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.114846 Y173.027685 Z19.401869 E6416.802303 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.982396 Y172.758977 Z19.411215 E6420.578405 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.857548 Y172.515468 Z19.420561 E6424.355289 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.739583 Y172.297367 Z19.429907 E6428.133008 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.627776 Y172.104867 Z19.439252 E6431.911617 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.521396 Y171.93814 Z19.448598 E6435.691167 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.41987 Y171.798566 Z19.457944 E6439.471589 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.322428 Y171.687217 Z19.46729 E6443.252638 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.227973 Y171.60205 Z19.476636 E6447.034273 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.135759 Y171.543146 Z19.485981 E6450.816544 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.045036 Y171.51056 Z19.495327 E6454.599506 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.955055 Y171.504331 Z19.504673 E6458.383212 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.865064 Y171.524474 Z19.514019 E6462.167715 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.774311 Y171.570984 Z19.523364 E6465.953068 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.682046 Y171.643836 Z19.53271 E6469.739324 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.587518 Y171.742981 Z19.542056 E6473.526537 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.489623 Y171.870498 Z19.551402 E6477.31454 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.387587 Y172.025347 Z19.560748 E6481.103141 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.280828 Y172.206175 Z19.570093 E6484.89234 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.168609 Y172.412843 Z19.579439 E6488.682191 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.050192 Y172.645188 Z19.588785 E6492.472747 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.92485 Y172.903028 Z19.598131 E6496.264061 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.791855 Y173.186162 Z19.607477 E6500.056186 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.650489 Y173.494366 Z19.616822 E6503.849177 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.500039 Y173.827399 Z19.626168 E6507.643086 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.339798 Y174.184997 Z19.635514 E6511.437966 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.167692 Y174.56967 Z19.64486 E6515.23355 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.984076 Y174.978508 Z19.654206 E6519.029705 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.788403 Y175.410897 Z19.663551 E6522.826473 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.580003 Y175.866487 Z19.672897 E6526.623907 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.358219 Y176.344912 Z19.682243 E6530.422061 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.122403 Y176.845783 Z19.691589 E6534.220987 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.871918 Y177.368699 Z19.700935 E6538.02074 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.606137 Y177.913236 Z19.71028 E6541.821372 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.324448 Y178.478956 Z19.719626 E6545.622937 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.025838 Y179.065872 Z19.728972 E6549.425428 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.708181 Y179.675061 Z19.738318 E6553.228568 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.372687 Y180.30386 Z19.747664 E6557.032282 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.018802 Y180.951753 Z19.757009 E6560.836623 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.645988 Y181.618213 Z19.766355 E6564.641644 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.253719 Y182.302697 Z19.775701 E6568.4474 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.841485 Y183.004645 Z19.785047 E6572.253942 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.408792 Y183.723487 Z19.794393 E6576.061325 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.955164 Y184.458635 Z19.803738 E6579.869603 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.480137 Y185.209492 Z19.813084 E6583.678829 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.981941 Y185.976271 Z19.82243 E6587.488901 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.459798 Y186.758371 Z19.831776 E6591.299589 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.914864 Y187.55411 Z19.841121 E6595.110866 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.346758 Y188.362836 Z19.850467 E6598.922783 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.755114 Y189.183885 Z19.859813 E6602.735395 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.139587 Y190.016584 Z19.869159 E6606.548756 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.499849 Y190.86025 Z19.878505 E6610.362919 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.835592 Y191.71419 Z19.88785 E6614.177937 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.146528 Y192.577706 Z19.897196 E6617.993865 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.432386 Y193.450087 Z19.906542 E6621.810756 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.690499 Y194.331268 Z19.915888 E6625.628408 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.922101 Y195.219931 Z19.925234 E6629.446649 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.127891 Y196.115072 Z19.934579 E6633.265491 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.307691 Y197.015954 Z19.943925 E6637.084989 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.461344 Y197.921835 Z19.953271 E6640.905196 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.588712 Y198.83197 Z19.962617 E6644.726167 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.68968 Y199.745608 Z19.971963 E6648.547954 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.764152 Y200.661996 Z19.981308 E6652.370611 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.812054 Y201.580379 Z19.990654 E6656.194193 F2400 ; clayline kind=print page=0 layer=8 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.833333 Y202.5 Z20 E6660.018753 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.824509 Y203.419987 Z20.009346 E6663.843986 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.789029 Y204.339467 Z20.018692 E6667.669782 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.726914 Y205.257681 Z20.028037 E6671.496195 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.638207 Y206.17387 Z20.037383 E6675.323277 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.522971 Y207.087277 Z20.046729 E6679.151083 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.381291 Y207.997148 Z20.056075 E6682.979667 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.213274 Y208.902728 Z20.065421 E6686.809082 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.019045 Y209.803268 Z20.074766 E6690.639383 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.798752 Y210.698022 Z20.084112 E6694.470623 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.551662 Y211.585975 Z20.093458 E6698.302764 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.276505 Y212.465796 Z20.102804 E6702.135543 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.975926 Y213.337406 Z20.11215 E6705.968898 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.650167 Y214.200084 Z20.121495 E6709.802884 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.299489 Y215.053114 Z20.130841 E6713.637555 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.924172 Y215.895788 Z20.140187 E6717.472964 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.524515 Y216.727407 Z20.149533 E6721.309165 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.100839 Y217.547278 Z20.158879 E6725.146213 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.653482 Y218.35472 Z20.168224 E6728.984161 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.182802 Y219.149059 Z20.17757 E6732.823064 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.687605 Y219.928583 Z20.186916 E6736.662786 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.168646 Y220.69267 Z20.196262 E6740.503113 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.627683 Y221.441516 Z20.205607 E6744.344032 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.065158 Y222.174497 Z20.214953 E6748.185595 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.481526 Y222.891004 Z20.224299 E6752.027858 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.877263 Y223.590438 Z20.233645 E6755.870874 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.252857 Y224.272214 Z20.242991 E6759.714697 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.608817 Y224.935763 Z20.252336 E6763.559382 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.945665 Y225.580527 Z20.261682 E6767.404982 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.263938 Y226.205964 Z20.271028 E6771.251551 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.562389 Y226.809354 Z20.280374 E6775.098854 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.843148 Y227.391761 Z20.28972 E6778.946734 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.107219 Y227.953175 Z20.299065 E6782.795219 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.355205 Y228.493123 Z20.308411 E6786.644365 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.58772 Y229.011154 Z20.317757 E6790.494224 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.805394 Y229.50683 Z20.327103 E6794.344851 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.008864 Y229.979733 Z20.336449 E6798.1963 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.198784 Y230.429463 Z20.345794 E6802.048625 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.375815 Y230.855637 Z20.35514 E6805.901881 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.540501 Y231.257602 Z20.364486 E6809.756091 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.692463 Y231.632374 Z20.373832 E6813.610961 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.833797 Y231.982471 Z20.383178 E6817.466398 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.965209 Y232.307594 Z20.392523 E6821.322455 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.087412 Y232.607469 Z20.401869 E6825.179186 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.201129 Y232.881838 Z20.411215 E6829.036645 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.307087 Y233.130465 Z20.420561 E6832.894887 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.406021 Y233.353133 Z20.429907 E6836.753966 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.498673 Y233.549647 Z20.439252 E6840.613936 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.585789 Y233.719832 Z20.448598 E6844.474852 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.667955 Y233.862277 Z20.457944 E6848.336642 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.745955 Y233.97589 Z20.46729 E6852.199059 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.820912 Y234.062756 Z20.476636 E6856.062056 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.893588 Y234.122794 Z20.485981 E6859.925688 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.964749 Y234.155946 Z20.495327 E6863.790008 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.03516 Y234.162175 Z20.504673 E6867.655072 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.105589 Y234.141465 Z20.514019 E6871.520933 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.176804 Y234.093822 Z20.523364 E6875.387646 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.249571 Y234.019271 Z20.53271 E6879.255265 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.324658 Y233.917862 Z20.542056 E6883.123845 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.403192 Y233.787474 Z20.551402 E6886.993217 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.485964 Y233.629167 Z20.560748 E6890.863183 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.573567 Y233.444324 Z20.570093 E6894.733744 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.666756 Y233.233089 Z20.579439 E6898.604955 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.766283 Y232.995628 Z20.588785 E6902.476869 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.872892 Y232.732125 Z20.598131 E6906.349541 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.987325 Y232.442789 Z20.607477 E6910.223025 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.110316 Y232.127848 Z20.616822 E6914.097376 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.242594 Y231.787548 Z20.626168 E6917.972649 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.384879 Y231.422159 Z20.635514 E6921.848897 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.539292 Y231.029117 Z20.64486 E6925.72585 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.705468 Y230.611396 Z20.654206 E6929.60337 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.883967 Y230.169623 Z20.663551 E6933.481499 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.075471 Y229.704155 Z20.672897 E6937.360292 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.280654 Y229.215368 Z20.682243 E6941.239804 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.500176 Y228.703656 Z20.691589 E6945.120088 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.734687 Y228.169434 Z20.700935 E6949.001199 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.984828 Y227.613131 Z20.71028 E6952.883193 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.251223 Y227.035197 Z20.719626 E6956.766123 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.534909 Y226.435619 Z20.728972 E6960.649983 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.838055 Y225.813295 Z20.738318 E6964.534491 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.159425 Y225.170948 Z20.747664 E6968.419569 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.499584 Y224.509103 Z20.757009 E6972.30527 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.859084 Y223.8283 Z20.766355 E6976.19165 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.23846 Y223.129094 Z20.775701 E6980.078763 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.638232 Y222.412055 Z20.785047 E6983.966664 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.058905 Y221.677769 Z20.794393 E6987.855407 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.500966 Y220.926833 Z20.803738 E6991.745047 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.964887 Y220.15986 Z20.813084 E6995.635639 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.452477 Y219.376631 Z20.82243 E6999.52708 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.964529 Y218.577761 Z20.831776 E7003.419135 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.499862 Y217.764966 Z20.841121 E7007.311774 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.058867 Y216.938914 Z20.850467 E7011.205051 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.641914 Y216.100284 Z20.859813 E7015.099022 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.249359 Y215.249762 Z20.869159 E7018.99374 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.881534 Y214.388046 Z20.878505 E7022.889262 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.538753 Y213.515844 Z20.88785 E7026.78564 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.221312 Y212.63387 Z20.897196 E7030.682931 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.929486 Y211.742848 Z20.906542 E7034.58119 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.665998 Y210.842847 Z20.915888 E7038.480211 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.429589 Y209.935211 Z20.925234 E7042.379817 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.219543 Y209.020967 Z20.934579 E7046.280021 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.036043 Y208.100867 Z20.943925 E7050.180878 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.879248 Y207.17567 Z20.953271 E7054.082444 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.749299 Y206.246136 Z20.962617 E7057.984772 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.646314 Y205.313032 Z20.971963 E7061.887918 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.570389 Y204.377126 Z20.981308 E7065.791937 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.521599 Y203.439191 Z20.990654 E7069.696883 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.5 Y202.5 Z21 E7073.602811 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.509144 Y201.560443 Z21.009346 E7077.509414 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.545512 Y200.621411 Z21.018692 E7081.416574 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.60908 Y199.68368 Z21.028037 E7085.324347 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.699805 Y198.748025 Z21.037383 E7089.232788 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.817622 Y197.815218 Z21.046729 E7093.141953 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.962443 Y196.886031 Z21.056075 E7097.051895 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.134161 Y195.961233 Z21.065421 E7100.96267 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.332645 Y195.04159 Z21.074766 E7104.874332 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.557745 Y194.127863 Z21.084112 E7108.786938 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.810209 Y193.22109 Z21.093458 E7112.700447 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.091336 Y192.322629 Z21.102804 E7116.614593 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.39842 Y191.43256 Z21.11215 E7120.529312 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.731215 Y190.55162 Z21.121495 E7124.444658 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.089457 Y189.68054 Z21.130841 E7128.360688 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.472857 Y188.820043 Z21.140187 E7132.277455 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.88111 Y187.970842 Z21.149533 E7136.195015 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.313888 Y187.133645 Z21.158879 E7140.113423 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.770845 Y186.309149 Z21.168224 E7144.032734 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.251616 Y185.498039 Z21.17757 E7147.953003 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.757419 Y184.702065 Z21.186916 E7151.874093 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.287484 Y183.921862 Z21.196262 E7155.795787 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.840014 Y183.157229 Z21.205607 E7159.718068 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.414559 Y182.408802 Z21.214953 E7163.640992 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.010652 Y181.677206 Z21.224299 E7167.564613 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.627809 Y180.963049 Z21.233645 E7171.488987 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.265529 Y180.26693 Z21.242991 E7175.414169 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.923295 Y179.58943 Z21.252336 E7179.340214 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.600571 Y178.931117 Z21.261682 E7183.267178 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.296809 Y178.292545 Z21.271028 E7187.195115 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.013282 Y177.676493 Z21.280374 E7191.123786 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.747817 Y177.081871 Z21.28972 E7195.053031 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.499386 Y176.508693 Z21.299065 E7198.982879 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.267374 Y175.957437 Z21.308411 E7202.913383 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.051153 Y175.428567 Z21.317757 E7206.844601 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.850081 Y174.922528 Z21.327103 E7210.776586 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.663505 Y174.439747 Z21.336449 E7214.709394 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.49076 Y173.980633 Z21.345794 E7218.643081 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.331169 Y173.545576 Z21.35514 E7222.577701 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.184177 Y173.135242 Z21.364486 E7226.51328 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.05017 Y172.752679 Z21.373832 E7230.449519 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.927008 Y172.395316 Z21.383178 E7234.38632 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.813971 Y172.063454 Z21.392523 E7238.323737 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.71033 Y171.757377 Z21.401869 E7242.261827 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.615347 Y171.477347 Z21.411215 E7246.200644 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.528278 Y171.223603 Z21.420561 E7250.140245 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.448374 Y170.996368 Z21.429907 E7254.080683 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.374877 Y170.795839 Z21.439252 E7258.022016 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.307025 Y170.622197 Z21.448598 E7261.964298 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.244221 Y170.476879 Z21.457944 E7265.907457 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.185662 Y170.361003 Z21.46729 E7269.851241 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.130203 Y170.272438 Z21.476636 E7273.795601 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.077064 Y170.211266 Z21.485981 E7277.740593 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.025466 Y170.177547 Z21.495327 E7281.686272 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.974625 Y170.171318 Z21.504673 E7285.632693 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.923758 Y170.192595 Z21.514019 E7289.579913 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.872082 Y170.241372 Z21.523364 E7293.527986 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.818812 Y170.317622 Z21.53271 E7297.476969 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.763166 Y170.421294 Z21.542056 E7301.426916 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.703994 Y170.554555 Z21.551402 E7305.377656 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.640486 Y170.716319 Z21.560748 E7309.328989 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.572038 Y170.905176 Z21.570093 E7313.280912 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.497879 Y171.120979 Z21.579439 E7317.233483 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.417242 Y171.363557 Z21.588785 E7321.186755 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.329366 Y171.632721 Z21.598131 E7325.140785 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.233495 Y171.928259 Z21.607477 E7329.095628 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.128878 Y172.249938 Z21.616822 E7333.05134 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.014773 Y172.597506 Z21.626168 E7337.007977 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.890443 Y172.970686 Z21.635514 E7340.965594 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.753724 Y173.372096 Z21.64486 E7344.923915 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.604988 Y173.7987 Z21.654206 E7348.8828 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.443664 Y174.249858 Z21.663551 E7352.842291 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.269054 Y174.725203 Z21.672897 E7356.802444 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.080473 Y175.224353 Z21.682243 E7360.763313 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.877246 Y175.746904 Z21.691589 E7364.724956 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.658708 Y176.292434 Z21.700935 E7368.687427 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.424207 Y176.860502 Z21.71028 E7372.650782 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.173105 Y177.45065 Z21.719626 E7376.615078 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.904344 Y178.062891 Z21.728972 E7380.580306 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.615709 Y178.698349 Z21.738318 E7384.546183 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.308463 Y179.354245 Z21.747664 E7388.512624 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.982029 Y180.030041 Z21.757009 E7392.479686 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.635844 Y180.725187 Z21.766355 E7396.447425 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.269362 Y181.439116 Z21.775701 E7400.415896 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.882052 Y182.171244 Z21.785047 E7404.385155 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.473398 Y182.920975 Z21.794393 E7408.355258 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.042904 Y183.687698 Z21.803738 E7412.326261 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.590089 Y184.470788 Z21.813084 E7416.29822 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.113106 Y185.270467 Z21.82243 E7420.271029 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.611144 Y186.086108 Z21.831776 E7424.244451 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.085411 Y186.915958 Z21.841121 E7428.218453 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.535509 Y187.759335 Z21.850467 E7432.19309 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.961057 Y188.615547 Z21.859813 E7436.16842 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.361695 Y189.483892 Z21.869159 E7440.144496 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.737084 Y190.363657 Z21.878505 E7444.121376 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.086901 Y191.254122 Z21.88785 E7448.099116 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.410848 Y192.154555 Z21.897196 E7452.07777 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.708643 Y193.064218 Z21.906542 E7456.057396 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.977505 Y193.983039 Z21.915888 E7460.037786 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.218721 Y194.909647 Z21.925234 E7464.018758 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.433022 Y195.842994 Z21.934579 E7468.000324 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.620223 Y196.782311 Z21.943925 E7471.982541 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.780159 Y197.726826 Z21.953271 E7475.965465 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.912689 Y198.675759 Z21.962617 E7479.949151 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.017693 Y199.628329 Z21.971963 E7483.933656 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.095071 Y200.583752 Z21.981308 E7487.919036 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.144747 Y201.541239 Z21.990654 E7491.905347 F2400 ; clayline kind=print page=0 layer=9 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.166667 Y202.5 Z22 E7495.892645 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.157202 Y203.459127 Z22.009346 E7499.880616 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.119948 Y204.417711 Z22.018692 E7503.869141 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.054927 Y205.374959 Z22.028037 E7507.858276 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.962184 Y206.330081 Z22.037383 E7511.848076 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.841786 Y207.282287 Z22.046729 E7515.838599 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.693823 Y208.23079 Z22.056075 E7519.829899 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.518405 Y209.174806 Z22.065421 E7523.822033 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.315665 Y210.113552 Z22.074766 E7527.815058 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.085758 Y211.046251 Z22.084112 E7531.80903 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.827919 Y211.971845 Z22.093458 E7535.803908 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.540824 Y212.888947 Z22.102804 E7539.799422 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.227235 Y213.797474 Z22.11215 E7543.795504 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.887402 Y214.696676 Z22.121495 E7547.792211 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.521597 Y215.585806 Z22.130841 E7551.789599 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.130114 Y216.464127 Z22.140187 E7555.787725 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.713266 Y217.330908 Z22.149533 E7559.786643 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.271386 Y218.185431 Z22.158879 E7563.786411 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.804828 Y219.026983 Z22.168224 E7567.787085 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.313967 Y219.854863 Z22.17757 E7571.788721 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.797557 Y220.667287 Z22.186916 E7575.791181 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.256386 Y221.463607 Z22.196262 E7579.794241 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.692289 Y222.244027 Z22.205607 E7583.797885 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.105725 Y223.007898 Z22.214953 E7587.802168 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.49717 Y223.754585 Z22.224299 E7591.807148 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.867119 Y224.483464 Z22.233645 E7595.81288 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.216084 Y225.193926 Z22.242991 E7599.819421 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.544594 Y225.885378 Z22.252336 E7603.826828 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.853193 Y226.557239 Z22.261682 E7607.835155 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.142444 Y227.208945 Z22.271028 E7611.844461 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.411046 Y227.83766 Z22.280374 E7615.854501 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.661218 Y228.444496 Z22.28972 E7619.865111 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.894009 Y229.02944 Z22.299065 E7623.876321 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.110048 Y229.592003 Z22.308411 E7627.888185 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.309974 Y230.131712 Z22.317757 E7631.900761 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.494445 Y230.648114 Z22.327103 E7635.914104 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.664125 Y231.140772 Z22.336449 E7639.928272 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.819696 Y231.609271 Z22.345794 E7643.94332 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.961847 Y232.05321 Z22.35514 E7647.959306 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.091145 Y232.471913 Z22.364486 E7651.976253 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.207197 Y232.862268 Z22.373832 E7655.993861 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.312186 Y233.226898 Z22.383178 E7660.012026 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.406849 Y233.565497 Z22.392523 E7664.030805 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.491928 Y233.877776 Z22.401869 E7668.050254 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.568178 Y234.163469 Z22.411215 E7672.07043 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.636357 Y234.422329 Z22.420561 E7676.091388 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.697231 Y234.654132 Z22.429907 E7680.113187 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.751573 Y234.858674 Z22.439252 E7684.135882 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.80016 Y235.035775 Z22.448598 E7688.15953 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.843603 Y235.183965 Z22.457944 E7692.184058 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.882721 Y235.302104 Z22.46729 E7696.20921 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.918683 Y235.392368 Z22.476636 E7700.234933 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.952283 Y235.454673 Z22.485981 E7704.261285 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.984319 Y235.488959 Z22.495327 E7708.288323 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.01559 Y235.495188 Z22.504673 E7712.316103 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.046894 Y235.473344 Z22.514019 E7716.344682 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.079033 Y235.423434 Z22.523364 E7720.374115 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.112805 Y235.345485 Z22.53271 E7724.404461 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.14901 Y235.23955 Z22.542056 E7728.435776 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.188821 Y235.103417 Z22.551402 E7732.467885 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.233064 Y234.938195 Z22.560748 E7736.500584 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.282357 Y234.745323 Z22.570093 E7740.53387 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.337486 Y234.524954 Z22.579439 E7744.5678 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.399233 Y234.277258 Z22.588785 E7748.602431 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.468376 Y234.002433 Z22.598131 E7752.637819 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.545685 Y233.700692 Z22.607477 E7756.674022 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.631927 Y233.372275 Z22.616822 E7760.711095 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.72786 Y233.017441 Z22.626168 E7764.749096 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.834235 Y232.636469 Z22.635514 E7768.788082 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.95326 Y232.226691 Z22.64486 E7772.827773 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.084556 Y231.791203 Z22.654206 E7776.868023 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.228706 Y231.330662 Z22.663551 E7780.908875 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.38642 Y230.845439 Z22.672897 E7784.950387 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.5584 Y230.335926 Z22.682243 E7788.992615 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.745333 Y229.802536 Z22.691589 E7793.035616 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.947897 Y229.245699 Z22.700935 E7797.079447 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.166758 Y228.665865 Z22.71028 E7801.124164 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.402567 Y228.063503 Z22.719626 E7805.169825 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.656403 Y227.438599 Z22.728972 E7809.216423 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.930526 Y226.790007 Z22.738318 E7813.263667 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.223648 Y226.120563 Z22.747664 E7817.311473 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.536358 Y225.430815 Z22.757009 E7821.359896 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.869228 Y224.721326 Z22.766355 E7825.408994 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.222816 Y223.992675 Z22.775701 E7829.458823 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.597665 Y223.245457 Z22.785047 E7833.509441 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.994299 Y222.48028 Z22.794393 E7837.560905 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.413225 Y221.69777 Z22.803738 E7841.61327 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.854935 Y220.898564 Z22.813084 E7845.666596 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.321312 Y220.082435 Z22.82243 E7849.720774 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.813183 Y219.250023 Z22.831776 E7853.775563 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.329315 Y218.403118 Z22.841121 E7857.830928 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.870116 Y217.542416 Z22.850467 E7861.886926 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.435972 Y216.668622 Z22.859813 E7865.943614 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.027251 Y215.782454 Z22.869159 E7870.001049 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.644299 Y214.884639 Z22.878505 E7874.059288 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.287444 Y213.975912 Z22.88785 E7878.118388 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.956993 Y213.057021 Z22.897196 E7882.178407 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.653229 Y212.128717 Z22.906542 E7886.239401 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.378993 Y211.191075 Z22.915888 E7890.30116 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.132969 Y210.245495 Z22.925234 E7894.363497 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.914412 Y209.293045 Z22.934579 E7898.426426 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.723511 Y208.33451 Z22.943925 E7902.490003 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.560433 Y207.370679 Z22.953271 E7906.554285 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.425322 Y206.402346 Z22.962617 E7910.61933 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.318301 Y205.43031 Z22.971963 E7914.685195 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.23947 Y204.45537 Z22.981308 E7918.751936 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.188907 Y203.478332 Z22.990654 E7922.819612 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.166667 Y202.5 Z23 E7926.888279 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.176451 Y201.521302 Z23.009346 E7930.957619 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.214593 Y200.543167 Z23.018692 E7935.027509 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.281067 Y199.566402 Z23.028037 E7939.098005 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.375828 Y198.591814 Z23.037383 E7943.169165 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.498806 Y197.620208 Z23.046729 E7947.241046 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.649911 Y196.652389 Z23.056075 E7951.313705 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.82903 Y195.689155 Z23.065421 E7955.387199 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.036025 Y194.731306 Z23.074766 E7959.461586 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.27074 Y193.779634 Z23.084112 E7963.536924 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.533953 Y192.83522 Z23.093458 E7967.613171 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.827016 Y191.899478 Z23.102804 E7971.690053 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.147111 Y190.972491 Z23.11215 E7975.767499 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.493981 Y190.055028 Z23.121495 E7979.845567 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.867349 Y189.147848 Z23.130841 E7983.924314 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.266915 Y188.251704 Z23.140187 E7988.003798 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.692359 Y187.367341 Z23.149533 E7992.084075 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.143341 Y186.495493 Z23.158879 E7996.165204 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.619498 Y185.636886 Z23.168224 E8000.247241 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.120451 Y184.792235 Z23.17757 E8004.330245 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.647467 Y183.963361 Z23.186916 E8008.414073 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.199744 Y183.150925 Z23.196262 E8012.4985 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.775408 Y182.354717 Z23.205607 E8016.583507 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.373992 Y181.575401 Z23.214953 E8020.669151 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.995008 Y180.813625 Z23.224299 E8024.755489 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.637953 Y180.070023 Z23.233645 E8028.84258 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.302302 Y179.345218 Z23.242991 E8032.93048 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.987518 Y178.639815 Z23.252336 E8037.019247 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.693042 Y177.954405 Z23.261682 E8041.108939 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.418303 Y177.289565 Z23.271028 E8045.199613 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.164626 Y176.648187 Z23.280374 E8049.291023 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.929747 Y176.029137 Z23.28972 E8053.382999 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.712595 Y175.432427 Z23.299065 E8057.47557 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.512531 Y174.858557 Z23.308411 E8061.568794 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.328898 Y174.308009 Z23.317757 E8065.662729 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.16103 Y173.781244 Z23.327103 E8069.75743 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.008244 Y173.278708 Z23.336449 E8073.852958 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.869848 Y172.800826 Z23.345794 E8077.949368 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.745137 Y172.348003 Z23.35514 E8082.046719 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.633532 Y171.920931 Z23.364486 E8086.145036 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.535436 Y171.522786 Z23.373832 E8090.244012 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.448619 Y171.150888 Z23.383178 E8094.343542 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.372332 Y170.805551 Z23.392523 E8098.443682 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.305813 Y170.48707 Z23.401869 E8102.544491 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.248297 Y170.195716 Z23.411215 E8106.646025 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.199008 Y169.931739 Z23.420561 E8110.748342 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.157164 Y169.695369 Z23.429907 E8114.851501 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.121978 Y169.486812 Z23.439252 E8118.955559 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.092655 Y169.306253 Z23.448598 E8123.060573 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.068573 Y169.155192 Z23.457944 E8127.166471 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.048896 Y169.034789 Z23.46729 E8131.27299 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.032432 Y168.942826 Z23.476636 E8135.380077 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.01837 Y168.879387 Z23.485981 E8139.48779 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.005896 Y168.844534 Z23.495327 E8143.596187 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.994196 Y168.838305 Z23.504673 E8147.705325 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.982453 Y168.860716 Z23.514019 E8151.815263 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.969852 Y168.91176 Z23.523364 E8155.926057 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.955578 Y168.991408 Z23.53271 E8160.037767 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.938814 Y169.099607 Z23.542056 E8164.150449 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.918364 Y169.238612 Z23.551402 E8168.263928 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.893385 Y169.407291 Z23.560748 E8172.377993 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.863248 Y169.604177 Z23.570093 E8176.492642 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.827149 Y169.829114 Z23.579439 E8180.607932 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.784291 Y170.081926 Z23.588785 E8184.723922 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.733882 Y170.362414 Z23.598131 E8188.840668 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.675134 Y170.670356 Z23.607477 E8192.95823 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.607267 Y171.005511 Z23.616822 E8197.076665 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.529507 Y171.367612 Z23.626168 E8201.196031 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.441088 Y171.756375 Z23.635514 E8205.316386 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.339756 Y172.174522 Z23.64486 E8209.437445 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.2259 Y172.618893 Z23.654206 E8213.559061 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.098925 Y173.088819 Z23.663551 E8217.681275 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.958105 Y173.583919 Z23.672897 E8221.804147 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.802727 Y174.103795 Z23.682243 E8225.927733 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.632088 Y174.648024 Z23.691589 E8230.052093 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.445498 Y175.216168 Z23.700935 E8234.177284 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.242277 Y175.807767 Z23.71028 E8238.303363 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.021761 Y176.422344 Z23.719626 E8242.43039 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.78285 Y177.05991 Z23.728972 E8246.558357 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.523238 Y177.721637 Z23.738318 E8250.68697 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.24424 Y178.40463 Z23.747664 E8254.81614 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.945256 Y179.108329 Z23.757009 E8258.945925 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.625701 Y179.832161 Z23.766355 E8263.076382 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.285006 Y180.575535 Z23.775701 E8267.20757 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.922618 Y181.337843 Z23.785047 E8271.339546 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.538004 Y182.118464 Z23.794393 E8275.47237 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.130645 Y182.916762 Z23.803738 E8279.606099 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.700041 Y183.732084 Z23.813084 E8283.740791 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.24427 Y184.564663 Z23.82243 E8287.876339 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.76249 Y185.413845 Z23.831776 E8292.012495 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.255958 Y186.277805 Z23.841121 E8296.149224 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.724259 Y187.155833 Z23.850467 E8300.286582 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.166999 Y188.047209 Z23.859813 E8304.424629 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.583803 Y188.9512 Z23.869159 E8308.563423 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.974318 Y189.867065 Z23.878505 E8312.703021 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.33821 Y190.794054 Z23.88785 E8316.843482 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.675167 Y191.731404 Z23.897196 E8320.984865 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.984899 Y192.678348 Z23.906542 E8325.127227 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.26451 Y193.63481 Z23.915888 E8329.270356 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.515341 Y194.599363 Z23.925234 E8333.414059 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.738153 Y195.570916 Z23.934579 E8337.55835 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.932754 Y196.548669 Z23.943925 E8341.703287 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.098974 Y197.531816 Z23.953271 E8345.848928 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.236666 Y198.519548 Z23.962617 E8349.995332 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.345705 Y199.511051 Z23.971963 E8354.142556 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.42599 Y200.505508 Z23.981308 E8358.290659 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.47744 Y201.502098 Z23.990654 E8362.4397 F2400 ; clayline kind=print page=0 layer=10 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.5 Y202.5 Z24 E8366.589736 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.478997 Y203.497948 Z24.009346 E8370.739822 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.429099 Y204.494675 Z24.018692 E8374.889104 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.35036 Y205.48936 Z24.028037 E8379.037641 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.242853 Y206.481182 Z24.037383 E8383.185492 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X241.106678 Y207.469323 Z24.046729 E8387.332714 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.941954 Y208.452969 Z24.056075 E8391.479367 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.748826 Y209.431309 Z24.065421 E8395.625508 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.527459 Y210.403537 Z24.074766 E8399.771196 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.278042 Y211.368851 Z24.084112 E8403.916489 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.999808 Y212.32616 Z24.093458 E8408.061394 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.691414 Y213.274034 Z24.102804 E8412.205706 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.355752 Y214.212396 Z24.11215 E8416.349232 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.993108 Y215.140476 Z24.121495 E8420.492029 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.603791 Y216.057512 Z24.130841 E8424.634155 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.188131 Y216.962751 Z24.140187 E8428.775669 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.746479 Y217.855447 Z24.149533 E8432.91663 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.279205 Y218.734868 Z24.158879 E8437.057094 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.786701 Y219.600291 Z24.168224 E8441.197121 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.269378 Y220.451004 Z24.17757 E8445.336769 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.725974 Y221.285175 Z24.186916 E8449.475988 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.15733 Y222.102152 Z24.196262 E8453.614532 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.565366 Y222.902161 Z24.205607 E8457.752305 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.950578 Y223.68455 Z24.214953 E8461.889366 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.313482 Y224.448678 Z24.224299 E8466.025773 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.65461 Y225.19392 Z24.233645 E8470.161583 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.974513 Y225.919667 Z24.242991 E8474.296855 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.273756 Y226.625323 Z24.252336 E8478.431647 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.552923 Y227.310311 Z24.261682 E8482.566017 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.812613 Y227.974069 Z24.271028 E8486.700023 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.051503 Y228.613695 Z24.280374 E8490.833556 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.271904 Y229.230357 Z24.28972 E8494.966337 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.474911 Y229.824066 Z24.299065 E8499.098363 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.661189 Y230.394339 Z24.308411 E8503.229692 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.831415 Y230.940713 Z24.317757 E8507.360383 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.986279 Y231.462745 Z24.327103 E8511.490493 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.126482 Y231.96001 Z24.336449 E8515.620081 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.252739 Y232.432104 Z24.345794 E8519.749205 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.365771 Y232.878641 Z24.35514 E8523.877922 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.466175 Y233.29895 Z24.364486 E8528.006275 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.55356 Y233.689859 Z24.373832 E8532.134093 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.630181 Y234.054094 Z24.383178 E8536.261114 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.696804 Y234.391363 Z24.392523 E8540.387397 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.754202 Y234.701398 Z24.401869 E8544.512999 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.803158 Y234.983952 Z24.411215 E8548.637978 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.844459 Y235.238799 Z24.420561 E8552.762393 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.878897 Y235.465736 Z24.429907 E8556.886302 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.907271 Y235.664583 Z24.439252 E8561.009761 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.930385 Y235.83518 Z24.448598 E8565.13283 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.948869 Y235.97605 Z24.457944 E8569.255497 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.963566 Y236.086058 Z24.46729 E8573.377544 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.975678 Y236.167457 Z24.476636 E8577.498811 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.986019 Y236.220193 Z24.485981 E8581.619355 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.995407 Y236.24423 Z24.495327 E8585.739234 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.004661 Y236.239558 Z24.504673 E8589.858506 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.014598 Y236.206189 Z24.514019 E8593.97723 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.026036 Y236.144158 Z24.523364 E8598.095463 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.039789 Y236.053522 Z24.53271 E8602.213263 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.056671 Y235.934362 Z24.542056 E8606.330687 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.077879 Y235.784448 Z24.551402 E8610.447668 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.104251 Y235.604943 Z24.560748 E8614.563949 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.136412 Y235.397343 Z24.570093 E8618.679465 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.175159 Y235.161831 Z24.579439 E8622.794275 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.221283 Y234.89861 Z24.588785 E8626.908436 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.275569 Y234.607906 Z24.598131 E8631.022005 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.338796 Y234.289967 Z24.607477 E8635.135042 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.411734 Y233.945061 Z24.616822 E8639.247604 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.495147 Y233.573479 Z24.626168 E8643.359748 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.58979 Y233.175532 Z24.635514 E8647.471532 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.697898 Y232.748531 Z24.64486 E8651.582828 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.819072 Y232.295654 Z24.654206 E8655.693346 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.953894 Y231.817593 Z24.663551 E8659.803117 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.103072 Y231.314752 Z24.672897 E8663.912196 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.267304 Y230.787553 Z24.682243 E8668.020643 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.447276 Y230.236439 Z24.691589 E8672.128515 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.643659 Y229.661872 Z24.700935 E8676.235869 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.857115 Y229.06433 Z24.71028 E8680.342763 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.088287 Y228.444313 Z24.719626 E8684.449256 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.338252 Y227.801828 Z24.728972 E8688.55537 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.609287 Y227.135735 Z24.738318 E8692.660922 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.900062 Y226.448934 Z24.747664 E8696.765683 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.211156 Y225.742 Z24.757009 E8700.869712 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.54313 Y225.015524 Z24.766355 E8704.973066 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.896529 Y224.27011 Z24.775701 E8709.075803 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.27188 Y223.506381 Z24.785047 E8713.17798 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.669693 Y222.724971 Z24.794393 E8717.279656 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.090461 Y221.926529 Z24.803738 E8721.380888 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.534657 Y221.111718 Z24.813084 E8725.481733 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.004163 Y220.280324 Z24.82243 E8729.582162 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.499791 Y219.433011 Z24.831776 E8733.681944 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.020269 Y218.571603 Z24.841121 E8737.780953 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.565985 Y217.696816 Z24.850467 E8741.879244 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.137304 Y216.809379 Z24.859813 E8745.976877 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.734573 Y215.910026 Z24.869159 E8750.073908 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.358117 Y214.999505 Z24.878505 E8754.170396 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.008239 Y214.078568 Z24.88785 E8758.266397 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.685223 Y213.147978 Z24.897196 E8762.36197 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.38933 Y212.208506 Z24.906542 E8766.457172 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.123396 Y211.260233 Z24.915888 E8770.551915 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.886066 Y210.304579 Z24.925234 E8774.645933 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.676561 Y209.342629 Z24.934579 E8778.739193 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.495045 Y208.375179 Z24.943925 E8782.831752 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.341658 Y207.403029 Z24.953271 E8786.923667 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.216517 Y206.426982 Z24.962617 E8791.014998 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.11972 Y205.447847 Z24.971963 E8795.1058 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.051338 Y204.46643 Z24.981308 E8799.196131 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.011422 Y203.483544 Z24.990654 E8803.286049 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174 Y202.5 Z25 E8807.375612 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.020763 Y201.51673 Z25.009346 E8811.46467 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.069995 Y200.534666 Z25.018692 E8815.552927 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.147645 Y199.55462 Z25.028037 E8819.640443 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.253638 Y198.577397 Z25.037383 E8823.727273 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.387878 Y197.603806 Z25.046729 E8827.813476 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.550245 Y196.634647 Z25.056075 E8831.899109 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.740598 Y195.67072 Z25.065421 E8835.98423 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X174.958773 Y194.71282 Z25.074766 E8840.068896 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.204585 Y193.761735 Z25.084112 E8844.153164 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.478788 Y192.818541 Z25.093458 E8848.237041 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.782705 Y191.884648 Z25.102804 E8852.320326 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.113489 Y190.96013 Z25.11215 E8856.402828 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.470855 Y190.045746 Z25.121495 E8860.484604 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.8545 Y189.142247 Z25.130841 E8864.56571 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.264097 Y188.250376 Z25.140187 E8868.646205 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.699303 Y187.370866 Z25.149533 E8872.726145 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.15975 Y186.504439 Z25.158879 E8876.805589 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.645054 Y185.651808 Z25.168224 E8880.884593 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.154809 Y184.813673 Z25.17757 E8884.963214 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.690258 Y183.991839 Z25.186916 E8889.041406 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.250573 Y183.18695 Z25.196262 E8893.118924 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.833862 Y182.398781 Z25.205607 E8897.195675 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.439635 Y181.627975 Z25.214953 E8901.271715 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.067385 Y180.875165 Z25.224299 E8905.347101 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.716586 Y180.140965 Z25.233645 E8909.421892 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.386697 Y179.425975 Z25.242991 E8913.496144 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.07716 Y178.730783 Z25.252336 E8917.569915 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.7874 Y178.055956 Z25.261682 E8921.643261 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.516827 Y177.402049 Z25.271028 E8925.71624 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.266743 Y176.77192 Z25.280374 E8929.788746 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.034873 Y176.164418 Z25.28972 E8933.860502 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.820136 Y175.579533 Z25.299065 E8937.931505 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.621877 Y175.017741 Z25.308411 E8942.001814 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.43943 Y174.479496 Z25.317757 E8946.071485 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.272115 Y173.965236 Z25.327103 E8950.140576 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.11924 Y173.475379 Z25.336449 E8954.209144 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.980103 Y173.010324 Z25.345794 E8958.277245 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.853991 Y172.570449 Z25.35514 E8962.344938 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.740316 Y172.156417 Z25.364486 E8966.412263 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.639465 Y171.771351 Z25.373832 E8970.479054 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.549215 Y171.412567 Z25.383178 E8974.545051 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.468811 Y171.08035 Z25.392523 E8978.610312 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.397491 Y170.774967 Z25.401869 E8982.674894 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.334485 Y170.496659 Z25.411215 E8986.738854 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.279018 Y170.24565 Z25.420561 E8990.802249 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.230307 Y170.022138 Z25.429907 E8994.865137 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.187566 Y169.826303 Z25.439252 E8998.927574 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.150004 Y169.658299 Z25.448598 E9002.989618 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.116999 Y169.519582 Z25.457944 E9007.051257 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.087721 Y169.411272 Z25.46729 E9011.112278 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.060986 Y169.331147 Z25.476636 E9015.172521 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.035992 Y169.279262 Z25.485981 E9019.232044 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.011932 Y169.25565 Z25.495327 E9023.290903 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.988 Y169.260322 Z25.504673 E9027.349156 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.963391 Y169.293266 Z25.514019 E9031.40686 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.9373 Y169.354446 Z25.523364 E9035.464072 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.908924 Y169.443808 Z25.53271 E9039.520848 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.87746 Y169.561271 Z25.542056 E9043.577247 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.841732 Y169.70903 Z25.551402 E9047.6332 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.800912 Y169.885943 Z25.560748 E9051.688455 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.754384 Y170.090532 Z25.570093 E9055.742949 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.701365 Y170.322618 Z25.579439 E9059.796738 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.641073 Y170.582002 Z25.588785 E9063.849879 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.572737 Y170.868459 Z25.598131 E9067.902429 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.495589 Y171.181747 Z25.607477 E9071.954446 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.40887 Y171.521599 Z25.616822 E9076.005986 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.311828 Y171.887731 Z25.626168 E9080.057106 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.203719 Y172.279834 Z25.635514 E9084.107863 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.08234 Y172.700559 Z25.64486 E9088.158131 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.948086 Y173.146774 Z25.654206 E9092.207625 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.800383 Y173.617797 Z25.663551 E9096.256374 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.638534 Y174.11323 Z25.672897 E9100.304433 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.46185 Y174.632656 Z25.682243 E9104.35186 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.269658 Y175.175641 Z25.691589 E9108.398712 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.061294 Y175.741728 Z25.700935 E9112.445046 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.836109 Y176.330445 Z25.71028 E9116.490918 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.593467 Y176.941302 Z25.719626 E9120.536386 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.332308 Y177.574289 Z25.728972 E9124.581473 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.05039 Y178.230532 Z25.738318 E9128.625998 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.749022 Y178.907171 Z25.747664 E9132.669735 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.427634 Y179.603642 Z25.757009 E9136.712743 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.085674 Y180.319361 Z25.766355 E9140.755077 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.722605 Y181.053732 Z25.775701 E9144.796794 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.337907 Y181.806144 Z25.785047 E9148.837952 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.931079 Y182.575971 Z25.794393 E9152.878607 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.501636 Y183.362572 Z25.803738 E9156.918815 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.049111 Y184.165296 Z25.813084 E9160.958635 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.57165 Y184.984352 Z25.82243 E9164.998036 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.068454 Y185.819088 Z25.831776 E9169.036793 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.540776 Y186.667705 Z25.841121 E9173.074778 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.988234 Y187.529497 Z25.850467 E9177.112049 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.410467 Y188.403748 Z25.859813 E9181.148662 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.807136 Y189.289733 Z25.869159 E9185.184674 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.177921 Y190.186718 Z25.878505 E9189.220142 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.52252 Y191.093958 Z25.88785 E9193.255122 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.840657 Y192.010703 Z25.897196 E9197.289671 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.132073 Y192.936195 Z25.906542 E9201.323846 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.393977 Y193.870353 Z25.915888 E9205.357562 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.627702 Y194.811777 Z25.925234 E9209.390555 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.834015 Y195.7594 Z25.934579 E9213.422792 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.012756 Y196.712437 Z25.943925 E9217.454331 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.163787 Y197.6701 Z25.953271 E9221.485227 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.286991 Y198.631597 Z25.962617 E9225.515538 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.382276 Y199.596133 Z25.971963 E9229.545319 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.449568 Y200.562911 Z25.981308 E9233.574629 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.488818 Y201.531133 Z25.990654 E9237.603523 F2400 ; clayline kind=print page=0 layer=11 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.5 Y202.5 Z26 E9241.632058 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.479477 Y203.468592 Z26.009346 E9245.660088 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.43091 Y204.435992 Z26.018692 E9249.687322 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.35435 Y205.401401 Z26.028037 E9253.713815 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.24987 Y206.364024 Z26.037383 E9257.739626 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X240.117566 Y207.323066 Z26.046729 E9261.764809 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.957556 Y208.277737 Z26.056075 E9265.789423 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.769978 Y209.227251 Z26.065421 E9269.813523 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.554994 Y210.170824 Z26.074766 E9273.837166 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.312788 Y211.107679 Z26.084112 E9277.860409 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.042616 Y212.036758 Z26.093458 E9281.883259 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.743175 Y212.95667 Z26.102804 E9285.905518 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.41727 Y213.867345 Z26.11215 E9289.926997 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.065182 Y214.768032 Z26.121495 E9293.947751 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.68721 Y215.657993 Z26.130841 E9297.967837 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.283674 Y216.536497 Z26.140187 E9301.987313 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.854916 Y217.402821 Z26.149533 E9306.006233 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.401295 Y218.256254 Z26.158879 E9310.024656 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.923191 Y219.096094 Z26.168224 E9314.042637 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.421004 Y219.921651 Z26.17757 E9318.060233 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.89351 Y220.731147 Z26.186916 E9322.077396 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.341525 Y221.523949 Z26.196262 E9326.093889 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.766911 Y222.300278 Z26.205607 E9330.109617 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.170152 Y223.059499 Z26.214953 E9334.124636 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.551749 Y223.800992 Z26.224299 E9338.139003 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.912218 Y224.524151 Z26.233645 E9342.152775 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.252093 Y225.228383 Z26.242991 E9346.166007 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.571924 Y225.913112 Z26.252336 E9350.178756 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.872277 Y226.577777 Z26.261682 E9354.191078 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.153733 Y227.221834 Z26.271028 E9358.203031 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.415011 Y227.842465 Z26.280374 E9362.214509 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.658351 Y228.440807 Z26.28972 E9366.22524 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.884818 Y229.016867 Z26.299065 E9370.235221 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.095057 Y229.570179 Z26.308411 E9374.24451 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.289724 Y230.100295 Z26.317757 E9378.253162 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.469491 Y230.606782 Z26.327103 E9382.261233 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.635037 Y231.089231 Z26.336449 E9386.26878 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.787055 Y231.547248 Z26.345794 E9390.27586 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.926247 Y231.980461 Z26.35514 E9394.282529 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.053192 Y232.388216 Z26.364486 E9398.288826 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.16751 Y232.767439 Z26.373832 E9402.29459 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.271389 Y233.120773 Z26.383178 E9406.299563 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.365574 Y233.447936 Z26.392523 E9410.303803 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.450815 Y233.748668 Z26.401869 E9414.307364 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.527871 Y234.022729 Z26.411215 E9418.310305 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.597506 Y234.269901 Z26.420561 E9422.312681 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.660489 Y234.489987 Z26.429907 E9426.314548 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.717597 Y234.682812 Z26.439252 E9430.315962 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.769607 Y234.848222 Z26.448598 E9434.316981 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.817133 Y234.984785 Z26.457944 E9438.317592 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.860992 Y235.091397 Z26.46729 E9442.317587 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.90235 Y235.170248 Z26.476636 E9446.316807 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.941998 Y235.221283 Z26.485981 E9450.315309 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.98073 Y235.24447 Z26.495327 E9454.313148 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.019339 Y235.239798 Z26.504673 E9458.310382 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.058619 Y235.20728 Z26.514019 E9462.307066 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.099364 Y235.146949 Z26.523364 E9466.303257 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.142363 Y235.058862 Z26.53271 E9470.29901 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.188408 Y234.943096 Z26.542056 E9474.294382 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.238657 Y234.797491 Z26.551402 E9478.289308 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.293926 Y234.623172 Z26.560748 E9482.283539 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.354819 Y234.421593 Z26.570093 E9486.27701 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.422112 Y234.192932 Z26.579439 E9490.269778 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.49657 Y233.937387 Z26.588785 E9494.2619 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.578956 Y233.655176 Z26.598131 E9498.253431 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.670026 Y233.34654 Z26.607477 E9502.244427 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.770526 Y233.01174 Z26.616822 E9506.234946 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.881198 Y232.651059 Z26.626168 E9510.225042 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.002773 Y232.264799 Z26.635514 E9514.214772 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.137422 Y231.85035 Z26.64486 E9518.204012 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.284756 Y231.410798 Z26.654206 E9522.192482 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.44534 Y230.946814 Z26.663551 E9526.180209 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.619861 Y230.458789 Z26.672897 E9530.167248 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.808995 Y229.947134 Z26.682243 E9534.153655 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.013408 Y229.41228 Z26.691589 E9538.139488 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.233752 Y228.854673 Z26.700935 E9542.124801 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.470667 Y228.274779 Z26.71028 E9546.109652 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.724779 Y227.673083 Z26.719626 E9550.094095 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.997132 Y227.049593 Z26.728972 E9554.078154 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.289933 Y226.403201 Z26.738318 E9558.061652 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.601895 Y225.736723 Z26.747664 E9562.044366 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.933576 Y225.050716 Z26.757009 E9566.026352 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.285522 Y224.345754 Z26.766355 E9570.007666 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.658261 Y223.622425 Z26.775701 E9573.988364 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.052305 Y222.88133 Z26.785047 E9577.968503 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.468148 Y222.123088 Z26.794393 E9581.948137 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.906267 Y221.348327 Z26.803738 E9585.927323 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.367121 Y220.55769 Z26.813084 E9589.906117 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.852537 Y219.750971 Z26.82243 E9593.884491 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.3633 Y218.928814 Z26.831776 E9597.862222 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.898179 Y218.092988 Z26.841121 E9601.839184 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.457548 Y217.24419 Z26.850467 E9605.815434 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.041761 Y216.383125 Z26.859813 E9609.791027 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.651154 Y215.510507 Z26.869159 E9613.76602 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.286042 Y214.62706 Z26.878505 E9617.740468 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.94672 Y213.733516 Z26.88785 E9621.714427 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.633463 Y212.830615 Z26.897196 E9625.687953 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.346523 Y211.919104 Z26.906542 E9629.661101 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.08865 Y210.999061 Z26.915888 E9633.63379 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.858531 Y210.071867 Z26.925234 E9637.605758 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.655409 Y209.138571 Z26.934579 E9641.576973 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.479444 Y208.199947 Z26.943925 E9645.547491 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.330769 Y207.256772 Z26.953271 E9649.517367 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.2095 Y206.309824 Z26.962617 E9653.486659 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.115729 Y205.359888 Z26.971963 E9657.455421 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.049527 Y204.407747 Z26.981308 E9661.423709 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.010941 Y203.454189 Z26.990654 E9665.391579 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175 Y202.5 Z27 E9669.359086 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.020283 Y201.546085 Z27.009346 E9673.326089 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.068184 Y200.593349 Z27.018692 E9677.292298 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.143655 Y199.642578 Z27.028037 E9681.25777 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.246621 Y198.694555 Z27.037383 E9685.22256 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.376989 Y197.750063 Z27.046729 E9689.186725 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.534644 Y196.809879 Z27.056075 E9693.150319 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.719446 Y195.874779 Z27.065421 E9697.113399 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X175.931238 Y194.945533 Z27.074766 E9701.07602 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.169839 Y194.022906 Z27.084112 E9705.038238 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.43598 Y193.107943 Z27.093458 E9709.00006 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.730945 Y192.202011 Z27.102804 E9712.961293 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.051971 Y191.305181 Z27.11215 E9716.921748 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.398781 Y190.41819 Z27.121495 E9720.881481 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.771081 Y189.541766 Z27.130841 E9724.840548 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.168554 Y188.67663 Z27.140187 E9728.799004 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.590866 Y187.823492 Z27.149533 E9732.756905 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.03766 Y186.983053 Z27.158879 E9736.714307 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.508564 Y186.156005 Z27.168224 E9740.671265 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.003182 Y185.343026 Z27.17757 E9744.627834 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.522722 Y184.545867 Z27.186916 E9748.583971 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.066378 Y183.765152 Z27.196262 E9752.539438 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.632316 Y183.000664 Z27.205607 E9756.494144 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.22006 Y182.253026 Z27.214953 E9760.448142 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.829117 Y181.522851 Z27.224299 E9764.40149 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.458978 Y180.810734 Z27.233645 E9768.354242 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.109117 Y180.117259 Z27.242991 E9772.306454 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.778993 Y179.442994 Z27.252336 E9776.258182 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.468046 Y178.78849 Z27.261682 E9780.209481 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.175706 Y178.154284 Z27.271028 E9784.160406 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.903235 Y177.54315 Z27.280374 E9788.110857 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.648425 Y176.953969 Z27.28972 E9792.060563 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.410228 Y176.386733 Z27.299065 E9796.009523 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.188009 Y175.841901 Z27.308411 E9799.957791 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.981121 Y175.319915 Z27.317757 E9803.905424 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.788903 Y174.821199 Z27.327103 E9807.852476 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.610686 Y174.346159 Z27.336449 E9811.799003 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.445787 Y173.89518 Z27.345794 E9815.745061 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.293515 Y173.46863 Z27.35514 E9819.690705 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.1533 Y173.06715 Z27.364486 E9823.635975 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.025516 Y172.693771 Z27.373832 E9827.580712 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.908007 Y172.345887 Z27.383178 E9831.524661 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.800041 Y172.023777 Z27.392523 E9835.467879 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.700878 Y171.727697 Z27.401869 E9839.410421 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.609772 Y171.457883 Z27.411215 E9843.352343 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.52597 Y171.214548 Z27.420561 E9847.293699 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.448714 Y170.997888 Z27.429907 E9851.234545 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.377241 Y170.808073 Z27.439252 E9855.174937 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.310782 Y170.645256 Z27.448598 E9859.11493 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.248735 Y170.510848 Z27.457944 E9863.054515 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.190295 Y170.405933 Z27.46729 E9866.993483 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.134314 Y170.328356 Z27.476636 E9870.93168 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.080013 Y170.278172 Z27.485981 E9874.869161 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.026609 Y170.25541 Z27.495327 E9878.805981 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.973322 Y170.260082 Z27.504673 E9882.742196 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.91937 Y170.292175 Z27.514019 E9886.67786 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.863972 Y170.351656 Z27.523364 E9890.61303 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.806349 Y170.438468 Z27.53271 E9894.54776 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.745724 Y170.552536 Z27.542056 E9898.482106 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.680954 Y170.695988 Z27.551402 E9902.416005 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.611237 Y170.867714 Z27.560748 E9906.34921 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.535977 Y171.066281 Z27.570093 E9910.281659 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.454412 Y171.291517 Z27.579439 E9914.213406 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.365786 Y171.543225 Z27.588785 E9918.144509 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.26935 Y171.82119 Z27.598131 E9922.075021 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.16436 Y172.125174 Z27.607477 E9926.004997 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.050078 Y172.45492 Z27.616822 E9929.934494 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.925777 Y172.810151 Z27.626168 E9933.863567 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.790735 Y173.190567 Z27.635514 E9937.79227 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.642816 Y173.59874 Z27.64486 E9941.720483 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.482402 Y174.03163 Z27.654206 E9945.647928 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.308937 Y174.488576 Z27.663551 E9949.574633 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.121745 Y174.969193 Z27.672897 E9953.500652 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.92016 Y175.473075 Z27.682243 E9957.42604 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.703526 Y175.9998 Z27.691589 E9961.350854 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.471202 Y176.548927 Z27.700935 E9965.275147 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.222557 Y177.119996 Z27.71028 E9969.198975 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.956975 Y177.712532 Z27.719626 E9973.122393 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.673429 Y178.326525 Z27.728972 E9977.045426 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.369743 Y178.963066 Z27.738318 E9980.967897 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.047189 Y179.619383 Z27.747664 E9984.889587 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.705214 Y180.294926 Z27.757009 E9988.810552 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.343282 Y180.989131 Z27.766355 E9992.730847 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.960872 Y181.701418 Z27.775701 E9996.650525 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.557482 Y182.431195 Z27.785047 E10000.569644 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.132625 Y183.177854 Z27.794393 E10004.488258 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.685831 Y183.940775 Z27.803738 E10008.406421 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.216647 Y184.719324 Z27.813084 E10012.32419 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.723277 Y185.513705 Z27.82243 E10016.241536 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.204945 Y186.323285 Z27.831776 E10020.158242 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.662866 Y187.146319 Z27.841121 E10024.074181 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.096671 Y187.982123 Z27.850467 E10027.98941 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.506011 Y188.830002 Z27.859813 E10031.903984 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.890555 Y189.689252 Z27.869159 E10035.817957 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.249995 Y190.559162 Z27.878505 E10039.731386 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.584039 Y191.439009 Z27.88785 E10043.644324 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.892417 Y192.328067 Z27.897196 E10047.556826 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.174881 Y193.225598 Z27.906542 E10051.468949 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.428723 Y194.131524 Z27.915888 E10055.38061 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.655237 Y195.04449 Z27.925234 E10059.291553 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.855166 Y195.963458 Z27.934579 E10063.201746 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.028357 Y196.887669 Z27.943925 E10067.111244 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.174675 Y197.816357 Z27.953271 E10071.020101 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.294008 Y198.748755 Z27.962617 E10074.928373 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.386266 Y199.684091 Z27.971963 E10078.836115 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.451379 Y200.621594 Z27.981308 E10082.743381 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.489299 Y201.560489 Z27.990654 E10086.650227 F2400 ; clayline kind=print page=0 layer=12 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.5 Y202.5 Z28 E10090.556708 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.479958 Y203.439237 Z28.009346 E10094.462683 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.432721 Y204.377309 Z28.018692 E10098.367868 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.358341 Y205.313443 Z28.028037 E10102.272319 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.256888 Y206.246866 Z28.037383 E10106.176089 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X239.128455 Y207.176809 Z28.046729 E10110.079234 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.973157 Y208.102505 Z28.056075 E10113.981809 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.79113 Y209.023192 Z28.065421 E10117.883869 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.582529 Y209.938111 Z28.074766 E10121.785467 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.347534 Y210.846508 Z28.084112 E10125.686661 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.085424 Y211.747355 Z28.093458 E10129.587455 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.794935 Y212.639307 Z28.102804 E10133.487662 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.478788 Y213.522293 Z28.11215 E10137.387094 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.137256 Y214.395588 Z28.121495 E10141.285806 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.770629 Y215.258474 Z28.130841 E10145.183853 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.379218 Y216.110243 Z28.140187 E10149.08129 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.963353 Y216.950195 Z28.149533 E10152.978172 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.523385 Y217.777639 Z28.158879 E10156.874553 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.059681 Y218.591897 Z28.168224 E10160.770488 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.572631 Y219.392298 Z28.17757 E10164.666032 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.061046 Y220.177119 Z28.186916 E10168.561141 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.525719 Y220.945746 Z28.196262 E10172.455583 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.968457 Y221.698394 Z28.205607 E10176.349266 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.389727 Y222.434448 Z28.214953 E10180.242244 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.790016 Y223.153306 Z28.224299 E10184.134572 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.169825 Y223.854381 Z28.233645 E10188.026305 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.529672 Y224.537099 Z28.242991 E10191.917497 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.870091 Y225.200901 Z28.252336 E10195.808204 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.19163 Y225.845243 Z28.261682 E10199.69848 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.494854 Y226.469598 Z28.271028 E10203.588379 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.778519 Y227.071236 Z28.280374 E10207.477802 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.044799 Y227.651256 Z28.28972 E10211.366484 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.294725 Y228.209668 Z28.299065 E10215.254422 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.528925 Y228.74602 Z28.308411 E10219.14167 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.748034 Y229.259876 Z28.317757 E10223.028283 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.952702 Y229.750819 Z28.327103 E10226.914316 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.143591 Y230.218452 Z28.336449 E10230.799823 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.321371 Y230.662392 Z28.345794 E10234.684859 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.486723 Y231.08228 Z28.35514 E10238.569479 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.640208 Y231.477483 Z28.364486 E10242.453722 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.781459 Y231.84502 Z28.373832 E10246.337431 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.912597 Y232.187452 Z28.383178 E10250.220357 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.034344 Y232.504509 Z28.392523 E10254.102554 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.147428 Y232.795937 Z28.401869 E10257.984076 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.252584 Y233.061506 Z28.411215 E10261.864979 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.350553 Y233.301003 Z28.420561 E10265.745315 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.442082 Y233.514238 Z28.429907 E10269.625142 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.527922 Y233.701041 Z28.439252 E10273.504511 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.608829 Y233.861265 Z28.448598 E10277.383479 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.685396 Y233.99352 Z28.457944 E10281.262036 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.758417 Y234.096737 Z28.46729 E10285.139979 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.829022 Y234.173039 Z28.476636 E10289.017153 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.897977 Y234.222374 Z28.485981 E10292.893613 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.966052 Y234.24471 Z28.495327 E10296.769414 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.034017 Y234.240038 Z28.504673 E10300.644609 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.10264 Y234.20837 Z28.514019 E10304.519254 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.172692 Y234.14974 Z28.523364 E10308.393403 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.244938 Y234.064201 Z28.53271 E10312.26711 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.320144 Y233.951831 Z28.542056 E10316.14043 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.399435 Y233.810533 Z28.551402 E10320.013302 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.4836 Y233.641401 Z28.560748 E10323.885482 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.573227 Y233.445844 Z28.570093 E10327.756908 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.669064 Y233.224034 Z28.579439 E10331.627636 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.771857 Y232.976164 Z28.588785 E10335.497718 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.882344 Y232.702445 Z28.598131 E10339.367211 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.001255 Y232.403113 Z28.607477 E10343.236168 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.129318 Y232.078419 Z28.616822 E10347.104644 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.267248 Y231.728639 Z28.626168 E10350.972693 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.415757 Y231.354066 Z28.635514 E10354.840369 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.576946 Y230.95217 Z28.64486 E10358.707554 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.75044 Y230.525943 Z28.654206 E10362.573976 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.936786 Y230.076034 Z28.663551 E10366.439659 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.136649 Y229.602826 Z28.672897 E10370.304658 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.350685 Y229.106715 Z28.682243 E10374.169027 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.57954 Y228.58812 Z28.691589 E10378.032821 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.823845 Y228.047474 Z28.700935 E10381.896094 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.084219 Y227.485229 Z28.71028 E10385.758901 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.361271 Y226.901853 Z28.719626 E10389.621295 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.656011 Y226.297357 Z28.728972 E10393.4833 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.97058 Y225.670667 Z28.738318 E10397.344744 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.303727 Y225.024512 Z28.747664 E10401.205411 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.655996 Y224.359432 Z28.757009 E10405.065355 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.027915 Y223.675985 Z28.766355 E10408.92463 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.419994 Y222.974739 Z28.775701 E10412.78329 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.83273 Y222.25628 Z28.785047 E10416.641389 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.266602 Y221.521204 Z28.794393 E10420.498982 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.722072 Y220.770124 Z28.803738 E10424.356123 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.199585 Y220.003662 Z28.813084 E10428.212866 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.70091 Y219.221618 Z28.82243 E10432.069186 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.22681 Y218.424617 Z28.831776 E10435.924865 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.776089 Y217.614374 Z28.841121 E10439.779782 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.349111 Y216.791564 Z28.850467 E10443.633991 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.946218 Y215.956871 Z28.859813 E10447.487545 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.567735 Y215.110988 Z28.869159 E10451.340499 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.213968 Y214.254616 Z28.878505 E10455.192908 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.885202 Y213.388465 Z28.88785 E10459.044825 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.581703 Y212.513252 Z28.897196 E10462.896305 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.303715 Y211.629701 Z28.906542 E10466.747401 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.053904 Y210.73789 Z28.915888 E10470.598035 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.830996 Y209.839154 Z28.925234 E10474.447953 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.634258 Y208.934513 Z28.934579 E10478.297124 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.463842 Y208.024715 Z28.943925 E10482.145602 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.319881 Y207.110515 Z28.953271 E10485.99344 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.202483 Y206.192666 Z28.962617 E10489.840693 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.111739 Y205.271929 Z28.971963 E10493.687415 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.047716 Y204.349064 Z28.981308 E10497.53366 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.010461 Y203.424833 Z28.990654 E10501.379482 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176 Y202.5 Z29 E10505.224935 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.019802 Y201.575441 Z29.009346 E10509.069883 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.066373 Y200.652033 Z29.018692 E10512.914045 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.139664 Y199.730537 Z29.028037 E10516.757474 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.239604 Y198.811713 Z29.037383 E10520.600224 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.366101 Y197.89632 Z29.046729 E10524.44235 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.519042 Y196.985111 Z29.056075 E10528.283906 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.698295 Y196.078837 Z29.065421 E10532.124945 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.903703 Y195.178245 Z29.074766 E10535.965522 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.135093 Y194.284078 Z29.084112 E10539.80569 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.393172 Y193.397346 Z29.093458 E10543.645458 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.679185 Y192.519374 Z29.102804 E10547.484638 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.990452 Y191.650232 Z29.11215 E10551.323047 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.326707 Y190.790634 Z29.121495 E10555.160738 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.687662 Y189.941285 Z29.130841 E10558.997766 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.073011 Y189.102884 Z29.140187 E10562.834184 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.482428 Y188.276118 Z29.149533 E10566.670046 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.915571 Y187.461668 Z29.158879 E10570.505407 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.372074 Y186.660202 Z29.168224 E10574.340319 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.851556 Y185.872379 Z29.17757 E10578.174838 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.355186 Y185.099895 Z29.186916 E10582.00892 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.882183 Y184.343355 Z29.196262 E10585.842337 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.43077 Y183.602547 Z29.205607 E10589.674997 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.000485 Y182.878077 Z29.214953 E10593.506954 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.59085 Y182.170536 Z29.224299 E10597.338263 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.201371 Y181.480504 Z29.233645 E10601.168977 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.831538 Y180.808543 Z29.242991 E10604.99915 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.480825 Y180.155205 Z29.252336 E10608.828836 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.148693 Y179.521024 Z29.261682 E10612.658088 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.834586 Y178.90652 Z29.271028 E10616.48696 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.539727 Y178.314379 Z29.280374 E10620.315357 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.261978 Y177.74352 Z29.28972 E10624.143014 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.000321 Y177.193932 Z29.299065 E10627.96993 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.754141 Y176.66606 Z29.308411 E10631.796158 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.522811 Y176.160334 Z29.317757 E10635.621752 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.305692 Y175.677162 Z29.327103 E10639.446766 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.102132 Y175.216938 Z29.336449 E10643.271253 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.911471 Y174.780036 Z29.345794 E10647.095268 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.733039 Y174.36681 Z29.35514 E10650.918864 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.566283 Y173.977883 Z29.364486 E10654.742079 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.411566 Y173.61619 Z29.373832 E10658.564762 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.266799 Y173.279208 Z29.383178 E10662.386664 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.131271 Y172.967205 Z29.392523 E10666.20784 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.004265 Y172.680428 Z29.401869 E10670.028342 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.885059 Y172.419106 Z29.411215 E10673.848226 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.772923 Y172.183446 Z29.420561 E10677.667543 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.667121 Y171.973637 Z29.429907 E10681.486349 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.566915 Y171.789844 Z29.439252 E10685.304697 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.47156 Y171.632214 Z29.448598 E10689.12264 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.380472 Y171.502113 Z29.457944 E10692.94017 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.29287 Y171.400593 Z29.46729 E10696.757087 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.207642 Y171.325565 Z29.476636 E10700.573238 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.124034 Y171.277081 Z29.485981 E10704.388677 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.041287 Y171.25517 Z29.495327 E10708.203458 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.958644 Y171.259842 Z29.504673 E10712.017635 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.875349 Y171.291084 Z29.514019 E10715.83126 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.790644 Y171.348865 Z29.523364 E10719.644389 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.703775 Y171.433129 Z29.53271 E10723.457073 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.613988 Y171.543802 Z29.542056 E10727.269367 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.520176 Y171.682945 Z29.551402 E10731.081212 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.421563 Y171.849484 Z29.560748 E10734.892367 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.31757 Y172.04203 Z29.570093 E10738.702771 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.207459 Y172.260415 Z29.579439 E10742.512478 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.090499 Y172.504448 Z29.588785 E10746.321542 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.965963 Y172.77392 Z29.598131 E10750.130015 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.83313 Y173.068601 Z29.607477 E10753.937953 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.691286 Y173.388241 Z29.616822 E10757.745407 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.539726 Y173.73257 Z29.626168 E10761.552432 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.377752 Y174.1013 Z29.635514 E10765.359082 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.203292 Y174.49692 Z29.64486 E10769.16524 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.016718 Y174.916485 Z29.654206 E10772.970638 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.817491 Y175.359355 Z29.663551 E10776.775299 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.604957 Y175.825156 Z29.672897 E10780.579278 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.378469 Y176.313494 Z29.682243 E10784.382629 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.137394 Y176.82396 Z29.691589 E10788.185404 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.881109 Y177.356126 Z29.700935 E10791.987657 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.609004 Y177.909547 Z29.71028 E10795.789441 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.320483 Y178.483762 Z29.719626 E10799.590811 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.014549 Y179.07876 Z29.728972 E10803.391789 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.689097 Y179.6956 Z29.738318 E10807.192207 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.345357 Y180.331594 Z29.747664 E10810.991851 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.982794 Y180.98621 Z29.757009 E10814.790774 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.600889 Y181.6589 Z29.766355 E10818.589029 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.19914 Y182.349104 Z29.775701 E10822.38667 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.777057 Y183.056246 Z29.785047 E10826.18375 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.334171 Y183.779737 Z29.794393 E10829.980323 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.870025 Y184.518977 Z29.803738 E10833.776441 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.384183 Y185.273352 Z29.813084 E10837.572159 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.874903 Y186.043058 Z29.82243 E10841.367452 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.341435 Y186.827482 Z29.831776 E10845.162106 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.784955 Y187.624933 Z29.841121 E10848.956 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.205108 Y188.434749 Z29.850467 E10852.749188 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.601554 Y189.256255 Z29.859813 E10856.541723 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.973974 Y190.088771 Z29.869159 E10860.333658 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.322069 Y190.931606 Z29.878505 E10864.125048 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.645557 Y191.784061 Z29.88785 E10867.915944 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.944177 Y192.64543 Z29.897196 E10871.706401 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.217689 Y193.515 Z29.906542 E10875.496471 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.463469 Y194.392696 Z29.915888 E10879.286077 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.682772 Y195.277203 Z29.925234 E10883.074971 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.876318 Y196.167517 Z29.934579 E10886.86312 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.043958 Y197.062901 Z29.943925 E10890.650578 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.185564 Y197.962614 Z29.953271 E10894.437397 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.301026 Y198.865913 Z29.962617 E10898.223631 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.390257 Y199.77205 Z29.971963 E10902.009333 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.45319 Y200.680277 Z29.981308 E10905.794557 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.489779 Y201.589844 Z29.990654 E10909.579355 F2400 ; clayline kind=print page=0 layer=13 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.5 Y202.5 Z30 E10913.363781 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.482773 Y203.40995 Z30.009346 E10917.147791 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.439196 Y204.3189 Z30.018692 E10920.931307 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.369312 Y205.2261 Z30.028037 E10924.714381 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.273185 Y206.130803 Z30.037383 E10928.497067 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.150899 Y207.03226 Z30.046729 E10932.279419 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238.002558 Y207.92973 Z30.056075 E10936.061488 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.82829 Y208.822471 Z30.065421 E10939.84333 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.628241 Y209.709748 Z30.074766 E10943.624996 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.402577 Y210.590828 Z30.084112 E10947.40654 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.150596 Y211.464715 Z30.093458 E10951.187959 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.871066 Y212.330101 Z30.102804 E10954.969055 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.566619 Y213.186916 Z30.11215 E10958.749671 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.237515 Y214.034456 Z30.121495 E10962.529861 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.88403 Y214.872024 Z30.130841 E10966.309677 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.506459 Y215.698928 Z30.140187 E10970.089172 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.10512 Y216.514489 Z30.149533 E10973.868401 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.680345 Y217.318035 Z30.158879 E10977.647416 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.232487 Y218.108904 Z30.168224 E10981.426269 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.761919 Y218.886444 Z30.17757 E10985.205015 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.267483 Y219.64898 Z30.186916 E10988.983592 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.749942 Y220.395913 Z30.196262 E10992.761778 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.211044 Y221.127449 Z30.205607 E10996.539499 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.651241 Y221.842987 Z30.214953 E11000.316807 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.070998 Y222.54194 Z30.224299 E11004.093757 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.470797 Y223.223734 Z30.233645 E11007.870401 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.851138 Y223.887809 Z30.242991 E11011.646792 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.212533 Y224.533619 Z30.252336 E11015.422984 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.555512 Y225.160632 Z30.261682 E11019.199029 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.880618 Y225.768332 Z30.271028 E11022.974981 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.186641 Y226.354064 Z30.280374 E11026.750715 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.475686 Y226.918892 Z30.28972 E11030.525995 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.748752 Y227.46282 Z30.299065 E11034.300824 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.006443 Y227.985405 Z30.308411 E11038.075256 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.249375 Y228.486219 Z30.317757 E11041.849344 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.478175 Y228.964853 Z30.327103 E11045.62314 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.693482 Y229.420915 Z30.336449 E11049.396698 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.895944 Y229.854031 Z30.345794 E11053.170071 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.086222 Y230.263845 Z30.35514 E11056.943311 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.264857 Y230.649738 Z30.364486 E11060.716455 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.431488 Y231.008807 Z30.373832 E11064.489322 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.588176 Y231.343538 Z30.383178 E11068.2617 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.735618 Y231.653661 Z30.392523 E11072.033642 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.874521 Y231.938925 Z30.401869 E11075.805201 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.005598 Y232.1991 Z30.411215 E11079.57643 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.129565 Y232.433975 Z30.420561 E11083.347382 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.247149 Y232.643359 Z30.429907 E11087.118111 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.359077 Y232.827082 Z30.439252 E11090.888668 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.466082 Y232.984994 Z30.448598 E11094.659108 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.568742 Y233.11574 Z30.457944 E11098.429409 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.667826 Y233.218275 Z30.46729 E11102.199363 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.764431 Y233.294656 Z30.476636 E11105.968843 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.859304 Y233.344827 Z30.485981 E11109.737902 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.953192 Y233.368752 Z30.495327 E11113.506592 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.046843 Y233.366416 Z30.504673 E11117.274967 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.141005 Y233.337826 Z30.514019 E11121.043079 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.236425 Y233.283007 Z30.523364 E11124.810982 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.333852 Y233.202007 Z30.53271 E11128.578729 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.434028 Y233.094896 Z30.542056 E11132.346372 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.53805 Y232.959628 Z30.551402 E11136.11383 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.646685 Y232.797262 Z30.560748 E11139.880876 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.760506 Y232.609162 Z30.570093 E11143.647462 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.880243 Y232.39549 Z30.579439 E11147.413641 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.006623 Y232.156429 Z30.588785 E11151.179466 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.140364 Y231.892179 Z30.598131 E11154.944991 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.282182 Y231.602963 Z30.607477 E11158.710267 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.432782 Y231.289022 Z30.616822 E11162.475348 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.592866 Y230.950617 Z30.626168 E11166.240288 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.763126 Y230.588029 Z30.635514 E11170.005138 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.945612 Y230.19879 Z30.64486 E11173.769753 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.139961 Y229.785806 Z30.654206 E11177.533894 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.346707 Y229.349707 Z30.663551 E11181.29759 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.566501 Y228.890857 Z30.672897 E11185.060894 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.799985 Y228.409639 Z30.682243 E11188.823858 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.047789 Y227.906455 Z30.691589 E11192.586536 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.310533 Y227.381723 Z30.700935 E11196.348981 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.588823 Y226.835878 Z30.71028 E11200.111244 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.883254 Y226.269373 Z30.719626 E11203.87338 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.194814 Y225.682211 Z30.728972 E11207.635405 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.525593 Y225.073344 Z30.738318 E11211.397129 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.874376 Y224.445424 Z30.747664 E11215.15837 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.241697 Y223.798975 Z30.757009 E11218.91918 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.628073 Y223.134535 Z30.766355 E11222.679613 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.034008 Y222.452656 Z30.775701 E11226.43972 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.459988 Y221.753902 Z30.785047 E11230.199555 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.906485 Y221.038854 Z30.794393 E11233.959171 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.373954 Y220.308102 Z30.803738 E11237.718621 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.862833 Y219.562251 Z30.813084 E11241.477957 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.374852 Y218.801104 Z30.82243 E11245.237139 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.910758 Y218.025264 Z30.831776 E11248.995953 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.469392 Y217.236403 Z30.841121 E11252.754297 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.051112 Y216.435174 Z30.850467 E11256.512225 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.656258 Y215.622242 Z30.859813 E11260.26979 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.285152 Y214.798281 Z30.869159 E11264.027044 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.938097 Y213.963971 Z30.878505 E11267.784041 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.615376 Y213.120002 Z30.88785 E11271.540833 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.317253 Y212.267073 Z30.897196 E11275.297473 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.043974 Y211.405887 Z30.906542 E11279.054013 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.798142 Y210.536519 Z30.915888 E11282.810352 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.578521 Y209.660269 Z30.925234 E11286.566259 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.384403 Y208.778131 Z30.934579 E11290.32171 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.215941 Y207.890835 Z30.943925 E11294.076761 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.073269 Y206.999113 Z30.953271 E11297.831462 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.9565 Y206.103703 Z30.962617 E11301.585867 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.865727 Y205.205344 Z30.971963 E11305.340029 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.801022 Y204.304778 Z30.981308 E11309.094 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.762436 Y203.402748 Z30.990654 E11312.847834 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.75 Y202.5 Z31 E11316.601583 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.767107 Y201.597389 Z31.009346 E11320.355079 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.810351 Y200.695771 Z31.018692 E11324.108082 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.87969 Y199.795889 Z31.028037 E11327.860646 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X176.975061 Y198.898487 Z31.037383 E11331.612822 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.096379 Y198.004304 Z31.046729 E11335.364663 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.243541 Y197.114078 Z31.056075 E11339.116223 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.416422 Y196.228543 Z31.065421 E11342.867555 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.614875 Y195.34843 Z31.074766 E11346.618709 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X177.838736 Y194.474465 Z31.084112 E11350.369741 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.088702 Y193.607636 Z31.093458 E11354.120647 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.365994 Y192.74924 Z31.102804 E11357.871229 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.668001 Y191.899346 Z31.11215 E11361.621333 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X178.994466 Y191.058655 Z31.121495 E11365.371012 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.345116 Y190.227856 Z31.130841 E11369.120318 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X179.719655 Y189.407635 Z31.140187 E11372.869304 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.117771 Y188.598667 Z31.149533 E11376.618023 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.539133 Y187.801618 Z31.158879 E11380.366527 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X180.98339 Y187.017145 Z31.168224 E11384.114869 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.450175 Y186.245894 Z31.17757 E11387.863102 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X181.940633 Y185.489527 Z31.186916 E11391.611165 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.45401 Y184.748637 Z31.196262 E11395.358838 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X182.988569 Y184.023022 Z31.205607 E11399.106048 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X183.543865 Y183.313276 Z31.214953 E11402.852846 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.119436 Y182.619982 Z31.224299 E11406.599286 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X184.714801 Y181.943709 Z31.233645 E11410.34542 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.329467 Y181.285012 Z31.242991 E11414.091301 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X185.962925 Y180.644434 Z31.252336 E11417.836982 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X186.614649 Y180.022502 Z31.261682 E11421.582516 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.284102 Y179.419727 Z31.271028 E11425.327954 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X187.972482 Y178.838744 Z31.280374 E11429.073174 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X188.677702 Y178.278496 Z31.28972 E11432.817942 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X189.398771 Y177.73898 Z31.299065 E11436.56226 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.13509 Y177.220635 Z31.308411 E11440.306182 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X190.886048 Y176.723885 Z31.317757 E11444.049759 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X191.651022 Y176.249137 Z31.327103 E11447.793046 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X192.42938 Y175.796779 Z31.336449 E11451.536094 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X193.220476 Y175.367183 Z31.345794 E11455.278955 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.023659 Y174.9607 Z31.35514 E11459.021684 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X194.838389 Y174.577946 Z31.364486 E11462.764314 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X195.665025 Y174.221798 Z31.373832 E11466.506667 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X196.501522 Y173.889792 Z31.383178 E11470.248533 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X197.347189 Y173.582196 Z31.392523 E11473.989964 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X198.201325 Y173.299257 Z31.401869 E11477.731013 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.063224 Y173.041206 Z31.411215 E11481.471732 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X199.932173 Y172.80825 Z31.420561 E11485.212175 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X200.807453 Y172.600579 Z31.429907 E11488.952393 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X201.688342 Y172.418361 Z31.439252 E11492.69244 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X202.574112 Y172.261745 Z31.448598 E11496.432367 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X203.464192 Y172.132076 Z31.457944 E11500.172154 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X204.357818 Y172.03039 Z31.46729 E11503.911595 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X205.253901 Y171.954646 Z31.476636 E11507.650563 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X206.151701 Y171.9049 Z31.485981 E11511.389111 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.050478 Y171.881188 Z31.495327 E11515.127292 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X207.949488 Y171.883524 Z31.504673 E11518.865157 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X208.84799 Y171.911902 Z31.514019 E11522.602759 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X209.745243 Y171.966296 Z31.523364 E11526.340152 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X210.640505 Y172.046658 Z31.53271 E11530.077387 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X211.533038 Y172.15292 Z31.542056 E11533.814517 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X212.421756 Y172.287111 Z31.551402 E11537.551461 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X213.305897 Y172.448181 Z31.560748 E11541.287994 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X214.184893 Y172.634775 Z31.570093 E11545.024069 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.058018 Y172.846734 Z31.579439 E11548.759737 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X215.924555 Y173.083877 Z31.588785 E11552.495053 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X216.783789 Y173.346003 Z31.598131 E11556.230068 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X217.635011 Y173.632894 Z31.607477 E11559.964834 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X218.47752 Y173.944308 Z31.616822 E11563.699405 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X219.310622 Y174.279988 Z31.626168 E11567.433832 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.133628 Y174.639654 Z31.635514 E11571.168168 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X220.944507 Y175.025755 Z31.64486 E11574.90227 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X221.743618 Y175.435408 Z31.654206 E11578.635899 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X222.530432 Y175.867988 Z31.663551 E11582.369084 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X223.304302 Y176.323134 Z31.672897 E11586.101877 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.064593 Y176.800466 Z31.682243 E11589.834332 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X224.810678 Y177.299585 Z31.691589 E11593.5665 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X225.541944 Y177.820077 Z31.700935 E11597.298434 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.257789 Y178.361509 Z31.71028 E11601.030187 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X226.957623 Y178.923435 Z31.719626 E11604.76181 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X227.640466 Y179.505847 Z31.728972 E11608.493321 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.304246 Y180.10979 Z31.738318 E11612.224532 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X228.950166 Y180.732629 Z31.747664 E11615.955261 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X229.577698 Y181.373846 Z31.757009 E11619.685561 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.186329 Y182.032907 Z31.766355 E11623.415483 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X230.775559 Y182.709266 Z31.775701 E11627.145081 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.344906 Y183.40236 Z31.785047 E11630.874406 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X231.893901 Y184.111617 Z31.794393 E11634.603512 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.422095 Y184.836449 Z31.803738 E11638.33245 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X232.929051 Y185.576256 Z31.813084 E11642.061274 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.413055 Y186.331234 Z31.82243 E11645.789942 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X233.873364 Y187.100785 Z31.831776 E11649.518242 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.31113 Y187.883251 Z31.841121 E11653.246075 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X234.725997 Y188.677983 Z31.850467 E11656.973493 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.117627 Y189.484321 Z31.859813 E11660.700548 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.485702 Y190.301599 Z31.869159 E11664.427292 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X235.829921 Y191.12914 Z31.878505 E11668.153779 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.150004 Y191.966261 Z31.88785 E11671.88006 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.445687 Y192.812268 Z31.897196 E11675.606188 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.716728 Y193.666463 Z31.906542 E11679.332216 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X236.960545 Y194.528774 Z31.915888 E11683.058041 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.178362 Y195.397909 Z31.925234 E11686.783435 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.370885 Y196.272883 Z31.934579 E11690.508375 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.537959 Y197.152973 Z31.943925 E11694.232915 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.679453 Y198.037451 Z31.953271 E11697.957107 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.795254 Y198.925587 Z31.962617 E11701.681002 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.88527 Y199.816646 Z31.971963 E11705.404654 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.949431 Y200.709893 Z31.981308 E11709.128115 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.987684 Y201.604591 Z31.990654 E11712.851436 F2400 ; clayline kind=print page=0 layer=14 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X238 Y202.5 Z32 E11716.574671 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave z-blend wall
G1 X237.985349 Y203.395341 Z32 E11720.297564 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.944766 Y204.289833 Z32 E11724.020255 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.878289 Y205.182738 Z32 E11727.742796 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.785974 Y206.073319 Z32 E11731.46524 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.667898 Y206.96084 Z32 E11735.187638 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.524159 Y207.84457 Z32 E11738.910044 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.354875 Y208.723779 Z32 E11742.632509 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.160185 Y209.597741 Z32 E11746.355085 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.940247 Y210.465734 Z32 E11750.077826 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.694364 Y211.326775 Z32 E11753.800719 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.421316 Y212.179576 Z32 E11757.523552 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.123691 Y213.024065 Z32 E11761.246197 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X235.801737 Y213.859547 Z32 E11764.968706 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X235.455721 Y214.685332 Z32 E11768.691132 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X235.085929 Y215.50074 Z32 E11772.413527 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X234.692668 Y216.305097 Z32 E11776.135944 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X234.27626 Y217.097739 Z32 E11779.858434 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X233.837048 Y217.87801 Z32 E11783.58105 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X233.375393 Y218.645267 Z32 E11787.303845 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X232.890151 Y219.397855 Z32 E11791.026738 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X232.382067 Y220.135182 Z32 E11794.749515 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X231.852859 Y220.857445 Z32 E11798.472118 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X231.302967 Y221.56405 Z32 E11802.194599 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X230.732845 Y222.254415 Z32 E11805.917011 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X230.142965 Y222.927971 Z32 E11809.639407 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X229.533813 Y223.584161 Z32 E11813.361838 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X228.905891 Y224.222442 Z32 E11817.084358 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X228.259717 Y224.842288 Z32 E11820.807018 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X227.595822 Y225.443183 Z32 E11824.52987 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X226.913009 Y226.022507 Z32 E11828.252763 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X226.213349 Y226.581303 Z32 E11831.975487 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X225.497825 Y227.119572 Z32 E11835.698052 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X224.767027 Y227.63687 Z32 E11839.420509 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X224.021561 Y228.132772 Z32 E11843.142912 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X223.262042 Y228.606869 Z32 E11846.865312 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X222.489095 Y229.058769 Z32 E11850.587762 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X221.70336 Y229.488098 Z32 E11854.310315 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X220.905483 Y229.8945 Z32 E11858.033022 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X220.095997 Y230.277359 Z32 E11861.755915 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X219.274542 Y230.633805 Z32 E11865.478788 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X218.44315 Y230.966285 Z32 E11869.201463 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X217.602507 Y231.274527 Z32 E11872.923993 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X216.753308 Y231.558278 Z32 E11876.64643 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X215.896255 Y231.817306 Z32 E11880.368827 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X215.032054 Y232.051396 Z32 E11884.091235 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X214.161419 Y232.260354 Z32 E11887.813708 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X213.285068 Y232.444008 Z32 E11891.536298 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X212.403725 Y232.602202 Z32 E11895.259056 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X211.517956 Y232.733594 Z32 E11898.98195 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X210.628522 Y232.837144 Z32 E11902.704763 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X209.736505 Y232.914878 Z32 E11906.427394 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X208.842642 Y232.966735 Z32 E11910.149893 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X207.94767 Y232.992674 Z32 E11913.872314 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X207.05233 Y232.992674 Z32 E11917.594709 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X206.157358 Y232.966735 Z32 E11921.31713 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X205.263495 Y232.914878 Z32 E11925.039629 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X204.371478 Y232.837144 Z32 E11928.76226 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X203.482044 Y232.733594 Z32 E11932.485073 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X202.596275 Y232.602202 Z32 E11936.207967 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X201.714932 Y232.444008 Z32 E11939.930725 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X200.838581 Y232.260354 Z32 E11943.653315 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X199.967946 Y232.051396 Z32 E11947.375787 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X199.103745 Y231.817306 Z32 E11951.098196 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X198.246692 Y231.558278 Z32 E11954.820593 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X197.397493 Y231.274527 Z32 E11958.54303 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X196.55685 Y230.966285 Z32 E11962.26556 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X195.725458 Y230.633805 Z32 E11965.988235 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X194.904003 Y230.277359 Z32 E11969.711108 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X194.094517 Y229.8945 Z32 E11973.434001 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X193.29664 Y229.488098 Z32 E11977.156708 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X192.510905 Y229.058769 Z32 E11980.879261 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X191.737958 Y228.606869 Z32 E11984.601711 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X190.978439 Y228.132772 Z32 E11988.324111 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X190.232973 Y227.63687 Z32 E11992.046514 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X189.502175 Y227.119572 Z32 E11995.768971 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X188.786651 Y226.581303 Z32 E11999.491536 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X188.086991 Y226.022507 Z32 E12003.21426 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X187.404178 Y225.443183 Z32 E12006.937153 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X186.740283 Y224.842288 Z32 E12010.660005 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X186.094109 Y224.222442 Z32 E12014.382665 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X185.466187 Y223.584161 Z32 E12018.105185 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X184.857035 Y222.927971 Z32 E12021.827616 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X184.267155 Y222.254415 Z32 E12025.550012 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X183.697033 Y221.56405 Z32 E12029.272424 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X183.147141 Y220.857445 Z32 E12032.994905 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X182.617933 Y220.135182 Z32 E12036.717508 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X182.109849 Y219.397855 Z32 E12040.440284 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X181.624607 Y218.645267 Z32 E12044.163178 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X181.162952 Y217.87801 Z32 E12047.885972 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X180.72374 Y217.097739 Z32 E12051.608589 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X180.307332 Y216.305097 Z32 E12055.331079 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X179.914071 Y215.50074 Z32 E12059.053495 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X179.544279 Y214.685332 Z32 E12062.775891 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X179.198263 Y213.859547 Z32 E12066.498317 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.876309 Y213.024065 Z32 E12070.220826 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.578684 Y212.179576 Z32 E12073.943471 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.305636 Y211.326775 Z32 E12077.666304 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.059753 Y210.465734 Z32 E12081.389197 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.839815 Y209.597741 Z32 E12085.111938 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.645125 Y208.723779 Z32 E12088.834514 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.475841 Y207.84457 Z32 E12092.556979 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.332102 Y206.96084 Z32 E12096.279385 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.214026 Y206.073319 Z32 E12100.001783 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.121711 Y205.182738 Z32 E12103.724227 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.055234 Y204.289833 Z32 E12107.446768 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.014651 Y203.395341 Z32 E12111.169459 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177 Y202.5 Z32 E12114.892352 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.014651 Y201.604659 Z32 E12118.615245 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.055234 Y200.710167 Z32 E12122.337936 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.121711 Y199.817262 Z32 E12126.060477 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.214026 Y198.926681 Z32 E12129.78292 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.332102 Y198.03916 Z32 E12133.505319 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.475841 Y197.15543 Z32 E12137.227724 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.645125 Y196.276221 Z32 E12140.950189 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X177.839815 Y195.402259 Z32 E12144.672766 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.059753 Y194.534266 Z32 E12148.395507 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.305636 Y193.673225 Z32 E12152.1184 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.578684 Y192.820424 Z32 E12155.841233 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X178.876309 Y191.975935 Z32 E12159.563878 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X179.198263 Y191.140453 Z32 E12163.286387 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X179.544279 Y190.314668 Z32 E12167.008813 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X179.914071 Y189.49926 Z32 E12170.731208 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X180.307332 Y188.694903 Z32 E12174.453624 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X180.72374 Y187.902261 Z32 E12178.176115 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X181.162952 Y187.12199 Z32 E12181.898731 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X181.624607 Y186.354733 Z32 E12185.621526 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X182.109849 Y185.602145 Z32 E12189.344419 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X182.617933 Y184.864818 Z32 E12193.067195 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X183.147141 Y184.142555 Z32 E12196.789798 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X183.697033 Y183.43595 Z32 E12200.512279 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X184.267155 Y182.745585 Z32 E12204.234692 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X184.857035 Y182.072029 Z32 E12207.957088 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X185.466187 Y181.415839 Z32 E12211.679519 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X186.094109 Y180.777558 Z32 E12215.402038 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X186.740283 Y180.157712 Z32 E12219.124698 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X187.404178 Y179.556817 Z32 E12222.847551 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X188.086991 Y178.977493 Z32 E12226.570444 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X188.786651 Y178.418697 Z32 E12230.293168 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X189.502175 Y177.880428 Z32 E12234.015732 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X190.232973 Y177.36313 Z32 E12237.73819 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X190.978439 Y176.867228 Z32 E12241.460592 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X191.737958 Y176.393131 Z32 E12245.182992 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X192.510905 Y175.941231 Z32 E12248.905443 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X193.29664 Y175.511902 Z32 E12252.627995 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X194.094517 Y175.1055 Z32 E12256.350702 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X194.904003 Y174.722641 Z32 E12260.073595 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X195.725458 Y174.366195 Z32 E12263.796468 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X196.55685 Y174.033715 Z32 E12267.519143 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X197.397493 Y173.725473 Z32 E12271.241673 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X198.246692 Y173.441722 Z32 E12274.964111 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X199.103745 Y173.182694 Z32 E12278.686507 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X199.967946 Y172.948604 Z32 E12282.408916 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X200.838581 Y172.739646 Z32 E12286.131389 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X201.714932 Y172.555992 Z32 E12289.853978 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X202.596275 Y172.397798 Z32 E12293.576737 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X203.482044 Y172.266406 Z32 E12297.29963 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X204.371478 Y172.162856 Z32 E12301.022444 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X205.263495 Y172.085122 Z32 E12304.745074 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X206.157358 Y172.033265 Z32 E12308.467574 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X207.05233 Y172.007326 Z32 E12312.189995 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X207.94767 Y172.007326 Z32 E12315.912389 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X208.842642 Y172.033265 Z32 E12319.63481 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X209.736505 Y172.085122 Z32 E12323.35731 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X210.628522 Y172.162856 Z32 E12327.07994 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X211.517956 Y172.266406 Z32 E12330.802754 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X212.403725 Y172.397798 Z32 E12334.525647 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X213.285068 Y172.555992 Z32 E12338.248406 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X214.161419 Y172.739646 Z32 E12341.970995 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X215.032054 Y172.948604 Z32 E12345.693468 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X215.896255 Y173.182694 Z32 E12349.415877 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X216.753308 Y173.441722 Z32 E12353.138274 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X217.602507 Y173.725473 Z32 E12356.860711 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X218.44315 Y174.033715 Z32 E12360.583241 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X219.274542 Y174.366195 Z32 E12364.305916 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X220.095997 Y174.722641 Z32 E12368.028789 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X220.905483 Y175.1055 Z32 E12371.751682 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X221.70336 Y175.511902 Z32 E12375.474389 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X222.489095 Y175.941231 Z32 E12379.196941 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X223.262042 Y176.393131 Z32 E12382.919392 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X224.021561 Y176.867228 Z32 E12386.641792 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X224.767027 Y177.36313 Z32 E12390.364195 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X225.497825 Y177.880428 Z32 E12394.086652 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X226.213349 Y178.418697 Z32 E12397.809216 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X226.913009 Y178.977493 Z32 E12401.53194 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X227.595822 Y179.556817 Z32 E12405.254833 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X228.259717 Y180.157712 Z32 E12408.977686 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X228.905891 Y180.777558 Z32 E12412.700346 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X229.533813 Y181.415839 Z32 E12416.422865 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X230.142965 Y182.072029 Z32 E12420.145297 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X230.732845 Y182.745585 Z32 E12423.867692 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X231.302967 Y183.43595 Z32 E12427.590105 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X231.852859 Y184.142555 Z32 E12431.312586 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X232.382067 Y184.864818 Z32 E12435.035189 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X232.890151 Y185.602145 Z32 E12438.757965 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X233.375393 Y186.354733 Z32 E12442.480858 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X233.837048 Y187.12199 Z32 E12446.203653 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X234.27626 Y187.902261 Z32 E12449.926269 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X234.692668 Y188.694903 Z32 E12453.64876 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X235.085929 Y189.49926 Z32 E12457.371176 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X235.455721 Y190.314668 Z32 E12461.093571 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X235.801737 Y191.140453 Z32 E12464.815997 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.123691 Y191.975935 Z32 E12468.538506 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.421316 Y192.820424 Z32 E12472.261151 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.694364 Y193.673225 Z32 E12475.983984 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X236.940247 Y194.534266 Z32 E12479.706877 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.160185 Y195.402259 Z32 E12483.429618 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.354875 Y196.276221 Z32 E12487.152195 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.524159 Y197.15543 Z32 E12490.87466 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=weave level rim
G1 X237.583926 Y197.522887 Z32 E12492.422448 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001
G1 X237.667898 Y198.03916 Z32 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=end-early tail
G1 X237.785974 Y198.926681 Z32 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=end-early tail
G1 X237.878289 Y199.817262 Z32 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=end-early tail
G1 X237.944766 Y200.710167 Z32 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=end-early tail
G1 X237.985349 Y201.604659 Z32 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=end-early tail
G1 X238 Y202.5 Z32 F2400 ; clayline kind=print page=0 layer=15 stroke=weave-00001-zblend-wall-layer-001 note=end-early tail
; CLAYLINE_STROKE_END page=0 layer=1 id=weave-00001-zblend-wall-layer-001
; CLAYLINE_BODY_END
; CLAYLINE_PROFILE_END_BEGIN
M83 ;Set to Relative Extrusion Mode
G91 ;Set to Relative Positioning
G1 Z150 E-100 F40000 ;Move Z Axis up and relieve Extruder pressure (v1.3.0: was E-3000, which left the next job dry)
G90 ;Set to Absolute Positioning
G28 Z ;Home Z
G1 X207.5 Y0 F500 ;Move X and Y slow to home position
M82 ;absolute extrusion mode
; CLAYLINE_PROFILE_END_END
