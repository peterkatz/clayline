; CLAYLINE_HEADER_BEGIN
; clayline_version=0.1.0.dev0
; generated_utc=reproducible
; job_id=zellige-rosette-job
; prepared_trace_sha256=529dda99bf35f5faf83f48a03e7b4a5e5700bacc4c9f5c42a088b41a71d597e9
; body_sha256=3eaedb22683fdec278a80afa154b95acbcde8f61e5f61336fdb977a6530190a8
; profile_name=potterbot-xl
; profile_version=1.3.0
; profile_verified=true
; profile_flavor=marlin
; extrusion_mode=absolute
; bead_width_mm=5
; layer_height_mm=1.5
; flow_multiplier=1
; wet_density_g_cm3=1.8
; prime_mm=15
; end_early_mm=5
; first_layer_z_mm=1.676008
; speed_default_mm_s=40
; speed_first_layer_mm_s=30
; speed_travel_mm_s=40
; virtual_filament_diameter_mm=1.75
; work_bounds=17,398,12,393,0,710
; machine_envelope=0,490,0,490,0,710
; stats.motion_count=6742
; stats.print_motion_count=6737
; stats.travel_motion_count=5
; stats.stroke_count=2
; stats.page_count=2
; stats.print_path_mm=5427.886021
; stats.deposited_path_mm=5427.886021
; stats.travel_path_mm=112.10815
; stats.total_motion_path_mm=5539.994171
; stats.motion_time_seconds=200.594412
; stats.pause_time_seconds=0
; stats.pressure_time_seconds=0
; stats.estimated_print_time_seconds=200.594412
; stats.body_volume_mm3=52714.00558
; stats.wet_weight_g=94.88521
; stats.body_e=21915.936805
; stats.pressure_e_excluded=0
; stats.warning_count=542
; nominal_label=calibrated centerline
; stats.warning_count.over_void=448
; stats.warning_count.tight_radius=54
; stats.warning_count.under_spaced=40
; parameter.alternate=true
; parameter.collision_lift=bounded-clearance-v1
; parameter.first_layer_flow_factor=1.1
; parameter.first_layer_height=1.5
; parameter.first_layer_speed_factor=0.6
; parameter.flow_modulation=0.95
; parameter.hardware_default_status=calibration pending, provisional reference defaults
; parameter.helical=false
; parameter.joint_boost=0.5
; parameter.layers=1
; parameter.overlap_fraction_provisional=0.2
; parameter.page_gap=30.0
; parameter.page_mode=stack
; parameter.page_pause_seconds=disabled
; parameter.page_travel_clearance=50.0
; parameter.page_travel_lift=3.0
; parameter.pass_model=explicit-passes
; parameter.provisional_flow_multiplier=1.0
; parameter.stack_job_page_count=2
; parameter.stack_page_0_datum_top_z_mm=2.4499999203913716
; parameter.stack_page_0_material_z_max_mm=3.8911921262847993
; parameter.stack_page_0_material_z_min_mm=0.5500001842751566
; parameter.stack_page_0_nominal_path_start_z_mm=1.5
; parameter.stack_page_0_nominal_top_z_mm=2.4499999203913716
; parameter.stack_page_0_path_start_z_mm=1.5
; parameter.stack_page_0_z_max_mm=4.0183667904912
; parameter.stack_page_0_z_min_mm=0.5500001842751566
; parameter.stack_page_1_datum_top_z_mm=4.899999736116215
; parameter.stack_page_1_material_z_max_mm=6.398405561486184
; parameter.stack_page_1_material_z_min_mm=3.0001515674663444
; parameter.stack_page_1_nominal_path_start_z_mm=3.9499999203913716
; parameter.stack_page_1_nominal_top_z_mm=4.899999736116215
; parameter.stack_page_1_path_start_z_mm=3.9499999203913716
; parameter.stack_page_1_prior_datum_top_z_mm=2.4499999203913716
; parameter.stack_page_1_z_max_mm=6.942870005664516
; parameter.stack_page_1_z_min_mm=3.0001515674663444
; parameter.stack_page_material_height_mm=1.5
; parameter.stack_total_height_mm=6.398405561486184
; parameter.standoff_z=20.0
; parameter.thread_protection_model=extra-clay-slowdown-v1
; parameter.z_mode=calibrated
; parameter.z_modulation=0.95
; parameter.z_step_per_layer=1.5
; pressure_management=profile and marked pressure blocks excluded from body volume
; thermal_policy=no heater or fan commands outside verbatim profile blocks
; CLAYLINE_HEADER_END
; CLAYLINE_PROFILE_START_BEGIN
M105
M109 S0
M82 ;absolute extrusion mode
G28 ;Home
G1 X207.5 Y202.5 Z20 F10000 ;Move X and Y to center, Z to 20mm high
G92 E0
G1 E100 F40000 ; Prime Extruder (v1.3.0: matches the reduced end-of-job depressurize)
G92 E0
G92 E0
G92 E0
M107
; CLAYLINE_PROFILE_START_END
; CLAYLINE_BODY_BEGIN
G21 ; clayline units: millimeters
G90 ; clayline absolute XYZ
M82 ; clayline absolute extrusion
G92 E0 ; clayline body extrusion origin
; CLAYLINE_PAGE index=0
; CLAYLINE_MARKER page=0 layer=0 text=layer 0 page_id=page-01-zellige-rosette page_name=zellige-rosette z_mode=calibrated
; CLAYLINE_STROKE_BEGIN page=0 layer=0 id=stroke-0000
G0 X134.162 Y202.5 Z20 F2400 ; clayline kind=travel_xy page=0 layer=0 stroke=stroke-0000 note=stroke start XY at safe Z
G0 X134.162 Y202.5 Z1.5 F2400 ; clayline kind=travel_approach page=0 layer=0 stroke=stroke-0000 note=stroke start vertical approach
G1 X134.30801 Y203.982465 Z1.676008 E0.476068 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X134.355915 Y204.468852 Z1.733754 E0.839704 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X134.646699 Y205.427438 Z1.844834 E2.09357 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X134.930208 Y206.362041 Z1.953135 E3.803507 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X135.172953 Y206.816185 Z2.002985 E5.041314 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X135.862809 Y208.106815 Z2.144653 E9.38329 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X135.881614 Y208.129729 Z2.146929 E9.492935 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X136.830412 Y209.285843 Z2.261745 E15.731977 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X137.117878 Y209.636122 Z2.296532 E17.89595 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X137.924993 Y210.298504 Z2.350839 E23.670294 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X138.647185 Y210.891191 Z2.399432 E29.440787 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X139.144723 Y211.157131 Z2.418627 E33.239832 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X139.189726 Y211.181185 Z2.420364 E33.593814 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X140.391959 Y211.823792 Z2.447027 E43.82178 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X140.47376 Y211.848606 Z2.446567 E44.500663 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X141.90915 Y212.284027 Z2.438502 E57.202957 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X142.285148 Y212.398085 Z2.43639 E60.777303 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X143.386309 Y212.50654 Z2.40029 E71.092317 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 note=prime ramp
G1 X143.994016 Y212.566394 Z2.380367 E77.003075 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X143.486959 Y212.720208 Z2.354662 E82.065121 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X141.742185 Y213.652809 Z2.226322 E99.673619 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X140.212878 Y214.907878 Z2.053322 E115.544614 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X139.844802 Y215.356381 Z1.995599 E120.031162 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.957809 Y216.437185 Z1.846298 E129.770834 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.025208 Y218.181959 Z1.617981 E141.225855 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.737584 Y219.130128 Z1.5 E146.359635 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.450915 Y220.075148 Z1.382409 E149.369669 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.257 Y222.044 Z1.154067 E153.837466 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.450915 Y224.012852 Z0.946997 E156.887242 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.025208 Y225.906041 Z0.773931 E158.753164 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.957809 Y227.650815 Z0.64551 E159.742635 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X140.212878 Y229.180122 Z0.569631 E160.215481 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X141.742185 Y230.435191 Z0.55096 E160.561299 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X143.486959 Y231.367792 Z0.590645 E161.176517 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X145.380148 Y231.942085 Z0.686246 E162.441806 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.349 Y232.136 Z0.831884 E164.699976 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X148.788133 Y231.994258 Z0.964939 E167.015835 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.317852 Y231.942085 Z1.018604 E168.443256 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.211041 Y231.367792 Z1.234924 E175.968349 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.955815 Y230.435191 Z1.467544 E185.884449 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.485122 Y229.180122 Z1.70216 E198.206511 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X155.740191 Y227.650815 Z1.924345 E212.795508 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.532108 Y226.169244 Z2.093027 E226.63351 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.672792 Y225.906041 Z2.120437 E228.29924 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.247085 Y224.012852 Z2.278379 E240.405256 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.441 Y222.044 Z2.388459 E253.239673 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.247085 Y220.075148 Z2.443908 E266.435711 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.672792 Y218.181959 Z2.441317 E279.608996 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X155.740191 Y216.437185 Z2.380845 E292.377882 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.485122 Y214.907878 Z2.26621 E304.383027 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.955815 Y213.652809 Z2.104461 E315.306812 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.211041 Y212.720208 Z1.905545 E324.892561 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X150.48624 Y212.500342 Z1.819843 E327.982063 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.317852 Y212.145915 Z2.292173 E333.288192 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.819843 matz1=2.292173 note=collision lift
G1 X148.973324 Y212.111982 Z2.424545 E334.738672 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.292173 matz1=2.424545 note=collision lift
G1 X147.349 Y211.952 Z3.046336 E343.245582 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.424545 matz1=2.946666 note=collision lift
G1 X145.380148 Y212.145915 Z3.803779 E351.037574 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.946666 matz1=2.71492 note=collision lift
G1 X145.190191 Y212.203538 Z3.881196 E351.646615 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.71492 matz1=2.693084 note=collision lift
G1 X143.994016 Y212.566394 Z3.921917 E355.221567 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.693084 matz1=2.555585 note=collision lift
G1 X143.995351 Y212.566525 Z3.921105 E355.22583 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.555585 matz1=2.555445 note=collision lift
G1 X144.253714 Y212.591972 Z3.912635 E355.931804 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.555445 matz1=2.528295 note=collision lift
G1 X144.254 Y212.592 Z3.912749 E355.932644 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.528295 matz1=2.528265 note=collision lift
G1 X145.241958 Y212.494695 Z3.880491 E357.669466 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.528265 matz1=2.43373 note=collision lift
G1 X146.222852 Y212.398085 Z3.293811 E359.67517 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.43373 matz1=2.33987 note=collision lift
G1 X146.68837 Y212.256872 Z3.014235 E360.229608 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.33987 matz1=2.303526 note=collision lift
G1 X147.338394 Y212.059689 Z3.097447 E360.905857 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.303526 matz1=2.252777 note=collision lift
G1 X147.341732 Y212.058676 Z3.095442 E360.909834 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.252777 matz1=2.252517 note=collision lift
G1 X147.608984 Y211.977606 Z3.126709 E361.187529 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.252517 matz1=2.231652 note=collision lift
G1 X147.609137 Y211.97756 Z3.126617 E361.187711 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.231652 matz1=2.23164 note=collision lift
G1 X147.734598 Y211.939502 Z3.140915 E361.318033 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.23164 matz1=2.221845 note=collision lift
G1 X147.735311 Y211.939286 Z3.141232 E361.318833 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.221845 matz1=2.221789 note=collision lift
G1 X148.104581 Y211.827269 Z3.18142 E361.702213 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.221789 matz1=2.19296 note=collision lift
G1 X148.116041 Y211.823792 Z3.186514 E361.715073 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.19296 matz1=2.192065 note=collision lift
G1 X148.86201 Y211.425064 Z3.239888 E362.341263 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.192065 matz1=2.143606 note=collision lift
G1 X148.868932 Y211.421364 Z3.235579 E362.345067 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.143606 matz1=2.143222 note=collision lift
G1 X148.914539 Y211.396986 Z3.237552 E362.367052 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.143222 matz1=2.140692 note=collision lift
G1 X148.916874 Y211.395738 Z3.238746 E362.368286 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.140692 matz1=2.140563 note=collision lift
G1 X149.218076 Y211.234742 Z3.246728 E362.513412 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.140563 matz1=2.123855 note=collision lift
G1 X149.218438 Y211.234549 Z3.246506 E362.513638 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.123855 matz1=2.123838 note=collision lift
G1 X149.439564 Y211.116355 Z3.244069 E362.634826 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.123838 matz1=2.113546 note=collision lift
G1 X149.442563 Y211.114751 Z3.24563 E362.636634 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.113546 matz1=2.113406 note=collision lift
G1 X149.66705 Y210.994761 Z3.226164 E362.760018 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.113406 matz1=2.102958 note=collision lift
G1 X149.684062 Y210.985668 Z3.215728 E362.770618 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.102958 matz1=2.102166 note=collision lift
G1 X149.695016 Y210.979812 Z3.212628 E362.776805 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.102166 matz1=2.101657 note=collision lift
G1 X149.696389 Y210.979079 Z3.213342 E362.777633 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.101657 matz1=2.101593 note=collision lift
G1 X149.725728 Y210.963397 Z3.196739 E362.795603 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.101593 matz1=2.100227 note=collision lift
G1 X149.860815 Y210.891191 Z3.113865 E362.879774 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.100227 matz1=2.09394 note=collision lift
G1 X151.390122 Y209.636122 Z2.082264 E363.471276 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.09394 matz1=2.051528 note=collision lift
G1 X152.645191 Y208.106815 Z1.108984 E364.236255 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051528 matz1=1.108984 note=collision lift
G1 X153.155759 Y207.151611 Z0.607539 E365.100177 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.108984 matz1=0.607539 note=collision lift
G1 X153.577792 Y206.362041 Z0.640688 E365.748655 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.152085 Y204.468852 Z0.766778 E368.469598 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.297408 Y202.993368 Z0.891361 E371.465413 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.346 Y202.5 Z0.937954 E372.213399 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.297408 Y202.006632 Z0.986728 E373.045035 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.152085 Y200.531148 Z1.143689 E377.982528 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X153.577792 Y198.637959 Z1.371334 E386.910019 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.824432 Y197.228521 Z1.561681 E395.701222 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.172 Y198.104 Z1.690764 E402.436895 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.872 Y198.669 Z1.764881 E406.627776 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.432 Y199.871 Z1.907577 E415.954819 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.188 Y201.154 Z2.042301 E426.372927 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.143756 Y201.93759 Z2.11647 E432.929207 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.112 Y202.5 Z2.16605 E436.160646 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.143756 Y203.06241 Z2.212293 E439.480118 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.188 Y203.846 Z2.270727 E446.649988 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.432 Y205.129 Z2.351114 E459.111633 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.872 Y206.331 Z2.407718 E471.687215 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.021281 Y206.612145 Z2.417458 E474.845082 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.172 Y206.896 Z2.587986 E478.452699 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.417458 matz1=2.587986 note=collision lift
G1 X152.203025 Y206.937632 Z2.614791 E479.038495 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.587986 matz1=2.614791 note=collision lift
G1 X152.426095 Y207.236962 Z2.434215 E483.195853 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.614791 matz1=2.434215 note=collision lift
G1 X152.426264 Y207.237189 Z2.43422 E483.198695 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.628538 Y207.508614 Z2.608984 E487.017888 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.43422 matz1=2.608984 note=collision lift
G1 X152.824432 Y207.771479 Z2.614321 E490.304907 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.608984 matz1=2.614321 note=collision lift
G1 X152.82668 Y207.774495 Z2.610621 E490.357806 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.614321 matz1=2.610621 note=collision lift
G1 X152.828702 Y207.777209 Z2.608984 E490.395497 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.610621 matz1=2.608984 note=collision lift
G1 X152.830725 Y207.779922 Z2.607347 E490.433188 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.608984 matz1=2.607347 note=collision lift
G1 X152.890809 Y207.860548 Z2.608984 E491.441381 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.607347 matz1=2.608984 note=collision lift
G1 X152.953 Y207.944 Z2.610678 E492.484911 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.608984 matz1=2.610678 note=collision lift
G1 X152.955414 Y207.946379 Z2.607294 E492.532949 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.610678 matz1=2.607294 note=collision lift
G1 X153.1815 Y208.169202 Z2.449033 E496.09069 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.607294 matz1=2.449033 note=collision lift
G1 X153.438 Y208.422 Z2.449551 E499.702982 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.618 Y209.275 Z2.42839 E514.150353 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X155.318 Y209.646 Z2.403768 E521.913872 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.955 Y210.265 Z2.318134 E538.304396 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.131669 Y210.310713 Z2.306846 E540.004058 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.898 Y210.509 Z2.253056 E544.774654 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X158.160737 Y210.551082 Z2.233273 E546.360911 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.052 Y210.854 Z2.068158 E561.871527 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X162.582 Y210.995 Z1.801233 E578.929392 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.14238 Y210.979137 Z1.737067 E582.520724 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.587866 Y211.810042 Z1.529169 E591.918624 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.015836 Y212.279495 Z1.441309 E595.048486 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.202216 Y212.947216 Z1.84261 E599.77957 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.441309 matz1=1.84261 note=collision lift
G1 X159.24593 Y214.112453 Z2.424091 E605.133834 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.84261 matz1=2.424091 note=collision lift
G1 X159.065042 Y214.332866 Z2.535333 E605.777144 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.424091 matz1=2.535333 note=collision lift
G1 X158.220046 Y215.913743 Z3.247619 E608.614153 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.535333 matz1=2.428815 note=collision lift
G1 X157.732902 Y217.519639 Z3.783591 E610.267922 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.428815 matz1=2.283591 note=collision lift
G1 X157.732833 Y217.519866 Z3.78357 E610.268145 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.283591 matz1=2.28357 note=collision lift
G1 X157.6997 Y217.629091 Z3.773693 E610.375694 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.28357 matz1=2.273693 note=collision lift
G1 X157.699699 Y217.629094 Z3.773692 E610.375698 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.273693 matz1=2.273692 note=collision lift
G1 X157.675208 Y217.877758 Z3.757185 E610.509057 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.273692 matz1=2.257185 note=collision lift
G1 X157.675196 Y217.877883 Z3.757176 E610.509124 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257185 matz1=2.257176 note=collision lift
G1 X157.577519 Y218.869614 Z3.69134 E611.040994 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257176 matz1=2.19134 note=collision lift
G1 X157.577512 Y218.869687 Z3.691336 E611.041034 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.19134 matz1=2.191336 note=collision lift
G1 X157.524 Y219.413 Z3.655268 E611.332415 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.191336 matz1=2.155268 note=collision lift
G1 X157.699699 Y221.196906 Z3.579525 E611.821794 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.155268 matz1=2.079525 note=collision lift
G1 X157.711416 Y221.235532 Z3.578866 E611.828757 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.079525 matz1=2.078866 note=collision lift
G1 X157.711464 Y221.235688 Z3.578864 E611.828786 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.078866 matz1=2.078864 note=collision lift
G1 X157.941672 Y221.994581 Z3.56593 E611.965597 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.078864 matz1=2.06593 note=collision lift
G1 X157.941703 Y221.994685 Z3.565928 E611.965616 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.06593 matz1=2.065928 note=collision lift
G1 X158.220046 Y222.912257 Z3.55029 E612.131034 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.065928 matz1=2.05029 note=collision lift
G1 X158.220197 Y222.912541 Z3.550293 E612.13111 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05029 matz1=2.050293 note=collision lift
G1 X158.25993 Y222.986877 Z3.551175 E612.151071 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050293 matz1=2.051175 note=collision lift
G1 X158.260479 Y222.987903 Z3.551187 E612.151347 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051175 matz1=2.051187 note=collision lift
G1 X158.405549 Y223.25931 Z3.554406 E612.224226 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051187 matz1=2.054406 note=collision lift
G1 X158.406111 Y223.26036 Z3.554419 E612.224508 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054406 matz1=2.054419 note=collision lift
G1 X158.47729 Y223.393527 Z3.555998 E612.260267 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054419 matz1=2.055998 note=collision lift
G1 X158.478084 Y223.395014 Z3.556016 E612.260666 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055998 matz1=2.056016 note=collision lift
G1 X158.550619 Y223.530717 Z3.557625 E612.297106 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056016 matz1=2.057625 note=collision lift
G1 X159.065042 Y224.493134 Z3.287138 E612.563347 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.057625 matz1=2.069041 note=collision lift
G1 X160.202216 Y225.878784 Z2.456658 E613.476967 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.069041 matz1=2.13483 note=collision lift
G1 X161.587866 Y227.015958 Z1.669892 E615.117529 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.13483 matz1=1.669892 note=collision lift
G1 X163.168743 Y227.860954 Z0.921308 E617.729501 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.669892 matz1=0.921308 note=collision lift
G1 X163.224802 Y227.87796 Z0.897847 E617.852968 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.921308 matz1=0.897847 note=collision lift
G1 X164.884094 Y228.381301 Z1.07042 E621.262233 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.167998 Y228.409263 Z1.101065 E621.853752 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.668 Y228.557 Z1.270528 E627.866648 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.451906 Y228.381301 Z1.482231 E636.988208 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.167257 Y227.860954 Z1.694832 E648.084749 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.748134 Y227.015958 Z1.897589 E661.056165 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X172.304577 Y226.559297 Z1.973903 E666.545387 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.133784 Y225.878784 Z2.080256 E675.30951 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.053092 Y224.758605 Z2.206882 E688.083795 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.270958 Y224.493134 Z2.233606 E691.156157 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.115954 Y222.912257 Z2.349889 E708.252569 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.237927 Y222.510166 Z2.371108 E712.302713 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.67 Y223.027 Z2.403574 E719.829976 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.544231 Y224.208586 Z2.444379 E736.161333 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.238 Y224.53 Z2.448664 E740.612388 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.881887 Y226.216511 Z2.427329 E762.072656 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.863 Y226.24 Z2.426541 E762.371505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X169.731 Y228.255 Z2.288689 E789.3977 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.041 Y230.143 Z2.083245 E810.105768 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X167.619719 Y230.725475 Z2.013219 E815.728848 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.918736 Y231.694674 Z1.887721 E824.315752 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.763 Y231.91 Z1.858548 E826.184351 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.268 Y232.75 Z1.748342 E832.486289 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.548 Y234.345 Z1.542334 E841.935755 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.316 Y235.102 Z1.447854 E845.824243 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.306936 Y235.158424 Z1.441043 E846.102885 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.724191 Y234.068185 Z1.29505 E851.194708 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.469122 Y232.538878 Z1.073102 E857.06468 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X162.044324 Y231.369577 Z0.889683 E860.778304 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.939815 Y231.283809 Z0.877403 E860.954033 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.933689 Y230.746023 Z0.786629 E861.817563 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.195041 Y230.351208 Z1.138759 E862.503109 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.786629 matz1=1.138759 note=collision lift
G1 X158.39552 Y229.805329 Z1.973724 E863.31261 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.138759 matz1=1.973724 note=collision lift
G1 X158.301852 Y229.776915 Z2.018494 E863.373821 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.973724 matz1=2.018494 note=collision lift
G1 X156.333 Y229.583 Z2.952923 E864.001648 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.018494 matz1=2.055773 note=collision lift
G1 X155.703396 Y229.645011 Z3.270303 E864.216764 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055773 matz1=2.056828 note=collision lift
G1 X155.702441 Y229.645105 Z3.269825 E864.21709 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056828 matz1=2.05683 note=collision lift
G1 X155.686761 Y229.646649 Z3.275482 E864.222178 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05683 matz1=2.056856 note=collision lift
G1 X155.684623 Y229.64686 Z3.27656 E864.222908 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056856 matz1=2.056859 note=collision lift
G1 X155.648693 Y229.650398 Z3.28475 E864.23416 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056859 matz1=2.05692 note=collision lift
G1 X155.647077 Y229.650558 Z3.285565 E864.234712 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05692 matz1=2.056922 note=collision lift
G1 X155.573788 Y229.657776 Z3.295264 E864.257287 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056922 matz1=2.057045 note=collision lift
G1 X155.571985 Y229.657953 Z3.296173 E864.257903 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.057045 matz1=2.057048 note=collision lift
G1 X155.424233 Y229.672506 Z3.30538 E864.303112 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.057048 matz1=2.057296 note=collision lift
G1 X155.421801 Y229.672745 Z3.306606 E864.303943 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.057296 matz1=2.0573 note=collision lift
G1 X155.125031 Y229.701975 Z3.309285 E864.394579 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.0573 matz1=2.057797 note=collision lift
G1 X155.121433 Y229.702329 Z3.311099 E864.395808 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.057797 matz1=2.057803 note=collision lift
G1 X154.542174 Y229.759381 Z3.291131 E864.572814 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.057803 matz1=2.058774 note=collision lift
G1 X154.536697 Y229.75992 Z3.288388 E864.574683 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058774 matz1=2.058783 note=collision lift
G1 X154.368242 Y229.776512 Z3.278846 E864.626209 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058783 matz1=2.059065 note=collision lift
G1 X154.364148 Y229.776915 Z3.28091 E864.627608 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059065 matz1=2.059072 note=collision lift
G1 X153.560074 Y230.020828 Z3.204616 E865.149501 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059072 matz1=2.085047 note=collision lift
G1 X153.553683 Y230.022767 Z3.201483 E865.154065 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.085047 matz1=2.085253 note=collision lift
G1 X153.403412 Y230.068351 Z3.184458 E865.25177 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.085253 matz1=2.090107 note=collision lift
G1 X153.402458 Y230.06864 Z3.184987 E865.252467 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.090107 matz1=2.090138 note=collision lift
G1 X152.803984 Y230.250186 Z3.113736 E865.641825 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.090138 matz1=2.109471 note=collision lift
G1 X152.802695 Y230.250577 Z3.113104 E865.642746 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.109471 matz1=2.109513 note=collision lift
G1 X152.471158 Y230.351147 Z3.071177 E865.858615 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.109513 matz1=2.120222 note=collision lift
G1 X152.470959 Y230.351208 Z3.071287 E865.858761 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.120222 matz1=2.120229 note=collision lift
G1 X151.743551 Y230.740015 Z2.967935 E866.86585 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.120229 matz1=2.168279 note=collision lift
G1 X151.74249 Y230.740583 Z2.967403 E866.867444 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.168279 matz1=2.168349 note=collision lift
G1 X150.726656 Y231.283557 Z2.831968 E868.272557 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.168349 matz1=2.235451 note=collision lift
G1 X150.726185 Y231.283809 Z2.832266 E868.273298 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.235451 matz1=2.235482 note=collision lift
G1 X150.05315 Y231.836155 Z2.73539 E870.066 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.235482 matz1=2.306892 note=collision lift
G1 X150.052364 Y231.836799 Z2.735981 E870.068406 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.306892 matz1=2.306976 note=collision lift
G1 X149.438688 Y232.34043 Z2.648596 E871.702784 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.306976 matz1=2.372088 note=collision lift
G1 X149.436312 Y232.34238 Z2.647311 E871.709602 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.372088 matz1=2.37234 note=collision lift
G1 X149.196878 Y232.538878 Z2.610682 E872.347864 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.37234 matz1=2.397745 note=collision lift
G1 X149.196606 Y232.53921 Z2.610507 E872.348842 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.397745 matz1=2.397785 note=collision lift
G1 X149.115692 Y232.637804 Z2.594922 E872.619802 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.397785 matz1=2.409639 note=collision lift
G1 X149.11414 Y232.639696 Z2.596373 E872.6258 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.409639 matz1=2.409866 note=collision lift
G1 X148.766445 Y233.063363 Z2.521004 E873.758719 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.409866 matz1=2.465379 note=collision lift
G1 X148.766136 Y233.06374 Z2.521297 E873.759884 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.465379 matz1=2.465428 note=collision lift
G1 X147.941809 Y234.068185 Z2.003212 E876.624516 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.465428 matz1=2.003212 note=collision lift
G1 X147.087476 Y235.666529 Z1.302308 E882.097176 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.003212 matz1=1.302308 note=collision lift
G1 X147.009208 Y235.812959 Z1.321113 E882.567781 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X146.434915 Y237.706148 Z1.556185 E889.785197 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X146.241 Y239.675 Z1.787803 E898.58358 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X146.434915 Y241.643852 Z2.001724 E908.833289 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.009208 Y243.537041 Z2.184794 E920.314709 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.941809 Y245.281815 Z2.325757 E932.735231 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.196878 Y246.811122 Z2.415944 E945.749834 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X150.726185 Y248.066191 Z2.449811 E958.982682 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.470959 Y248.998792 Z2.425274 E972.048096 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.364148 Y249.573085 Z2.343843 E984.570527 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.333 Y249.767 Z2.210524 E996.204023 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X158.301852 Y249.573085 Z2.033515 E1006.651629 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.195041 Y248.998792 Z1.823702 E1015.684296 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.982611 Y248.577827 Z1.721647 E1019.450558 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.939815 Y248.066191 Z1.593983 E1025.601592 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.469122 Y246.811122 Z1.358486 E1034.401478 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.568863 Y245.471083 Z1.158804 E1040.31614 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.724191 Y245.281815 Z1.131691 E1041.116752 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.656792 Y243.537041 Z0.927542 E1045.491645 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.231085 Y241.643852 Z0.758594 E1048.133351 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.29486 Y240.996336 Z0.714424 E1048.747194 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.340303 Y240.534947 Z0.914761 E1049.222583 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.714424 matz1=0.914761 note=collision lift
G1 X166.389058 Y240.039921 Z1.134789 E1049.654286 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.914761 matz1=1.134789 note=collision lift
G1 X166.425 Y239.675 Z1.299099 E1049.933858 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.134789 matz1=1.299099 note=collision lift
G1 X166.41331 Y239.556306 Z1.352935 E1050.021 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.299099 matz1=1.352935 note=collision lift
G1 X166.231085 Y237.706148 Z2.218102 E1050.707259 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.352935 matz1=2.065048 note=collision lift
G1 X165.805905 Y236.304517 Z2.941052 E1051.147213 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.065048 matz1=2.055649 note=collision lift
G1 X165.792942 Y236.261786 Z2.947297 E1051.159357 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055649 matz1=2.055362 note=collision lift
G1 X165.791769 Y236.257917 Z2.949293 E1051.160572 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055362 matz1=2.055336 note=collision lift
G1 X165.656792 Y235.812959 Z3.014744 E1051.287048 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055336 matz1=2.052352 note=collision lift
G1 X165.656192 Y235.811835 Z3.014125 E1051.287505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052352 matz1=2.05237 note=collision lift
G1 X165.542245 Y235.598657 Z3.042285 E1051.365998 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05237 matz1=2.055738 note=collision lift
G1 X165.540278 Y235.594976 Z3.04443 E1051.367512 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055738 matz1=2.055796 note=collision lift
G1 X165.306936 Y235.158424 Z3.091835 E1051.527904 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055796 matz1=2.062692 note=collision lift
G1 X165.30613 Y235.163444 Z3.089444 E1051.530917 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.062692 matz1=2.062843 note=collision lift
G1 X165.271712 Y235.377697 Z3.063883 E1051.648078 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.062843 matz1=2.069283 note=collision lift
G1 X165.24288 Y235.557179 Z3.133362 E1051.752429 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.069283 matz1=2.074678 note=collision lift
G1 X165.242879 Y235.557188 Z3.133372 E1051.752436 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074678 matz1=2.074679 note=collision lift
G1 X165.117742 Y236.336177 Z3.433382 E1052.205045 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074679 matz1=2.098094 note=collision lift
G1 X165.117677 Y236.33658 Z3.433394 E1052.205264 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.098094 matz1=2.098106 note=collision lift
G1 X165.108678 Y236.392601 Z3.455001 E1052.237819 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.098106 matz1=2.09979 note=collision lift
G1 X165.085 Y236.54 Z3.459432 E1052.317904 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.09979 matz1=2.104221 note=collision lift
G1 X165.08 Y237.221 Z3.48975 E1052.789769 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.104221 matz1=2.134539 note=collision lift
G1 X165.269 Y238.514 Z3.565435 E1054.205492 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.134539 matz1=2.210224 note=collision lift
G1 X165.456 Y239.126 Z2.970467 E1055.352706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.210224 matz1=2.255188 note=collision lift
G1 X165.590673 Y239.416083 Z2.676091 E1056.094017 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.255188 matz1=2.280633 note=collision lift
G1 X165.8598 Y239.99578 Z2.726939 E1057.187447 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.280633 matz1=2.33148 note=collision lift
G1 X165.917912 Y240.120954 Z2.738744 E1057.432081 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.33148 matz1=2.343285 note=collision lift
G1 X165.995 Y240.287 Z2.754709 E1057.771731 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.343285 matz1=2.35925 note=collision lift
G1 X166.115576 Y240.464415 Z2.773846 E1058.190992 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.35925 matz1=2.378387 note=collision lift
G1 X166.694823 Y241.316713 Z2.258594 E1061.0507 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.378387 matz1=2.258594 note=collision lift
G1 X166.729 Y241.367 Z2.258594 E1061.201616 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.258594 matz1=2.258594 note=collision lift
G1 X167.628 Y242.372 Z1.72614 E1065.857303 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.258594 matz1=1.72614 note=collision lift
G1 X168.525292 Y243.174652 Z1.260362 E1071.015737 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.72614 matz1=1.260362 note=collision lift
G1 X168.633 Y243.271 Z1.276708 E1071.596905 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X169.237851 Y243.682075 Z1.36239 E1074.863914 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.356148 Y243.768915 Z1.467678 E1079.305865 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.049518 Y243.86193 Z1.505677 E1081.301826 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.462959 Y244.343208 Z2.531265 E1093.360968 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.505677 matz1=2.531265 note=collision lift
G1 X165.822738 Y244.685413 Z2.635687 E1098.735962 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.531265 matz1=2.635687 note=collision lift
G1 X165.813647 Y244.690272 Z2.631691 E1098.816984 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.635687 matz1=2.631691 note=collision lift
G1 X164.718185 Y245.275809 Z2.631691 E1107.920275 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.631691 matz1=2.631691 note=collision lift
G1 X164.54795 Y245.415517 Z2.544933 E1109.683414 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.631691 matz1=2.544933 note=collision lift
G1 X163.624799 Y246.173128 Z2.065139 E1120.413889 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.544933 matz1=2.065139 note=collision lift
G1 X163.188878 Y246.530878 Z2.120539 E1125.138285 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.130516 Y246.601993 Z2.127882 E1125.982736 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.933809 Y248.060185 Z3.221647 E1145.934736 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.127882 matz1=3.221647 note=collision lift
G1 X161.422173 Y249.017389 Z3.221647 E1156.238891 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.221647 matz1=3.221647 note=collision lift
G1 X161.001208 Y249.804959 Z2.818381 E1162.58584 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.221647 matz1=2.818381 note=collision lift
G1 X160.751636 Y250.627686 Z2.412589 E1168.924702 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.818381 matz1=2.412589 note=collision lift
G1 X160.426915 Y251.698148 Z2.443924 E1176.386164 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.233 Y253.667 Z2.441299 E1189.559328 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.426915 Y255.635852 Z2.380795 E1202.32788 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.001208 Y257.529041 Z2.266131 E1214.332499 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.933809 Y259.273815 Z2.104358 E1225.255593 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.188878 Y260.803122 Z1.905424 E1234.840527 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.718185 Y262.058191 Z1.68156 E1242.909454 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.462959 Y262.990792 Z1.446532 E1249.377542 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.356148 Y263.565085 Z1.214792 E1254.2611 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.325 Y263.759 Z1.00059 E1257.677824 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X172.293852 Y263.565085 Z0.817095 E1259.838786 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.187041 Y262.990792 Z0.675592 E1261.033354 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.931815 Y262.058191 Z0.584782 E1261.609267 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X177.360304 Y260.88586 Z0.55073 E1261.93087 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X177.461122 Y260.803122 Z0.550247 E1261.964587 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.34964 Y259.720458 Z0.561124 E1262.40505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.057915 Y260.682148 Z0.586857 E1262.85429 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.005742 Y261.211867 Z0.606414 E1263.145908 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X177.864 Y262.651 Z0.679411 E1264.036928 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.057915 Y264.619852 Z0.822422 E1266.230512 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.632208 Y266.513041 Z1.007098 E1269.686503 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.564809 Y268.257815 Z1.222081 E1274.615202 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.819878 Y269.787122 Z1.454153 E1281.134234 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.349185 Y271.042191 Z1.689045 E1289.259455 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.093959 Y271.974792 Z1.912312 E1298.903874 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.987148 Y272.549085 Z2.110227 E1309.884994 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.956 Y272.743 Z2.270619 E1321.939373 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X189.924852 Y272.549085 Z2.383626 E1334.742004 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X191.818041 Y271.974792 Z2.442299 E1347.927738 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X193.562815 Y271.042191 Z2.443031 E1361.112645 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.092122 Y269.787122 Z2.385777 E1373.914395 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.347191 Y268.257815 Z2.274057 E1385.971863 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.881064 Y267.25901 Z2.188112 E1392.548246 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.279792 Y266.513041 Z2.11474 E1399.601675 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.854085 Y264.619852 Z1.917624 E1414.10256 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.048 Y262.651 Z1.694828 E1426.341121 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.854085 Y260.682148 Z1.460052 E1436.181683 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.279792 Y258.788959 Z1.227732 E1443.639886 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.637185 Y257.586726 Z1.076567 E1447.708451 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.347191 Y257.044185 Z1.012155 E1448.795025 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.092122 Y255.514878 Z0.826574 E1451.020801 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X193.562815 Y254.259809 Z0.682402 E1452.261816 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X191.818041 Y253.327208 Z0.588504 E1452.863056 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X189.924852 Y252.752915 Z0.550653 E1453.206835 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.956 Y252.559 Z0.571176 E1453.689846 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.987148 Y252.752915 Z0.648813 E1454.70043 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.093959 Y253.327208 Z0.778789 E1456.596295 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X183.830756 Y253.467892 Z0.80248 E1456.906901 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.349185 Y254.259809 Z0.953111 E1460.838917 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.819878 Y255.514878 Z1.161061 E1467.604671 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.564809 Y257.044185 Z1.389853 E1476.7225 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.632208 Y258.788959 Z1.625417 E1488.258599 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.34964 Y259.720458 Z1.739382 E1494.508002 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.716191 Y259.273815 Z1.805445 E1498.414016 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.826247 Y259.067916 Z1.830457 E1500.247092 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.648792 Y257.529041 Z2.889853 E1516.183557 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.830457 matz1=2.889853 note=collision lift
G1 X180.133448 Y255.931345 Z2.889853 E1530.76522 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.889853 matz1=2.889853 note=collision lift
G1 X180.133535 Y255.931059 Z2.89003 E1530.768256 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.889853 matz1=2.89003 note=collision lift
G1 X180.223085 Y255.635852 Z2.853387 E1533.481458 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.89003 matz1=2.853387 note=collision lift
G1 X180.351655 Y254.330463 Z2.288531 E1546.96299 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.853387 matz1=2.288531 note=collision lift
G1 X180.417 Y253.667 Z2.334781 E1553.271382 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.223085 Y251.698148 Z2.420697 E1572.839833 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.194671 Y251.60448 Z2.423507 E1573.808917 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.648792 Y249.804959 Z2.45 E1586.387674 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.716191 Y248.060185 Z2.420888 E1599.423733 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.630423 Y247.955676 Z2.416791 E1600.312996 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X177.461122 Y246.530878 Z2.335152 E1617.732855 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.931815 Y245.275809 Z2.198062 E1635.058212 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.193488 Y244.346654 Z2.01878 E1650.523745 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.187041 Y244.343208 Z2.018049 E1650.581121 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X172.46691 Y243.821412 Z1.825548 E1662.729985 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X172.293852 Y243.768915 Z1.896604 E1664.035748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.825548 matz1=1.896604 note=collision lift
G1 X170.325 Y243.575 Z2.655099 E1675.759683 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.896604 matz1=2.655099 note=collision lift
G1 X169.960079 Y243.610942 Z2.794741 E1677.842595 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.655099 matz1=2.794741 note=collision lift
G1 X169.465053 Y243.659697 Z2.984078 E1680.505375 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.794741 matz1=2.972413 note=collision lift
G1 X169.241569 Y243.681709 Z3.011019 E1681.605247 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.972413 matz1=2.94563 note=collision lift
G1 X169.237851 Y243.682075 Z3.012441 E1681.624686 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.94563 matz1=2.945185 note=collision lift
G1 X169.535585 Y243.884424 Z2.977033 E1683.304002 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.945185 matz1=2.902352 note=collision lift
G1 X169.537241 Y243.885549 Z2.975795 E1683.31462 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.902352 matz1=2.902114 note=collision lift
G1 X169.596185 Y243.925609 Z2.967741 E1683.63821 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.902114 matz1=2.893664 note=collision lift
G1 X169.59628 Y243.925674 Z2.967784 E1683.638766 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.893664 matz1=2.89365 note=collision lift
G1 X169.71298 Y244.004986 Z2.952036 E1684.279318 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.89365 matz1=2.87692 note=collision lift
G1 X169.713 Y244.005 Z2.952046 E1684.279436 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.87692 matz1=2.876918 note=collision lift
G1 X169.877403 Y244.081325 Z2.929646 E1685.083095 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.876918 matz1=2.855496 note=collision lift
G1 X169.879046 Y244.082088 Z2.930338 E1685.091626 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.855496 matz1=2.855282 note=collision lift
G1 X170.32941 Y244.291172 Z2.863565 E1686.967199 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.855282 matz1=2.797504 note=collision lift
G1 X170.365206 Y244.30779 Z2.839241 E1687.140751 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.797504 matz1=2.792912 note=collision lift
G1 X170.874 Y244.544 Z3.054443 E1689.389989 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.792912 matz1=2.727638 note=collision lift
G1 X171.486 Y244.731 Z3.302179 E1691.703914 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.727638 matz1=2.655408 note=collision lift
G1 X171.497897 Y244.732739 Z3.306902 E1691.738164 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.655408 matz1=2.654119 note=collision lift
G1 X171.97869 Y244.803017 Z3.373784 E1693.038577 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.654119 matz1=2.602029 note=collision lift
G1 X171.980098 Y244.803223 Z3.374343 E1693.04263 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.602029 matz1=2.601877 note=collision lift
G1 X172.779 Y244.92 Z3.478051 E1695.200848 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.601877 matz1=2.515321 note=collision lift
G1 X172.779596 Y244.919996 Z3.477693 E1695.202447 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.515321 matz1=2.515262 note=collision lift
G1 X173.076938 Y244.917812 Z3.518302 E1695.893032 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.515262 matz1=2.485543 note=collision lift
G1 X173.077138 Y244.917811 Z3.518182 E1695.893568 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.485543 matz1=2.485523 note=collision lift
G1 X173.08159 Y244.917778 Z3.519964 E1695.904604 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.485523 matz1=2.485078 note=collision lift
G1 X173.457897 Y244.915015 Z3.568574 E1696.777743 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.485078 matz1=2.447467 note=collision lift
G1 X173.46 Y244.915 Z3.569415 E1696.782955 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.447467 matz1=2.447257 note=collision lift
G1 X173.930062 Y244.839489 Z3.621709 E1697.732677 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.447257 matz1=2.402449 note=collision lift
G1 X173.931608 Y244.839241 Z3.620779 E1697.73629 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.402449 matz1=2.402302 note=collision lift
G1 X174.103088 Y244.811694 Z3.637567 E1698.082285 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.402302 matz1=2.385956 note=collision lift
G1 X174.108788 Y244.810779 Z3.63991 E1698.09464 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.385956 matz1=2.385413 note=collision lift
G1 X174.824524 Y244.695803 Z3.69986 E1699.276725 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.385413 matz1=2.322342 note=collision lift
G1 X174.827253 Y244.695365 Z3.698238 E1699.281933 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.322342 matz1=2.322101 note=collision lift
G1 X174.889685 Y244.685336 Z3.701745 E1699.384852 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.322101 matz1=2.3166 note=collision lift
G1 X174.898 Y244.684 Z3.705223 E1699.399659 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.3166 matz1=2.315867 note=collision lift
G1 X175.655 Y244.452 Z3.730742 E1700.433964 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.315867 matz1=2.253778 note=collision lift
G1 X175.658062 Y244.450618 Z3.72885 E1700.436811 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.253778 matz1=2.253566 note=collision lift
G1 X176.023154 Y244.285811 Z3.726206 E1700.732553 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.253566 matz1=2.228324 note=collision lift
G1 X176.026856 Y244.28414 Z3.727981 E1700.735825 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.228324 matz1=2.228068 note=collision lift
G1 X176.398713 Y244.11628 Z3.702358 E1701.037634 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.228068 matz1=2.202358 note=collision lift
G1 X177.25 Y243.732 Z3.179943 E1701.827738 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.202358 matz1=2.143499 note=collision lift
G1 X178.09 Y243.237 Z2.648635 E1702.397251 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.143499 matz1=2.099691 note=collision lift
G1 X178.305326 Y243.081264 Z2.506142 E1702.536982 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.099691 matz1=2.090069 note=collision lift
G1 X179.274525 Y242.380281 Z1.877457 E1702.950291 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.090069 matz1=1.877457 note=collision lift
G1 X179.857 Y241.959 Z1.509806 E1703.163093 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.877457 matz1=1.509806 note=collision lift
G1 X181.285469 Y240.680339 Z0.575879 E1704.082633 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.509806 matz1=0.575879 note=collision lift
G1 X181.745 Y240.269 Z0.58381 E1704.34859 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.13041 Y239.861212 Z0.603783 E1704.648381 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.618699 Y241.548094 Z0.694915 E1706.418509 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.443 Y243.332 Z0.827898 E1709.450845 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.590737 Y244.832002 Z0.966327 E1713.08231 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.618699 Y245.115906 Z0.994839 E1713.568916 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.139046 Y246.831257 Z1.187304 E1717.818968 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.984042 Y248.412134 Z1.395569 E1723.362248 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.121216 Y249.797784 Z1.60911 E1730.229624 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.506866 Y250.934958 Z1.817138 E1738.382159 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.087743 Y251.779954 Z2.009143 E1747.713923 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X188.803094 Y252.300301 Z2.175422 E1758.059172 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X190.587 Y252.476 Z2.307575 E1769.202874 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X192.370906 Y252.300301 Z2.398923 E1780.893205 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X194.086257 Y251.779954 Z2.444852 E1792.854697 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.667134 Y250.934958 Z2.443042 E1804.801138 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.887547 Y250.75407 Z2.438325 E1806.697079 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.052784 Y249.797784 Z2.393582 E1821.389174 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.189958 Y248.412134 Z2.298973 E1838.00325 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.034954 Y246.831257 Z2.163995 E1853.392845 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.555301 Y245.115906 Z1.995467 E1867.245573 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.625844 Y244.399671 Z1.920235 E1872.533078 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.731 Y243.332 Z1.801905 E1879.762744 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.588975 Y241.89 Z1.633807 E1888.271831 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.555301 Y241.548094 Z1.593089 E1890.217488 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.407349 Y241.060364 Z1.532379 E1892.540245 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.034954 Y239.832743 Z2.021 E1898.752446 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.532379 matz1=2.021 note=collision lift
G1 X198.836948 Y239.462299 Z2.181471 E1900.672632 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.021 matz1=2.181471 note=collision lift
G1 X198.801 Y240.229 Z2.476022 E1903.806028 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.181471 matz1=2.476022 note=collision lift
G1 X198.839537 Y241.860909 Z3.111471 E1908.853517 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.476022 matz1=2.560067 note=collision lift
G1 X198.85 Y242.304 Z3.286889 E1910.113757 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.560067 matz1=2.513877 note=collision lift
G1 X198.863569 Y242.428397 Z3.301525 E1910.316278 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.513877 matz1=2.502234 note=collision lift
G1 X198.863921 Y242.431626 Z3.302847 E1910.321914 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.502234 matz1=2.501931 note=collision lift
G1 X198.953779 Y243.25545 Z3.410337 E1911.665192 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.501931 matz1=2.424822 note=collision lift
G1 X198.953896 Y243.256525 Z3.409696 E1911.667212 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.424822 matz1=2.424721 note=collision lift
G1 X198.962863 Y243.338736 Z3.420095 E1911.801194 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.424721 matz1=2.417026 note=collision lift
G1 X198.96299 Y243.339896 Z3.42057 E1911.803218 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.417026 matz1=2.416918 note=collision lift
G1 X199.032707 Y243.979066 Z3.495626 E1912.843771 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.416918 matz1=2.357091 note=collision lift
G1 X199.032844 Y243.980327 Z3.496143 E1912.845973 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.357091 matz1=2.356973 note=collision lift
G1 X199.084745 Y244.456155 Z3.550389 E1913.620309 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.356973 matz1=2.312436 note=collision lift
G1 X199.084837 Y244.457001 Z3.549894 E1913.621879 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.312436 matz1=2.312366 note=collision lift
G1 X199.087923 Y244.485293 Z3.552975 E1913.667532 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.312366 matz1=2.310026 note=collision lift
G1 X199.088 Y244.486 Z3.553272 E1913.66876 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.310026 matz1=2.309968 note=collision lift
G1 X199.074307 Y244.969724 Z3.603249 E1913.971744 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.309968 matz1=2.2788 note=collision lift
G1 X199.074299 Y244.969996 Z3.603367 E1913.971929 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.2788 matz1=2.278782 note=collision lift
G1 X199.057194 Y245.574236 Z3.663561 E1914.350258 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.278782 matz1=2.239849 note=collision lift
G1 X199.05699 Y245.581452 Z3.666706 E1914.355162 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.239849 matz1=2.239384 note=collision lift
G1 X199.021809 Y246.824231 Z3.659308 E1915.129481 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.239384 matz1=2.159308 note=collision lift
G1 X199.0217 Y246.828057 Z3.659062 E1915.13187 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.159308 matz1=2.159062 note=collision lift
G1 X199.0209 Y246.856335 Z3.65724 E1915.149524 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.159062 matz1=2.15724 note=collision lift
G1 X199.020863 Y246.85762 Z3.657157 E1915.150327 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.15724 matz1=2.157157 note=collision lift
G1 X199.005 Y247.418 Z3.62105 E1915.500191 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.157157 matz1=2.12105 note=collision lift
G1 X199.005046 Y247.418821 Z3.621028 E1915.500413 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.12105 matz1=2.121028 note=collision lift
G1 X199.007441 Y247.461796 Z3.619861 E1915.512016 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.121028 matz1=2.119861 note=collision lift
G1 X199.007716 Y247.466739 Z3.619727 E1915.513351 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.119861 matz1=2.119727 note=collision lift
G1 X199.057547 Y248.36086 Z3.595458 E1915.754766 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.119727 matz1=2.095458 note=collision lift
G1 X199.057709 Y248.363773 Z3.595379 E1915.755553 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.095458 matz1=2.095379 note=collision lift
G1 X199.102124 Y249.16073 Z3.573748 E1915.970733 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.095379 matz1=2.073748 note=collision lift
G1 X199.10305 Y249.17733 Z3.573297 E1915.975215 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.073748 matz1=2.073297 note=collision lift
G1 X199.107881 Y249.264028 Z3.570944 E1915.998624 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.073297 matz1=2.070944 note=collision lift
G1 X199.146 Y249.948 Z3.449774 E1916.186097 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.070944 matz1=2.052379 note=collision lift
G1 X199.448918 Y251.839263 Z2.50339 E1916.886046 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052379 matz1=2.06368 note=collision lift
G1 X199.491 Y252.102 Z2.376241 E1916.95642 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.06368 matz1=2.069573 note=collision lift
G1 X199.689287 Y252.868331 Z2.004108 E1917.236104 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.069573 matz1=2.004108 note=collision lift
G1 X199.735 Y253.045 Z1.919599 E1917.33953 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.004108 matz1=1.919599 note=collision lift
G1 X200.354 Y254.682 Z1.132541 E1919.19526 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.919599 matz1=1.132541 note=collision lift
G1 X200.725 Y255.382 Z0.789447 E1920.265682 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.132541 matz1=0.789447 note=collision lift
G1 X200.781779 Y255.460545 Z0.74875 E1920.459082 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.789447 matz1=0.74875 note=collision lift
G1 X201.578 Y256.562 Z0.857608 E1922.967666 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X202.056 Y257.047 Z0.919776 E1924.444466 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X202.228521 Y257.175568 Z0.940324 E1924.934111 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.893185 Y257.354809 Z0.977627 E1925.872967 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.082004 Y258.020528 Z1.087762 E1929.262441 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X200.812381 Y258.241802 Z1.298768 E1930.571964 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.087762 matz1=1.298768 note=collision lift
G1 X200.363878 Y258.609878 Z1.653431 E1932.982279 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.298768 matz1=1.653431 note=collision lift
G1 X199.108809 Y260.139185 Z2.873051 E1943.975416 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.653431 matz1=2.873051 note=collision lift
G1 X199.036034 Y260.275336 Z2.968651 E1944.915507 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.873051 matz1=2.937773 note=collision lift
G1 X198.872186 Y260.581874 Z3.049098 E1946.76256 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.937773 matz1=2.97922 note=collision lift
G1 X198.869644 Y260.586632 Z3.047045 E1946.792443 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.97922 matz1=2.979864 note=collision lift
G1 X198.769117 Y260.774704 Z3.084947 E1947.913794 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.979864 matz1=3.005293 note=collision lift
G1 X198.765258 Y260.781924 Z3.090017 E1947.963649 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.005293 matz1=3.00627 note=collision lift
G1 X198.406316 Y261.453457 Z3.198072 E1952.532797 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.00627 matz1=3.096749 note=collision lift
G1 X198.403587 Y261.458563 Z3.195865 E1952.569608 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.096749 matz1=3.097437 note=collision lift
G1 X198.176208 Y261.883959 Z3.248491 E1955.452322 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.097437 matz1=3.154753 note=collision lift
G1 X198.176124 Y261.884235 Z3.24838 E1955.45452 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.154753 matz1=3.154786 note=collision lift
G1 X197.952332 Y262.621979 Z3.333222 E1960.963748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.154786 matz1=3.242805 note=collision lift
G1 X197.952182 Y262.622474 Z3.333023 E1960.967681 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.242805 matz1=3.242864 note=collision lift
G1 X197.946708 Y262.640519 Z3.335073 E1961.102416 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.242864 matz1=3.245017 note=collision lift
G1 X197.946559 Y262.641009 Z3.335387 E1961.106686 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.245017 matz1=3.245076 note=collision lift
G1 X197.723389 Y263.376703 Z3.417887 E1966.598987 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.245076 matz1=3.332851 note=collision lift
G1 X197.723231 Y263.377223 Z3.417678 E1966.603122 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.332851 matz1=3.332913 note=collision lift
G1 X197.60206 Y263.776669 Z3.459268 E1969.582833 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.332913 matz1=3.38057 note=collision lift
G1 X197.601915 Y263.777148 Z3.459575 E1969.587011 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.38057 matz1=3.380627 note=collision lift
G1 X197.528639 Y264.521129 Z3.537717 E1975.709162 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.380627 matz1=3.457136 note=collision lift
G1 X197.528637 Y264.521149 Z3.537709 E1975.70934 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.457136 matz1=3.457138 note=collision lift
G1 X197.45438 Y265.275101 Z3.614951 E1981.911922 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.457138 matz1=3.534671 note=collision lift
G1 X197.454361 Y265.275291 Z3.615066 E1981.913736 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.534671 matz1=3.534691 note=collision lift
G1 X197.408025 Y265.745747 Z3.657373 E1985.779496 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.534691 matz1=3.583071 note=collision lift
G1 X197.408 Y265.746 Z3.657526 E1985.781909 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.583071 matz1=3.583097 note=collision lift
G1 X197.446824 Y266.140186 Z3.688203 E1989.304961 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.583097 matz1=3.617201 note=collision lift
G1 X197.447258 Y266.144593 Z3.690798 E1989.350478 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.617201 matz1=3.617582 note=collision lift
G1 X197.550524 Y267.193074 Z3.747576 E1998.706886 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.617582 matz1=3.708293 note=collision lift
G1 X197.551148 Y267.199403 Z3.744944 E1998.767926 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.708293 matz1=3.708841 note=collision lift
G1 X197.567947 Y267.36997 Z3.751729 E2000.289011 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.708841 matz1=3.723597 note=collision lift
G1 X197.567982 Y267.370324 Z3.751937 E2000.292668 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.723597 matz1=3.723628 note=collision lift
G1 X197.594581 Y267.640393 Z3.760766 E2001.922172 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.723628 matz1=3.744075 note=collision lift
G1 X197.59465 Y267.641086 Z3.76047 E2001.926713 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.744075 matz1=3.744128 note=collision lift
G1 X197.601747 Y267.713149 Z3.762329 E2002.361433 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.744128 matz1=3.749584 note=collision lift
G1 X197.601915 Y267.714852 Z3.763313 E2002.373276 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.749584 matz1=3.749712 note=collision lift
G1 X198.176208 Y269.608041 Z2.894641 E2016.233641 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.749712 matz1=2.894641 note=collision lift
G1 X198.67062 Y270.533021 Z2.405751 E2023.922603 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.894641 matz1=2.405751 note=collision lift
G1 X199.108809 Y271.352815 Z2.437235 E2030.102678 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X200.363878 Y272.882122 Z2.446611 E2043.312023 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.893185 Y274.137191 Z2.397781 E2056.193792 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X203.637959 Y275.069792 Z2.293746 E2068.382507 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X205.531148 Y275.644085 Z2.140905 E2079.550442 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.5 Y275.838 Z1.948655 E2089.426943 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X209.468852 Y275.644085 Z1.728817 E2097.8167 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X211.362041 Y275.069792 Z1.49491 E2104.614922 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.106815 Y274.137191 Z1.261315 E2109.816897 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.636122 Y272.882122 Z1.042397 E2113.519929 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.891191 Y271.352815 Z0.851617 E2115.916979 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.823792 Y269.608041 Z0.700706 E2117.282872 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.398085 Y267.714852 Z0.598942 E2117.955155 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.432018 Y267.370324 Z0.586705 E2118.058175 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.592 Y265.746 Z0.552584 E2118.499846 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.398085 Y263.777148 Z0.564482 E2119.156198 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.092054 Y262.7683 Z0.597502 E2119.752323 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.977606 Y262.391016 Z0.806982 E2120.00465 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.597502 matz1=0.806982 note=collision lift
G1 X216.952 Y262.651 Z0.948975 E2120.190095 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.806982 matz1=0.948975 note=collision lift
G1 X217.145915 Y264.619852 Z2.053985 E2122.953725 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.948975 matz1=2.053985 note=collision lift
G1 X217.484311 Y265.735394 Z2.079062 E2125.352009 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053985 matz1=2.079062 note=collision lift
G1 X217.48459 Y265.736314 Z2.078661 E2125.354153 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.079062 matz1=2.078661 note=collision lift
G1 X217.566394 Y266.005984 Z2.084201 E2125.93389 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.078661 matz1=2.084201 note=collision lift
G1 X217.566407 Y266.006026 Z2.084182 E2125.933988 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.084201 matz1=2.084182 note=collision lift
G1 X217.604714 Y266.132311 Z2.08671 E2126.205471 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.084182 matz1=2.08671 note=collision lift
G1 X217.604718 Y266.132323 Z2.086705 E2126.2055 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.08671 matz1=2.086705 note=collision lift
G1 X217.720208 Y266.513041 Z2.086705 E2127.023809 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086705 matz1=2.086705 note=collision lift
G1 X218.118936 Y267.25901 Z1.745292 E2129.282468 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086705 matz1=1.745292 note=collision lift
G1 X218.652809 Y268.257815 Z1.297157 E2131.786598 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.745292 matz1=1.297157 note=collision lift
G1 X218.903694 Y268.56352 Z1.144252 E2132.984507 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.297157 matz1=1.144252 note=collision lift
G1 X219.907878 Y269.787122 Z1.323694 E2137.485217 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X221.437185 Y271.042191 Z1.558808 E2144.72057 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X223.181959 Y271.974792 Z1.790306 E2153.535988 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X225.075148 Y272.549085 Z2.003953 E2163.800759 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.044 Y272.743 Z2.186613 E2175.294351 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.012852 Y272.549085 Z2.327053 E2187.723455 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.906041 Y271.974792 Z2.416638 E2200.742589 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.650815 Y271.042191 Z2.44986 E2213.975696 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.180122 Y269.787122 Z2.424675 E2227.037099 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.435191 Y268.257815 Z2.342633 E2239.551472 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.367792 Y266.513041 Z2.208777 E2251.173301 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.942085 Y264.619852 Z2.03134 E2261.606285 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.136 Y262.651 Z1.82123 E2270.622231 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.994258 Y261.211867 Z1.654367 E2276.385929 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.942085 Y260.682148 Z1.591369 E2279.395557 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.367792 Y258.788959 Z1.355889 E2288.168812 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.435191 Y257.044185 Z1.12927 E2294.615795 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.180122 Y255.514878 Z0.925448 E2298.969184 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.650815 Y254.259809 Z0.756954 E2301.594088 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X231.169244 Y253.467892 Z0.649415 E2302.88815 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.906041 Y253.327208 Z0.63415 E2303.025651 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.012852 Y252.752915 Z0.564586 E2303.464187 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.044 Y252.559 Z0.552541 E2303.82072 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X225.075148 Y252.752915 Z0.598754 E2304.491019 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X223.181959 Y253.327208 Z0.700384 E2305.852564 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X221.437185 Y254.259809 Z0.851182 E2308.242505 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.907878 Y255.514878 Z1.041875 E2311.936572 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.652809 Y257.044185 Z1.260739 E2317.13024 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.362815 Y257.586726 Z1.332456 E2318.89865 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.720208 Y258.788959 Z1.494314 E2325.921307 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.201516 Y260.498857 Z1.705591 E2337.291355 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.145915 Y260.682148 Z1.824009 E2338.71437 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.705591 matz1=1.824009 note=collision lift
G1 X217.139193 Y260.750402 Z1.865975 E2339.301953 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.824009 matz1=1.865975 note=collision lift
G1 X217.100128 Y261.147035 Z2.309127 E2343.657483 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.865975 matz1=2.309127 note=collision lift
G1 X217.074521 Y261.407019 Z2.451121 E2345.830375 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.309127 matz1=2.451121 note=collision lift
G1 X217.074101 Y261.41129 Z2.448975 E2345.865435 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.451121 matz1=2.448975 note=collision lift
G1 X217.025854 Y261.901153 Z2.448975 E2349.462588 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.448975 matz1=2.448975 note=collision lift
G1 X216.977606 Y262.391016 Z2.448975 E2353.059742 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.448975 matz1=2.448975 note=collision lift
G1 X216.900699 Y262.137487 Z2.448975 E2355.071845 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.448975 matz1=2.448975 note=collision lift
G1 X216.823792 Y261.883959 Z2.448975 E2357.083949 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.448975 matz1=2.448975 note=collision lift
G1 X216.687014 Y261.628065 Z2.187311 E2360.297941 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.448975 matz1=2.187311 note=collision lift
G1 X216.51479 Y261.305857 Z2.040511 E2363.536809 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.187311 matz1=2.040511 note=collision lift
G1 X216.234742 Y260.781924 Z2.098844 E2368.447182 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.891191 Y260.139185 Z2.163781 E2374.710398 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.636122 Y258.609878 Z2.310601 E2393.190479 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.187619 Y258.241802 Z2.344536 E2398.706008 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.106815 Y257.354809 Z2.407577 E2412.442131 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X211.362041 Y256.422208 Z2.448747 E2432.281963 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X209.468852 Y255.847915 Z2.431579 E2451.943496 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.993368 Y255.702592 Z2.380972 E2466.299878 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.5 Y255.654 Z2.357129 E2469.461419 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.006632 Y255.702592 Z2.329961 E2472.577782 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X205.531148 Y255.847915 Z2.229974 E2485.803978 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X204.105277 Y256.280448 Z2.100401 E2497.792335 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X203.637959 Y256.422208 Z2.302107 E2502.027409 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.100401 matz1=2.302107 note=collision lift
G1 X203.330923 Y256.586322 Z2.440324 E2504.712616 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.302107 matz1=2.440324 note=collision lift
G1 X202.996139 Y256.765268 Z2.477566 E2507.446948 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.440324 matz1=2.477566 note=collision lift
G1 X202.995587 Y256.765563 Z2.47794 E2507.452174 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.477566 matz1=2.47794 note=collision lift
G1 X202.995035 Y256.765858 Z2.477627 E2507.457188 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.47794 matz1=2.477627 note=collision lift
G1 X202.228521 Y257.175568 Z2.477627 E2513.687735 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.477627 matz1=2.477627 note=collision lift
G1 X203.0622 Y257.79685 Z2.477627 E2520.488616 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.477627 matz1=2.477627 note=collision lift
G1 X203.062368 Y257.796975 Z2.477709 E2520.490086 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.477627 matz1=2.477709 note=collision lift
G1 X203.104 Y257.828 Z2.469948 E2520.833476 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.477709 matz1=2.469948 note=collision lift
G1 X203.669 Y258.128 Z2.076111 E2525.461332 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.469948 matz1=2.076111 note=collision lift
G1 X204.380299 Y258.388376 Z1.607803 E2530.253856 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.076111 matz1=1.607803 note=collision lift
G1 X204.871 Y258.568 Z1.546005 E2533.08559 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X205.513712 Y258.690231 Z1.468035 E2536.103722 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X206.154 Y258.812 Z1.71624 E2539.298505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.468035 matz1=1.71624 note=collision lift
G1 X206.93759 Y258.856244 Z2.016274 E2542.748092 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.71624 matz1=2.016274 note=collision lift
G1 X207.5 Y258.888 Z2.232778 E2544.26497 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.016274 matz1=2.232778 note=collision lift
G1 X208.06241 Y258.856244 Z2.450621 E2545.650871 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.232778 matz1=2.450621 note=collision lift
G1 X208.846 Y258.812 Z2.756967 E2548.177708 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.450621 matz1=2.582941 note=collision lift
G1 X210.129 Y258.568 Z3.276114 E2551.424926 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.582941 matz1=2.44909 note=collision lift
G1 X211.331 Y258.128 Z3.799272 E2553.78865 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.44909 matz1=2.332248 note=collision lift
G1 X211.617277 Y257.975994 Z3.805847 E2554.255919 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.332248 matz1=2.305847 note=collision lift
G1 X211.890629 Y257.830852 Z3.780638 E2554.703476 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.305847 matz1=2.280638 note=collision lift
G1 X211.896 Y257.828 Z3.780143 E2554.71227 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.280638 matz1=2.280143 note=collision lift
G1 X212.771479 Y257.175568 Z3.70356 E2555.773591 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.280143 matz1=2.20356 note=collision lift
G1 X212.774668 Y257.173191 Z3.703281 E2555.777457 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.20356 matz1=2.203281 note=collision lift
G1 X212.942205 Y257.048338 Z3.688626 E2555.980558 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.203281 matz1=2.188626 note=collision lift
G1 X212.944 Y257.047 Z3.688469 E2555.982734 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.188626 matz1=2.188469 note=collision lift
G1 X213.421877 Y256.562125 Z3.649238 E2556.506285 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.188469 matz1=2.149238 note=collision lift
G1 X213.422 Y256.562 Z3.649228 E2556.50642 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.149238 matz1=2.149228 note=collision lift
G1 X213.659807 Y256.233029 Z3.631744 E2556.687272 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.149228 matz1=2.131744 note=collision lift
G1 X214.275 Y255.382 Z3.345848 E2557.171706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.131744 matz1=2.086516 note=collision lift
G1 X214.646 Y254.682 Z2.928325 E2557.471706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086516 matz1=2.065112 note=collision lift
G1 X215.265 Y253.045 Z2.038962 E2557.984905 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.065112 matz1=2.038962 note=collision lift
G1 X215.310713 Y252.868331 Z1.948868 E2558.039312 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.038962 matz1=1.948868 note=collision lift
G1 X215.509 Y252.102 Z1.563827 E2558.228629 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.948868 matz1=1.563827 note=collision lift
G1 X215.551082 Y251.839263 Z1.436485 E2558.297841 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.563827 matz1=1.436485 note=collision lift
G1 X215.825658 Y250.124952 Z0.632957 E2559.672075 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.436485 matz1=0.632957 note=collision lift
G1 X215.854 Y249.948 Z0.63962 E2559.800895 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.995 Y247.418 Z0.808974 E2563.837931 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.979137 Y246.85762 Z0.856575 E2564.870091 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.810042 Y248.412134 Z1.025846 E2569.660755 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.947216 Y249.797784 Z1.221694 E2576.356169 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.112453 Y250.75407 Z1.397704 E2583.365593 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.332866 Y250.934958 Z1.431605 E2584.283119 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X220.913743 Y251.779954 Z1.644971 E2591.372455 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X222.629094 Y252.300301 Z1.851012 E2599.733598 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X224.413 Y252.476 Z2.039318 E2609.24989 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X226.196906 Y252.300301 Z2.200374 E2619.746441 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.912257 Y251.779954 Z2.326043 E2631.001086 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.493134 Y250.934958 Z2.409974 E2642.757078 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.878784 Y249.797784 Z2.447928 E2654.736241 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.015958 Y248.412134 Z2.437987 E2666.651778 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.860954 Y246.831257 Z2.380652 E2678.220533 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.381301 Y245.115906 Z2.278821 E2689.174919 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.409263 Y244.832002 Z2.258822 E2690.90013 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.557 Y243.332 Z2.137639 E2703.640573 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.381301 Y241.548094 Z1.964239 E2717.207512 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.860954 Y239.832743 Z1.767383 E2728.966189 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.015958 Y238.251866 Z1.557017 E2738.781398 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X231.559297 Y237.695423 Z1.471121 E2742.403478 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.878784 Y236.866216 Z1.34377 E2747.092907 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.758605 Y235.946908 Z1.176654 E2752.17119 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.493134 Y235.729042 Z1.138417 E2753.306176 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X228.810753 Y235.364301 Z1.057663 E2755.112628 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.912257 Y234.884046 Z1.46073 E2757.656762 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.057663 matz1=1.46073 note=collision lift
G1 X227.510166 Y234.762073 Z1.630655 E2758.615563 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.46073 matz1=1.630655 note=collision lift
G1 X228.027 Y235.33 Z1.945514 E2760.076229 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.630655 matz1=1.945514 note=collision lift
G1 X229.208586 Y236.455769 Z2.63575 E2762.048215 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.945514 matz1=2.216304 note=collision lift
G1 X229.53 Y236.762 Z2.829001 E2762.5155 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.216304 matz1=2.187584 note=collision lift
G1 X229.62669 Y236.839748 Z2.843421 E2762.570234 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.187584 matz1=2.181712 note=collision lift
G1 X229.629026 Y236.841626 Z2.844779 E2762.571676 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.181712 matz1=2.18157 note=collision lift
G1 X230.275418 Y237.361386 Z2.960522 E2762.938658 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.18157 matz1=2.142319 note=collision lift
G1 X230.276369 Y237.36215 Z2.959854 E2762.939267 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.142319 matz1=2.142261 note=collision lift
G1 X230.340387 Y237.413627 Z2.970969 E2762.975592 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.142261 matz1=2.138373 note=collision lift
G1 X230.341304 Y237.414365 Z2.971501 E2762.976158 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.138373 matz1=2.138318 note=collision lift
G1 X230.842381 Y237.817277 Z3.057161 E2763.260399 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.138318 matz1=2.10789 note=collision lift
G1 X230.84358 Y237.818241 Z3.057858 E2763.261139 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.10789 matz1=2.107817 note=collision lift
G1 X231.216511 Y238.118113 Z3.12555 E2763.472923 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.107817 matz1=2.085171 note=collision lift
G1 X231.217366 Y238.1188 Z3.124967 E2763.473461 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.085171 matz1=2.085136 note=collision lift
G1 X231.239357 Y238.136483 Z3.128781 E2763.485797 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.085136 matz1=2.084234 note=collision lift
G1 X231.24 Y238.137 Z3.129167 E2763.486192 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.084234 matz1=2.084208 note=collision lift
G1 X231.572343 Y238.488641 Z3.191545 E2763.623475 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.084208 matz1=2.07934 note=collision lift
G1 X231.572558 Y238.488868 Z3.191698 E2763.623573 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.07934 matz1=2.079337 note=collision lift
G1 X231.985987 Y238.926302 Z3.266516 E2763.794252 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.079337 matz1=2.073282 note=collision lift
G1 X231.992748 Y238.933456 Z3.271338 E2763.797337 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.073282 matz1=2.073183 note=collision lift
G1 X232.846755 Y239.83705 Z3.40818 E2764.149323 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.073183 matz1=2.060675 note=collision lift
G1 X232.850739 Y239.841265 Z3.405222 E2764.151155 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060675 matz1=2.060617 note=collision lift
G1 X232.868377 Y239.859928 Z3.407753 E2764.158416 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060617 matz1=2.060358 note=collision lift
G1 X232.86959 Y239.861212 Z3.408619 E2764.15897 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060358 matz1=2.060341 note=collision lift
G1 X233.255 Y240.269 Z3.460991 E2764.317553 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060341 matz1=2.054696 note=collision lift
G1 X233.255947 Y240.269848 Z3.460394 E2764.318505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054696 matz1=2.054734 note=collision lift
G1 X233.284857 Y240.295726 Z3.463558 E2764.344893 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054734 matz1=2.055914 note=collision lift
G1 X233.29114 Y240.30135 Z3.468031 E2764.351363 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055914 matz1=2.056171 note=collision lift
G1 X233.96076 Y240.900745 Z3.515663 E2764.961395 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056171 matz1=2.083499 note=collision lift
G1 X233.965435 Y240.90493 Z3.512717 E2764.966094 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.083499 matz1=2.08369 note=collision lift
G1 X234.255344 Y241.164435 Z3.520343 E2765.229884 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.08369 matz1=2.095522 note=collision lift
G1 X234.257794 Y241.166628 Z3.522087 E2765.232408 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.095522 matz1=2.095622 note=collision lift
G1 X234.554828 Y241.432512 Z3.510847 E2765.502738 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.095622 matz1=2.107745 note=collision lift
G1 X234.568768 Y241.44499 Z3.502061 E2765.516748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.107745 matz1=2.108314 note=collision lift
G1 X234.593836 Y241.467428 Z3.497152 E2765.539794 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.108314 matz1=2.109337 note=collision lift
G1 X234.594836 Y241.468323 Z3.496522 E2765.540799 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.109337 matz1=2.109378 note=collision lift
G1 X234.61255 Y241.48418 Z3.490792 E2765.557376 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.109378 matz1=2.110101 note=collision lift
G1 X234.613339 Y241.484886 Z3.491354 E2765.558189 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.110101 matz1=2.110133 note=collision lift
G1 X235.143 Y241.959 Z3.15754 E2766.090523 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.110133 matz1=2.131749 note=collision lift
G1 X235.725475 Y242.380281 Z2.836432 E2766.779421 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.131749 matz1=2.17007 note=collision lift
G1 X236.694674 Y243.081264 Z2.316951 E2768.447715 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.17007 matz1=2.248653 note=collision lift
G1 X236.91 Y243.237 Z2.203909 E2768.846622 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.248653 matz1=2.203909 note=collision lift
G1 X237.75 Y243.732 Z1.795971 E2770.739172 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.203909 matz1=1.795971 note=collision lift
G1 X239.345 Y244.452 Z1.087413 E2775.736547 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.795971 matz1=1.087413 note=collision lift
G1 X239.484472 Y244.494744 Z1.029862 E2776.219009 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.087413 matz1=1.029862 note=collision lift
G1 X240.102 Y244.684 Z1.097986 E2778.217138 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.158424 Y244.693064 Z1.104177 E2778.395817 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.068185 Y245.275809 Z1.242564 E2783.148175 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.538878 Y246.530878 Z1.475487 E2793.145856 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.369577 Y247.955676 Z1.694147 E2804.54939 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.283809 Y248.060185 Z1.709917 E2805.114257 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.351208 Y249.804959 Z1.93144 E2814.888337 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.805329 Y251.60448 Z2.117601 E2825.372872 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.776915 Y251.698148 Z2.126433 E2826.195277 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.583 Y253.667 Z2.282908 E2844.399473 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.736622 Y255.226746 Z2.368731 E2859.672556 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.776915 Y255.635852 Z2.596784 E2864.24682 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.368731 matz1=2.596784 note=collision lift
G1 X234.866465 Y255.931059 Z2.629428 E2867.350725 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.596784 matz1=2.629428 note=collision lift
G1 X234.866562 Y255.931378 Z2.62927 E2867.354412 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.629428 matz1=2.62927 note=collision lift
G1 X235.351208 Y257.529041 Z2.62927 E2884.059502 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.62927 matz1=2.62927 note=collision lift
G1 X235.52515 Y257.854464 Z2.443923 E2888.181454 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.62927 matz1=2.443923 note=collision lift
G1 X235.70435 Y258.189725 Z2.443047 E2891.976195 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.283809 Y259.273815 Z3.054831 E2905.682461 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.443047 matz1=3.054831 note=collision lift
G1 X236.484845 Y259.518778 Z3.091547 E2908.764571 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.054831 matz1=3.091547 note=collision lift
G1 X236.485058 Y259.519037 Z3.091369 E2908.768244 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.091547 matz1=3.091369 note=collision lift
G1 X237.538878 Y260.803122 Z3.091369 E2924.817152 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.091369 matz1=3.091369 note=collision lift
G1 X237.639696 Y260.88586 Z3.020088 E2926.24847 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.091369 matz1=3.020088 note=collision lift
G1 X238.642012 Y261.70844 Z2.294387 E2935.226035 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.020088 matz1=2.294387 note=collision lift
G1 X239.068185 Y262.058191 Z2.261486 E2938.562908 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.812959 Y262.990792 Z2.09831 E2949.445453 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X242.706148 Y263.565085 Z1.898345 E2958.982603 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.675 Y263.759 Z1.673885 E2966.99939 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.643852 Y263.565085 Z1.438734 E2973.414235 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.537041 Y262.990792 Z1.20735 E2978.246844 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.281815 Y262.058191 Z0.993961 E2981.618174 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.811122 Y260.803122 Z0.811687 E2983.742162 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.066191 Y259.273815 Z0.671738 E2984.910444 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.998792 Y257.529041 Z0.582718 E2985.472315 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.573085 Y255.635852 Z0.550101 E2985.812335 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.767 Y253.667 Z0.575893 E2986.32737 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.573085 Y251.698148 Z0.658508 E2987.403899 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.998792 Y249.804959 Z0.792865 E2989.395784 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.577827 Y249.017389 Z0.868356 E2990.528082 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.066191 Y248.060185 Z0.970704 E2993.168204 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.811122 Y246.530878 Z1.181089 E3000.13983 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.471083 Y245.431137 Z1.382029 E3008.059225 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.281815 Y245.275809 Z1.411083 E3009.21498 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.537041 Y244.343208 Z1.646545 E3020.967582 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.643852 Y243.768915 Z1.872996 E3035.034028 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X245.534947 Y243.659697 Z1.991286 E3043.631374 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X245.039921 Y243.610942 Z2.041119 E3047.595141 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.675 Y243.575 Z2.076512 E3050.583171 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.556306 Y243.58669 Z2.087763 E3051.561788 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X242.706148 Y243.768915 Z2.244578 E3068.30791 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.812959 Y244.343208 Z2.366861 E3087.346222 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.158424 Y244.693064 Z2.399288 E3094.605397 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X241.54 Y244.915 Z2.438993 E3108.570283 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X242.221 Y244.92 Z2.447881 E3115.395832 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X243.441063 Y244.741661 Z2.445631 E3127.73777 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X243.514 Y244.731 Z2.482352 E3128.56207 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.445631 matz1=2.482352 note=collision lift
G1 X244.126 Y244.544 Z2.79184 E3135.638875 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.482352 matz1=2.79184 note=collision lift
G1 X244.99578 Y244.1402 Z3.244329 E3146.047909 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.79184 matz1=3.244329 note=collision lift
G1 X245.120954 Y244.082088 Z3.308354 E3147.537466 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.244329 matz1=3.308354 note=collision lift
G1 X245.287 Y244.005 Z3.392864 E3149.504382 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.308354 matz1=3.392864 note=collision lift
G1 X245.464415 Y243.884424 Z3.491286 E3151.795944 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.392864 matz1=3.491286 note=collision lift
G1 X246.367 Y243.271 Z3.491286 E3162.084502 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.491286 matz1=3.491286 note=collision lift
G1 X247.372 Y242.372 Z2.72796 E3175.982178 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.491286 matz1=2.72796 note=collision lift
G1 X248.01823 Y241.649574 Z2.163951 E3185.403574 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.72796 matz1=2.163951 note=collision lift
G1 X248.271 Y241.367 Z2.132908 E3188.59939 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.682075 Y240.762149 Z2.06522 E3194.513832 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.69103 Y240.853076 Z2.05611 E3195.211525 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.768915 Y241.643852 Z2.374187 E3201.715053 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05611 matz1=2.374187 note=collision lift
G1 X249.343208 Y243.537041 Z3.146545 E3215.483408 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.374187 matz1=3.146545 note=collision lift
G1 X249.7813 Y244.356654 Z3.146545 E3220.395062 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.146545 matz1=3.146545 note=collision lift
G1 X249.786815 Y244.366972 Z3.151018 E3220.461262 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.146545 matz1=3.14931 note=collision lift
G1 X250.268912 Y245.268912 Z3.065594 E3225.885092 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.14931 matz1=3.028956 note=collision lift
G1 X250.272546 Y245.27571 Z3.060833 E3225.932978 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.028956 matz1=3.028049 note=collision lift
G1 X250.275809 Y245.281815 Z3.060146 E3225.969739 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.028049 matz1=3.027234 note=collision lift
G1 X250.27581 Y245.281816 Z3.060146 E3225.969748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.027234 matz1=3.027234 note=collision lift
G1 X250.277395 Y245.283748 Z3.05987 E3225.982696 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.027234 matz1=3.026936 note=collision lift
G1 X250.277502 Y245.283878 Z3.059934 E3225.983623 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.026936 matz1=3.026916 note=collision lift
G1 X250.413122 Y245.449132 Z3.036031 E3227.091405 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.026916 matz1=3.001398 note=collision lift
G1 X250.415517 Y245.45205 Z3.037469 E3227.112211 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.001398 matz1=3.000948 note=collision lift
G1 X251.068254 Y246.247412 Z2.913183 E3231.33923 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.000948 matz1=2.879099 note=collision lift
G1 X251.0709 Y246.250637 Z2.910604 E3231.359236 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.879099 matz1=2.878605 note=collision lift
G1 X251.219699 Y246.431949 Z2.882078 E3232.322929 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.878605 matz1=2.850828 note=collision lift
G1 X251.219813 Y246.432088 Z2.882147 E3232.323713 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.850828 matz1=2.850807 note=collision lift
G1 X251.530878 Y246.811122 Z2.823203 E3234.337982 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.850807 matz1=2.792739 note=collision lift
G1 X251.531067 Y246.811276 Z2.823053 E3234.338822 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.792739 matz1=2.792711 note=collision lift
G1 X252.477453 Y247.587955 Z2.681142 E3237.959476 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.792711 matz1=2.655484 note=collision lift
G1 X252.477808 Y247.588247 Z2.681321 E3237.960925 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.655484 matz1=2.655433 note=collision lift
G1 X253.059529 Y248.065653 Z2.603858 E3240.183332 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.655433 matz1=2.571083 note=collision lift
G1 X253.059535 Y248.065658 Z2.603853 E3240.183361 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.571083 matz1=2.571082 note=collision lift
G1 X253.060185 Y248.066191 Z2.604179 E3240.186009 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.571082 matz1=2.570988 note=collision lift
G1 X253.06236 Y248.067354 Z2.605159 E3240.192285 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.570988 matz1=2.570735 note=collision lift
G1 X254.017389 Y248.577827 Z2.491636 E3242.767634 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.570735 matz1=2.459723 note=collision lift
G1 X254.020901 Y248.579705 Z2.48927 E3242.773602 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.459723 matz1=2.459348 note=collision lift
G1 X254.164738 Y248.656587 Z2.470757 E3242.985074 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.459348 matz1=2.443987 note=collision lift
G1 X254.164813 Y248.656627 Z2.470707 E3242.985201 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.443987 matz1=2.443979 note=collision lift
G1 X254.203149 Y248.677118 Z2.465754 E3243.041567 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.443979 matz1=2.439885 note=collision lift
G1 X254.208789 Y248.680133 Z2.468349 E3243.050458 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.439885 matz1=2.439283 note=collision lift
G1 X254.804959 Y248.998792 Z2.37833 E3243.929054 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.439283 matz1=2.375616 note=collision lift
G1 X256.698148 Y249.573085 Z1.232162 E3245.643671 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.375616 matz1=1.232162 note=collision lift
G1 X257.720252 Y249.673754 Z0.662086 E3246.085672 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.232162 matz1=0.662086 note=collision lift
G1 X258.667 Y249.767 Z0.609704 E3246.444181 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.635852 Y249.573085 Z0.555515 E3246.821034 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.529041 Y248.998792 Z0.559402 E3247.224119 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X264.273815 Y248.066191 Z0.621125 E3248.046442 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.803122 Y246.811122 Z0.73689 E3249.656665 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.058191 Y245.281815 Z0.899578 E3252.377249 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.990792 Y243.537041 Z1.099185 E3256.463808 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X268.565085 Y241.643852 Z1.323439 E3262.087233 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X268.759 Y239.675 Z1.558549 E3269.320816 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X268.565085 Y237.706148 Z1.790059 E3278.134555 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.990792 Y235.812959 Z2.003733 E3288.39784 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.058191 Y234.068185 Z2.186433 E3299.890233 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.88586 Y232.639696 Z2.31915 E3311.450433 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.803122 Y232.538878 Z2.326925 E3312.678494 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X264.273815 Y231.283809 Z2.41657 E3332.206528 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.529041 Y230.351208 Z2.449855 E3352.056153 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.635852 Y229.776915 Z2.424734 E3371.648854 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X258.667 Y229.583 Z2.342752 E3390.421609 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X256.698148 Y229.776915 Z2.20895 E3407.856082 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X256.60448 Y229.805329 Z2.201118 E3408.715509 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.804959 Y230.351208 Z2.031555 E3418.634121 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.060185 Y231.283809 Z1.821474 E3427.651717 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X252.955676 Y231.369577 Z1.806241 E3428.261281 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.530878 Y232.538878 Z1.591627 E3438.683147 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.275809 Y234.068185 Z1.356145 E3447.459029 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.188251 Y234.231994 Z1.334864 E3448.065311 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.346654 Y235.806512 Z2.022976 E3454.270125 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.334864 matz1=2.022976 note=collision lift
G1 X249.343208 Y235.812959 Z2.025828 E3454.295537 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.022976 matz1=2.025828 note=collision lift
G1 X248.768915 Y237.706148 Z2.811162 E3458.956979 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.025828 matz1=2.425654 note=collision lift
G1 X248.59071 Y239.515492 Z3.565327 E3461.560741 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.425654 matz1=2.27077 note=collision lift
G1 X248.575222 Y239.672744 Z3.583287 E3461.771113 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.27077 matz1=2.257309 note=collision lift
G1 X248.575 Y239.675 Z3.584227 E3461.774359 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257309 matz1=2.257116 note=collision lift
G1 X248.610942 Y240.039921 Z3.621733 E3462.211728 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257116 matz1=2.230629 note=collision lift
G1 X248.611034 Y240.040862 Z3.621197 E3462.212832 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.230629 matz1=2.230565 note=collision lift
G1 X248.623338 Y240.165786 Z3.6328 E3462.340811 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.230565 matz1=2.22216 note=collision lift
G1 X248.623531 Y240.167741 Z3.633651 E3462.342984 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.22216 matz1=2.222028 note=collision lift
G1 X248.659697 Y240.534947 Z3.661622 E3462.718647 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.222028 matz1=2.197319 note=collision lift
G1 X248.659767 Y240.535655 Z3.661222 E3462.719416 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.197319 matz1=2.197275 note=collision lift
G1 X248.682075 Y240.762149 Z3.675835 E3462.934225 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.197275 matz1=2.183074 note=collision lift
G1 X248.682332 Y240.76177 Z3.675579 E3462.934662 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.183074 matz1=2.183047 note=collision lift
G1 X248.884424 Y240.464415 Z3.646021 E3463.235297 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.183047 matz1=2.161981 note=collision lift
G1 X248.884442 Y240.464388 Z3.646004 E3463.235325 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.161981 matz1=2.161979 note=collision lift
G1 X248.973626 Y240.333164 Z3.632911 E3463.358372 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.161979 matz1=2.153284 note=collision lift
G1 X248.97363 Y240.333157 Z3.632907 E3463.358379 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.153284 matz1=2.153284 note=collision lift
G1 X249.004992 Y240.287012 Z3.627743 E3463.401685 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.153284 matz1=2.150226 note=collision lift
G1 X249.005 Y240.287 Z3.62775 E3463.401698 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.150226 matz1=2.150225 note=collision lift
G1 X249.082047 Y240.121041 Z3.611005 E3463.534684 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.150225 matz1=2.140685 note=collision lift
G1 X249.082088 Y240.120954 Z3.611048 E3463.53476 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.140685 matz1=2.14068 note=collision lift
G1 X249.291172 Y239.67059 Z3.56528 E3463.773791 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.14068 matz1=2.119176 note=collision lift
G1 X249.544 Y239.126 Z3.239068 E3464.101347 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.119176 matz1=2.093173 note=collision lift
G1 X249.731 Y238.514 Z2.899289 E3464.374811 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.093173 matz1=2.073359 note=collision lift
G1 X249.837123 Y237.787985 Z2.520205 E3464.594053 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.073359 matz1=2.06114 note=collision lift
G1 X249.92 Y237.221 Z2.591024 E3464.747325 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.06114 matz1=2.051598 note=collision lift
G1 X249.919995 Y237.220333 Z2.590689 E3464.747519 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051598 matz1=2.051597 note=collision lift
G1 X249.917812 Y236.923062 Z2.629753 E3464.825207 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051597 matz1=2.051057 note=collision lift
G1 X249.917811 Y236.922795 Z2.629619 E3464.825284 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051057 matz1=2.051056 note=collision lift
G1 X249.917778 Y236.91841 Z2.631804 E3464.826554 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051056 matz1=2.051048 note=collision lift
G1 X249.915016 Y236.542139 Z2.69303 E3464.925332 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051048 matz1=2.050365 note=collision lift
G1 X249.915 Y236.54 Z2.694095 E3464.925951 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050365 matz1=2.050361 note=collision lift
G1 X249.839489 Y236.069938 Z2.759968 E3465.063826 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050361 matz1=2.054271 note=collision lift
G1 X249.839137 Y236.067745 Z2.758875 E3465.064536 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054271 matz1=2.054289 note=collision lift
G1 X249.811702 Y235.896957 Z2.779937 E3465.114524 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054289 matz1=2.055709 note=collision lift
G1 X249.810779 Y235.891212 Z2.782894 E3465.116396 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055709 matz1=2.055757 note=collision lift
G1 X249.695803 Y235.175476 Z2.858411 E3465.382588 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055757 matz1=2.06957 note=collision lift
G1 X249.69519 Y235.171662 Z2.856552 E3465.384154 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.06957 matz1=2.069644 note=collision lift
G1 X249.685936 Y235.11405 Z2.862112 E3465.405561 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.069644 matz1=2.070756 note=collision lift
G1 X249.684 Y235.102 Z2.868446 E3465.410583 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.070756 matz1=2.070988 note=collision lift
G1 X249.452 Y234.345 Z2.91228 E3465.799419 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.070988 matz1=2.095309 note=collision lift
G1 X249.448998 Y234.338349 Z2.908985 E3465.806847 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.095309 matz1=2.095663 note=collision lift
G1 X249.28414 Y233.973144 Z2.904443 E3466.178629 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.095663 matz1=2.115131 note=collision lift
G1 X249.282334 Y233.969143 Z2.902461 E3466.183096 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.115131 matz1=2.115344 note=collision lift
G1 X249.201225 Y233.789464 Z2.890098 E3466.366359 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.115344 matz1=2.124922 note=collision lift
G1 X249.20021 Y233.787215 Z2.891452 E3466.36897 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.124922 matz1=2.125042 note=collision lift
G1 X249.11628 Y233.601287 Z2.861721 E3466.560233 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.125042 matz1=2.134953 note=collision lift
G1 X248.732 Y232.75 Z2.440099 E3467.510996 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.134953 matz1=2.180332 note=collision lift
G1 X248.237 Y231.91 Z2.017438 E3468.851433 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.180332 matz1=2.017438 note=collision lift
G1 X248.081264 Y231.694674 Z1.904247 E3469.245024 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.017438 matz1=1.904247 note=collision lift
G1 X247.380281 Y230.725475 Z1.404574 E3471.667626 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.904247 matz1=1.404574 note=collision lift
G1 X246.959 Y230.143 Z1.111342 E3473.382949 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.404574 matz1=1.111342 note=collision lift
G1 X246.716357 Y229.871929 Z0.967699 E3474.783397 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.111342 matz1=0.967699 note=collision lift
G1 X245.269 Y228.255 Z1.195918 E3482.596152 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X243.137 Y226.24 Z1.540666 E3498.410846 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X243.118113 Y226.216511 Z1.54426 E3498.573926 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X241.762 Y224.53 Z1.797536 E3513.11953 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X241.455769 Y224.208586 Z1.847379 E3516.216348 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.33 Y223.027 Z2.02017 E3529.052008 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.44 Y220.397 Z2.333554 E3566.032307 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.96348 Y219.258906 Z2.416573 E3584.433049 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.701 Y217.515 Z2.445903 E3603.499846 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.758 Y215.565 Z2.316504 E3625.510863 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.469 Y213.67 Z2.002407 E3645.138476 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X223.848 Y211.896 Z1.547995 E3659.724291 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.908 Y210.309 Z1.058592 E3667.916309 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.661 Y208.977 Z0.67949 E3670.666444 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.427 Y208.427 Z0.577032 E3671.27493 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.977 Y210.661 Z0.551187 E3671.678886 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.309 Y214.908 Z0.720962 E3675.054693 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.896 Y218.848 Z1.105951 E3683.919033 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.67 Y222.469 Z1.574965 E3698.886332 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X220.565 Y225.758 Z2.001398 E3718.556922 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X222.515 Y228.701 Z2.299211 E3740.421155 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X224.258906 Y230.96348 Z2.428693 E3759.337731 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X225.397 Y232.44 Z2.449769 E3778.039837 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.510166 Y234.762073 Z2.36874 E3808.236288 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X226.196906 Y234.363699 Z2.289884 E3820.894892 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X224.413 Y234.188 Z2.152038 E3836.175757 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X222.629094 Y234.363699 Z1.981248 E3849.898397 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X222.523608 Y234.395698 Z1.969856 E3850.736453 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X220.913743 Y234.884046 Z1.786142 E3858.201899 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.429951 Y235.677149 Z1.58967 E3864.532822 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.332866 Y235.729042 Z1.576578 E3865.146865 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.947216 Y236.866216 Z1.363145 E3873.163428 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.810042 Y238.251866 Z1.156627 E3879.259211 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.965046 Y239.832743 Z0.967458 E3883.594271 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.444699 Y241.548094 Z0.805197 E3886.420448 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.411025 Y241.89 Z0.777882 E3886.91318 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.38568 Y242.14733 Z0.760065 E3887.150599 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.269 Y243.332 Z1.273242 E3888.338027 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.760065 matz1=1.273242 note=collision lift
G1 X215.374156 Y244.399671 Z1.753097 E3889.072559 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.273242 matz1=1.753097 note=collision lift
G1 X215.444699 Y245.115906 Z2.083886 E3889.449175 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.753097 matz1=2.083886 note=collision lift
G1 X215.610704 Y245.66315 Z2.357134 E3889.620854 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.083886 matz1=2.07973 note=collision lift
G1 X215.965046 Y246.831257 Z2.474293 E3889.953022 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.07973 matz1=2.052649 note=collision lift
G1 X215.965473 Y246.832057 Z2.473832 E3889.953296 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052649 matz1=2.052641 note=collision lift
G1 X215.975434 Y246.850693 Z2.475861 E3889.959018 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052641 matz1=2.052457 note=collision lift
G1 X215.979137 Y246.85762 Z2.47972 E3889.961377 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052457 matz1=2.052389 note=collision lift
G1 X215.943765 Y245.60812 Z2.360033 E3890.442146 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052389 matz1=2.063994 note=collision lift
G1 X215.921094 Y244.807242 Z1.966872 E3890.783839 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.063994 matz1=1.966872 note=collision lift
G1 X215.912 Y244.486 Z2.130541 E3890.921918 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.966872 matz1=2.074416 note=collision lift
G1 X215.915255 Y244.456155 Z2.146366 E3890.935053 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074416 matz1=2.07523 note=collision lift
G1 X215.921584 Y244.39813 Z2.178043 E3890.992347 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.07523 matz1=2.077722 note=collision lift
G1 X216.028832 Y243.414878 Z2.245646 E3891.847629 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077722 matz1=2.119961 note=collision lift
G1 X216.028832 Y243.414875 Z2.245644 E3891.847632 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.119961 matz1=2.119961 note=collision lift
G1 X216.0297 Y243.406923 Z2.246191 E3891.854549 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.119961 matz1=2.120302 note=collision lift
G1 X216.079982 Y242.945934 Z2.277882 E3892.255541 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.120302 matz1=2.140106 note=collision lift
G1 X216.117523 Y242.601755 Z2.305181 E3892.555156 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.140106 matz1=2.154891 note=collision lift
G1 X216.117544 Y242.601555 Z2.30529 E3892.555353 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.154891 matz1=2.154899 note=collision lift
G1 X216.14994 Y242.304552 Z2.337328 E3892.814578 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.154899 matz1=2.167658 note=collision lift
G1 X216.15 Y242.304 Z2.33763 E3892.815123 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.167658 matz1=2.167682 note=collision lift
G1 X216.160463 Y241.860909 Z2.385925 E3893.261191 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.167682 matz1=2.194467 note=collision lift
G1 X216.160476 Y241.860382 Z2.3857 E3893.262117 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.194467 matz1=2.194505 note=collision lift
G1 X216.16268 Y241.76705 Z2.395586 E3893.413749 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.194505 matz1=2.201338 note=collision lift
G1 X216.162707 Y241.765899 Z2.396245 E3893.415892 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.201338 matz1=2.201422 note=collision lift
G1 X216.179181 Y241.06828 Z2.467539 E3894.54885 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.201422 matz1=2.252493 note=collision lift
G1 X216.179276 Y241.064248 Z2.46985 E3894.556359 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.252493 matz1=2.252789 note=collision lift
G1 X216.199 Y240.229 Z2.569431 E3895.915358 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.252789 matz1=2.313935 note=collision lift
G1 X216.198838 Y240.225536 Z2.568044 E3895.928901 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.313935 matz1=2.314282 note=collision lift
G1 X216.185999 Y239.951723 Z2.596836 E3896.928389 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.314282 matz1=2.341705 note=collision lift
G1 X216.185957 Y239.950822 Z2.597377 E3896.932203 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.341705 matz1=2.341796 note=collision lift
G1 X216.163052 Y239.462299 Z2.644367 E3898.713848 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.341796 matz1=2.390722 note=collision lift
G1 X216.162993 Y239.461056 Z2.643869 E3898.71871 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.390722 matz1=2.390847 note=collision lift
G1 X216.156757 Y239.328048 Z2.655724 E3899.203476 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.390847 matz1=2.404168 note=collision lift
G1 X216.156251 Y239.317257 Z2.662206 E3899.249163 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.404168 matz1=2.405249 note=collision lift
G1 X216.107842 Y238.28479 Z2.739291 E3903.007719 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.405249 matz1=2.508653 note=collision lift
G1 X216.107557 Y238.278717 Z2.73686 E3903.031462 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.508653 matz1=2.509261 note=collision lift
G1 X216.078135 Y237.651205 Z2.755395 E3905.310501 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.509261 matz1=2.572108 note=collision lift
G1 X216.077695 Y237.641827 Z2.75164 E3905.347168 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.572108 matz1=2.573047 note=collision lift
G1 X216.067537 Y237.425172 Z2.746379 E3906.13392 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.573047 matz1=2.594746 note=collision lift
G1 X216.067409 Y237.422453 Z2.745291 E3906.14455 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.594746 matz1=2.595018 note=collision lift
G1 X216.062238 Y237.312155 Z2.736144 E3906.546335 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.595018 matz1=2.606064 note=collision lift
G1 X216.062128 Y237.309811 Z2.735206 E3906.5555 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.606064 matz1=2.606299 note=collision lift
G1 X216.059588 Y237.255646 Z2.726445 E3906.754682 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.606299 matz1=2.611724 note=collision lift
G1 X216.059451 Y237.252728 Z2.725276 E3906.766093 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.611724 matz1=2.612016 note=collision lift
G1 X216.058318 Y237.228548 Z2.718736 E3906.857019 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.612016 matz1=2.614438 note=collision lift
G1 X216.058264 Y237.227392 Z2.719431 E3906.861914 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.614438 matz1=2.614554 note=collision lift
G1 X216.016 Y236.326 Z2.358516 E3910.386247 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.614554 matz1=2.358516 note=collision lift
G1 X215.776662 Y234.477251 Z1.644092 E3919.861429 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.358516 matz1=1.644092 note=collision lift
G1 X215.719761 Y234.037724 Z1.474869 E3921.911656 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.644092 matz1=1.474869 note=collision lift
G1 X215.41 Y231.645 Z1.759986 E3932.411113 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.707 Y228.184 Z2.127136 E3952.227607 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.722 Y224.519 Z2.384716 E3976.817128 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X212.416 Y220.704 Z2.441505 E4003.672297 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X210.752 Y216.796 Z2.246049 E4029.136983 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X208.691 Y212.851 Z1.820289 E4049.385131 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.5 Y210.882 Z1.551948 E4057.744357 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X206.309 Y212.851 Z1.279292 E4063.938294 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X204.248 Y216.796 Z0.822638 E4068.889686 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X202.584 Y220.704 Z0.577968 E4070.027469 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.278 Y224.519 Z0.582782 E4071.172409 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X200.293 Y228.184 Z0.798691 E4075.066717 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.59 Y231.645 Z1.141789 E4082.877617 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.223338 Y234.477251 Z1.473648 E4092.47921 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.198585 Y234.668458 Z1.49652 E4093.672705 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.984 Y236.326 Z2.530486 E4105.753982 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.49652 matz1=2.530486 note=collision lift
G1 X198.895493 Y238.213671 Z3.681471 E4123.254039 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.530486 matz1=3.400912 note=collision lift
G1 X198.836948 Y239.462299 Z3.192808 E4133.868923 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.400912 matz1=3.192808 note=collision lift
G1 X198.189958 Y238.251866 Z2.633051 E4146.556737 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.192808 matz1=2.633051 note=collision lift
G1 X197.594502 Y237.5263 Z2.234451 E4155.994135 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.633051 matz1=2.234451 note=collision lift
G1 X197.052784 Y236.866216 Z2.29878 E4163.919156 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.667134 Y235.729042 Z2.393461 E4181.405894 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.570049 Y235.677149 Z2.397841 E4182.481636 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X194.086257 Y234.884046 Z2.442998 E4193.698198 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X192.476392 Y234.395698 Z2.446162 E4204.928004 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X192.370906 Y234.363699 Z2.444889 E4206.031105 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X190.587 Y234.188 Z2.399038 E4223.550668 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X188.803094 Y234.363699 Z2.307762 E4240.244311 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.087743 Y234.884046 Z2.175673 E4255.740061 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.506866 Y235.729042 Z2.009444 E4269.720597 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.241395 Y235.946908 Z1.974375 E4272.339213 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.121216 Y236.866216 Z1.817475 E4282.219155 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X183.440703 Y237.695423 Z1.694263 E4288.853573 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X183.066764 Y238.151068 Z1.624825 E4292.241445 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.984042 Y238.251866 Z1.674662 E4293.038273 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.624825 matz1=1.674662 note=collision lift
G1 X182.139046 Y239.832743 Z2.35739 E4301.879918 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.674662 matz1=2.35739 note=collision lift
G1 X182.13041 Y239.861212 Z2.368736 E4302.026106 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.35739 matz1=2.368736 note=collision lift
G1 X183.76 Y238.137 Z3.282452 E4310.134276 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.368736 matz1=2.61989 note=collision lift
G1 X183.783489 Y238.118113 Z3.294227 E4310.236929 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.61989 matz1=2.616595 note=collision lift
G1 X183.82894 Y238.081565 Z3.317477 E4310.36524 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.616595 matz1=2.610683 note=collision lift
G1 X184.599957 Y237.461596 Z3.423775 E4312.398751 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.610683 matz1=2.510388 note=collision lift
G1 X184.599959 Y237.461594 Z3.423773 E4312.398758 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.510388 matz1=2.510388 note=collision lift
G1 X184.605905 Y237.456813 Z3.424593 E4312.414438 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.510388 matz1=2.509614 note=collision lift
G1 X184.605906 Y237.456812 Z3.424593 E4312.414442 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.509614 matz1=2.509614 note=collision lift
G1 X184.967038 Y237.166428 Z3.474376 E4313.366906 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.509614 matz1=2.462637 note=collision lift
G1 X185.236545 Y236.94972 Z3.509412 E4314.077264 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.462637 matz1=2.427579 note=collision lift
G1 X185.236796 Y236.949518 Z3.50954 E4314.077971 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.427579 matz1=2.427547 note=collision lift
G1 X185.469335 Y236.762534 Z3.542323 E4314.69144 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.427547 matz1=2.397298 note=collision lift
G1 X185.47 Y236.762 Z3.542663 E4314.693317 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.397298 matz1=2.397211 note=collision lift
G1 X185.791414 Y236.455769 Z3.592191 E4315.514258 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.397211 matz1=2.357207 note=collision lift
G1 X185.791717 Y236.455481 Z3.59195 E4315.514825 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.357207 matz1=2.357174 note=collision lift
G1 X185.858983 Y236.391392 Z3.602023 E4315.624557 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.357174 matz1=2.349831 note=collision lift
G1 X185.860253 Y236.390182 Z3.602761 E4315.626791 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.349831 matz1=2.349693 note=collision lift
G1 X186.365566 Y235.908739 Z3.67579 E4316.450781 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.349693 matz1=2.294531 note=collision lift
G1 X186.36823 Y235.906201 Z3.677339 E4316.455469 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.294531 matz1=2.29424 note=collision lift
G1 X186.973 Y235.33 Z3.728221 E4317.438101 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.29424 matz1=2.228221 note=collision lift
G1 X186.97433 Y235.328538 Z3.728135 E4317.438693 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.228221 matz1=2.228135 note=collision lift
G1 X187.159967 Y235.124549 Z3.716135 E4317.521363 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.228135 matz1=2.216135 note=collision lift
G1 X187.160516 Y235.123946 Z3.716099 E4317.521607 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.216135 matz1=2.216099 note=collision lift
G1 X187.489834 Y234.762073 Z3.69481 E4317.668262 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.216099 matz1=2.19481 note=collision lift
G1 X187.490307 Y234.761553 Z3.69478 E4317.668473 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.19481 matz1=2.19478 note=collision lift
G1 X187.583321 Y234.659343 Z3.688767 E4317.709895 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.19478 matz1=2.188767 note=collision lift
G1 X187.587461 Y234.654794 Z3.688499 E4317.711739 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.188767 matz1=2.188499 note=collision lift
G1 X188.283049 Y233.89044 Z3.643532 E4318.021505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.188499 matz1=2.143532 note=collision lift
G1 X188.284441 Y233.88891 Z3.643442 E4318.022125 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.143532 matz1=2.143442 note=collision lift
G1 X188.710247 Y233.42101 Z3.615915 E4318.211749 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.143442 matz1=2.115915 note=collision lift
G1 X188.712225 Y233.418837 Z3.615788 E4318.212629 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.115915 matz1=2.115788 note=collision lift
G1 X188.862298 Y233.253927 Z3.606086 E4318.279461 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.115788 matz1=2.106086 note=collision lift
G1 X188.862804 Y233.253371 Z3.606053 E4318.279687 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.106086 matz1=2.106053 note=collision lift
G1 X188.937098 Y233.171732 Z3.60125 E4318.312772 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.106053 matz1=2.10125 note=collision lift
G1 X188.938324 Y233.170386 Z3.601171 E4318.313318 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.10125 matz1=2.101171 note=collision lift
G1 X189.014349 Y233.086844 Z3.596256 E4318.347174 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.101171 matz1=2.096256 note=collision lift
G1 X189.603 Y232.44 Z3.35738 E4318.618663 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.096256 matz1=2.058203 note=collision lift
G1 X190.741094 Y230.96348 Z2.422072 E4319.208982 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058203 matz1=2.055012 note=collision lift
G1 X192.485 Y228.701 Z1.088254 E4320.825377 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055012 matz1=1.088254 note=collision lift
G1 X192.969707 Y227.969465 Z0.715102 E4322.177762 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.088254 matz1=0.715102 note=collision lift
G1 X194.435 Y225.758 Z0.913478 E4325.950573 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.33 Y222.469 Z1.322057 E4336.715264 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.104 Y218.848 Z1.797288 E4354.781308 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.691 Y214.908 Z2.215001 E4379.887837 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.023 Y210.661 Z2.437954 E4409.510992 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.573 Y208.427 Z2.442021 E4424.836117 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.339 Y208.977 Z2.367894 E4439.583905 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.092 Y210.309 Z2.030638 E4463.018606 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X191.152 Y211.896 Z1.55591 E4478.498031 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.531 Y213.67 Z1.088652 E4486.693736 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.242 Y215.565 Z0.741415 E4489.849984 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.299 Y217.515 Z0.56938 E4490.691112 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.013639 Y217.734955 Z0.568402 E4490.767273 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.03652 Y219.258906 Z1.809771 E4491.356601 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.568402 matz1=1.809771 note=collision lift
G1 X177.56 Y220.397 Z2.80192 E4492.678465 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.809771 matz1=2.121662 note=collision lift
G1 X176.162418 Y221.668848 Z3.746017 E4496.246199 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.121662 matz1=2.246017 note=collision lift
G1 X175.594495 Y222.185678 Z3.79655 E4497.545937 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.246017 matz1=2.29655 note=collision lift
G1 X175.594491 Y222.185681 Z3.796551 E4497.545946 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.29655 matz1=2.296551 note=collision lift
G1 X175.238116 Y222.509995 Z3.828261 E4498.361539 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.296551 matz1=2.328261 note=collision lift
G1 X175.237927 Y222.510166 Z3.828277 E4498.36197 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.328261 matz1=2.328277 note=collision lift
G1 X175.390661 Y222.006672 Z3.876295 E4499.594752 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.328277 matz1=2.376295 note=collision lift
G1 X175.390915 Y222.005833 Z3.876375 E4499.596806 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.376295 matz1=2.376375 note=collision lift
G1 X175.600783 Y221.313991 Z3.87188 E4501.283772 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.376375 matz1=2.442354 note=collision lift
G1 X175.636301 Y221.196906 Z3.821869 E4501.592191 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.442354 matz1=2.45352 note=collision lift
G1 X175.812 Y219.413 Z3.112973 E4507.948227 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.45352 matz1=2.640893 note=collision lift
G1 X175.636301 Y217.629094 Z2.422222 E4516.31374 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.640893 matz1=2.422222 note=collision lift
G1 X175.604302 Y217.523608 Z2.380106 E4516.83551 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.422222 matz1=2.380106 note=collision lift
G1 X175.115954 Y215.913743 Z1.739231 E4523.378807 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.380106 matz1=1.739231 note=collision lift
G1 X174.946682 Y215.597057 Z1.601869 E4525.036822 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.739231 matz1=1.601869 note=collision lift
G1 X174.322851 Y214.429951 Z1.757324 E4530.783164 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.270958 Y214.332866 Z1.76995 E4531.507147 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.133784 Y212.947216 Z1.966572 E4545.113692 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.748134 Y211.810042 Z2.13962 E4560.305343 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.167257 Y210.965046 Z2.28035 E4576.775099 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.451906 Y210.444699 Z2.381652 E4594.156275 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.11 Y210.411025 Z2.396101 E4597.510769 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.668 Y210.269 Z2.438407 E4611.967526 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.600329 Y210.374156 Z2.449779 E4622.730269 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.884094 Y210.444699 Z2.447748 E4629.942426 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.960074 Y210.724998 Z2.426984 E4639.429407 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.168743 Y210.965046 Z2.822672 E4648.434192 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.426984 matz1=2.822672 note=collision lift
G1 X163.14238 Y210.979137 Z2.836577 E4648.75785 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.822672 matz1=2.836577 note=collision lift
G1 X165.514 Y210.912 Z3.900892 E4672.654669 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.836577 matz1=3.786191 note=collision lift
G1 X165.543845 Y210.915255 Z3.913885 E4672.954955 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.786191 matz1=3.784174 note=collision lift
G1 X165.60187 Y210.921584 Z3.938407 E4673.479784 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.784174 matz1=3.779511 note=collision lift
G1 X167.568374 Y211.136079 Z3.938407 E4689.878187 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.779511 matz1=3.621492 note=collision lift
G1 X167.695992 Y211.149999 Z3.934628 E4690.942833 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.621492 matz1=3.611237 note=collision lift
G1 X167.696 Y211.15 Z3.934632 E4690.942909 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.611237 matz1=3.611236 note=collision lift
G1 X168.036426 Y211.158039 Z3.925288 E4693.69417 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.611236 matz1=3.579404 note=collision lift
G1 X168.036432 Y211.158039 Z3.925284 E4693.69423 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.579404 matz1=3.579404 note=collision lift
G1 X168.092329 Y211.159359 Z3.923747 E4694.145977 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.579404 matz1=3.574177 note=collision lift
G1 X168.139029 Y211.160462 Z3.922463 E4694.523402 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.574177 matz1=3.56981 note=collision lift
G1 X168.139091 Y211.160463 Z3.922488 E4694.523943 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.56981 matz1=3.569805 note=collision lift
G1 X169.093141 Y211.182993 Z3.896127 E4701.415245 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.569805 matz1=3.4723 note=collision lift
G1 X169.093178 Y211.182994 Z3.896105 E4701.415555 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.4723 matz1=3.472296 note=collision lift
G1 X169.454184 Y211.191519 Z3.881661 E4704.024274 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.472296 matz1=3.435401 note=collision lift
G1 X169.454282 Y211.191521 Z3.881699 E4704.025031 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.435401 matz1=3.435391 note=collision lift
G1 X169.770935 Y211.198998 Z3.865987 E4706.314222 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.435391 matz1=3.403028 note=collision lift
G1 X169.771 Y211.199 Z3.866013 E4706.314728 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.403028 matz1=3.403022 note=collision lift
G1 X170.100981 Y211.183528 Z3.849877 E4707.930892 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.403022 matz1=3.364702 note=collision lift
G1 X170.101105 Y211.183522 Z3.849801 E4707.931603 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.364702 matz1=3.364688 note=collision lift
G1 X170.175117 Y211.180052 Z3.8461 E4708.294116 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.364688 matz1=3.356093 note=collision lift
G1 X170.177333 Y211.179948 Z3.846952 E4708.305728 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.356093 matz1=3.355836 note=collision lift
G1 X171.405989 Y211.12234 Z3.781389 E4714.324732 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.355836 matz1=3.213156 note=collision lift
G1 X171.407329 Y211.122277 Z3.781904 E4714.331757 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.213156 matz1=3.213 note=collision lift
G1 X172.132542 Y211.088274 Z3.715835 E4717.894094 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.213 matz1=3.128783 note=collision lift
G1 X172.133963 Y211.088208 Z3.716381 E4717.901538 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.128783 matz1=3.128618 note=collision lift
G1 X172.747677 Y211.059433 Z3.644093 E4720.924483 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.128618 matz1=3.05735 note=collision lift
G1 X172.765267 Y211.058608 Z3.633246 E4721.025549 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.05735 matz1=3.055307 note=collision lift
G1 X172.773198 Y211.058236 Z3.630235 E4721.067042 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.055307 matz1=3.054386 note=collision lift
G1 X172.774269 Y211.058186 Z3.630647 E4721.072657 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.054386 matz1=3.054262 note=collision lift
G1 X172.800862 Y211.056939 Z3.614402 E4721.225052 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.054262 matz1=3.051174 note=collision lift
G1 X173.674 Y211.016 Z3.075959 E4726.241718 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.051174 matz1=2.949779 note=collision lift
G1 X175.522749 Y210.776662 Z1.925034 E4734.480692 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.949779 matz1=1.925034 note=collision lift
G1 X176.899444 Y210.598436 Z1.083728 E4736.864059 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.925034 matz1=1.083728 note=collision lift
G1 X178.355 Y210.41 Z0.92808 E4739.031163 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.816 Y209.707 Z0.657778 E4740.94799 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.481 Y208.722 Z0.550008 E4741.599197 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X189.296 Y207.416 Z0.66751 E4743.916974 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X193.204 Y205.752 Z1.016158 E4751.462039 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.149 Y203.691 Z1.52369 E4767.191439 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.118 Y202.5 Z1.793526 E4777.471119 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.149 Y201.309 Z2.038987 E4789.687167 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X193.204 Y199.248 Z2.37195 E4818.345073 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X189.296 Y197.584 Z2.44252 E4846.649087 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.481 Y196.278 Z2.266341 E4871.102256 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.816 Y195.293 Z1.923115 E4889.702351 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.355 Y194.59 Z1.516909 E4902.101869 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.522749 Y194.223338 Z1.182219 E4908.830318 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.674 Y193.984 Z0.983086 E4913.489978 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.537701 Y193.836948 Z0.716416 E4916.998503 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.748134 Y193.189958 Z0.635862 E4917.959531 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.133784 Y192.052784 Z0.569541 E4918.601305 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.270958 Y190.667134 Z0.550232 E4919.064592 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.322851 Y190.570049 Z0.550613 E4919.093258 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.115954 Y189.086257 Z0.578911 E4919.548697 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.604302 Y187.476392 Z0.648221 E4920.404692 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.636301 Y187.370906 Z0.65413 E4920.492231 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.812 Y185.587 Z0.772088 E4923.006982 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.636301 Y183.803094 Z0.926824 E4926.957999 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.115954 Y182.087743 Z1.110522 E4932.618008 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.270958 Y180.506866 Z1.313898 E4940.172316 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.053092 Y180.241395 Z1.354262 E4941.6921 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.133784 Y179.121216 Z1.526677 E4949.400559 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X172.304577 Y178.440703 Z1.654056 E4955.814491 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.748134 Y177.984042 Z1.738108 E4960.431003 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.167257 Y177.139046 Z1.937509 E4973.770164 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.138788 Y177.13041 Z1.940658 E4973.991908 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.863 Y178.76 Z2.168431 E4994.450463 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X171.881887 Y178.783489 Z2.170983 E4994.710509 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.238 Y180.47 Z2.326969 E5015.105076 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.544231 Y180.791414 Z2.351753 E5019.341162 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.67 Y181.973 Z2.419586 E5035.473155 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X177.56 Y184.603 Z2.423373 E5074.140849 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.03652 Y185.741094 Z2.346307 E5091.864544 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.299 Y187.485 Z2.140744 E5107.981982 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.242 Y189.435 Z1.777656 E5123.534869 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.531 Y191.33 Z1.329546 E5134.410229 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X191.152 Y193.104 Z0.897413 E5139.93804 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.092 Y194.691 Z0.60757 E5141.508885 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.339 Y196.023 Z0.570753 E5142.589084 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.573 Y196.573 Z0.665624 E5143.897186 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.023 Y194.339 Z0.829754 E5146.505991 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.691 Y190.092 Z1.28913 E5158.617354 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.104 Y186.152 Z1.789749 E5177.537874 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.33 Y182.531 Z2.192407 E5201.060756 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X194.435 Y179.242 Z2.413746 E5226.019309 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X192.485 Y176.299 Z2.436864 E5249.473517 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X190.741094 Y174.03652 Z2.32184 E5267.33822 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X189.603 Y172.56 Z2.188775 E5283.577064 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.489834 Y170.237927 Z1.884361 E5306.043995 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X188.803094 Y170.636301 Z1.729577 E5314.780665 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X190.587 Y170.812 Z1.517877 E5324.233254 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X192.370906 Y170.636301 Z1.305274 E5331.711929 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X192.476392 Y170.604302 Z1.292413 E5332.164388 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X194.086257 Y170.115954 Z1.10251 E5335.663086 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.570049 Y169.322851 Z0.930291 E5338.159158 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.667134 Y169.270958 Z0.91983 E5338.398011 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.052784 Y168.133784 Z0.766463 E5340.86444 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.189958 Y166.748134 Z0.65016 E5342.252197 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.034954 Y165.167257 Z0.576796 E5342.961037 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.555301 Y163.451906 Z0.550078 E5343.422932 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.588975 Y163.11 Z0.550438 E5343.512085 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.731 Y161.668 Z0.571356 E5344.044095 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.625844 Y160.600329 Z0.606705 E5344.633393 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.555301 Y159.884094 Z0.639556 E5345.15068 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.034954 Y158.168743 Z0.751231 E5347.472142 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.020863 Y158.14238 Z0.753432 E5347.511223 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.088 Y160.514 Z0.958941 E5353.134356 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.084745 Y160.543845 Z0.961891 E5353.206043 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.85 Y162.696 Z1.192055 E5360.957833 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.839537 Y163.139091 Z1.24256 E5362.662057 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.801 Y164.771 Z1.434226 E5370.561951 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.984 Y168.674 Z1.888858 E5398.670114 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.223338 Y170.522749 Z2.079433 E5413.897496 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.59 Y173.355 Z2.306933 E5431.653474 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X200.293 Y176.816 Z2.444033 E5455.220206 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.278 Y180.481 Z2.387498 E5479.792231 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X202.584 Y184.296 Z2.111509 E5502.132784 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X204.248 Y188.204 Z1.656561 E5519.078826 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X206.309 Y192.149 Z1.135517 E5528.847173 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.5 Y194.118 Z0.900479 E5532.024574 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X208.691 Y192.149 Z0.715225 E5533.72883 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X210.752 Y188.204 Z0.550736 E5534.503917 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X212.416 Y184.296 Z0.663757 E5536.890497 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.722 Y180.481 Z0.987605 E5543.656164 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.707 Y176.816 Z1.411985 E5555.601341 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.41 Y173.355 Z1.826666 E5571.782279 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.776662 Y170.522749 Z2.119173 E5587.725953 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.016 Y168.674 Z2.269507 E5604.752481 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.163052 Y165.537701 Z2.424531 E5635.878753 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.810042 Y166.748134 Z2.448313 E5649.638619 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.947216 Y168.133784 Z2.436996 E5667.502871 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.332866 Y169.270958 Z2.378336 E5684.835048 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.429951 Y169.322851 Z2.373245 E5685.897142 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X220.913743 Y170.115954 Z2.275297 E5696.159251 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X222.523608 Y170.604302 Z2.142835 E5705.668113 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X222.629094 Y170.636301 Z2.133084 E5706.59792 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X224.413 Y170.812 Z1.958885 E5720.115829 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X226.196906 Y170.636301 Z1.761499 E5731.820292 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.912257 Y170.115954 Z1.550901 E5741.578856 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.493134 Y169.270958 Z1.337731 E5749.359245 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.758605 Y169.053092 Z1.297499 E5750.777979 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.878784 Y168.133784 Z1.132759 E5755.525953 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X231.559297 Y167.304577 Z1.018344 E5758.402898 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.015958 Y166.748134 Z0.946344 E5760.064189 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.146618 Y166.503687 Z0.921844 E5760.476353 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.860954 Y165.167257 Z1.545583 E5762.903669 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.921844 matz1=1.545583 note=collision lift
G1 X232.86959 Y165.138788 Z1.558112 E5762.951095 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.545583 matz1=1.558112 note=collision lift
G1 X231.24 Y166.863 Z2.591926 E5764.723928 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.558112 matz1=2.13315 note=collision lift
G1 X231.216511 Y166.881887 Z2.60553 E5764.746332 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.13315 matz1=2.131684 note=collision lift
G1 X231.17106 Y166.918435 Z2.632762 E5764.766227 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.131684 matz1=2.129754 note=collision lift
G1 X230.400043 Y167.538404 Z2.74437 E5765.07396 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.129754 matz1=2.097017 note=collision lift
G1 X230.40004 Y167.538406 Z2.744368 E5765.073961 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.097017 matz1=2.097017 note=collision lift
G1 X230.394095 Y167.543187 Z2.745229 E5765.076334 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.097017 matz1=2.096764 note=collision lift
G1 X230.394094 Y167.543188 Z2.745229 F1200 ; clayline kind=print e_deferred=true page=0 layer=0 stroke=stroke-0000 matz0=2.096764 matz1=2.096764 note=collision lift
G1 X230.032962 Y167.833572 Z2.797499 E5765.220471 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.096764 matz1=2.081431 note=collision lift
G1 X229.763477 Y168.050263 Z2.83769 E5765.328071 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.081431 matz1=2.069989 note=collision lift
G1 X229.763204 Y168.050482 Z2.837854 E5765.32819 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.069989 matz1=2.069977 note=collision lift
G1 X229.530755 Y168.237393 Z2.879878 E5765.421293 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.069977 matz1=2.060107 note=collision lift
G1 X229.53 Y168.238 Z2.880331 E5765.421623 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060107 matz1=2.060075 note=collision lift
G1 X229.208586 Y168.544231 Z2.943845 E5765.545856 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060075 matz1=2.053843 note=collision lift
G1 X229.208168 Y168.544629 Z2.943557 E5765.546043 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053843 matz1=2.053844 note=collision lift
G1 X229.141151 Y168.60848 Z2.956428 E5765.573107 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053844 matz1=2.053983 note=collision lift
G1 X229.139747 Y168.609818 Z2.9574 E5765.573735 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053983 matz1=2.053986 note=collision lift
G1 X228.635736 Y169.09002 Z3.050809 E5765.777138 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053986 matz1=2.055028 note=collision lift
G1 X228.63177 Y169.093799 Z3.053557 E5765.778913 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055028 matz1=2.055036 note=collision lift
G1 X228.027 Y169.67 Z3.164398 E5766.022932 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055036 matz1=2.056286 note=collision lift
G1 X228.024726 Y169.672499 Z3.16285 E5766.027124 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056286 matz1=2.056427 note=collision lift
G1 X227.840273 Y169.875187 Z3.194899 E5766.338358 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056427 matz1=2.067856 note=collision lift
G1 X227.839484 Y169.876054 Z3.195534 E5766.339861 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.067856 matz1=2.067905 note=collision lift
G1 X227.510166 Y170.237927 Z3.247868 E5766.894916 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.067905 matz1=2.088309 note=collision lift
G1 X227.509346 Y170.238828 Z3.24731 E5766.896428 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.088309 matz1=2.08836 note=collision lift
G1 X227.420551 Y170.336402 Z3.260384 E5767.045971 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.08836 matz1=2.093862 note=collision lift
G1 X227.412539 Y170.345206 Z3.266832 E5767.061241 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.093862 matz1=2.094358 note=collision lift
G1 X226.716951 Y171.10956 Z3.340482 E5768.229941 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.094358 matz1=2.137457 note=collision lift
G1 X226.713506 Y171.113345 Z3.338137 E5768.236291 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.137457 matz1=2.13767 note=collision lift
G1 X226.289753 Y171.57899 Z3.355858 E5768.946745 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.13767 matz1=2.163926 note=collision lift
G1 X226.284516 Y171.584745 Z3.352291 E5768.9564 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.163926 matz1=2.164251 note=collision lift
G1 X226.137702 Y171.746073 Z3.347204 E5769.202514 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.164251 matz1=2.173347 note=collision lift
G1 X226.136238 Y171.747681 Z3.346207 E5769.205212 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.173347 matz1=2.173438 note=collision lift
G1 X226.061676 Y171.829614 Z3.337416 E5769.330564 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.173438 matz1=2.178058 note=collision lift
G1 X226.060492 Y171.830916 Z3.33661 E5769.332747 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.178058 matz1=2.178131 note=collision lift
G1 X226.023664 Y171.871385 Z3.328147 E5769.395202 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.178131 matz1=2.180413 note=collision lift
G1 X226.022443 Y171.872726 Z3.327316 E5769.397452 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.180413 matz1=2.180489 note=collision lift
G1 X226.005466 Y171.891381 Z3.320793 E5769.42684 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.180489 matz1=2.181541 note=collision lift
G1 X226.004657 Y171.89227 Z3.321445 E5769.428382 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.181541 matz1=2.181591 note=collision lift
G1 X225.397 Y172.56 Z2.907678 E5770.548615 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.181591 matz1=2.219241 note=collision lift
G1 X224.258906 Y174.03652 Z2.12252 E5774.359775 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.219241 matz1=2.12252 note=collision lift
G1 X222.724969 Y176.026594 Z1.120412 E5780.439045 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.12252 matz1=1.120412 note=collision lift
G1 X222.515 Y176.299 Z1.155209 E5781.215931 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X220.565 Y179.242 Z1.568554 E5794.243554 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.67 Y182.531 Z1.995926 E5813.842989 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.896 Y186.152 Z2.32684 E5839.193647 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.309 Y190.092 Z2.44983 E5867.612801 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.977 Y194.339 Z2.29556 E5895.041446 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.427 Y196.573 Z2.114511 E5907.82145 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.661 Y196.023 Z1.882453 E5918.786176 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.908 Y194.691 Z1.362741 E5932.04682 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X223.848 Y193.104 Z0.903562 E5937.960611 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.469 Y191.33 Z0.61966 E5939.619644 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.758 Y189.435 Z0.553989 E5940.322661 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.701 Y187.485 Z0.682896 E5942.538847 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.96348 Y185.741094 Z0.905224 E5946.521202 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.44 Y184.603 Z1.093425 E5952.241879 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.762073 Y182.489834 Z1.454695 E5967.765153 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.363699 Y183.803094 Z1.618203 E5975.716243 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.188 Y185.587 Z1.825757 E5988.024689 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.363699 Y187.370906 Z2.016851 E6002.093078 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.395698 Y187.476392 Z2.027843 E6002.963878 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.884046 Y189.086257 Z2.181831 E6012.708987 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.677149 Y190.570049 Z2.30547 E6023.155965 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.729042 Y190.667134 Z2.31236 E6024.18445 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X241.866216 Y192.052784 Z2.401844 E6041.745999 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X243.251866 Y193.189958 Z2.445761 E6059.696112 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.832743 Y194.034954 Z2.441891 E6077.605196 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.548094 Y194.555301 Z2.390431 E6095.046835 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.89 Y194.588975 Z2.375311 E6098.364827 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.332 Y194.731 Z2.293981 E6111.759799 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.399671 Y194.625844 Z2.216666 E6121.259802 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.115906 Y194.555301 Z2.157414 E6127.417644 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.231638 Y194.520194 Z2.145959 E6128.347429 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.831257 Y194.034954 Z2.823429 E6142.152219 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.145959 matz1=2.823429 note=collision lift
G1 X251.85762 Y194.020863 Z2.835309 E6142.397904 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.823429 matz1=2.835309 note=collision lift
G1 X249.486 Y194.088 Z3.760186 E6158.422938 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.835309 matz1=3.223156 note=collision lift
G1 X249.456155 Y194.084745 Z3.771712 E6158.624735 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.223156 matz1=3.219671 note=collision lift
G1 X249.39813 Y194.078416 Z3.793982 E6158.93434 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.219671 matz1=3.212757 note=collision lift
G1 X248.414878 Y193.971168 Z3.849052 E6163.843618 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.212757 matz1=3.095601 note=collision lift
G1 X248.414876 Y193.971168 Z3.849051 E6163.843629 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.095601 matz1=3.0956 note=collision lift
G1 X248.406923 Y193.970301 Z3.849496 E6163.883338 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.0956 matz1=3.094653 note=collision lift
G1 X247.945934 Y193.920018 Z3.875312 E6166.185011 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.094653 matz1=3.039725 note=collision lift
G1 X247.601642 Y193.882465 Z3.890428 E6167.903002 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.039725 matz1=2.998702 note=collision lift
G1 X247.601555 Y193.882456 Z3.890461 E6167.903465 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.998702 matz1=2.998691 note=collision lift
G1 X247.304219 Y193.850024 Z3.900633 E6169.386593 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.998691 matz1=2.963263 note=collision lift
G1 X247.304 Y193.85 Z3.900717 E6169.387763 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.963263 matz1=2.963237 note=collision lift
G1 X246.860909 Y193.839537 Z3.916034 E6171.465108 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.963237 matz1=2.91045 note=collision lift
G1 X246.860772 Y193.839533 Z3.915949 E6171.465704 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.91045 matz1=2.910434 note=collision lift
G1 X246.766387 Y193.837305 Z3.91912 E6171.815476 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.910434 matz1=2.8994 note=collision lift
G1 X246.765899 Y193.837293 Z3.919307 E6171.817412 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.8994 matz1=2.899343 note=collision lift
G1 X246.064248 Y193.820724 Z3.942047 E6174.417506 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.899343 matz1=2.817321 note=collision lift
G1 X246.064075 Y193.82072 Z3.941941 E6174.41826 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.817321 matz1=2.8173 note=collision lift
G1 X245.229 Y193.801 Z3.943977 E6177.511165 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.8173 matz1=2.71968 note=collision lift
G1 X245.228941 Y193.801003 Z3.943941 E6177.511281 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.71968 matz1=2.719674 note=collision lift
G1 X244.950845 Y193.814042 Z3.94454 E6177.976518 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.719674 matz1=2.691539 note=collision lift
G1 X244.950822 Y193.814043 Z3.944549 E6177.976559 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.691539 matz1=2.691537 note=collision lift
G1 X244.462299 Y193.836948 Z3.94551 E6178.793829 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.691537 matz1=2.642112 note=collision lift
G1 X244.462279 Y193.836949 Z3.945497 E6178.79387 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.642112 matz1=2.64211 note=collision lift
G1 X244.317257 Y193.843749 Z3.945762 E6179.036483 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.64211 matz1=2.627437 note=collision lift
G1 X244.317255 Y193.843749 Z3.945761 E6179.036487 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.627437 matz1=2.627437 note=collision lift
G1 X242.25345 Y193.940515 Z3.918638 E6182.489401 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.627437 matz1=2.418638 note=collision lift
G1 X242.252323 Y193.940567 Z3.918524 E6182.491296 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.418638 matz1=2.418524 note=collision lift
G1 X242.199138 Y193.943061 Z3.913143 E6182.580724 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.418524 matz1=2.413143 note=collision lift
G1 X241.326 Y193.984 Z3.414739 E6184.262199 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.413143 matz1=2.324806 note=collision lift
G1 X239.477251 Y194.223338 Z2.345967 E6186.341988 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.324806 matz1=2.188122 note=collision lift
G1 X236.645 Y194.59 Z0.796484 E6187.084018 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.188122 matz1=0.796484 note=collision lift
G1 X236.194399 Y194.681526 Z0.568476 E6187.226826 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.796484 matz1=0.568476 note=collision lift
G1 X233.184 Y195.293 Z0.581125 E6188.081594 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.519 Y196.278 Z0.79436 E6191.919281 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X225.704 Y197.584 Z1.191718 E6201.532611 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X221.796 Y199.248 Z1.691777 E6219.015233 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.851 Y201.309 Z2.156255 E6244.437685 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.882 Y202.5 Z2.324884 E6258.880014 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.12 Y202.5 Z2.36616 E6263.764602 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.973584 Y201.013412 Z2.423764 E6273.628518 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.539962 Y199.583952 Z2.448913 E6283.615376 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.835798 Y198.266555 Z2.440723 E6293.559009 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X212.888154 Y197.111846 Z2.399483 E6303.294904 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X211.733445 Y196.164202 Z2.326641 E6312.664999 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X210.416048 Y195.460038 Z2.224757 E6321.52249 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X208.986588 Y195.026416 Z2.09741 E6329.736661 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.5 Y194.88 Z1.949073 E6337.197645 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X206.013412 Y195.026416 Z1.78496 E6343.820874 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X204.583952 Y195.460038 Z1.610834 E6349.550877 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X203.266555 Y196.164202 Z1.432815 E6354.364065 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X202.1312 Y197.095963 Z1.2601 E6358.204689 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X202.111846 Y197.111846 Z1.269674 E6358.274302 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.2601 matz1=1.269674 note=collision lift
G1 X201.164202 Y198.266555 Z1.849438 E6361.517081 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.269674 matz1=1.849438 note=collision lift
G1 X200.460038 Y199.583952 Z2.443605 E6363.928399 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.849438 matz1=2.437306 note=collision lift
G1 X200.026416 Y201.013412 Z3.057542 E6365.614341 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.437306 matz1=2.304352 note=collision lift
G1 X199.970079 Y201.585417 Z3.303175 E6366.034203 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.304352 matz1=2.262598 note=collision lift
G1 X199.947559 Y201.814063 Z3.337206 E6366.190214 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.262598 matz1=2.245908 note=collision lift
G1 X199.947213 Y201.817579 Z3.335183 E6366.19295 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.245908 matz1=2.245651 note=collision lift
G1 X199.925516 Y202.037863 Z3.347762 E6366.341873 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.245651 matz1=2.229572 note=collision lift
G1 X199.925039 Y202.042708 Z3.349843 E6366.34543 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.229572 matz1=2.229218 note=collision lift
G1 X199.880807 Y202.49181 Z3.352936 E6366.648565 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.229218 matz1=2.196436 note=collision lift
G1 X199.88 Y202.5 Z3.356453 E6366.654576 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.196436 matz1=2.195838 note=collision lift
G1 X199.970079 Y203.414583 Z3.2994 E6367.019595 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.195838 matz1=2.14646 note=collision lift
G1 X200.026416 Y203.986588 Z2.981131 E6367.280048 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.14646 matz1=2.115577 note=collision lift
G1 X200.247398 Y204.715067 Z2.575435 E6367.476475 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.115577 matz1=2.09051 note=collision lift
G1 X200.460038 Y205.416048 Z2.917575 E6367.660576 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.09051 matz1=2.066389 note=collision lift
G1 X201.164202 Y206.733445 Z3.550001 E6367.938777 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.066389 matz1=2.050001 note=collision lift
G1 X201.528857 Y207.17778 Z3.556539 E6368.070862 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050001 matz1=2.056539 note=collision lift
G1 X202.111846 Y207.888154 Z3.56699 E6368.282031 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056539 matz1=2.06699 note=collision lift
G1 X202.82222 Y208.471143 Z3.597608 E6368.650262 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.06699 matz1=2.097608 note=collision lift
G1 X203.266555 Y208.835798 Z3.616759 E6368.880589 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.097608 matz1=2.116759 note=collision lift
G1 X204.583952 Y209.539962 Z3.007676 E6369.973711 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.116759 matz1=2.197559 note=collision lift
G1 X205.678585 Y209.872015 Z2.519195 E6371.281534 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.197559 matz1=2.281021 note=collision lift
G1 X206.013412 Y209.973584 Z2.719671 E6371.70554 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.281021 matz1=2.306551 note=collision lift
G1 X206.585417 Y210.029921 Z3.058369 E6372.712164 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.306551 matz1=2.357863 note=collision lift
G1 X207.5 Y210.12 Z3.120741 E6374.102006 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.357863 matz1=2.439906 note=collision lift
G1 X207.509652 Y210.119049 Z3.116885 E6374.123233 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.439906 matz1=2.4409 note=collision lift
G1 X207.957292 Y210.074961 Z3.113514 E6375.038051 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.4409 matz1=2.486981 note=collision lift
G1 X207.963143 Y210.074384 Z3.111177 E6375.050919 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.486981 matz1=2.487583 note=collision lift
G1 X208.185937 Y210.052441 Z3.097268 E6375.507099 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.487583 matz1=2.510518 note=collision lift
G1 X208.189667 Y210.052074 Z3.095778 E6375.515302 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.510518 matz1=2.510902 note=collision lift
G1 X208.298548 Y210.04135 Z3.082346 E6375.739479 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.510902 matz1=2.522111 note=collision lift
G1 X208.30026 Y210.041181 Z3.083382 E6375.743565 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.522111 matz1=2.522287 note=collision lift
G1 X208.414583 Y210.029921 Z3.056628 E6375.983447 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.522287 matz1=2.534056 note=collision lift
G1 X208.986588 Y209.973584 Z2.828126 E6377.241381 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.534056 matz1=2.592939 note=collision lift
G1 X210.416048 Y209.539962 Z2.24857 E6381.419623 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.592939 matz1=2.24857 note=collision lift
G1 X211.733445 Y208.835798 Z1.677436 E6386.554054 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.24857 matz1=1.677436 note=collision lift
G1 X212.106662 Y208.529507 Z1.493564 E6388.528171 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.677436 matz1=1.493564 note=collision lift
G1 X212.888154 Y207.888154 Z1.614035 E6392.418509 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.670733 Y206.934578 Z1.757725 E6397.905206 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.835798 Y206.733445 Z1.91813 E6399.2556 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.757725 matz1=1.91813 note=collision lift
G1 X214.539962 Y205.416048 Z2.828899 E6407.968272 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.91813 matz1=2.828899 note=collision lift
G1 X214.973584 Y203.986588 Z3.723791 E6417.524007 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.828899 matz1=3.599912 note=collision lift
G1 X214.997479 Y203.743981 Z3.866395 E6419.196815 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.599912 matz1=3.620626 note=collision lift
G1 X215.119614 Y202.50392 Z3.914442 E6426.582676 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.620626 matz1=3.726502 note=collision lift
G1 X215.12 Y202.5 Z3.916746 E6426.609707 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.726502 matz1=3.726837 note=collision lift
G1 X215.882 Y202.5 Z3.904557 E6431.267763 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.726837 matz1=3.781994 note=collision lift
G1 X215.883716 Y202.501038 Z3.90366 E6431.282102 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.781994 matz1=3.7821 note=collision lift
G1 X216.339046 Y202.776456 Z3.871036 E6434.762693 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.7821 matz1=3.810163 note=collision lift
G1 X217.851 Y203.691 Z3.080707 E6447.399851 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.810163 matz1=3.080707 note=collision lift
G1 X219.051727 Y204.3183 Z2.408939 E6457.366853 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.080707 matz1=2.408939 note=collision lift
G1 X221.796 Y205.752 Z2.421714 E6477.775352 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X225.704 Y207.416 Z2.176439 E6502.239673 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.519 Y208.722 Z1.76772 E6519.863051 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.184 Y209.707 Z1.319445 E6530.60381 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.645 Y210.41 Z0.936463 E6535.92189 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.477251 Y210.776662 Z0.703746 E6537.924307 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X241.326 Y211.016 Z0.60522 E6538.934885 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.462299 Y211.163052 Z0.55128 E6539.763375 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X243.251866 Y211.810042 Z0.573817 E6540.284697 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X241.866216 Y212.947216 Z0.644431 E6541.617739 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.729042 Y214.332866 Z0.758273 E6544.004456 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.677149 Y214.429951 Z0.766555 E6544.155853 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.925725 Y215.835766 Z0.902076 E6546.403366 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.884046 Y215.913743 Z0.953801 E6546.547276 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.902076 matz1=0.953801 note=collision lift
G1 X239.395698 Y217.523608 Z1.964267 E6550.44395 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.953801 matz1=1.964267 note=collision lift
G1 X239.363699 Y217.629094 Z2.03122 E6550.835941 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.964267 matz1=2.03122 note=collision lift
G1 X239.188 Y219.413 Z3.129318 E6559.407906 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.03122 matz1=2.792572 note=collision lift
G1 X239.283706 Y220.384716 Z3.733175 E6565.343409 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.792572 matz1=2.90822 note=collision lift
G1 X239.288705 Y220.435478 Z3.746544 E6565.616028 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.90822 matz1=2.914261 note=collision lift
G1 X239.288889 Y220.437343 Z3.745829 E6565.626397 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.914261 matz1=2.914483 note=collision lift
G1 X239.293632 Y220.485504 Z3.751747 E6565.878462 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.914483 matz1=2.920215 note=collision lift
G1 X239.293705 Y220.48624 Z3.752204 E6565.882955 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.920215 matz1=2.920302 note=collision lift
G1 X239.303605 Y220.586756 Z3.758753 E6566.406236 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.920302 matz1=2.932265 note=collision lift
G1 X239.303704 Y220.587764 Z3.759379 E6566.412394 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.932265 matz1=2.932385 note=collision lift
G1 X239.323549 Y220.78925 Z3.763898 E6567.459389 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.932385 matz1=2.956365 note=collision lift
G1 X239.323703 Y220.790811 Z3.764868 E6567.468923 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.956365 matz1=2.956551 note=collision lift
G1 X239.363116 Y221.190987 Z3.760532 E6569.547981 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.956551 matz1=3.004177 note=collision lift
G1 X239.363699 Y221.196906 Z3.76421 E6569.584134 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.004177 matz1=3.004881 note=collision lift
G1 X239.762073 Y222.510166 Z3.686221 E6578.190427 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.004881 matz1=3.167235 note=collision lift
G1 X239.76568 Y222.522058 Z3.681478 E6578.273709 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.167235 matz1=3.168705 note=collision lift
G1 X239.884046 Y222.912257 Z3.651946 E6580.833397 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.168705 matz1=3.216944 note=collision lift
G1 X239.884353 Y222.912833 Z3.651693 E6580.838503 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.216944 matz1=3.217017 note=collision lift
G1 X240.086907 Y223.291784 Z3.616493 E6583.983897 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.217017 matz1=3.265223 note=collision lift
G1 X240.087695 Y223.293259 Z3.617517 E6583.998206 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.265223 matz1=3.265411 note=collision lift
G1 X240.597981 Y224.247937 Z3.521745 E6591.926677 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.265411 matz1=3.386854 note=collision lift
G1 X240.600588 Y224.252814 Z3.519601 E6591.969955 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.386854 matz1=3.387475 note=collision lift
G1 X240.729042 Y224.493134 Z3.486747 E6593.972413 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.387475 matz1=3.418046 note=collision lift
G1 X240.72925 Y224.493388 Z3.486618 E6593.975051 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.418046 matz1=3.41808 note=collision lift
G1 X240.916881 Y224.722017 Z3.453712 E6596.20194 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.41808 matz1=3.449441 note=collision lift
G1 X240.946908 Y224.758605 Z3.435065 E6596.582629 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.449441 matz1=3.435065 note=collision lift
G1 X241.866216 Y225.878784 Z2.854073 E6609.418729 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.435065 matz1=2.854073 note=collision lift
G1 X242.695423 Y226.559297 Z2.4115 E6619.519164 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.854073 matz1=2.4115 note=collision lift
G1 X243.035082 Y226.838048 Z2.225976 E6623.808094 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.4115 matz1=2.225976 note=collision lift
G1 X243.251866 Y227.015958 Z2.247788 E6626.337503 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.832743 Y227.860954 Z2.359767 E6643.522596 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.548094 Y228.381301 Z2.428306 E6661.319346 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.332 Y228.557 Z2.449941 E6679.303938 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.832002 Y228.409263 Z2.43096 E6694.279219 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.115906 Y228.381301 Z2.423579 E6696.162048 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.831257 Y227.860954 Z2.350551 E6707.54926 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.412134 Y227.015958 Z2.234548 E6718.236119 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.797784 Y225.878784 Z2.081431 E6727.994665 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X255.934958 Y224.493134 Z1.898936 E6736.640228 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X256.779954 Y222.912257 Z1.696285 E6744.042219 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.300301 Y221.196906 Z1.483716 E6750.132792 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.476 Y219.413 Z1.271969 E6754.912103 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.300301 Y217.629094 Z1.071744 E6758.44923 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X256.779954 Y215.913743 Z0.893158 E6760.878456 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X255.934958 Y214.332866 Z0.745233 E6762.391352 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X255.75407 Y214.112453 Z0.72505 E6762.612002 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.797784 Y212.947216 Z0.635444 E6763.664287 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.412134 Y211.810042 Z0.569338 E6764.304185 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.831257 Y210.965046 Z0.550254 E6764.767682 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.115906 Y210.444699 Z0.579159 E6765.497815 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.399671 Y210.374156 Z0.604017 E6765.883198 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.332 Y210.269 Z0.65459 E6766.737429 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.89 Y210.411025 Z0.747034 E6768.582784 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.548094 Y210.444699 Z0.772736 E6769.066217 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.832743 Y210.965046 Z0.927629 E6773.024711 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.462299 Y211.163052 Z0.968429 E6774.04179 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X245.229 Y211.199 Z1.046725 E6776.211984 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.860909 Y211.160463 Z1.226289 E6782.348441 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X247.304 Y211.15 Z1.277355 E6784.132777 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.456155 Y210.915255 Z1.533707 E6795.72701 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.486 Y210.912 Z1.537289 E6795.888366 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X252.418 Y210.995 Z1.876809 E6816.804477 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.948 Y210.854 Z2.130886 E6838.172739 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X256.839263 Y210.551082 Z2.28201 E6855.78801 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.102 Y210.509 Z2.299606 E6857.434028 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.868331 Y210.310713 Z2.346595 E6862.456435 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X258.045 Y210.265 Z2.356255 E6864.201684 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X259.682 Y209.646 Z2.425402 E6881.552017 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.382 Y209.275 Z2.442167 E6889.470075 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X261.562 Y208.422 Z2.448591 E6904.067393 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.047 Y207.944 Z2.4407 E6910.86709 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.175568 Y207.771479 Z2.436772 E6913.011407 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.354809 Y208.106815 Z2.428156 E6916.784377 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.241802 Y209.187619 Z2.378462 E6930.305651 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.609878 Y209.636122 Z2.349782 E6935.834173 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.139185 Y210.891191 Z2.219155 E6953.370889 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.781924 Y211.234742 Z2.159372 E6959.613755 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X266.883959 Y211.823792 Z2.044308 E6969.584144 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.391016 Y211.977606 Z1.991296 E6973.669948 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.682148 Y212.145915 Z1.805809 E6985.273281 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.788959 Y212.720208 Z1.575095 E6996.290417 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.586726 Y213.362815 Z1.412558 E7002.736026 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.044185 Y213.652809 Z1.339764 E7004.520323 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.666398 Y214.78353 Z1.136625 E7008.30002 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.514878 Y214.907878 Z1.212291 E7008.742715 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.136625 matz1=1.212291 note=collision lift
G1 X259.259809 Y216.437185 Z1.999718 E7011.75557 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.212291 matz1=1.999718 note=collision lift
G1 X258.551709 Y217.761946 Z2.625019 E7013.133392 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.999718 matz1=2.286759 note=collision lift
G1 X258.551253 Y217.7628 Z2.624454 E7013.134341 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.286759 matz1=2.286678 note=collision lift
G1 X258.543009 Y217.778222 Z2.631269 E7013.150234 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.286678 matz1=2.285214 note=collision lift
G1 X258.536742 Y217.789947 Z2.636803 E7013.162428 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.285214 matz1=2.284101 note=collision lift
G1 X258.508905 Y217.842026 Z2.654478 E7013.214626 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.284101 matz1=2.279157 note=collision lift
G1 X258.506809 Y217.845949 Z2.656329 E7013.218705 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.279157 matz1=2.278784 note=collision lift
G1 X258.449004 Y217.954095 Z2.685015 E7013.325349 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.278784 matz1=2.268517 note=collision lift
G1 X258.446942 Y217.957952 Z2.686836 E7013.32936 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.268517 matz1=2.268151 note=collision lift
G1 X258.327208 Y218.181959 Z2.733942 E7013.548115 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.268151 matz1=2.246885 note=collision lift
G1 X258.326904 Y218.182961 Z2.733355 E7013.54864 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.246885 matz1=2.246822 note=collision lift
G1 X258.251666 Y218.430988 Z2.772081 E7013.663297 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.246822 matz1=2.231189 note=collision lift
G1 X258.251229 Y218.432428 Z2.772743 E7013.664016 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.231189 matz1=2.231098 note=collision lift
G1 X257.939915 Y219.458692 Z2.909678 E7014.137031 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.231098 matz1=2.166412 note=collision lift
G1 X257.939701 Y219.459398 Z2.909264 E7014.137401 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.166412 matz1=2.166367 note=collision lift
G1 X257.764679 Y220.036366 Z2.983906 E7014.403204 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.166367 matz1=2.130001 note=collision lift
G1 X257.764598 Y220.036635 Z2.983749 E7014.403345 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.130001 matz1=2.129984 note=collision lift
G1 X257.753483 Y220.073275 Z2.988289 E7014.420214 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.129984 matz1=2.127674 note=collision lift
G1 X257.752915 Y220.075148 Z2.98915 E7014.421149 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.127674 matz1=2.127556 note=collision lift
G1 X257.639145 Y221.230279 Z3.119333 E7014.669023 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.127556 matz1=2.08902 note=collision lift
G1 X257.639046 Y221.231281 Z3.118796 E7014.669265 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.08902 matz1=2.088986 note=collision lift
G1 X257.632566 Y221.29707 Z3.126051 E7014.683379 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.088986 matz1=2.086791 note=collision lift
G1 X257.632506 Y221.297679 Z3.126337 E7014.683522 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086791 matz1=2.086771 note=collision lift
G1 X257.568973 Y221.942747 Z3.196514 E7014.821885 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086771 matz1=2.065251 note=collision lift
G1 X257.56894 Y221.943081 Z3.196335 E7014.821966 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.065251 matz1=2.06524 note=collision lift
G1 X257.559684 Y222.037052 Z3.205335 E7014.842096 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.06524 matz1=2.062105 note=collision lift
G1 X257.559 Y222.044 Z3.208594 E7014.843731 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.062105 matz1=2.061873 note=collision lift
G1 X257.63621 Y222.827924 Z3.261222 E7014.989615 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.061873 matz1=2.058688 note=collision lift
G1 X257.636277 Y222.828606 Z3.260876 E7014.989757 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058688 matz1=2.058685 note=collision lift
G1 X257.69256 Y223.400055 Z3.279494 E7015.09592 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058685 matz1=2.056364 note=collision lift
G1 X257.693159 Y223.406136 Z3.276414 E7015.097184 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056364 matz1=2.056339 note=collision lift
G1 X257.711544 Y223.592804 Z3.273171 E7015.13185 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056339 matz1=2.055581 note=collision lift
G1 X257.711698 Y223.594367 Z3.272379 E7015.132175 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055581 matz1=2.055575 note=collision lift
G1 X257.721036 Y223.689179 Z3.2655 E7015.149826 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055575 matz1=2.055189 note=collision lift
G1 X257.72116 Y223.690437 Z3.264863 E7015.150087 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055189 matz1=2.055184 note=collision lift
G1 X257.725782 Y223.737366 Z3.257923 E7015.158895 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055184 matz1=2.054994 note=collision lift
G1 X257.725902 Y223.738586 Z3.257305 E7015.159149 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054994 matz1=2.054989 note=collision lift
G1 X257.728046 Y223.760352 Z3.251808 E7015.163316 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054989 matz1=2.0549 note=collision lift
G1 X257.728155 Y223.76146 Z3.25236 E7015.163546 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.0549 matz1=2.054896 note=collision lift
G1 X257.752915 Y224.012852 Z3.125035 E7015.215819 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054896 matz1=2.053874 note=collision lift
G1 X258.321684 Y225.887831 Z2.195056 E7015.989872 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053874 matz1=2.10357 note=collision lift
G1 X258.327208 Y225.906041 Z2.205054 E7015.997544 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.10357 matz1=2.104053 note=collision lift
G1 X258.467892 Y226.169244 Z2.366748 E7016.133207 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.104053 matz1=2.116526 note=collision lift
G1 X259.259809 Y227.650815 Z3.299512 E7018.202583 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.116526 matz1=2.209322 note=collision lift
G1 X259.915626 Y228.449931 Z3.789734 E7020.34058 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.209322 matz1=2.289734 note=collision lift
G1 X259.999881 Y228.552595 Z3.800065 E7020.589513 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.289734 matz1=2.300065 note=collision lift
G1 X260.000901 Y228.553838 Z3.80019 E7020.592526 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.300065 matz1=2.30019 note=collision lift
G1 X260.084049 Y228.655154 Z3.810385 E7020.838189 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.30019 matz1=2.310385 note=collision lift
G1 X260.084136 Y228.65526 Z3.810395 E7020.838446 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.310385 matz1=2.310395 note=collision lift
G1 X260.514878 Y229.180122 Z3.86321 E7022.111089 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.310395 matz1=2.36321 note=collision lift
G1 X260.515388 Y229.18054 Z3.863275 E7022.112986 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.36321 matz1=2.363275 note=collision lift
G1 X260.756547 Y229.378454 Z3.893716 E7023.010056 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.363275 matz1=2.393716 note=collision lift
G1 X260.756688 Y229.37857 Z3.893734 E7023.010583 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.393716 matz1=2.393734 note=collision lift
G1 X261.370364 Y229.882201 Z3.949978 E7025.288266 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.393734 matz1=2.471198 note=collision lift
G1 X261.3706 Y229.882394 Z3.949855 E7025.289206 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.471198 matz1=2.471227 note=collision lift
G1 X262.044185 Y230.435191 Z3.949855 E7027.782994 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.471227 matz1=2.556254 note=collision lift
G1 X263.45599 Y231.189817 Z3.949855 E7034.179048 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.556254 matz1=2.734536 note=collision lift
G1 X263.788944 Y231.367784 Z3.943503 E7035.687676 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.734536 matz1=2.776581 note=collision lift
G1 X263.788959 Y231.367792 Z3.943514 E7035.687757 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.776581 matz1=2.776583 note=collision lift
G1 X264.167541 Y231.482634 Z3.937266 E7037.745111 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.776583 matz1=2.82339 note=collision lift
G1 X264.167568 Y231.482642 Z3.937255 E7037.745272 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.82339 matz1=2.823393 note=collision lift
G1 X264.20948 Y231.495356 Z3.936558 E7037.973037 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.823393 matz1=2.828575 note=collision lift
G1 X264.209629 Y231.495401 Z3.936655 E7037.973988 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.828575 matz1=2.828593 note=collision lift
G1 X265.386941 Y231.852535 Z3.916667 E7044.371988 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.828593 matz1=2.974152 note=collision lift
G1 X265.387021 Y231.852559 Z3.916635 E7044.372453 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.974152 matz1=2.974162 note=collision lift
G1 X265.681522 Y231.941895 Z3.902312 E7045.974413 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.974162 matz1=3.010573 note=collision lift
G1 X265.682148 Y231.942085 Z3.902717 E7045.978415 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.010573 matz1=3.01065 note=collision lift
G1 X266.211867 Y231.994258 Z3.876354 E7048.92355 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.01065 matz1=3.074119 note=collision lift
G1 X266.213597 Y231.994428 Z3.875689 E7048.931494 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.074119 matz1=3.074323 note=collision lift
G1 X266.244609 Y231.997483 Z3.873996 E7049.064661 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.074323 matz1=3.077986 note=collision lift
G1 X266.247222 Y231.99774 Z3.875617 E7049.077829 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.077986 matz1=3.078294 note=collision lift
G1 X266.961058 Y232.068047 Z3.829889 E7052.144771 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.078294 matz1=3.162589 note=collision lift
G1 X266.97597 Y232.069515 Z3.824158 E7052.213227 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.162589 matz1=3.16435 note=collision lift
G1 X266.998353 Y232.07172 Z3.819671 E7052.311089 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.16435 matz1=3.166993 note=collision lift
G1 X266.999424 Y232.071825 Z3.820335 E7052.316484 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.166993 matz1=3.16712 note=collision lift
G1 X267.040169 Y232.075838 Z3.804713 E7052.503475 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.16712 matz1=3.171931 note=collision lift
G1 X267.651 Y232.136 Z3.569951 E7055.307586 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.171931 matz1=3.244063 note=collision lift
G1 X269.619852 Y231.942085 Z2.799167 E7065.958094 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.244063 matz1=2.799167 note=collision lift
G1 X271.221194 Y231.456323 Z2.123151 E7076.187228 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.799167 matz1=2.123151 note=collision lift
G1 X271.513041 Y231.367792 Z2.152436 E7077.923731 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X273.257815 Y230.435191 Z2.302286 E7090.188607 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X274.787122 Y229.180122 Z2.402804 E7103.117196 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.042191 Y227.650815 Z2.447809 E7116.337945 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.974792 Y225.906041 Z2.434534 E7129.465489 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X277.549085 Y224.012852 Z2.363796 E7142.120804 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X277.743 Y222.044 Z2.239942 E7153.950715 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X277.549085 Y220.075148 Z2.070591 E7164.647311 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.974792 Y218.181959 Z1.866154 E7173.967039 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.042191 Y216.437185 Z1.639202 E7181.748067 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X274.787122 Y214.907878 Z1.403691 E7187.923576 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X273.719245 Y214.031495 Z1.243375 E7191.139117 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X273.257815 Y213.652809 Z1.472565 E7192.617528 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.243375 matz1=1.472565 note=collision lift
G1 X272.25901 Y213.118936 Z1.915557 E7194.915099 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.472565 matz1=1.915557 note=collision lift
G1 X271.513041 Y212.720208 Z2.252204 E7197.090977 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.915557 matz1=2.252204 note=collision lift
G1 X269.619852 Y212.145915 Z3.064768 E7200.259235 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.252204 matz1=2.287927 note=collision lift
G1 X268.638958 Y212.049305 Z3.491406 E7201.116198 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.287927 matz1=2.221745 note=collision lift
G1 X268.122425 Y211.998431 Z3.544343 E7201.532486 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.221745 matz1=2.186894 note=collision lift
G1 X268.121709 Y211.998361 Z3.544654 E7201.533112 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.186894 matz1=2.186845 note=collision lift
G1 X267.651 Y211.952 Z3.589589 E7201.91221 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.186845 matz1=2.155086 note=collision lift
G1 X267.650797 Y211.95202 Z3.589476 E7201.91238 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.155086 matz1=2.155075 note=collision lift
G1 X267.391016 Y211.977606 Z3.61136 E7202.102796 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.155075 matz1=2.141286 note=collision lift
G1 X267.391042 Y211.977614 Z3.611345 E7202.10281 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.141286 matz1=2.141285 note=collision lift
G1 X268.080134 Y212.186648 Z3.544497 E7202.407606 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.141285 matz1=2.111771 note=collision lift
G1 X268.080544 Y212.186772 Z3.544265 E7202.407811 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.111771 matz1=2.111753 note=collision lift
G1 X268.587191 Y212.340462 Z3.491296 E7202.632064 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.111753 matz1=2.090053 note=collision lift
G1 X268.777148 Y212.398085 Z3.383908 E7202.727183 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.090053 matz1=2.081917 note=collision lift
G1 X270.502789 Y212.568046 Z2.488992 E7203.229763 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.081917 matz1=2.053996 note=collision lift
G1 X270.745598 Y212.59196 Z2.514667 E7203.292951 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053996 matz1=2.050068 note=collision lift
G1 X270.746 Y212.592 Z2.514862 E7203.293066 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050068 matz1=2.050061 note=collision lift
G1 X271.136668 Y212.553523 Z2.550612 E7203.430524 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050061 matz1=2.054322 note=collision lift
G1 X271.144593 Y212.552742 Z2.55468 E7203.433642 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054322 matz1=2.054409 note=collision lift
G1 X272.193074 Y212.449476 Z2.636119 E7203.802128 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054409 matz1=2.065845 note=collision lift
G1 X272.200615 Y212.448733 Z2.632413 E7203.80507 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.065845 matz1=2.065927 note=collision lift
G1 X272.369712 Y212.432078 Z2.642061 E7203.864417 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.065927 matz1=2.067772 note=collision lift
G1 X272.370324 Y212.432018 Z2.642375 E7203.864658 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.067772 matz1=2.067778 note=collision lift
G1 X272.640393 Y212.405419 Z2.655039 E7203.93605 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.067778 matz1=2.074706 note=collision lift
G1 X272.641268 Y212.405332 Z2.654621 E7203.936306 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074706 matz1=2.074729 note=collision lift
G1 X272.712105 Y212.398356 Z2.657242 E7203.955024 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074729 matz1=2.076546 note=collision lift
G1 X272.714852 Y212.398085 Z2.658692 E7203.955843 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.076546 matz1=2.076616 note=collision lift
G1 X272.985098 Y212.316107 Z2.654982 E7204.110791 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.076616 matz1=2.088512 note=collision lift
G1 X272.987516 Y212.315373 Z2.653825 E7204.112315 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.088512 matz1=2.088618 note=collision lift
G1 X273.120221 Y212.275117 Z2.644704 E7204.18856 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.088618 matz1=2.094459 note=collision lift
G1 X273.122071 Y212.274557 Z2.64382 E7204.189726 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.094459 matz1=2.094541 note=collision lift
G1 X273.187783 Y212.254623 Z2.634531 E7204.227743 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.094541 matz1=2.097433 note=collision lift
G1 X273.189536 Y212.254091 Z2.633692 E7204.228848 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.097433 matz1=2.097511 note=collision lift
G1 X273.220209 Y212.244786 Z2.626307 E7204.246894 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.097511 matz1=2.098861 note=collision lift
G1 X273.221564 Y212.244376 Z2.627074 E7204.247777 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.098861 matz1=2.09892 note=collision lift
G1 X274.608041 Y211.823792 Z1.963671 E7205.122014 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.09892 matz1=1.963671 note=collision lift
G1 X276.352815 Y210.891191 Z1.10947 E7207.301964 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.963671 matz1=1.10947 note=collision lift
G1 X276.839089 Y210.492117 Z0.851644 E7208.405581 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.10947 matz1=0.851644 note=collision lift
G1 X277.882122 Y209.636122 Z0.973279 E7210.604832 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X279.137191 Y208.106815 Z1.184008 E7215.272588 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X280.069792 Y206.362041 Z1.414167 E7221.517727 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X280.644085 Y204.468852 Z1.649604 E7229.373689 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X280.838 Y202.5 Z1.875843 E7238.770646 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X280.644085 Y200.531148 Z2.07897 E7249.541456 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X280.069792 Y198.637959 Z2.246498 E7261.43515 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X279.137191 Y196.893185 Z2.368123 E7274.135682 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X277.882122 Y195.363878 Z2.436368 E7287.283191 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.352815 Y194.108809 Z2.447037 E7300.49547 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X274.608041 Y193.176208 Z2.399473 E7313.388522 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X272.714852 Y192.601915 Z2.2966 E7325.596256 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X272.370324 Y192.567982 Z2.273335 E7327.70672 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X271.005984 Y192.433606 Z2.167299 E7339.501955 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X271.513041 Y192.279792 Z2.12083 E7343.937552 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X272.25901 Y191.881064 Z2.041038 E7350.67363 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X273.257815 Y191.347191 Z1.924809 E7356.237419 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X274.787122 Y190.092122 Z1.702667 E7364.449688 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.042191 Y188.562815 Z1.468063 E7371.064735 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.974792 Y186.818041 Z1.235422 E7376.089503 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X277.549085 Y184.924852 Z1.019051 E7379.632648 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X277.743 Y182.956 Z0.832252 E7381.897253 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X277.549085 Y180.987148 Z0.686513 E7383.166314 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.974792 Y179.093959 Z0.590795 E7383.783148 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X276.042191 Y177.349185 Z0.550984 E7384.12918 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X274.787122 Y175.819878 Z0.569526 E7384.600988 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X273.257815 Y174.564809 Z0.645283 E7385.587567 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X271.513041 Y173.632208 Z0.773597 E7387.448023 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X269.619852 Y173.057915 Z0.946576 E7390.48993 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.651 Y172.864 Z1.153585 E7394.949199 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X266.211867 Y173.005742 Z1.319154 E7399.038782 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.682148 Y173.057915 Z1.381894 E7401.470613 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.788959 Y173.632208 Z1.617466 E7412.925219 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.044185 Y174.564809 Z1.845815 E7426.714696 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.514878 Y175.819878 Z2.052901 E7442.607423 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X259.259809 Y177.349185 Z2.225988 E7460.242692 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X258.467892 Y178.830756 Z2.338264 E7476.166527 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X258.327208 Y179.093959 Z2.354435 E7478.067589 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.752915 Y180.987148 Z2.430343 E7491.176037 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.559 Y182.956 Z2.449045 E7504.402344 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.752915 Y184.924852 Z2.409391 E7517.36158 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X258.327208 Y186.818041 Z2.313819 E7529.684039 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X259.259809 Y188.562815 Z2.168206 E7541.034671 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.514878 Y190.092122 Z1.981505 E7551.132445 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.044185 Y191.347191 Z1.765197 E7559.768904 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.586726 Y191.637185 Z1.693954 E7562.30503 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.788959 Y192.279792 Z1.532581 E7569.597659 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X264.288036 Y192.431186 Z1.470732 E7571.7538 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.682148 Y192.854085 Z2.026385 E7578.155086 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.470732 matz1=2.026385 note=collision lift
G1 X267.651 Y193.048 Z2.793378 E7584.44061 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.026385 matz1=2.575767 note=collision lift
G1 X269.619852 Y192.854085 Z3.586458 E7588.603939 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.575767 matz1=2.379658 note=collision lift
G1 X269.809809 Y192.796462 Z3.669266 E7588.89128 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.379658 matz1=2.363213 note=collision lift
G1 X271.005984 Y192.433606 Z3.759662 E7590.565571 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.363213 matz1=2.259662 note=collision lift
G1 X271.002332 Y192.433247 Z3.759393 E7590.570124 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.259662 matz1=2.259393 note=collision lift
G1 X270.746575 Y192.408057 Z3.740564 E7590.888998 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.259393 matz1=2.240564 note=collision lift
G1 X270.746 Y192.408 Z3.740521 E7590.889715 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.240564 matz1=2.240521 note=collision lift
G1 X269.758042 Y192.505305 Z3.667594 E7591.521932 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.240521 matz1=2.181775 note=collision lift
G1 X268.991859 Y192.580768 Z3.237089 E7592.082167 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.181775 matz1=2.136215 note=collision lift
G1 X268.777148 Y192.601915 Z3.224322 E7592.219436 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.136215 matz1=2.123448 note=collision lift
G1 X267.989208 Y192.840934 Z3.198029 E7592.4749 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.123448 matz1=2.097155 note=collision lift
G1 X267.661606 Y192.940311 Z3.408767 E7592.599562 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.097155 matz1=2.086223 note=collision lift
G1 X267.658214 Y192.94134 Z3.408654 E7592.600662 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086223 matz1=2.086109 note=collision lift
G1 X267.391862 Y193.022137 Z3.577221 E7592.701569 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086109 matz1=2.077221 note=collision lift
G1 X267.391016 Y193.022394 Z3.577193 E7592.701844 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077221 matz1=2.077193 note=collision lift
G1 X267.390987 Y193.022402 Z3.577181 E7592.701854 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077193 matz1=2.077192 note=collision lift
G1 X267.390908 Y193.022426 Z3.57719 E7592.701879 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077192 matz1=2.07719 note=collision lift
G1 X267.39083 Y193.02245 Z3.577157 E7592.701907 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.07719 matz1=2.077187 note=collision lift
G1 X267.39061 Y193.022517 Z3.57718 E7592.701978 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077187 matz1=2.07718 note=collision lift
G1 X267.390313 Y193.022607 Z3.577055 E7592.702082 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.07718 matz1=2.07717 note=collision lift
G1 X267.389484 Y193.022858 Z3.577142 E7592.702352 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.07717 matz1=2.077142 note=collision lift
G1 X267.388357 Y193.0232 Z3.576672 E7592.702745 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077142 matz1=2.077104 note=collision lift
G1 X267.385225 Y193.02415 Z3.577 E7592.703766 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077104 matz1=2.077 note=collision lift
G1 X267.380965 Y193.025442 Z3.575221 E7592.705252 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077 matz1=2.076858 note=collision lift
G1 X267.36912 Y193.029036 Z3.576463 E7592.70911 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.076858 matz1=2.076463 note=collision lift
G1 X267.353016 Y193.033921 Z3.569736 E7592.71473 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.076463 matz1=2.075925 note=collision lift
G1 X267.308232 Y193.047506 Z3.574431 E7592.729315 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.075925 matz1=2.074431 note=collision lift
G1 X267.247343 Y193.065976 Z3.548999 E7592.750564 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074431 matz1=2.072399 note=collision lift
G1 X267.078017 Y193.117341 Z3.566749 E7592.80571 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.072399 matz1=2.066749 note=collision lift
G1 X266.895955 Y193.172569 Z3.560673 E7592.864738 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.066749 matz1=2.060673 note=collision lift
G1 X266.883959 Y193.176208 Z3.560273 E7592.868627 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060673 matz1=2.060273 note=collision lift
G1 X266.850636 Y193.194019 Z3.54382 E7592.879238 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060273 matz1=2.059964 note=collision lift
G1 X266.083126 Y193.604262 Z3.164862 E7593.123641 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059964 matz1=2.052841 note=collision lift
G1 X266.075565 Y193.608303 Z3.156218 E7593.126775 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052841 matz1=2.052771 note=collision lift
G1 X265.781924 Y193.765258 Z2.997896 E7593.221704 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052771 matz1=2.050046 note=collision lift
G1 X265.781507 Y193.765481 Z2.997426 E7593.221893 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050046 matz1=2.050049 note=collision lift
G1 X265.560288 Y193.883725 Z2.869452 E7593.301404 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050049 matz1=2.051713 note=collision lift
G1 X265.557437 Y193.885249 Z2.869473 E7593.302317 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051713 matz1=2.051735 note=collision lift
G1 X265.549504 Y193.889489 Z2.864255 E7593.305253 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051735 matz1=2.051794 note=collision lift
G1 X265.33295 Y194.005239 Z2.844574 E7593.374809 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051794 matz1=2.053424 note=collision lift
G1 X265.310529 Y194.017223 Z2.832032 E7593.382813 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053424 matz1=2.053592 note=collision lift
G1 X265.303611 Y194.020921 Z2.82998 E7593.385103 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053592 matz1=2.053644 note=collision lift
G1 X265.30041 Y194.022632 Z2.82819 E7593.386245 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053644 matz1=2.053668 note=collision lift
G1 X265.289726 Y194.028343 Z2.823223 E7593.389942 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053668 matz1=2.053749 note=collision lift
G1 X265.288941 Y194.028762 Z2.823674 E7593.390224 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053749 matz1=2.053755 note=collision lift
G1 X265.139185 Y194.108809 Z2.739898 E7593.443688 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053755 matz1=2.054881 note=collision lift
G1 X263.609878 Y195.363878 Z1.803432 E7594.655458 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054881 matz1=1.803432 note=collision lift
G1 X263.241802 Y195.812381 Z1.539433 E7595.093961 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.803432 matz1=1.539433 note=collision lift
G1 X262.354809 Y196.893185 Z0.921839 E7596.786304 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.539433 matz1=0.921839 note=collision lift
G1 X262.159991 Y197.257663 Z0.747758 E7597.642402 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.921839 matz1=0.747758 note=collision lift
G1 X261.422208 Y198.637959 Z0.871053 E7600.639504 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.847915 Y200.531148 Z1.06558 E7606.424082 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.702592 Y202.006632 Z1.229595 E7612.023374 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.654 Y202.5 Z1.286818 E7613.370176 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.655646 Y202.516709 Z1.288784 E7613.419162 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.702592 Y202.993368 Z1.584352 E7615.050139 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.288784 matz1=1.584352 note=collision lift
G1 X260.847915 Y204.468852 Z2.50196 E7624.210756 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.584352 matz1=2.50196 note=collision lift
G1 X261.422208 Y206.362041 Z3.724194 E7639.216642 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.50196 matz1=3.254211 note=collision lift
G1 X261.586322 Y206.669077 Z3.936931 E7642.221941 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.254211 matz1=3.292875 note=collision lift
G1 X261.635801 Y206.761646 Z3.940754 E7642.995606 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.292875 matz1=3.304532 note=collision lift
G1 X261.636668 Y206.763268 Z3.941878 E7643.011485 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.304532 matz1=3.304737 note=collision lift
G1 X261.876654 Y207.212251 Z3.94922 E7646.76187 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.304737 matz1=3.361276 note=collision lift
G1 X261.877417 Y207.213677 Z3.948591 E7646.774651 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.361276 matz1=3.361456 note=collision lift
G1 X262.175568 Y207.771479 Z3.948591 E7651.433523 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.361456 matz1=3.431698 note=collision lift
G1 X262.389168 Y207.484855 Z3.948591 E7654.271985 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.431698 matz1=3.468264 note=collision lift
G1 X262.389181 Y207.484838 Z3.948604 E7654.272176 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.468264 matz1=3.468267 note=collision lift
G1 X262.793936 Y206.941709 Z3.940713 E7659.651192 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.468267 matz1=3.537556 note=collision lift
G1 X262.793956 Y206.941683 Z3.9407 E7659.651474 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.537556 matz1=3.537559 note=collision lift
G1 X262.827999 Y206.896001 Z3.939659 E7660.103938 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.537559 matz1=3.543387 note=collision lift
G1 X262.828 Y206.896 Z3.93966 E7660.103954 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.543387 matz1=3.543387 note=collision lift
G1 X262.902925 Y206.754891 Z3.936773 E7661.422814 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.543387 matz1=3.558577 note=collision lift
G1 X263.128 Y206.331 Z3.742433 E7665.696437 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.558577 matz1=3.604208 note=collision lift
G1 X263.568 Y205.129 Z3.212044 E7677.913386 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.604208 matz1=3.212044 note=collision lift
G1 X263.812 Y203.846 Z2.651872 E7691.122241 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.212044 matz1=2.651872 note=collision lift
G1 X263.850923 Y203.156644 Z2.346667 E7698.315784 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.651872 matz1=2.346667 note=collision lift
G1 X263.856244 Y203.06241 Z2.352138 E7699.216692 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.888 Y202.5 Z2.379706 E7702.852842 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.856244 Y201.93759 Z2.402868 E7706.532504 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.812 Y201.154 Z2.427579 E7714.319797 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.568 Y199.871 Z2.448637 E7727.414884 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X263.128 Y198.669 Z2.444539 E7740.220739 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.828 Y198.104 Z2.433321 E7746.584751 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.246775 Y197.324071 Z2.402407 E7756.056727 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.223356 Y197.292647 Z2.420757 E7756.477913 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.402407 matz1=2.420757 note=collision lift
G1 X262.221975 Y197.290794 Z2.422995 E7756.509227 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.420757 matz1=2.422995 note=collision lift
G1 X262.200246 Y197.261637 Z2.421839 E7756.863331 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.422995 matz1=2.421839 note=collision lift
G1 X262.178697 Y197.23272 Z2.420693 E7757.214515 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.421839 matz1=2.420693 note=collision lift
G1 X262.177234 Y197.230757 Z2.421839 E7757.240824 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.420693 matz1=2.421839 note=collision lift
G1 X262.175771 Y197.228794 Z2.422985 E7757.267132 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.421839 matz1=2.422985 note=collision lift
G1 X262.175568 Y197.228521 Z2.423315 E7757.271746 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.422985 matz1=2.423315 note=collision lift
G1 X262.147819 Y197.191285 Z2.421839 E7757.723963 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.423315 matz1=2.421839 note=collision lift
G1 X262.118305 Y197.151683 Z2.395574 E7758.268428 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.421839 matz1=2.395574 note=collision lift
G1 X262.082922 Y197.104202 Z2.393692 E7758.845065 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.047 Y197.056 Z2.421839 E7759.491126 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.393692 matz1=2.421839 note=collision lift
G1 X262.004185 Y197.013803 Z2.389023 E7760.14672 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.421839 matz1=2.389023 note=collision lift
G1 X261.562 Y196.578 Z2.360532 E7766.095908 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.382 Y195.725 Z2.272937 E7779.401246 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X259.682 Y195.354 Z2.214213 E7786.407559 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X258.045 Y194.735 Z2.060352 E7800.511556 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.868331 Y194.689287 Z2.042614 E7801.966718 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.102 Y194.491 Z1.962493 E7805.957736 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X257.042873 Y194.48153 Z1.956192 E7806.253989 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X256.839263 Y194.448918 Z2.037595 E7807.344764 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.956192 matz1=2.037595 note=collision lift
G1 X254.948 Y194.146 Z2.781371 E7820.247975 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.037595 matz1=2.781371 note=collision lift
G1 X253.107416 Y194.043422 Z3.484567 E7829.588992 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.781371 matz1=3.00206 note=collision lift
G1 X253.083251 Y194.042075 Z3.487397 E7829.704359 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.00206 matz1=2.999191 note=collision lift
G1 X253.081238 Y194.041963 Z3.488166 E7829.714576 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.999191 matz1=2.998952 note=collision lift
G1 X252.418 Y194.005 Z3.551774 E7832.873871 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.998952 matz1=2.920209 note=collision lift
G1 X252.417567 Y194.005012 Z3.551506 E7832.876106 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.920209 matz1=2.920158 note=collision lift
G1 X251.858777 Y194.020831 Z3.603347 E7835.342168 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.920158 matz1=2.85391 note=collision lift
G1 X251.85762 Y194.020863 Z3.603789 E7835.347612 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.85391 matz1=2.853773 note=collision lift
G1 X252.933659 Y193.445709 Z3.488181 E7839.453261 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.853773 matz1=2.713499 note=collision lift
G1 X252.934608 Y193.445201 Z3.48752 E7839.457493 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.713499 matz1=2.713375 note=collision lift
G1 X252.960021 Y193.431618 Z3.484564 E7839.554532 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.713375 matz1=2.710062 note=collision lift
G1 X253.412134 Y193.189958 Z3.169303 E7841.57064 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.710062 matz1=2.651124 note=collision lift
G1 X254.797784 Y192.052784 Z2.084485 E7846.557125 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.651124 matz1=2.084485 note=collision lift
G1 X255.137281 Y191.639106 Z1.767955 E7847.595747 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.084485 matz1=1.767955 note=collision lift
G1 X255.75407 Y190.887547 Z2.165142 E7849.350159 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.767955 matz1=2.165142 note=collision lift
G1 X255.934958 Y190.667134 Z2.284207 E7849.669362 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.165142 matz1=2.284207 note=collision lift
G1 X256.779954 Y189.086257 Z3.05439 E7850.84106 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.284207 matz1=2.175094 note=collision lift
G1 X257.267098 Y187.480361 Z3.596074 E7851.389581 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.175094 matz1=2.096074 note=collision lift
G1 X257.300253 Y187.371064 Z3.590696 E7851.425147 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.096074 matz1=2.090696 note=collision lift
G1 X257.300301 Y187.370906 Z3.590688 E7851.425198 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.090696 matz1=2.090688 note=collision lift
G1 X257.324315 Y187.127084 Z3.585431 E7851.469097 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.090688 matz1=2.085431 note=collision lift
G1 X257.324804 Y187.122117 Z3.585324 E7851.469991 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.085431 matz1=2.085324 note=collision lift
G1 X257.422481 Y186.130386 Z3.563942 E7851.648544 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.085324 matz1=2.063942 note=collision lift
G1 X257.422755 Y186.127605 Z3.563882 E7851.649044 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.063942 matz1=2.063882 note=collision lift
G1 X257.476 Y185.587 Z3.552226 E7851.746376 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.063882 matz1=2.052226 note=collision lift
G1 X257.475995 Y185.586949 Z3.552227 E7851.746387 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052226 matz1=2.052227 note=collision lift
G1 X257.338045 Y184.186317 Z3.559627 E7852.044007 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.052227 matz1=2.059627 note=collision lift
G1 X257.300301 Y183.803094 Z3.561652 E7852.125437 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059627 matz1=2.061652 note=collision lift
G1 X256.779954 Y182.087743 Z3.618489 E7852.854313 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.061652 matz1=2.118489 note=collision lift
G1 X256.740036 Y182.013061 Z3.623278 E7852.918276 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.118489 matz1=2.123278 note=collision lift
G1 X256.739521 Y182.012097 Z3.62334 E7852.919101 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.123278 matz1=2.12334 note=collision lift
G1 X256.449381 Y181.469283 Z3.658149 E7853.384003 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.12334 matz1=2.158149 note=collision lift
G1 X255.934958 Y180.506866 Z3.455369 E7854.221052 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.158149 matz1=2.219866 note=collision lift
G1 X254.797784 Y179.121216 Z2.699895 E7856.627398 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.219866 matz1=2.36066 note=collision lift
G1 X253.412134 Y177.984042 Z1.976724 E7860.166114 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.36066 matz1=1.976724 note=collision lift
G1 X251.831257 Y177.139046 Z1.27711 E7864.986848 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.976724 matz1=1.27711 note=collision lift
G1 X251.741885 Y177.111935 Z1.241369 E7865.309496 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.27711 matz1=1.241369 note=collision lift
G1 X250.115906 Y176.618699 Z1.44069 E7870.829414 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.832002 Y176.590737 Z1.474711 E7871.789916 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.332 Y176.443 Z1.653964 E7880.801667 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.548094 Y176.618699 Z1.859458 E7893.421348 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.832743 Y177.139046 Z2.04679 E7907.764266 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X243.251866 Y177.984042 Z2.206494 E7923.564707 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X242.695423 Y178.440703 Z2.260978 E7930.10518 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X241.866216 Y179.121216 Z2.330502 E7940.228836 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.946908 Y180.241395 Z2.400304 E7954.413125 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.729042 Y180.506866 Z2.412548 E7957.794547 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.884046 Y182.087743 Z2.448486 E7975.768018 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.819797 Y182.299542 Z2.44928 E7977.988541 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.762073 Y182.489834 Z2.549421 E7980.222249 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.44928 matz1=2.549421 note=collision lift
G1 X240.33 Y181.973 Z2.929283 E7988.799266 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.549421 matz1=2.929283 note=collision lift
G1 X241.455769 Y180.791414 Z3.707538 E8006.549821 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.929283 matz1=3.707538 note=collision lift
G1 X241.762 Y180.47 Z3.912548 E8011.307744 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.707538 matz1=3.891192 note=collision lift
G1 X241.949518 Y180.236796 Z3.912548 E8014.032899 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.891192 matz1=3.874441 note=collision lift
G1 X242.166428 Y179.967039 Z3.900304 E8017.187176 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.874441 matz1=3.855065 note=collision lift
G1 X242.456812 Y179.605906 Z3.878157 E8021.412083 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.855065 matz1=3.829126 note=collision lift
G1 X242.461595 Y179.599959 Z3.877792 E8021.481662 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.829126 matz1=3.828698 note=collision lift
G1 X242.461596 Y179.599957 Z3.877793 E8021.481681 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.828698 matz1=3.828698 note=collision lift
G1 X243.081565 Y178.828941 Z3.830503 E8030.501837 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.828698 matz1=3.773317 note=collision lift
G1 X243.118113 Y178.783489 Z3.827174 E8031.033845 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.773317 matz1=3.770053 note=collision lift
G1 X243.118115 Y178.783487 Z3.827173 E8031.03387 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.770053 matz1=3.770052 note=collision lift
G1 X243.11953 Y178.781726 Z3.827043 E8031.054454 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.770052 matz1=3.769894 note=collision lift
G1 X243.136944 Y178.760069 Z3.825453 E8031.307639 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.769894 matz1=3.767946 note=collision lift
G1 X243.137 Y178.76 Z3.825492 E8031.30852 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.767946 matz1=3.76794 note=collision lift
G1 X243.884077 Y178.053921 Z3.761021 E8039.335709 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.76794 matz1=3.679245 note=collision lift
G1 X243.884102 Y178.053897 Z3.761 E8039.336022 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.679245 matz1=3.679242 note=collision lift
G1 X244.42204 Y177.545481 Z3.706546 E8045.120301 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.679242 matz1=3.615376 note=collision lift
G1 X244.42231 Y177.545225 Z3.7067 E8045.123442 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.615376 matz1=3.615344 note=collision lift
G1 X244.839231 Y177.151184 Z3.658355 E8049.610233 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.615344 matz1=3.565846 note=collision lift
G1 X244.839527 Y177.150904 Z3.658116 E8049.613914 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.565846 matz1=3.565811 note=collision lift
G1 X244.841553 Y177.14899 Z3.657877 E8049.635718 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.565811 matz1=3.56557 note=collision lift
G1 X244.841864 Y177.148696 Z3.658054 E8049.639324 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.56557 matz1=3.565533 note=collision lift
G1 X245.26861 Y176.745368 Z3.606872 E8054.23299 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.565533 matz1=3.514869 note=collision lift
G1 X245.269 Y176.745 Z3.607093 E8054.237512 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.514869 matz1=3.514822 note=collision lift
G1 X245.707546 Y176.255074 Z3.547864 E8058.445932 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.514822 matz1=3.443245 note=collision lift
G1 X245.711781 Y176.250343 Z3.550348 E8058.489392 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.443245 matz1=3.442554 note=collision lift
G1 X246.252957 Y175.645763 Z3.440731 E8063.708726 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.442554 matz1=3.354226 note=collision lift
G1 X246.256395 Y175.641921 Z3.437592 E8063.747202 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.354226 matz1=3.353664 note=collision lift
G1 X246.50014 Y175.36962 Z3.366156 E8066.120908 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.353664 matz1=3.313881 note=collision lift
G1 X246.959 Y174.857 Z2.947267 E8071.255445 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.313881 matz1=2.947267 note=collision lift
G1 X247.380281 Y174.274525 Z2.50392 E8076.274559 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.947267 matz1=2.50392 note=collision lift
G1 X248.081264 Y173.305326 Z1.763758 E8083.605361 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.50392 matz1=1.763758 note=collision lift
G1 X248.237 Y173.09 Z1.599164 E8085.183438 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.763758 matz1=1.599164 note=collision lift
G1 X248.356729 Y172.886823 Z1.453205 E8086.418159 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.599164 matz1=1.453205 note=collision lift
G1 X248.732 Y172.25 Z1.365307 E8089.732083 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.452 Y170.655 Z1.163411 E8095.744729 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.684 Y169.898 Z1.076833 E8098.108469 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.693064 Y169.841576 Z1.070735 E8098.277229 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.275809 Y170.931815 Z0.94478 E8101.120763 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.530878 Y172.461122 Z0.772173 E8103.901631 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X252.955676 Y173.630423 Z0.651455 E8105.340959 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.060185 Y173.716191 Z0.64432 E8105.407976 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.584922 Y173.996669 Z0.621693 E8105.549062 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.804959 Y174.648792 Z1.260775 E8105.910144 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.621693 matz1=1.260775 note=collision lift
G1 X256.60448 Y175.194671 Z2.18254 E8106.273613 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.260775 matz1=2.0506 note=collision lift
G1 X256.698148 Y175.223085 Z2.231968 E8106.302435 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.0506 matz1=2.051087 note=collision lift
G1 X258.667 Y175.417 Z3.261509 E8107.351639 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051087 matz1=2.091439 note=collision lift
G1 X259.277831 Y175.356838 Z3.598254 E8108.02757 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.091439 matz1=2.121291 note=collision lift
G1 X259.315377 Y175.35314 Z3.611769 E8108.066262 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.121291 matz1=2.123125 note=collision lift
G1 X259.316817 Y175.352999 Z3.611116 E8108.067795 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.123125 matz1=2.123196 note=collision lift
G1 X259.351993 Y175.349534 Z3.617362 E8108.10245 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.123196 matz1=2.124915 note=collision lift
G1 X259.352923 Y175.349442 Z3.617875 E8108.103479 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.124915 matz1=2.12496 note=collision lift
G1 X259.42685 Y175.342161 Z3.625496 E8108.175576 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.12496 matz1=2.128573 note=collision lift
G1 X259.428015 Y175.342047 Z3.626139 E8108.176865 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.128573 matz1=2.12863 note=collision lift
G1 X259.576534 Y175.327419 Z3.633349 E8108.32112 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.12863 matz1=2.135888 note=collision lift
G1 X259.578199 Y175.327255 Z3.634267 E8108.322963 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.135888 matz1=2.13597 note=collision lift
G1 X259.876017 Y175.297922 Z3.636361 E8108.611901 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.13597 matz1=2.150524 note=collision lift
G1 X259.878567 Y175.297671 Z3.637766 E8108.614722 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.150524 matz1=2.150649 note=collision lift
G1 X260.457826 Y175.240619 Z3.622211 E8109.176895 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.150649 matz1=2.178958 note=collision lift
G1 X260.462455 Y175.240163 Z3.620112 E8109.181822 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.178958 matz1=2.179184 note=collision lift
G1 X260.632849 Y175.223381 Z3.612593 E8109.34729 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.179184 matz1=2.187511 note=collision lift
G1 X260.635852 Y175.223085 Z3.614248 E8109.350613 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.187511 matz1=2.187658 note=collision lift
G1 X261.439926 Y174.979172 Z3.554814 E8110.797372 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.187658 matz1=2.249739 note=collision lift
G1 X261.445347 Y174.977527 Z3.5524 E8110.807948 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.249739 matz1=2.250157 note=collision lift
G1 X261.596738 Y174.931603 Z3.537261 E8111.080907 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.250157 matz1=2.261846 note=collision lift
G1 X261.597542 Y174.93136 Z3.537742 E8111.082569 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.261846 matz1=2.261908 note=collision lift
G1 X262.196016 Y174.749814 Z3.474853 E8112.162128 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.261908 matz1=2.308115 note=collision lift
G1 X262.197256 Y174.749438 Z3.4743 E8112.164548 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.308115 matz1=2.308211 note=collision lift
G1 X262.528873 Y174.648843 Z3.437284 E8112.76312 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.308211 matz1=2.333814 note=collision lift
G1 X262.529041 Y174.648792 Z3.437385 E8112.763468 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.333814 matz1=2.333827 note=collision lift
G1 X263.256449 Y174.259985 Z3.34616 E8114.987654 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.333827 matz1=2.411844 note=collision lift
G1 X263.257496 Y174.259425 Z3.345678 E8114.99109 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.411844 matz1=2.411956 note=collision lift
G1 X264.273375 Y173.716427 Z3.212724 E8118.099002 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.411956 matz1=2.520912 note=collision lift
G1 X264.273815 Y173.716191 Z3.213021 E8118.100558 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.520912 matz1=2.520959 note=collision lift
G1 X264.94677 Y173.163911 Z3.117934 E8121.42367 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.520959 matz1=2.616266 note=collision lift
G1 X264.947636 Y173.163201 Z3.118617 E8121.428647 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.616266 matz1=2.616389 note=collision lift
G1 X265.561312 Y172.65957 Z3.023455 E8124.462683 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.616389 matz1=2.703301 note=collision lift
G1 X265.564275 Y172.657138 Z3.021958 E8124.478299 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.703301 matz1=2.70372 note=collision lift
G1 X265.803122 Y172.461122 Z2.982167 E8125.660454 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.70372 matz1=2.737547 note=collision lift
G1 X265.803457 Y172.460713 Z2.981963 E8125.662648 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.737547 matz1=2.737608 note=collision lift
G1 X265.884244 Y172.362273 Z2.965018 E8126.16005 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.737608 matz1=2.752253 note=collision lift
G1 X265.88586 Y172.360304 Z2.966584 E8126.171627 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.752253 matz1=2.752546 note=collision lift
G1 X266.233362 Y171.936873 Z2.884554 E8128.014927 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.752546 matz1=2.817084 note=collision lift
G1 X266.233864 Y171.93626 Z2.885044 E8128.018027 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.817084 matz1=2.817178 note=collision lift
G1 X267.058191 Y170.931815 Z2.388442 E8132.647449 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.817178 matz1=2.388442 note=collision lift
G1 X267.923835 Y169.312309 Z1.687987 E8140.769437 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.388442 matz1=1.687987 note=collision lift
G1 X267.990792 Y169.187041 Z1.704827 E8141.360527 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X268.565085 Y167.293852 Z1.926786 E8151.103069 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X268.759 Y165.325 Z2.122502 E8162.166693 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X268.565085 Y163.356148 Z2.279941 E8174.283099 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.990792 Y161.462959 Z2.389422 E8187.123845 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X267.058191 Y159.718185 Z2.444213 E8200.32183 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X265.803122 Y158.188878 Z2.440945 E8213.492597 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X264.273815 Y156.933809 Z2.379819 E8226.254645 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X262.529041 Y156.001208 Z2.264593 E8238.249005 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X260.635852 Y155.426915 Z2.102353 E8249.158653 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X258.667 Y155.233 Z1.903074 E8258.727728 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X256.698148 Y155.426915 Z1.679011 E8266.779335 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.804959 Y156.001208 Z1.44394 E8273.229725 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.017389 Y156.422173 Z1.338093 E8275.814775 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.060185 Y156.933809 Z1.212317 E8279.819046 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.530878 Y158.188878 Z0.998383 E8284.921462 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.431137 Y159.528917 Z0.835876 E8287.930238 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.275809 Y159.718185 Z0.815293 E8288.328817 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X249.343208 Y161.462959 Z0.674305 E8290.107501 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.768915 Y163.356148 Z0.584089 E8290.9643 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.659697 Y164.465053 Z0.557854 E8291.29606 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.616998 Y164.898583 Z0.552796 E8291.412791 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.610942 Y164.960079 Z0.582976 E8291.431217 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.552796 matz1=0.582976 note=collision lift
G1 X248.575 Y165.325 Z0.764432 E8291.536867 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.582976 matz1=0.764432 note=collision lift
G1 X248.58669 Y165.443694 Z0.823887 E8291.571158 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.764432 matz1=0.823887 note=collision lift
G1 X248.768915 Y167.293852 Z1.778127 E8292.374259 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.823887 matz1=1.778127 note=collision lift
G1 X249.194095 Y168.695483 Z2.570743 E8293.711784 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.778127 matz1=2.134964 note=collision lift
G1 X249.207316 Y168.739068 Z2.576446 E8293.748649 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.134964 matz1=2.136838 note=collision lift
G1 X249.208231 Y168.742083 Z2.578151 E8293.751527 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.136838 matz1=2.136968 note=collision lift
G1 X249.343208 Y169.187041 Z2.638129 E8294.128056 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.136968 matz1=2.1561 note=collision lift
G1 X249.343814 Y169.188175 Z2.637562 E8294.129505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.1561 matz1=2.156176 note=collision lift
G1 X249.458001 Y169.401804 Z2.663422 E8294.38067 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.156176 matz1=2.170634 note=collision lift
G1 X249.459722 Y169.405024 Z2.665465 E8294.384983 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.170634 matz1=2.170852 note=collision lift
G1 X249.693064 Y169.841576 Z2.711924 E8294.897585 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.170852 matz1=2.200396 note=collision lift
G1 X249.693958 Y169.83601 Z2.709517 E8294.907124 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.200396 matz1=2.200808 note=collision lift
G1 X249.728469 Y169.621175 Z2.684398 E8295.247974 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.200808 matz1=2.216679 note=collision lift
G1 X249.757121 Y169.442812 Z2.753869 E8295.549162 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.216679 matz1=2.229856 note=collision lift
G1 X249.757123 Y169.442802 Z2.753869 E8295.549176 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.229856 matz1=2.229856 note=collision lift
G1 X249.882258 Y168.663823 Z3.061777 E8296.867108 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.229856 matz1=2.287404 note=collision lift
G1 X249.882323 Y168.663418 Z3.061807 E8296.867748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.287404 matz1=2.287434 note=collision lift
G1 X249.891322 Y168.607399 Z3.084122 E8296.962623 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.287434 matz1=2.291573 note=collision lift
G1 X249.915 Y168.46 Z3.095011 E8297.195554 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.291573 matz1=2.302462 note=collision lift
G1 X249.92 Y167.779 Z3.15269 E8298.461929 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.302462 matz1=2.360141 note=collision lift
G1 X249.731 Y166.486 Z3.276087 E8301.727257 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.360141 matz1=2.483538 note=collision lift
G1 X249.544 Y165.874 Z2.701875 E8304.156921 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.483538 matz1=2.549258 note=collision lift
G1 X249.4315 Y165.631675 Z2.463628 E8305.359658 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.549258 matz1=2.463628 note=collision lift
G1 X249.1402 Y165.00422 Z2.538507 E8307.697554 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.463628 matz1=2.538507 note=collision lift
G1 X249.082088 Y164.879046 Z2.553896 E8308.175112 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.538507 matz1=2.553896 note=collision lift
G1 X249.005 Y164.713 Z2.574462 E8308.828152 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.553896 matz1=2.574462 note=collision lift
G1 X248.884424 Y164.535585 Z2.59877 E8309.620437 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.574462 matz1=2.59877 note=collision lift
G1 X248.305819 Y163.684232 Z2.084089 E8314.593138 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.59877 matz1=2.084089 note=collision lift
G1 X248.271 Y163.633 Z2.084089 E8314.860792 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.084089 matz1=2.084089 note=collision lift
G1 X247.372 Y162.628 Z1.570087 E8322.285485 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.084089 matz1=1.570087 note=collision lift
G1 X247.267576 Y162.53459 Z1.51668 E8323.180529 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.570087 matz1=1.51668 note=collision lift
G1 X246.367 Y161.729 Z1.660239 E8330.444076 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X245.762149 Y161.317925 Z1.745496 E8335.162095 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.643852 Y161.231085 Z1.84594 E8341.336522 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.167799 Y160.768801 Z2.012623 E8354.13046 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.537041 Y160.656792 Z2.245938 E8357.733301 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.012623 matz1=2.245938 note=collision lift
G1 X249.177262 Y160.314587 Z2.318053 E8364.21175 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.245938 matz1=2.318053 note=collision lift
G1 X249.183162 Y160.311433 Z2.315293 E8364.276021 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.318053 matz1=2.315293 note=collision lift
G1 X250.281815 Y159.724191 Z2.315293 E8375.338927 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.315293 matz1=2.315293 note=collision lift
G1 X250.419748 Y159.610992 Z2.239584 E8377.076901 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.315293 matz1=2.239584 note=collision lift
G1 X250.45205 Y159.584483 Z2.242748 E8377.45265 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.811122 Y158.469122 Z2.354494 E8394.261455 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X252.548878 Y157.570162 Z2.399096 E8405.819748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.066191 Y156.939815 Z2.838093 E8415.017462 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.399096 matz1=2.838093 note=collision lift
G1 X253.577827 Y155.982611 Z2.838093 E8425.894481 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.838093 matz1=2.838093 note=collision lift
G1 X253.945743 Y155.294289 Z2.44889 E8431.724836 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.838093 matz1=2.44889 note=collision lift
G1 X253.998792 Y155.195041 Z2.449039 E8432.47715 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.573085 Y153.301852 Z2.409353 E8445.436127 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.767 Y151.333 Z2.31375 E8457.758127 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X254.573085 Y149.364148 Z2.168111 E8469.108124 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.998792 Y147.470959 Z1.98139 E8479.205123 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X253.066191 Y145.726185 Z1.765068 E8487.840712 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X251.811122 Y144.196878 Z1.532448 E8494.894899 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X250.281815 Y142.941809 Z1.297832 E8500.346718 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X248.537041 Y142.009208 Z1.075648 E8504.277471 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X246.643852 Y141.434915 Z0.879557 E8506.865664 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X244.675 Y141.241 Z0.721616 E8508.374278 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X242.706148 Y141.434915 Z0.611538 E8509.132316 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.812959 Y142.009208 Z0.556091 E8509.513082 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.068185 Y142.941809 Z0.558684 E8509.911296 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.639696 Y144.11414 Z0.613445 E8510.63067 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.538878 Y144.196878 Z0.619158 E8510.710702 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.65036 Y145.279542 Z0.69507 E8512.11842 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.942085 Y144.317852 Z0.765032 E8513.492073 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.994258 Y143.788133 Z0.806908 E8514.335152 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.136 Y142.349 Z0.935738 E8516.504989 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.942085 Y140.380148 Z1.14114 E8520.878983 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.367792 Y138.486959 Z1.368608 E8526.811964 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.435191 Y136.742185 Z1.604156 E8534.357396 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.180122 Y135.212878 Z1.833299 E8543.465298 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.650815 Y133.957809 Z2.041947 E8553.98658 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.906041 Y133.025208 Z2.217272 E8565.685211 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.012852 Y132.450915 Z2.348492 E8578.256157 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.044 Y132.257 Z2.427539 E8591.34637 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X225.075148 Y132.450915 Z2.449552 E8604.576341 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X223.181959 Y133.025208 Z2.413177 E8617.560859 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X221.437185 Y133.957809 Z2.320652 E8629.928836 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.907878 Y135.212878 Z2.177666 E8641.342734 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.652809 Y136.742185 Z1.99301 E8651.517946 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.118936 Y137.74099 Z1.872844 E8656.880741 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.720208 Y138.486959 Z1.778039 E8662.47735 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.145915 Y140.380148 Z1.545972 E8673.19689 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.952 Y142.349 Z1.311078 E8681.510525 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.145915 Y144.317852 Z1.087801 E8687.531505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.720208 Y146.211041 Z0.88987 E8691.519648 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.362815 Y147.413274 Z0.774669 E8693.452922 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X218.652809 Y147.955815 Z0.729455 E8693.938386 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.907878 Y149.485122 Z0.61642 E8694.729673 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X221.437185 Y150.740191 Z0.557717 E8695.121496 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X223.181959 Y151.672792 Z0.556953 E8695.507968 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X225.075148 Y152.247085 Z0.614178 E8696.283071 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.044 Y152.441 Z0.72587 E8697.81821 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.012852 Y152.247085 Z0.885164 E8700.440291 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.906041 Y151.672792 Z1.082263 E8704.410939 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X231.169244 Y151.532108 Z1.114549 E8705.043687 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.650815 Y150.740191 Z1.305049 E8712.046441 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.180122 Y149.485122 Z1.539822 E8722.704652 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.435191 Y147.955815 Z1.772147 E8735.742318 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.367792 Y146.211041 Z1.987737 E8750.975067 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.65036 Y145.279542 Z2.083567 E8758.944139 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.283809 Y145.726185 Z2.136411 E8763.829042 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.276798 Y145.739302 Z2.137568 E8763.966457 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.351208 Y147.470959 Z3.272147 E8784.855581 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.137568 matz1=3.272147 note=collision lift
G1 X234.866559 Y149.068631 Z3.272147 E8801.139887 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.272147 matz1=3.272147 note=collision lift
G1 X234.866465 Y149.068941 Z3.272327 E8801.143506 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.272147 matz1=3.272327 note=collision lift
G1 X234.776915 Y149.364148 Z3.235118 E8804.17422 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.272327 matz1=3.235118 note=collision lift
G1 X234.612375 Y151.034746 Z2.438459 E8822.778597 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.235118 matz1=2.438459 note=collision lift
G1 X234.583 Y151.333 Z2.446079 E8825.780262 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.776915 Y153.301852 Z2.438207 E8845.508677 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X234.805329 Y153.39552 Z2.436301 E8846.48399 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X235.351208 Y155.195041 Z2.372646 E8858.569482 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.283809 Y156.939815 Z2.253426 E8870.489358 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X236.369577 Y157.044324 Z2.243486 E8871.300031 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X237.538878 Y158.469122 Z2.087878 E8886.411491 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X239.068185 Y159.724191 Z1.886182 E8900.594031 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.576778 Y160.530551 Z1.69128 E8910.883167 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X240.806512 Y160.653346 Z1.791846 E8912.551947 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.69128 matz1=1.791846 note=collision lift
G1 X240.812959 Y160.656792 Z1.794641 E8912.598683 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.791846 matz1=1.794641 note=collision lift
G1 X242.706148 Y161.231085 Z2.548504 E8922.678788 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.794641 matz1=2.548504 note=collision lift
G1 X244.515492 Y161.40929 Z3.245507 E8929.637905 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.548504 matz1=2.713368 note=collision lift
G1 X244.675 Y161.425 Z3.263373 E8930.2143 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.713368 matz1=2.694674 note=collision lift
G1 X244.675015 Y161.424999 Z3.263364 E8930.21436 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.694674 matz1=2.694672 note=collision lift
G1 X245.039921 Y161.389058 Z3.304934 E8931.455197 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.694672 matz1=2.65356 note=collision lift
G1 X245.399843 Y161.353609 Z3.345937 E8932.576878 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.65356 matz1=2.613876 note=collision lift
G1 X245.399871 Y161.353606 Z3.345948 E8932.57697 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.613876 matz1=2.613873 note=collision lift
G1 X245.534898 Y161.340307 Z3.360396 E8932.997462 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.613873 matz1=2.598985 note=collision lift
G1 X245.534947 Y161.340303 Z3.360415 E8932.997624 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.598985 matz1=2.59898 note=collision lift
G1 X245.759163 Y161.318219 Z3.38427 E8933.667215 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.59898 matz1=2.574763 note=collision lift
G1 X245.762149 Y161.317925 Z3.385448 E8933.67674 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.574763 matz1=2.574441 note=collision lift
G1 X245.464415 Y161.115576 Z3.354197 E8934.674069 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.574441 matz1=2.536467 note=collision lift
G1 X245.462948 Y161.11458 Z3.353127 E8934.679549 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.536467 matz1=2.536283 note=collision lift
G1 X245.403816 Y161.074392 Z3.345995 E8934.869663 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.536283 matz1=2.52889 note=collision lift
G1 X245.40372 Y161.074326 Z3.346042 E8934.869995 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.52889 matz1=2.528878 note=collision lift
G1 X245.287019 Y160.995013 Z3.331018 E8935.245455 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.528878 matz1=2.514287 note=collision lift
G1 X245.287 Y160.995 Z3.331027 E8935.24552 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.514287 matz1=2.514285 note=collision lift
G1 X245.122489 Y160.918625 Z3.309644 E8935.711228 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.514285 matz1=2.495805 note=collision lift
G1 X245.120954 Y160.917912 Z3.310317 E8935.715873 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.495805 matz1=2.495633 note=collision lift
G1 X244.67059 Y160.708828 Z3.246617 E8936.719811 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.495633 matz1=2.447725 note=collision lift
G1 X244.126 Y160.456 Z2.888478 E8938.121862 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.447725 matz1=2.389794 note=collision lift
G1 X243.905285 Y160.388559 Z2.752701 E8938.580997 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.389794 matz1=2.369411 note=collision lift
G1 X243.514 Y160.269 Z2.921138 E8939.339674 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.369411 matz1=2.333277 note=collision lift
G1 X243.502103 Y160.267261 Z2.926214 E8939.355227 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.333277 matz1=2.332341 note=collision lift
G1 X243.021384 Y160.196993 Z3.00049 E8939.94089 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.332341 matz1=2.294546 note=collision lift
G1 X243.019902 Y160.196777 Z3.001122 E8939.942827 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.294546 matz1=2.294429 note=collision lift
G1 X242.221 Y160.08 Z3.116313 E8940.914699 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.294429 matz1=2.231617 note=collision lift
G1 X242.220321 Y160.080005 Z3.115928 E8940.915449 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.231617 matz1=2.231572 note=collision lift
G1 X241.923211 Y160.082186 Z3.160998 E8941.204079 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.231572 matz1=2.211966 note=collision lift
G1 X241.91841 Y160.082222 Z3.163082 E8941.209106 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.211966 matz1=2.211649 note=collision lift
G1 X241.542622 Y160.084981 Z3.223891 E8941.574735 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.211649 matz1=2.186851 note=collision lift
G1 X241.54 Y160.085 Z3.225029 E8941.57748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.186851 matz1=2.186678 note=collision lift
G1 X241.069938 Y160.160511 Z3.290537 E8941.945781 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.186678 matz1=2.159349 note=collision lift
G1 X241.067966 Y160.160827 Z3.289423 E8941.947534 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.159349 matz1=2.159234 note=collision lift
G1 X240.898079 Y160.188118 Z3.310258 E8942.080363 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.159234 matz1=2.149357 note=collision lift
G1 X240.891212 Y160.189221 Z3.313336 E8942.086193 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.149357 matz1=2.148958 note=collision lift
G1 X240.175476 Y160.304197 Z3.388435 E8942.502071 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.148958 matz1=2.114455 note=collision lift
G1 X240.171994 Y160.304756 Z3.386503 E8942.504366 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.114455 matz1=2.114287 note=collision lift
G1 X240.113796 Y160.314105 Z3.391313 E8942.538113 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.114287 matz1=2.111482 note=collision lift
G1 X240.102 Y160.316 Z3.396718 E8942.545596 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.111482 matz1=2.110913 note=collision lift
G1 X239.345 Y160.548 Z3.434262 E8942.880261 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.110913 matz1=2.082064 note=collision lift
G1 X239.340066 Y160.550227 Z3.431459 E8942.881854 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.082064 matz1=2.081967 note=collision lift
G1 X238.973144 Y160.71586 Z3.42755 E8942.987045 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.081967 matz1=2.074772 note=collision lift
G1 X238.970274 Y160.717155 Z3.42592 E8942.987971 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074772 matz1=2.074715 note=collision lift
G1 X238.789413 Y160.798798 Z3.41526 E8943.039893 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074715 matz1=2.071169 note=collision lift
G1 X238.787215 Y160.79979 Z3.416423 E8943.040592 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.071169 matz1=2.071125 note=collision lift
G1 X238.601287 Y160.88372 Z3.390958 E8943.094306 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.071125 matz1=2.067479 note=collision lift
G1 X237.75 Y161.268 Z2.907262 E8943.369128 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.067479 matz1=2.050784 note=collision lift
G1 X236.91 Y161.763 Z2.42216 E8943.667105 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050784 matz1=2.053183 note=collision lift
G1 X236.694674 Y161.918736 Z2.292411 E8943.752773 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053183 matz1=2.056305 note=collision lift
G1 X235.725475 Y162.619719 Z1.721349 E8944.320879 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.056305 matz1=1.721349 note=collision lift
G1 X235.143 Y163.041 Z1.388153 E8944.76741 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.721349 matz1=1.388153 note=collision lift
G1 X235.044244 Y163.1294 Z1.329644 E8944.959676 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.388153 matz1=1.329644 note=collision lift
G1 X233.769102 Y164.270814 Z2.285558 E8947.561042 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.329644 matz1=2.217527 note=collision lift
G1 X233.750446 Y164.287513 Z2.287809 E8947.594402 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.217527 matz1=2.218993 note=collision lift
G1 X233.749657 Y164.288219 Z2.288401 E8947.596013 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.218993 matz1=2.219055 note=collision lift
G1 X233.255 Y164.731 Z2.347729 E8948.480534 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.219055 matz1=2.257935 note=collision lift
G1 X233.254615 Y164.731407 Z2.347492 E8948.481478 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257935 matz1=2.257979 note=collision lift
G1 X232.870026 Y165.138327 Z2.395947 E8949.353441 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257979 matz1=2.301519 note=collision lift
G1 X232.86959 Y165.138788 Z2.396314 E8949.354578 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.301519 matz1=2.301568 note=collision lift
G1 X233.381301 Y163.451906 Z1.673473 E8953.864817 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.301568 matz1=1.673473 note=collision lift
G1 X233.521142 Y162.032072 Z1.109938 E8958.981727 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.673473 matz1=1.109938 note=collision lift
G1 X233.557 Y161.668 Z1.148354 E8960.208761 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.409263 Y160.167998 Z1.320802 E8966.615395 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X233.381301 Y159.884094 Z1.354355 E8967.457135 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.860954 Y158.168743 Z1.567715 E8974.068125 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X232.015958 Y156.587866 Z1.777654 E8981.977237 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X230.878784 Y155.202216 Z1.973564 E8991.091121 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X229.493134 Y154.065042 Z2.145546 E9001.254915 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X227.912257 Y153.220046 Z2.284911 E9012.262228 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X226.196906 Y152.699699 Z2.384617 E9023.86736 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X224.413 Y152.524 Z2.439626 E9035.798412 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X222.629094 Y152.699699 Z2.44716 E9047.770274 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X220.913743 Y153.220046 Z2.406837 E9059.497077 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.332866 Y154.065042 Z2.320695 E9070.704202 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X219.112453 Y154.24593 Z2.303026 E9072.470944 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X217.947216 Y155.202216 Z2.193086 E9085.636503 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.810042 Y156.587866 Z2.030457 E9099.809075 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.965046 Y158.168743 Z1.841027 E9112.245527 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.761715 Y158.839034 Z1.760272 E9116.360608 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.444699 Y159.884094 Z2.180408 E9123.189649 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.760272 matz1=2.180408 note=collision lift
G1 X215.374156 Y160.600329 Z2.45477 E9127.346078 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.180408 matz1=2.45477 note=collision lift
G1 X215.269 Y161.668 Z2.863226 E9132.785168 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.45477 matz1=2.863226 note=collision lift
G1 X215.411025 Y163.11 Z3.417594 E9138.777908 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.863226 matz1=2.750794 note=collision lift
G1 X215.444699 Y163.451906 Z3.55004 E9140.125693 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.750794 matz1=2.711461 note=collision lift
G1 X215.722559 Y164.367886 Z3.924577 E9142.85754 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.711461 matz1=2.607399 note=collision lift
G1 X215.965046 Y165.167257 Z3.938958 E9145.078031 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.607399 matz1=2.516585 note=collision lift
G1 X215.965081 Y165.167323 Z3.938913 E9145.078243 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.516585 matz1=2.516577 note=collision lift
G1 X216.162715 Y165.53707 Z3.946178 E9146.101063 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.516577 matz1=2.474183 note=collision lift
G1 X216.163052 Y165.537701 Z3.946463 E9146.102941 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.474183 matz1=2.474111 note=collision lift
G1 X216.199 Y164.771 Z3.900364 E9147.686809 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.474111 matz1=2.400364 note=collision lift
G1 X216.198992 Y164.770674 Z3.900337 E9147.687252 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.400364 matz1=2.400337 note=collision lift
G1 X216.187593 Y164.287942 Z3.859657 E9148.342556 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.400337 matz1=2.359657 note=collision lift
G1 X216.160463 Y163.139091 Z3.253245 E9150.099706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.359657 matz1=2.262846 note=collision lift
G1 X216.15 Y162.696 Z2.999422 E9150.705748 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.262846 matz1=2.23063 note=collision lift
G1 X216.13513 Y162.559673 Z2.923161 E9150.793889 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.23063 matz1=2.222937 note=collision lift
G1 X216.046221 Y161.74455 Z3.038175 E9151.25898 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.222937 matz1=2.176937 note=collision lift
G1 X216.04609 Y161.743343 Z3.037499 E9151.25976 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.176937 matz1=2.176869 note=collision lift
G1 X216.037142 Y161.661309 Z3.04872 E9151.30654 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.176869 matz1=2.17224 note=collision lift
G1 X216.03701 Y161.660104 Z3.049258 E9151.307285 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.17224 matz1=2.172172 note=collision lift
G1 X215.967323 Y161.021203 Z3.13451 E9151.671455 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.172172 matz1=2.136117 note=collision lift
G1 X215.967156 Y161.019673 Z3.135194 E9151.672401 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.136117 matz1=2.136031 note=collision lift
G1 X215.915255 Y160.543845 Z3.201715 E9151.94385 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.136031 matz1=2.109178 note=collision lift
G1 X215.915139 Y160.542783 Z3.201136 E9151.944525 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.109178 matz1=2.109134 note=collision lift
G1 X215.91209 Y160.514823 Z3.204871 E9151.960281 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.109134 matz1=2.107974 note=collision lift
G1 X215.912 Y160.514 Z3.20525 E9151.960787 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.107974 matz1=2.107939 note=collision lift
G1 X215.925692 Y160.030317 Z3.26653 E9152.086623 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.107939 matz1=2.098405 note=collision lift
G1 X215.925701 Y160.030004 Z3.266681 E9152.086713 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.098405 matz1=2.098399 note=collision lift
G1 X215.942737 Y159.428189 Z3.340199 E9152.243196 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.098399 matz1=2.086537 note=collision lift
G1 X215.94301 Y159.418548 Z3.344831 E9152.245957 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086537 matz1=2.086347 note=collision lift
G1 X215.978191 Y158.175769 Z3.476512 E9152.568514 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086347 matz1=2.06185 note=collision lift
G1 X215.978348 Y158.170247 Z3.47364 E9152.570121 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.06185 matz1=2.061741 note=collision lift
G1 X215.979088 Y158.144102 Z3.476121 E9152.576899 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.061741 matz1=2.061226 note=collision lift
G1 X215.979137 Y158.14238 Z3.476949 E9152.577392 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.061226 matz1=2.061192 note=collision lift
G1 X215.995 Y157.582 Z3.527307 E9152.722609 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.061192 matz1=2.050146 note=collision lift
G1 X215.994933 Y157.580795 Z3.526729 E9152.723319 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050146 matz1=2.050171 note=collision lift
G1 X215.99273 Y157.541272 Z3.529835 E9152.744383 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050171 matz1=2.050999 note=collision lift
G1 X215.992284 Y157.533261 Z3.534015 E9152.749183 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050999 matz1=2.051166 note=collision lift
G1 X215.942291 Y156.636227 Z3.569946 E9153.226179 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051166 matz1=2.069946 note=collision lift
G1 X215.941969 Y156.630455 Z3.570067 E9153.229247 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.069946 matz1=2.070067 note=collision lift
G1 X215.920259 Y156.240905 Z3.578222 E9153.436269 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.070067 matz1=2.078222 note=collision lift
G1 X215.920083 Y156.237748 Z3.578288 E9153.437947 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.078222 matz1=2.078288 note=collision lift
G1 X215.897876 Y155.83927 Z3.574022 E9153.64968 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.078288 matz1=2.08663 note=collision lift
G1 X215.896938 Y155.822445 Z3.565949 E9153.659592 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.08663 matz1=2.086982 note=collision lift
G1 X215.895088 Y155.789258 Z3.561354 E9153.677393 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.086982 matz1=2.087677 note=collision lift
G1 X215.894997 Y155.787621 Z3.562208 E9153.678374 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.087677 matz1=2.087711 note=collision lift
G1 X215.892119 Y155.735972 Z3.546891 E9153.706994 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.087711 matz1=2.088793 note=collision lift
G1 X215.854 Y155.052 Z3.218693 E9154.10996 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.088793 matz1=2.103111 note=collision lift
G1 X215.551082 Y153.160737 Z2.361521 E9156.308327 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.103111 matz1=2.203624 note=collision lift
G1 X215.509 Y152.898 Z2.246239 E9156.528525 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.203624 matz1=2.221385 note=collision lift
G1 X215.310713 Y152.131669 Z1.908357 E9157.35299 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.221385 matz1=1.908357 note=collision lift
G1 X215.265 Y151.955 Z1.831494 E9157.652169 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.908357 matz1=1.831494 note=collision lift
G1 X214.646 Y150.318 Z1.11204 E9162.026041 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.831494 matz1=1.11204 note=collision lift
G1 X214.493556 Y150.03037 Z0.982009 E9162.979983 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.11204 matz1=0.982009 note=collision lift
G1 X214.275 Y149.618 Z1.028939 E9164.256464 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.422 Y148.438 Z1.186908 E9169.432389 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X212.944 Y147.953 Z1.264712 E9172.128988 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X212.771479 Y147.824432 Z1.289681 E9173.009011 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.106815 Y147.645191 Z1.33417 E9174.652008 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.187619 Y146.758198 Z1.500231 E9181.897753 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.636122 Y146.390122 Z1.569434 E9185.112745 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.891191 Y144.860815 Z1.800428 E9198.439218 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.071322 Y144.523814 Z1.842984 E9201.172198 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X216.234742 Y144.218076 Z2.054929 E9204.060461 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.842984 matz1=2.054929 note=collision lift
G1 X216.823792 Y143.116041 Z2.811078 E9215.429445 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.054929 matz1=2.811078 note=collision lift
G1 X217.398085 Y141.222852 Z2.811078 E9232.671299 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.811078 matz1=2.811078 note=collision lift
G1 X217.462829 Y140.565493 Z2.526988 E9239.44951 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.811078 matz1=2.526988 note=collision lift
G1 X217.592 Y139.254 Z3.278039 E9253.748295 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.526988 matz1=3.278039 note=collision lift
G1 X217.432018 Y137.629676 Z3.278039 E9269.771518 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.278039 matz1=3.278039 note=collision lift
G1 X217.398085 Y137.285148 Z3.116217 E9272.287342 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.278039 matz1=3.116217 note=collision lift
G1 X216.993522 Y135.951481 Z2.440938 E9282.645304 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.116217 matz1=2.440938 note=collision lift
G1 X216.823792 Y135.391959 Z2.449983 E9286.556446 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X215.891191 Y133.647185 Z2.422174 E9299.601109 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X214.636122 Y132.117878 Z2.337661 E9312.082374 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X213.106815 Y130.862809 Z2.201641 E9323.656529 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X211.362041 Y129.930208 Z2.022478 E9334.029945 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X209.468852 Y129.355915 Z1.811187 E9342.97792 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.5 Y129.162 Z1.580762 E9350.361267 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X205.531148 Y129.355915 Z1.345371 E9356.138197 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X203.637959 Y129.930208 Z1.119488 E9360.369193 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.893185 Y130.862809 Z0.917002 E9363.213644 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X200.363878 Y132.117878 Z0.750365 E9364.91857 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.108809 Y133.647185 Z0.629822 E9365.801141 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.176208 Y135.391959 Z0.562786 E9366.227434 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.601915 Y137.285148 Z0.553378 E9366.58965 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.567982 Y137.629676 Z0.557755 E9366.658236 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.433606 Y138.994016 Z0.59247 E9367.310674 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.279792 Y138.486959 Z0.61317 E9367.619427 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.881064 Y137.74099 Z0.654313 E9368.291763 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.347191 Y136.742185 Z0.724251 E9369.164531 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.092122 Y135.212878 Z0.883032 E9371.772043 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X193.562815 Y133.957809 Z1.07975 E9375.725477 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X191.818041 Y133.025208 Z1.302309 E9381.204081 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X189.924852 Y132.450915 Z1.537024 E9388.290411 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.956 Y132.257 Z1.769463 E9396.963907 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.987148 Y132.450915 Z1.985332 E9407.102809 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.093959 Y133.025208 Z2.171359 E9418.494243 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.349185 Y133.957809 Z2.316104 E9430.850792 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.819878 Y135.212878 Z2.410667 E9443.830887 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.564809 Y136.742185 Z2.449234 E9457.060398 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.632208 Y138.486959 Z2.429433 E9470.153689 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.057915 Y140.380148 Z2.352482 E9482.733658 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X177.864 Y142.349 Z2.223113 E9494.451225 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.005742 Y143.788133 Z2.099858 E9502.415356 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.057915 Y144.317852 Z2.049279 E9506.677246 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.632208 Y146.211041 Z1.841671 E9520.408576 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.564809 Y147.955815 Z1.613053 E9531.813304 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.819878 Y149.485122 Z1.377484 E9540.807967 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.349185 Y150.740191 Z1.149448 E9547.462218 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X183.830756 Y151.532108 Z0.972214 E9551.566283 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.093959 Y151.672792 Z0.942968 E9552.021896 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.987148 Y152.247085 Z0.770739 E9553.86601 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.956 Y152.441 Z0.643352 E9554.840775 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X189.924852 Y152.247085 Z0.56864 E9555.306879 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X191.818041 Y151.672792 Z0.551196 E9555.654297 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X193.562815 Y150.740191 Z0.592094 E9556.279357 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.092122 Y149.485122 Z0.688819 E9557.562161 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.347191 Y147.955815 Z0.835422 E9559.844489 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X196.637185 Y147.413274 Z0.889834 E9560.670264 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.279792 Y146.211041 Z1.02289 E9564.355008 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.854085 Y144.317852 Z1.239695 E9571.929152 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.048 Y142.349 Z1.472506 E9581.896219 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.854085 Y140.380148 Z1.707008 E9594.267889 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.433606 Y138.994016 Z1.871426 E9604.554006 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.408 Y139.254 Z1.899925 E9606.446771 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.430808 Y139.485569 Z1.923417 E9608.37157 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.601915 Y141.222852 Z2.972506 E9625.133643 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.923417 matz1=2.972506 note=collision lift
G1 X198.176208 Y143.116041 Z2.972506 E9643.073705 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.972506 matz1=2.972506 note=collision lift
G1 X198.765258 Y144.218076 Z2.426942 E9655.993694 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.972506 matz1=2.426942 note=collision lift
G1 X198.845573 Y144.368335 Z2.350344 E9657.799106 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.426942 matz1=2.350344 note=collision lift
G1 X199.108809 Y144.860815 Z2.378502 E9663.202923 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X200.363878 Y146.390122 Z2.44046 E9682.963795 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X200.812381 Y146.758198 Z2.447744 E9688.77846 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X201.893185 Y147.645191 Z2.44459 E9702.766927 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X203.637959 Y148.577792 Z2.390637 E9722.018141 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X205.531148 Y149.152085 Z2.28192 E9740.182974 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.006632 Y149.297408 Z2.168446 E9752.947081 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.5 Y149.346 Z2.125123 E9755.720997 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X207.993368 Y149.297408 Z2.079374 E9758.418 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X209.468852 Y149.152085 Z1.929887 E9769.38046 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X209.54657 Y149.128509 Z1.920787 E9769.888473 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X211.362041 Y148.577792 Z2.656799 E9782.537988 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.920787 matz1=2.656799 note=collision lift
G1 X211.669077 Y148.413678 Z2.789681 E9784.491887 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.656799 matz1=2.789681 note=collision lift
G1 X212.003789 Y148.234771 Z2.834087 E9786.495455 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.789681 matz1=2.834087 note=collision lift
G1 X212.004413 Y148.234437 Z2.834524 E9786.499817 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.834087 matz1=2.834524 note=collision lift
G1 X212.005038 Y148.234104 Z2.83417 E9786.503967 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.834524 matz1=2.83417 note=collision lift
G1 X212.771479 Y147.824432 Z2.83417 E9791.060761 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.83417 matz1=2.83417 note=collision lift
G1 X211.937836 Y147.203177 Z2.83417 E9795.816287 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.83417 matz1=2.83417 note=collision lift
G1 X211.937632 Y147.203025 Z2.834267 E9795.817534 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.83417 matz1=2.834267 note=collision lift
G1 X211.896 Y147.172 Z2.825012 E9796.058766 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.834267 matz1=2.825012 note=collision lift
G1 X211.331 Y146.872 Z2.429752 E9799.206581 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.825012 matz1=2.429752 note=collision lift
G1 X210.129 Y146.432 Z1.642964 E9804.361427 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.429752 matz1=1.642964 note=collision lift
G1 X209.525921 Y146.317307 Z1.2698 E9806.305502 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.642964 matz1=1.2698 note=collision lift
G1 X208.846 Y146.188 Z1.541196 E9808.317255 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.2698 matz1=1.541196 note=collision lift
G1 X208.06241 Y146.143756 Z1.854853 E9810.26193 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.541196 matz1=1.854853 note=collision lift
G1 X207.5 Y146.112 Z2.083246 E9811.083268 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.854853 matz1=2.083246 note=collision lift
G1 X206.93759 Y146.143756 Z2.314674 E9811.801246 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.083246 matz1=2.314674 note=collision lift
G1 X206.154 Y146.188 Z2.642648 E9813.023465 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.314674 matz1=2.27928 note=collision lift
G1 X204.871 Y146.432 Z3.20421 E9814.397375 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.27928 matz1=2.187844 note=collision lift
G1 X203.669 Y146.872 Z3.619394 E9815.223976 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.187844 matz1=2.119394 note=collision lift
G1 X203.382723 Y147.024006 Z3.606333 E9815.380221 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.119394 matz1=2.106333 note=collision lift
G1 X203.104 Y147.172 Z3.593617 E9815.532343 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.106333 matz1=2.093617 note=collision lift
G1 X203.101937 Y147.173538 Z3.59355 E9815.533129 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.093617 matz1=2.09355 note=collision lift
G1 X203.063446 Y147.202222 Z3.592289 E9815.547776 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.09355 matz1=2.092289 note=collision lift
G1 X203.062368 Y147.203025 Z3.592254 E9815.548187 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.092289 matz1=2.092254 note=collision lift
G1 X202.098802 Y147.921103 Z3.560691 E9815.914878 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.092254 matz1=2.060691 note=collision lift
G1 X202.098278 Y147.921493 Z3.560674 E9815.915078 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060691 matz1=2.060674 note=collision lift
G1 X202.056201 Y147.95285 Z3.559296 E9815.93109 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.060674 matz1=2.059296 note=collision lift
G1 X202.056 Y147.953 Z3.559289 E9815.931167 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059296 matz1=2.059289 note=collision lift
G1 X201.578 Y148.438 Z3.551405 E9816.111274 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059289 matz1=2.051405 note=collision lift
G1 X201.577981 Y148.438026 Z3.551405 E9816.111284 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051405 matz1=2.051405 note=collision lift
G1 X201.340595 Y148.766415 Z3.553196 E9816.231874 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.051405 matz1=2.053196 note=collision lift
G1 X200.725 Y149.618 Z3.424213 E9816.546933 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.053196 matz1=2.057843 note=collision lift
G1 X200.354 Y150.318 Z3.044867 E9816.884135 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.057843 matz1=2.074616 note=collision lift
G1 X199.735 Y151.955 Z2.238968 E9818.309418 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.074616 matz1=2.143779 note=collision lift
G1 X199.689287 Y152.131669 Z2.157387 E9818.467221 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.143779 matz1=2.153441 note=collision lift
G1 X199.491 Y152.898 Z1.808597 E9819.0619 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.153441 matz1=1.808597 note=collision lift
G1 X199.448918 Y153.160737 Z1.693153 E9819.278813 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.808597 matz1=1.693153 note=collision lift
G1 X199.146 Y155.052 Z0.886607 E9823.226176 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.693153 matz1=0.886607 note=collision lift
G1 X199.14406 Y155.086815 Z0.872668 E9823.346591 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.886607 matz1=0.872668 note=collision lift
G1 X199.005 Y157.582 Z1.123263 E9831.400358 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X199.020863 Y158.14238 Z1.185584 E9833.389949 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X198.189958 Y156.587866 Z1.390213 E9841.517224 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X197.052784 Y155.202216 Z1.603753 E9851.768537 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.887547 Y154.24593 Z1.779708 E9861.760663 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X195.667134 Y154.065042 Z1.812052 E9863.052079 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X194.086257 Y153.220046 Z2.004584 E9872.355941 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X192.370906 Y152.699699 Z2.17162 E9882.678119 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X190.587 Y152.524 Z2.304723 E9893.804672 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X188.803094 Y152.699699 Z2.397165 E9905.484543 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X187.087743 Y153.220046 Z2.444277 E9917.4427 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X185.506866 Y154.065042 Z2.443678 E9929.393045 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X184.121216 Y155.202216 Z2.395398 E9941.050776 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.984042 Y156.587866 Z2.301876 E9952.144351 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.139046 Y158.168743 Z2.167839 E9962.427382 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.618699 Y159.884094 Z2.000059 E9971.690529 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.590737 Y160.167998 Z1.970787 E9973.137233 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.443 Y161.668 Z1.807012 E9983.332427 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X181.618699 Y163.451906 Z1.598452 E9993.531213 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.139046 Y165.167257 Z1.384919 E10001.750055 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.64115 Y166.106629 Z1.26149 E10005.485998 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X182.984042 Y166.748134 Z1.540897 E10008.200885 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.26149 matz1=1.540897 note=collision lift
G1 X183.440703 Y167.304577 Z1.821425 E10010.577062 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.540897 matz1=1.821425 note=collision lift
G1 X184.121216 Y168.133784 Z2.245757 E10013.460263 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.821425 matz1=2.245757 note=collision lift
G1 X185.241395 Y169.053092 Z2.834155 E10016.273664 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.245757 matz1=2.349633 note=collision lift
G1 X185.506866 Y169.270958 Z2.976598 E10016.886471 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.349633 matz1=2.320363 note=collision lift
G1 X186.351163 Y169.722244 Z3.385257 E10017.900117 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.320363 matz1=2.250353 note=collision lift
G1 X187.087743 Y170.115954 Z3.469596 E10018.717574 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.250353 matz1=2.189275 note=collision lift
G1 X187.088299 Y170.116123 Z3.469271 E10018.718137 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.189275 matz1=2.18924 note=collision lift
G1 X187.489834 Y170.237927 Z3.50601 E10019.074122 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.18924 matz1=2.164269 note=collision lift
G1 X187.489165 Y170.237192 Z3.505462 E10019.07485 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.164269 matz1=2.164218 note=collision lift
G1 X186.973014 Y169.670016 Z3.431107 E10019.568907 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.164218 matz1=2.124636 note=collision lift
G1 X186.973 Y169.67 Z3.431117 E10019.568922 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.124636 matz1=2.124635 note=collision lift
G1 X186.623409 Y169.336923 Z3.384373 E10019.738173 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.124635 matz1=2.107823 note=collision lift
G1 X185.791414 Y168.544231 Z2.76978 E10020.192837 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.107823 matz1=2.067812 note=collision lift
G1 X185.47 Y168.238 Z2.53905 E10020.344845 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.067812 matz1=2.059053 note=collision lift
G1 X185.384477 Y168.169231 Z2.48415 E10020.381771 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059053 matz1=2.059024 note=collision lift
G1 X185.372681 Y168.159746 Z2.485583 E10020.386346 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.059024 matz1=2.05902 note=collision lift
G1 X185.370974 Y168.158374 Z2.486678 E10020.387083 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05902 matz1=2.05902 note=collision lift
G1 X184.724582 Y167.638614 Z2.588485 E10020.638555 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05902 matz1=2.058804 note=collision lift
G1 X184.72366 Y167.637873 Z2.587894 E10020.638953 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058804 matz1=2.058803 note=collision lift
G1 X184.659403 Y167.586204 Z2.597706 E10020.663941 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058803 matz1=2.058782 note=collision lift
G1 X184.658696 Y167.585635 Z2.59816 E10020.664246 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058782 matz1=2.058782 note=collision lift
G1 X184.15747 Y167.182603 Z2.677357 E10020.859253 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058782 matz1=2.058614 note=collision lift
G1 X184.15642 Y167.181759 Z2.67803 E10020.859706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058614 matz1=2.058614 note=collision lift
G1 X183.783489 Y166.881887 Z2.744871 E10021.005108 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058614 matz1=2.05849 note=collision lift
G1 X183.782577 Y166.881154 Z2.744305 E10021.005503 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.05849 matz1=2.058508 note=collision lift
G1 X183.760553 Y166.863444 Z2.748076 E10021.014154 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058508 matz1=2.058965 note=collision lift
G1 X183.76 Y166.863 Z2.748442 E10021.014396 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058965 matz1=2.058976 note=collision lift
G1 X183.427628 Y166.511329 Z2.81004 E10021.438885 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.058976 matz1=2.077148 note=collision lift
G1 X183.427442 Y166.511132 Z2.810186 E10021.439154 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077148 matz1=2.077158 note=collision lift
G1 X183.013774 Y166.073445 Z2.884105 E10021.967174 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.077158 matz1=2.099775 note=collision lift
G1 X183.007252 Y166.066544 Z2.889209 E10021.976555 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.099775 matz1=2.100132 note=collision lift
G1 X182.153245 Y165.16295 Z3.037644 E10023.066203 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.100132 matz1=2.146823 note=collision lift
G1 X182.148626 Y165.158062 Z3.034534 E10023.072651 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.146823 matz1=2.147076 note=collision lift
G1 X182.131606 Y165.140054 Z3.037184 E10023.094337 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.147076 matz1=2.148007 note=collision lift
G1 X182.13041 Y165.138788 Z3.03812 E10023.096058 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.148007 matz1=2.148072 note=collision lift
G1 X181.745 Y164.731 Z3.094929 E10023.586841 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.148072 matz1=2.169144 note=collision lift
G1 X181.7439 Y164.730016 Z3.0943 E10023.589772 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.169144 matz1=2.169252 note=collision lift
G1 X181.715856 Y164.704912 Z3.09763 E10023.658808 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.169252 matz1=2.172014 note=collision lift
G1 X181.70886 Y164.69865 Z3.103014 E10023.678583 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.172014 matz1=2.172704 note=collision lift
G1 X181.03924 Y164.099255 Z3.160304 E10025.323888 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.172704 matz1=2.238663 note=collision lift
G1 X181.033129 Y164.093785 Z3.156806 E10025.340178 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.238663 matz1=2.239265 note=collision lift
G1 X180.744944 Y163.835823 Z3.165923 E10026.047032 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.239265 matz1=2.267652 note=collision lift
G1 X180.742206 Y163.833372 Z3.16803 E10026.054772 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.267652 matz1=2.267921 note=collision lift
G1 X180.445172 Y163.567488 Z3.154511 E10026.783546 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.267921 matz1=2.29718 note=collision lift
G1 X180.42356 Y163.548143 Z3.142137 E10026.841162 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.29718 matz1=2.299309 note=collision lift
G1 X180.406164 Y163.532572 Z3.138039 E10026.884468 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.299309 matz1=2.301022 note=collision lift
G1 X180.404153 Y163.530772 Z3.136888 E10026.88983 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.301022 matz1=2.30122 note=collision lift
G1 X180.387509 Y163.515873 Z3.130413 E10026.932323 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.30122 matz1=2.30286 note=collision lift
G1 X180.386661 Y163.515114 Z3.131066 E10026.934721 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.30286 matz1=2.302943 note=collision lift
G1 X179.857 Y163.041 Z2.827808 E10028.346745 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.302943 matz1=2.355116 note=collision lift
G1 X179.274525 Y162.619719 Z2.533939 E10030.027586 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.355116 matz1=2.420676 note=collision lift
G1 X178.305326 Y161.918736 Z2.055152 E10033.606771 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.420676 matz1=2.055152 note=collision lift
G1 X178.09 Y161.763 Z1.950288 E10034.441573 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.055152 matz1=1.950288 note=collision lift
G1 X177.25 Y161.268 Z1.569431 E10038.074604 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.950288 matz1=1.569431 note=collision lift
G1 X176.530277 Y160.943109 Z1.265994 E10041.892208 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.569431 matz1=1.265994 note=collision lift
G1 X175.655 Y160.548 Z1.377138 E10046.254893 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.898 Y160.316 Z1.471317 E10050.239457 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.841576 Y160.306936 Z1.478137 E10050.529089 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X175.931815 Y159.724191 Z1.625347 E10057.737097 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X177.461122 Y158.469122 Z1.853204 E10071.60189 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.630423 Y157.044324 Z2.046217 E10086.344887 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X178.716191 Y156.939815 Z2.059343 E10087.071386 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X179.648792 Y155.195041 Z2.231088 E10098.862278 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.194671 Y153.39552 Z2.352794 E10110.837811 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.223085 Y153.301852 Z2.357879 E10111.774706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.417 Y151.333 Z2.431919 E10131.452723 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.345969 Y150.611813 Z2.43805 E10138.718367 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X180.223085 Y149.364148 Z3.075507 E10152.819067 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.43805 matz1=3.075507 note=collision lift
G1 X180.133535 Y149.068941 Z3.113235 E10155.868435 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.075507 matz1=3.113235 note=collision lift
G1 X180.133433 Y149.068607 Z3.113053 E10155.872302 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.113235 matz1=3.113053 note=collision lift
G1 X179.648792 Y147.470959 Z3.113053 E10172.253289 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.113053 matz1=3.113053 note=collision lift
G1 X179.418842 Y147.040752 Z2.845141 E10177.435043 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.113053 matz1=2.845141 note=collision lift
G1 X178.716191 Y145.726185 Z3.517066 E10192.658257 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.845141 matz1=3.517066 note=collision lift
G1 X178.515155 Y145.481222 Z3.549436 E10195.38296 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.517066 matz1=3.549436 note=collision lift
G1 X178.514982 Y145.48101 Z3.549279 E10195.385661 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.549436 matz1=3.549279 note=collision lift
G1 X177.653839 Y144.431705 Z3.549279 E10206.996579 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.549279 matz1=3.549279 note=collision lift
G1 X177.479861 Y144.219712 Z3.666001 E10209.545971 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.549279 matz1=3.664731 note=collision lift
G1 X177.470699 Y144.208549 Z3.657706 E10209.688427 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.664731 matz1=3.657706 note=collision lift
G1 X177.461122 Y144.196878 Z3.664132 E10209.828775 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.657706 matz1=3.662534 note=collision lift
G1 X177.362407 Y144.115865 Z3.667355 E10210.914044 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.662534 matz1=3.651522 note=collision lift
G1 X177.360304 Y144.11414 Z3.66848 E10210.93905 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.651522 matz1=3.651287 note=collision lift
G1 X177.07479 Y143.879824 Z3.672007 E10212.807307 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.651287 matz1=3.61598 note=collision lift
G1 X177.074036 Y143.879205 Z3.671426 E10212.813047 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.61598 matz1=3.615887 note=collision lift
G1 X176.90286 Y143.738725 Z3.666253 E10213.933384 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.615887 matz1=3.594719 note=collision lift
G1 X176.9019 Y143.737937 Z3.665514 E10213.940696 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.594719 matz1=3.5946 note=collision lift
G1 X176.816895 Y143.668176 Z3.657987 E10214.498196 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.5946 matz1=3.584088 note=collision lift
G1 X176.816195 Y143.667601 Z3.657447 E10214.503531 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.584088 matz1=3.584002 note=collision lift
G1 X176.775474 Y143.634182 Z3.650656 E10214.772179 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.584002 matz1=3.578966 note=collision lift
G1 X176.773913 Y143.632901 Z3.651473 E10214.783197 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.578966 matz1=3.578773 note=collision lift
G1 X176.730931 Y143.597626 Z3.636152 E10215.074918 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.578773 matz1=3.573458 note=collision lift
G1 X175.931815 Y142.941809 Z3.020447 E10221.160809 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.573458 matz1=3.020447 note=collision lift
G1 X174.187041 Y142.009208 Z1.814177 E10231.1554 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.020447 matz1=1.814177 note=collision lift
G1 X174.078678 Y141.976336 Z1.744225 E10231.623186 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.814177 matz1=1.744225 note=collision lift
G1 X172.293852 Y141.434915 Z1.524639 E10238.223415 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.325 Y141.241 Z1.290206 E10243.62306 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.356148 Y141.434915 Z1.068672 E10247.50604 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.462959 Y142.009208 Z0.873661 E10250.053898 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.718185 Y142.941809 Z0.717164 E10251.532116 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.188878 Y144.196878 Z0.608802 E10252.271524 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.933809 Y145.726185 Z0.555239 E10252.646501 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.001208 Y147.470959 Z0.55977 E10253.052083 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.426915 Y149.364148 Z0.622114 E10253.881129 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.233 Y151.333 Z0.738439 E10255.50191 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.426915 Y153.301852 Z0.901592 E10258.236263 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.001208 Y155.195041 Z1.101541 E10262.338959 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.422173 Y155.982611 Z1.200623 E10264.498136 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.933809 Y156.939815 Z1.325991 E10269.141226 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.188878 Y158.469122 Z1.56114 E10280.01819 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.528917 Y159.568863 Z1.764587 E10291.374319 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.718185 Y159.724191 Z1.79253 E10293.013105 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.462959 Y160.656792 Z2.005933 E10308.430327 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.356148 Y161.231085 Z2.188226 E10325.686915 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X169.465053 Y161.340303 Z2.272887 E10335.879886 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X169.960079 Y161.389058 Z2.305884 E10340.511653 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.325 Y161.425 Z2.3282 E10343.967072 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.443694 Y161.41331 Z2.335082 E10345.094997 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X172.293852 Y161.231085 Z2.417249 E10363.45136 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.187041 Y160.656792 Z2.449897 E10383.301303 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.841576 Y160.306936 Z2.447072 E10390.73607 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X174.627815 Y160.272597 Z2.442795 E10392.874516 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X173.46 Y160.085 Z3.010824 E10405.832062 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.442795 matz1=3.010824 note=collision lift
G1 X172.779 Y160.08 Z3.327535 E10413.157074 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.010824 matz1=3.327535 note=collision lift
G1 X171.486 Y160.269 Z3.917074 E10426.66774 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.327535 matz1=3.831801 note=collision lift
G1 X170.874234 Y160.455928 Z3.896275 E10432.569403 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.831801 matz1=3.792263 note=collision lift
G1 X170.874 Y160.456 Z3.896382 E10432.571869 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.792263 matz1=3.792248 note=collision lift
G1 X170.372345 Y160.688896 Z3.880311 E10437.478205 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.792248 matz1=3.752586 note=collision lift
G1 X170.371895 Y160.689105 Z3.880028 E10437.483269 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.752586 matz1=3.75255 note=collision lift
G1 X170.154363 Y160.790095 Z3.87233 E10439.610998 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.75255 matz1=3.735352 note=collision lift
G1 X170.154319 Y160.790115 Z3.872303 E10439.611494 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.735352 matz1=3.735348 note=collision lift
G1 X170.00422 Y160.8598 Z3.866782 E10441.079706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.735348 matz1=3.723481 note=collision lift
G1 X170.004209 Y160.859805 Z3.866775 E10441.079833 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.723481 matz1=3.72348 note=collision lift
G1 X169.879063 Y160.917904 Z3.862053 E10442.296332 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.72348 matz1=3.712696 note=collision lift
G1 X169.879046 Y160.917912 Z3.862061 E10442.296516 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.712696 matz1=3.712695 note=collision lift
G1 X169.713072 Y160.994966 Z3.855643 E10443.896147 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.712695 matz1=3.698064 note=collision lift
G1 X169.713 Y160.995 Z3.855677 E10443.896904 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.698064 matz1=3.698057 note=collision lift
G1 X169.535832 Y161.115409 Z3.84905 E10445.749811 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.698057 matz1=3.68046 note=collision lift
G1 X169.535585 Y161.115576 Z3.849175 E10445.752603 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.68046 matz1=3.680436 note=collision lift
G1 X169.195468 Y161.34673 Z3.835264 E10449.104645 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.680436 matz1=3.643877 note=collision lift
G1 X169.195234 Y161.346889 Z3.835097 E10449.107325 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.643877 matz1=3.643851 note=collision lift
G1 X169.075731 Y161.428107 Z3.82827 E10450.285729 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.643851 matz1=3.631006 note=collision lift
G1 X169.075005 Y161.4286 Z3.828631 E10450.293459 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.631006 matz1=3.630928 note=collision lift
G1 X168.739109 Y161.656885 Z3.806335 E10453.606993 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.630928 matz1=3.594822 note=collision lift
G1 X168.73848 Y161.657313 Z3.805887 E10453.61418 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.594822 matz1=3.594755 note=collision lift
G1 X168.633919 Y161.728375 Z3.797492 E10454.646363 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.594755 matz1=3.583515 note=collision lift
G1 X168.633 Y161.729 Z3.797949 E10454.656154 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.583515 matz1=3.583416 note=collision lift
G1 X168.377887 Y161.957206 Z3.77355 E10457.213716 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.583416 matz1=3.549201 note=collision lift
G1 X168.377133 Y161.95788 Z3.772944 E10457.222506 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.549201 matz1=3.549099 note=collision lift
G1 X168.2815 Y162.043426 Z3.760723 E10458.183147 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.549099 matz1=3.536273 note=collision lift
G1 X168.275622 Y162.048684 Z3.763878 E10458.24646 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.536273 matz1=3.535485 note=collision lift
G1 X167.892099 Y162.391756 Z3.697822 E10462.113101 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.535485 matz1=3.484046 note=collision lift
G1 X167.628 Y162.628 Z3.485229 E10465.192897 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.484046 matz1=3.448625 note=collision lift
G1 X166.729 Y163.633 Z2.663379 E10475.762772 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.448625 matz1=2.663379 note=collision lift
G1 X166.475894 Y164.005417 Z2.38654 E10479.072473 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.663379 matz1=2.38654 note=collision lift
G1 X166.317925 Y164.237851 Z2.494792 E10480.958192 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.38654 matz1=2.494792 note=collision lift
G1 X166.231085 Y163.356148 Z2.833674 E10486.389597 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.494792 matz1=2.833674 note=collision lift
G1 X165.716363 Y161.659336 Z3.509123 E10494.954546 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.833674 matz1=2.901787 note=collision lift
G1 X165.656792 Y161.462959 Z3.526709 E10495.884258 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.901787 matz1=2.877352 note=collision lift
G1 X165.656661 Y161.462712 Z3.526538 E10495.885354 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.877352 matz1=2.877319 note=collision lift
G1 X165.502489 Y161.174278 Z3.52676 E10496.977948 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.877319 matz1=2.839623 note=collision lift
G1 X165.500783 Y161.171086 Z3.528152 E10496.990902 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.839623 matz1=2.839206 note=collision lift
G1 X165.215279 Y160.636945 Z3.508278 E10499.015323 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.839206 matz1=2.769399 note=collision lift
G1 X165.213185 Y160.633028 Z3.509987 E10499.031222 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.769399 matz1=2.768887 note=collision lift
G1 X164.731088 Y159.731088 Z3.432566 E10502.457554 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.768887 matz1=2.651011 note=collision lift
G1 X164.727838 Y159.725007 Z3.428324 E10502.484599 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.651011 matz1=2.650216 note=collision lift
G1 X164.724191 Y159.718185 Z3.427629 E10502.510545 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.650216 matz1=2.649324 note=collision lift
G1 X164.72419 Y159.718184 Z3.427628 E10502.51055 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.649324 matz1=2.649324 note=collision lift
G1 X164.722595 Y159.71624 Z3.427376 E10502.518676 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.649324 matz1=2.649047 note=collision lift
G1 X164.722498 Y159.716122 Z3.427436 E10502.519204 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.649047 matz1=2.64903 note=collision lift
G1 X164.58666 Y159.550603 Z3.405738 E10503.211291 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.64903 matz1=2.625407 note=collision lift
G1 X164.584483 Y159.54795 Z3.407075 E10503.223136 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.625407 matz1=2.625028 note=collision lift
G1 X163.931746 Y158.752588 Z3.294434 E10505.581507 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.625028 matz1=2.518419 note=collision lift
G1 X163.929299 Y158.749607 Z3.292106 E10505.59177 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.518419 matz1=2.518019 note=collision lift
G1 X163.780302 Y158.568052 Z3.264635 E10506.130558 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.518019 matz1=2.493684 note=collision lift
G1 X163.780187 Y158.567912 Z3.264707 E10506.131002 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.493684 matz1=2.493665 note=collision lift
G1 X163.469122 Y158.188878 Z3.205027 E10507.256465 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.493665 matz1=2.44286 note=collision lift
G1 X163.46892 Y158.188713 Z3.204874 E10507.256887 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.44286 matz1=2.442837 note=collision lift
G1 X162.522569 Y157.412063 Z3.061198 E10508.973333 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.442837 matz1=2.336274 note=collision lift
G1 X162.522192 Y157.411753 Z3.0614 E10508.974069 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.336274 matz1=2.336232 note=collision lift
G1 X161.940535 Y156.934399 Z2.974829 E10510.028771 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.336232 matz1=2.270735 note=collision lift
G1 X161.939815 Y156.933809 Z2.975213 E10510.030174 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.270735 matz1=2.270654 note=collision lift
G1 X161.93764 Y156.932646 Z2.976273 E10510.032862 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.270654 matz1=2.270481 note=collision lift
G1 X160.982611 Y156.422173 Z2.849387 E10511.124808 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.270481 matz1=2.194659 note=collision lift
G1 X160.97823 Y156.419831 Z2.846617 E10511.127604 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.194659 matz1=2.194373 note=collision lift
G1 X160.835262 Y156.343413 Z2.826051 E10511.207918 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.194373 matz1=2.185049 note=collision lift
G1 X160.835169 Y156.343363 Z2.825992 E10511.207978 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.185049 matz1=2.185043 note=collision lift
G1 X160.79738 Y156.323164 Z2.820012 E10511.229241 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.185043 matz1=2.182578 note=collision lift
G1 X160.791211 Y156.319867 Z2.823107 E10511.233001 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.182578 matz1=2.182176 note=collision lift
G1 X160.195041 Y156.001208 Z2.71284 E10511.569636 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.182176 matz1=2.143294 note=collision lift
G1 X160.174216 Y155.99489 Z2.701137 E10511.575451 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.143294 matz1=2.142473 note=collision lift
G1 X160.173199 Y155.994582 Z2.70089 E10511.575708 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.142473 matz1=2.142433 note=collision lift
G1 X160.172227 Y155.994287 Z2.701359 E10511.575971 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.142433 matz1=2.142394 note=collision lift
G1 X160.076045 Y155.965111 Z2.675625 E10511.600388 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.142394 matz1=2.1386 note=collision lift
G1 X160.073554 Y155.964355 Z2.674224 E10511.601084 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.1386 matz1=2.138502 note=collision lift
G1 X160.027954 Y155.950522 Z2.658098 E10511.612923 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.138502 matz1=2.136703 note=collision lift
G1 X160.024006 Y155.949325 Z2.655879 E10511.614026 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.136703 matz1=2.136548 note=collision lift
G1 X160.004891 Y155.943526 Z2.646845 E10511.619185 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.136548 matz1=2.135794 note=collision lift
G1 X160.003909 Y155.943228 Z2.64732 E10511.619451 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.135794 matz1=2.135755 note=collision lift
G1 X158.301852 Y155.426915 Z1.690856 E10512.094723 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.135755 matz1=1.690856 note=collision lift
G1 X156.333 Y155.233 Z0.684256 E10512.484562 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.690856 matz1=0.684256 note=collision lift
G1 X156.068175 Y155.259083 Z0.556708 E10512.577816 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.684256 matz1=0.556708 note=collision lift
G1 X154.364148 Y155.426915 Z0.592133 E10513.119032 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.470959 Y156.001208 Z0.688888 E10514.402309 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X150.726185 Y156.933809 Z0.835517 E10516.685288 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.196878 Y158.188878 Z1.023006 E10520.250169 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.941809 Y159.718185 Z1.239824 E10525.300479 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.009208 Y161.462959 Z1.47264 E10531.946105 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X146.434915 Y163.356148 Z1.707138 E10540.194774 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X146.241 Y165.325 Z1.9289 E10549.951645 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X146.434915 Y167.293852 Z2.124289 E10561.027273 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.009208 Y169.187041 Z2.281291 E10573.152653 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.941809 Y170.931815 Z2.390252 E10585.998849 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.11414 Y172.360304 Z2.442667 E10598.317205 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.196878 Y172.461122 Z2.444471 E10599.622088 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X150.279542 Y173.34964 Z2.4478 E10613.657752 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.317852 Y173.057915 Z2.432115 E10623.648898 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X148.788133 Y173.005742 Z2.417767 E10628.902707 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.349 Y172.864 Z2.358312 E10638.127796 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X145.380148 Y173.057915 Z2.231732 E10649.902911 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X143.486959 Y173.632208 Z2.060159 E10660.529483 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X141.742185 Y174.564809 Z1.854142 E10669.768025 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X140.212878 Y175.819878 Z1.626349 E10677.461632 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.957809 Y177.349185 Z1.390786 E10683.548974 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.025208 Y179.093959 Z1.16194 E10688.070675 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.450915 Y180.987148 Z0.95388 E10691.167571 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.257 Y182.956 Z0.779401 E10693.070871 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.450915 Y184.924852 Z0.649231 E10694.085702 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.025208 Y186.818041 Z0.571374 E10694.570405 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.957809 Y188.562815 Z0.550618 E10694.913907 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X140.212878 Y190.092122 Z0.588239 E10695.512784 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X141.742185 Y191.347191 Z0.681924 E10696.748655 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X142.74099 Y191.881064 Z0.758697 E10697.755879 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X143.486959 Y192.279792 Z0.825911 E10699.178655 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X145.380148 Y192.854085 Z1.011348 E10704.406284 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X147.349 Y193.048 Z1.226832 E10711.848179 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.317852 Y192.854085 Z1.459113 E10721.677672 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X151.211041 Y192.279792 Z1.693908 E10733.915276 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.413274 Y191.637185 Z1.849605 E10743.442335 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X152.955815 Y191.347191 Z1.916779 E10746.449564 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.485122 Y190.092122 Z2.114023 E10757.456206 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X155.740191 Y188.562815 Z2.273511 E10769.529836 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.672792 Y186.818041 Z2.385437 E10782.344379 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.247085 Y184.924852 Z2.442917 E10795.534074 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.441 Y182.956 Z2.442418 E10808.714821 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.247085 Y180.987148 Z2.383971 E10821.504533 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.672792 Y179.093959 Z2.271168 E10833.54274 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.532108 Y178.830756 Z2.249824 E10835.338508 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X155.740191 Y177.349185 Z2.110947 E10849.309655 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X155.273527 Y176.780554 Z2.037405 E10854.684617 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.485122 Y175.819878 Z2.534545 E10864.416441 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.037405 matz1=2.534545 note=collision lift
G1 X152.955815 Y174.564809 Z3.300541 E10877.404829 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.534545 matz1=3.189966 note=collision lift
G1 X151.458667 Y173.764566 Z3.9478 E10886.332397 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.189966 matz1=2.988427 note=collision lift
G1 X151.211041 Y173.632208 Z3.9478 E10887.712116 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.988427 matz1=2.955092 note=collision lift
G1 X150.279542 Y173.34964 Z3.9478 E10891.917157 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.955092 matz1=2.83964 note=collision lift
G1 X150.726185 Y173.716191 Z3.9478 E10894.212502 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.83964 matz1=2.772135 note=collision lift
G1 X151.324315 Y174.035898 Z3.9478 E10896.139355 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.772135 matz1=2.696742 note=collision lift
G1 X151.562013 Y174.162951 Z3.783077 E10897.036779 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.696742 matz1=2.66678 note=collision lift
G1 X152.351596 Y174.584992 Z3.683552 E10899.596062 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.66678 matz1=2.567255 note=collision lift
G1 X152.470959 Y174.648792 Z3.80385 E10900.110521 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.567255 matz1=2.55221 note=collision lift
G1 X152.8025 Y174.749364 Z4.016966 E10900.863531 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.55221 matz1=2.518518 note=collision lift
G1 X152.803984 Y174.749814 Z4.018367 E10900.8674 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.518518 matz1=2.518367 note=collision lift
G1 X152.977657 Y174.802497 Z3.947293 E10901.228222 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.518367 matz1=2.500718 note=collision lift
G1 X153.226284 Y174.877918 Z3.975452 E10901.712018 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.500718 matz1=2.475452 note=collision lift
G1 X153.402458 Y174.93136 Z3.957548 E10902.054443 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.475452 matz1=2.457548 note=collision lift
G1 X153.403286 Y174.931611 Z3.957464 E10902.056052 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.457548 matz1=2.457464 note=collision lift
G1 X153.474911 Y174.953338 Z3.92776 E10902.205126 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.457464 matz1=2.450186 note=collision lift
G1 X153.553234 Y174.977097 Z3.895278 E10902.368142 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.450186 matz1=2.442226 note=collision lift
G1 X153.560074 Y174.979172 Z3.894583 E10902.381437 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.442226 matz1=2.441531 note=collision lift
G1 X154.364148 Y175.223085 Z3.542371 E10904.068083 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.441531 matz1=2.359819 note=collision lift
G1 X154.367389 Y175.223404 Z3.538864 E10904.073175 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.359819 matz1=2.359567 note=collision lift
G1 X154.481799 Y175.234673 Z3.48715 E10904.207294 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.359567 matz1=2.350675 note=collision lift
G1 X154.536388 Y175.240049 Z3.489903 E10904.265727 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.350675 matz1=2.346432 note=collision lift
G1 X154.542174 Y175.240619 Z3.49236 E10904.272442 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.346432 matz1=2.345982 note=collision lift
G1 X155.121433 Y175.297671 Z3.510135 E10904.892007 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.345982 matz1=2.30096 note=collision lift
G1 X155.124205 Y175.297944 Z3.508528 E10904.895428 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.30096 matz1=2.300745 note=collision lift
G1 X155.421801 Y175.327255 Z3.506136 E10905.213593 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.300745 matz1=2.277615 note=collision lift
G1 X155.423624 Y175.327434 Z3.505079 E10905.215844 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.277615 matz1=2.277473 note=collision lift
G1 X155.571985 Y175.342047 Z3.496848 E10905.374695 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.277473 matz1=2.265942 note=collision lift
G1 X155.573275 Y175.342174 Z3.4961 E10905.376288 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.265942 matz1=2.265841 note=collision lift
G1 X155.647077 Y175.349442 Z3.487405 E10905.455729 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.265841 matz1=2.260105 note=collision lift
G1 X155.64813 Y175.349546 Z3.486794 E10905.457028 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.260105 matz1=2.260023 note=collision lift
G1 X155.682968 Y175.352977 Z3.479725 E10905.495025 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.260023 matz1=2.257316 note=collision lift
G1 X155.684623 Y175.35314 Z3.480428 E10905.496946 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257316 matz1=2.257187 note=collision lift
G1 X155.722169 Y175.356838 Z3.464985 E10905.540318 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.257187 matz1=2.254269 note=collision lift
G1 X156.333 Y175.417 Z3.110616 E10906.29437 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.254269 matz1=2.206793 note=collision lift
G1 X158.301852 Y175.223085 Z2.017174 E10907.486895 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.206793 matz1=2.017174 note=collision lift
G1 X158.39552 Y175.194671 Z1.964468 E10907.543392 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.017174 matz1=1.964468 note=collision lift
G1 X160.195041 Y174.648792 Z0.978917 E10907.932785 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.964468 matz1=0.978917 note=collision lift
G1 X160.945459 Y174.247686 Z0.5574 E10908.136691 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.978917 matz1=0.5574 note=collision lift
G1 X161.939815 Y173.716191 Z0.562606 E10908.378803 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X162.044324 Y173.630423 Z0.565361 E10908.409119 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.469122 Y172.461122 Z0.629379 E10909.63676 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.724191 Y170.931815 Z0.749686 E10912.182908 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.653346 Y169.193488 Z0.915441 E10916.410766 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.656792 Y169.187041 Z0.916129 E10916.426485 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.660897 Y169.173511 Z0.917575 E10916.471711 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.231085 Y167.293852 Z2.100594 E10923.767993 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.917575 matz1=2.100594 note=collision lift
G1 X166.40929 Y165.484508 Z3.217154 E10933.035771 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.100594 matz1=2.825986 note=collision lift
G1 X166.424825 Y165.326781 Z3.2395 E10933.73102 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.825986 matz1=2.844075 note=collision lift
G1 X166.425 Y165.325 Z3.240599 E10933.740144 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.844075 matz1=2.844279 note=collision lift
G1 X166.389058 Y164.960079 Z3.287122 E10935.428116 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.844279 matz1=2.887613 note=collision lift
G1 X166.388905 Y164.958526 Z3.286528 E10935.436252 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.887613 matz1=2.887798 note=collision lift
G1 X166.376645 Y164.834039 Z3.300871 E10936.049554 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.887798 matz1=2.902672 note=collision lift
G1 X166.376469 Y164.832259 Z3.301978 E10936.059801 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.902672 matz1=2.902885 note=collision lift
G1 X166.340303 Y164.465053 Z3.339381 E10937.866327 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.902885 matz1=2.946759 note=collision lift
G1 X166.340177 Y164.463782 Z3.338894 E10937.873177 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.946759 matz1=2.946911 note=collision lift
G1 X166.317925 Y164.237851 Z3.358386 E10939.015003 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.946911 matz1=2.973989 note=collision lift
G1 X166.31732 Y164.238742 Z3.357976 E10939.021034 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.973989 matz1=2.974118 note=collision lift
G1 X166.115576 Y164.535585 Z3.318519 E10940.91023 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.974118 matz1=3.01696 note=collision lift
G1 X166.115534 Y164.535647 Z3.318491 E10940.910662 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.01696 matz1=3.016969 note=collision lift
G1 X166.026374 Y164.666836 Z3.300988 E10941.766637 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.016969 matz1=3.035896 note=collision lift
G1 X166.026364 Y164.666852 Z3.300981 E10941.766744 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.035896 matz1=3.035898 note=collision lift
G1 X165.995008 Y164.712989 Z3.294577 E10942.067927 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.035898 matz1=3.042554 note=collision lift
G1 X165.995 Y164.713 Z3.294585 E10942.068014 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.042554 matz1=3.042555 note=collision lift
G1 X165.917949 Y164.878966 Z3.273814 E10943.076471 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.042555 matz1=3.064365 note=collision lift
G1 X165.917912 Y164.879046 Z3.273868 E10943.077035 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.064365 matz1=3.064375 note=collision lift
G1 X165.708828 Y165.32941 Z3.217097 E10946.147138 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.064375 matz1=3.123052 note=collision lift
G1 X165.456 Y165.874 Z2.987841 E10950.095262 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.123052 matz1=2.987841 note=collision lift
G1 X165.269 Y166.486 Z2.741953 E10954.567898 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.987841 matz1=2.741953 note=collision lift
G1 X165.08 Y167.779 Z2.233964 E10964.763524 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.741953 matz1=2.233964 note=collision lift
G1 X165.084706 Y168.419984 Z1.980851 E10970.029102 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.233964 matz1=1.980851 note=collision lift
G1 X165.085 Y168.46 Z1.985058 E10970.336538 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.189221 Y169.108788 Z2.050778 E10975.605505 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.316 Y169.898 Z2.125621 E10982.320103 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.548 Y170.655 Z2.19354 E10989.244093 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.268 Y172.25 Z2.318461 E11005.658293 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.763 Y173.09 Z2.371271 E11015.058919 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.918736 Y173.305326 Z2.383428 E11017.636682 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X167.619719 Y174.274525 Z2.425783 E11029.495366 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.041 Y174.857 Z2.441235 E11036.676615 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X169.731 Y176.745 Z2.434228 E11061.892708 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.138788 Y177.13041 Z2.419761 E11067.436538 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.451906 Y176.618699 Z2.345044 E11084.185026 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.668 Y176.443 Z2.226747 E11100.144547 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.167998 Y176.590737 Z2.098556 E11112.585685 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.884094 Y176.618699 Z2.07173 E11114.13039 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.168743 Y177.139046 Z1.887826 E11122.70797 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X162.349599 Y177.576887 Z1.782381 E11126.50523 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X161.587866 Y177.984042 Z2.116186 E11130.266725 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.782381 matz1=2.116186 note=collision lift
G1 X160.202216 Y179.121216 Z2.799641 E11136.659334 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.116186 matz1=2.799641 note=collision lift
G1 X159.065042 Y180.506866 Z3.484536 E11141.662429 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.799641 matz1=2.760139 note=collision lift
G1 X158.550619 Y181.469283 Z3.908869 E11143.914954 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.760139 matz1=2.638835 note=collision lift
G1 X158.405549 Y181.74069 Z3.929376 E11144.508309 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.638835 matz1=2.604627 note=collision lift
G1 X158.40498 Y181.741755 Z3.928637 E11144.511033 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.604627 matz1=2.604493 note=collision lift
G1 X158.260479 Y182.012097 Z3.942757 E11145.101376 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.604493 matz1=2.570419 note=collision lift
G1 X158.260218 Y182.012585 Z3.942418 E11145.102626 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.570419 matz1=2.570357 note=collision lift
G1 X158.220047 Y182.08774 Z3.942444 E11145.266566 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.570357 matz1=2.560885 note=collision lift
G1 X158.220046 Y182.087743 Z3.942445 E11145.266573 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.560885 matz1=2.560884 note=collision lift
G1 X157.941703 Y183.005315 Z3.942708 E11146.528887 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.560884 matz1=2.466168 note=collision lift
G1 X157.711464 Y183.764312 Z3.88782 E11147.575544 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.466168 matz1=2.38782 note=collision lift
G1 X157.711464 Y183.764313 Z3.88782 E11147.575545 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.38782 matz1=2.38782 note=collision lift
G1 X157.699699 Y183.803094 Z3.883817 E11147.629157 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.38782 matz1=2.383817 note=collision lift
G1 X157.524 Y185.587 Z3.737883 E11149.096574 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.383817 matz1=2.237883 note=collision lift
G1 X157.577312 Y186.128288 Z3.705286 E11149.340386 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.237883 matz1=2.205286 note=collision lift
G1 X157.577519 Y186.130386 Z3.70516 E11149.341331 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.205286 matz1=2.20516 note=collision lift
G1 X157.675196 Y187.122117 Z3.645438 E11149.788036 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.20516 matz1=2.145438 note=collision lift
G1 X157.675425 Y187.124449 Z3.645298 E11149.789086 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.145438 matz1=2.145298 note=collision lift
G1 X157.699699 Y187.370906 Z3.630456 E11149.900098 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.145298 matz1=2.130456 note=collision lift
G1 X157.69972 Y187.370975 Z3.630453 E11149.900115 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.130456 matz1=2.130453 note=collision lift
G1 X157.732902 Y187.480361 Z3.626405 E11149.926386 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.130453 matz1=2.126405 note=collision lift
G1 X158.220046 Y189.086257 Z2.987296 E11150.338837 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.126405 matz1=2.066964 note=collision lift
G1 X159.065042 Y190.667134 Z2.074679 E11150.688047 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.066964 matz1=2.050615 note=collision lift
G1 X159.24593 Y190.887547 Z1.933945 E11150.74525 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.050615 matz1=1.933945 note=collision lift
G1 X160.202216 Y192.052784 Z1.21003 E11151.452759 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.933945 matz1=1.21003 note=collision lift
G1 X161.172799 Y192.849322 Z0.636865 E11152.590558 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.21003 matz1=0.636865 note=collision lift
G1 X161.587866 Y193.189958 Z0.660227 E11153.033614 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X163.168743 Y194.034954 Z0.78065 E11155.627732 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X164.884094 Y194.555301 Z0.937418 E11159.677209 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.600329 Y194.625844 Z1.008856 E11161.570662 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X166.668 Y194.731 Z1.122612 E11165.026541 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.11 Y194.588975 Z1.286721 E11170.928947 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.451906 Y194.555301 Z1.326874 E11172.400472 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.167257 Y194.034954 Z1.539884 E11182.058247 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X170.537701 Y193.836948 Z1.589905 E11184.430265 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X169.771 Y193.801 Z1.680565 E11189.124668 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X168.139091 Y193.839537 Z1.86676 E11200.677688 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X167.696 Y193.85 Z1.914975 E11203.923303 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.543845 Y194.084745 Z2.129344 E11222.160269 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X165.514 Y194.088 Z2.132025 E11222.413354 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X162.582 Y194.005 Z2.345122 E11250.331429 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X160.052 Y194.146 Z2.438479 E11275.620259 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X158.160737 Y194.448918 Z2.446587 E11294.802934 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.898 Y194.491 Z2.443368 E11296.5767 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X157.131669 Y194.689287 Z2.427577 E11301.811193 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X156.955 Y194.735 Z2.422628 E11303.616981 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X155.318 Y195.354 Z2.351013 E11320.297924 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.618 Y195.725 Z2.304834 E11327.666926 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X154.574981 Y195.756098 Z2.300996 E11328.132293 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X153.438 Y196.578 Z2.901037 E11341.474767 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.300996 matz1=2.901037 note=collision lift
G1 X152.953 Y197.056 Z3.184025 E11347.704761 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.901037 matz1=3.184025 note=collision lift
G1 X152.918944 Y197.101698 Z3.190763 E11348.183946 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.184025 matz1=3.190763 note=collision lift
G1 X152.918936 Y197.101709 Z3.190771 E11348.184082 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.190763 matz1=3.190771 note=collision lift
G1 X152.918928 Y197.10172 Z3.190764 E11348.18421 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.190771 matz1=3.190764 note=collision lift
G1 X152.824432 Y197.228521 Z3.190764 E11349.504629 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.190764 matz1=3.190764 note=collision lift
G1 X152.682584 Y196.963143 Z3.190764 E11351.963008 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.190764 matz1=3.190764 note=collision lift
G1 X152.682508 Y196.963 Z3.19083 E11351.964439 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.190764 matz1=3.19083 note=collision lift
G1 X152.645191 Y196.893185 Z3.184693 E11352.613119 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.19083 matz1=3.184693 note=collision lift
G1 X151.758198 Y195.812381 Z2.346118 E11364.762918 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=3.184693 matz1=2.346118 note=collision lift
G1 X151.390122 Y195.363878 Z1.993818 E11369.60413 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.346118 matz1=1.993818 note=collision lift
G1 X151.223823 Y195.2274 Z1.861738 E11371.111789 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.993818 matz1=1.861738 note=collision lift
G1 X150.711415 Y194.806878 Z1.786203 E11375.096294 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X149.860815 Y194.108809 Z2.211002 E11382.140775 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.786203 matz1=2.211002 note=collision lift
G1 X149.218076 Y193.765258 Z2.489097 E11386.453117 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.211002 matz1=2.489097 note=collision lift
G1 X148.116041 Y193.176208 Z2.964866 E11392.819793 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.489097 matz1=2.925491 note=collision lift
G1 X148.107517 Y193.173622 Z2.959373 E11392.8572 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.925491 matz1=2.924452 note=collision lift
G1 X148.10751 Y193.17362 Z2.959372 E11392.857228 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924452 matz1=2.924451 note=collision lift
G1 X148.107502 Y193.173617 Z2.959372 E11392.857256 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924451 matz1=2.92445 note=collision lift
G1 X148.107495 Y193.173615 Z2.959371 E11392.857283 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.92445 matz1=2.924449 note=collision lift
G1 X148.107487 Y193.173613 Z2.95937 E11392.857311 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924449 matz1=2.924448 note=collision lift
G1 X148.10748 Y193.173611 Z2.959369 E11392.857339 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924448 matz1=2.924447 note=collision lift
G1 X148.107472 Y193.173608 Z2.959368 E11392.857367 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924447 matz1=2.924446 note=collision lift
G1 X148.107465 Y193.173606 Z2.959368 E11392.857395 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924446 matz1=2.924445 note=collision lift
G1 X148.107457 Y193.173604 Z2.959367 E11392.857423 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924445 matz1=2.924444 note=collision lift
G1 X148.10745 Y193.173602 Z2.959362 E11392.857456 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924444 matz1=2.924443 note=collision lift
G1 X147.608984 Y193.022394 Z2.904739 E11394.729565 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.924443 matz1=2.86369 note=collision lift
G1 X147.608351 Y193.022202 Z2.904331 E11394.732344 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.86369 matz1=2.863613 note=collision lift
G1 X147.342973 Y192.9417 Z2.87371 E11395.729625 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.863613 matz1=2.831268 note=collision lift
G1 X147.338394 Y192.940311 Z2.875544 E11395.747944 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.831268 matz1=2.83071 note=collision lift
G1 X146.222852 Y192.601915 Z2.734699 E11399.945089 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.83071 matz1=2.694747 note=collision lift
G1 X146.217108 Y192.601349 Z2.731194 E11399.96186 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.694747 matz1=2.694129 note=collision lift
G1 X146.18282 Y192.597972 Z2.726833 E11400.048119 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.694129 matz1=2.690437 note=collision lift
G1 X146.182818 Y192.597972 Z2.726832 E11400.048125 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.690437 matz1=2.690437 note=collision lift
G1 X144.254002 Y192.408 Z2.51573 E11404.890637 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.690437 matz1=2.482774 note=collision lift
G1 X144.254 Y192.408 Z2.51573 E11404.890642 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.482774 matz1=2.482773 note=collision lift
G1 X144.210966 Y192.412238 Z2.511362 E11404.964728 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.482773 matz1=2.478761 note=collision lift
G1 X144.21084 Y192.412251 Z2.511414 E11404.964961 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.478761 matz1=2.478749 note=collision lift
G1 X143.994801 Y192.433529 Z2.492875 E11405.336351 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.478749 matz1=2.458605 note=collision lift
G1 X143.994016 Y192.433606 Z2.493196 E11405.337805 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.458605 matz1=2.458532 note=collision lift
G1 X143.424263 Y192.489722 Z2.441809 E11406.317633 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.458532 matz1=2.405407 note=collision lift
G1 X143.423247 Y192.489822 Z2.442225 E11406.319512 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.405407 matz1=2.405312 note=collision lift
G1 X142.629676 Y192.567982 Z2.364254 E11407.685268 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.405312 matz1=2.331319 note=collision lift
G1 X142.627973 Y192.56815 Z2.363256 E11407.687325 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.331319 matz1=2.331177 note=collision lift
G1 X142.285355 Y192.601895 Z2.326818 E11408.046649 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.331177 matz1=2.302621 note=collision lift
G1 X142.285148 Y192.601915 Z2.326905 E11408.046883 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.302621 matz1=2.302604 note=collision lift
G1 X142.279625 Y192.60359 Z2.32939 E11408.050446 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.302604 matz1=2.302203 note=collision lift
G1 X140.391959 Y193.176208 Z1.206201 E11409.337576 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.302203 matz1=1.206201 note=collision lift
G1 X139.437924 Y193.68615 Z0.617485 E11409.686593 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.206201 matz1=0.617485 note=collision lift
G1 X138.74253 Y194.057846 Z0.582622 E11409.910263 F1800 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X138.647185 Y194.108809 Z0.579353 E11409.95442 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X137.117878 Y195.363878 Z0.55 E11410.463409 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X135.862809 Y196.893185 Z0.579062 E11411.268237 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X135.664908 Y197.263432 Z0.597246 E11411.624424 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000
G1 X135.186503 Y198.158465 Z1.148636 E11412.60343 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=0.597246 matz1=1.148636 note=collision lift
G1 X134.930208 Y198.637959 Z1.444032 E11413.127911 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.148636 matz1=1.444032 note=attached-tail
G1 X134.355915 Y200.531148 Z2.570269 E11416.662706 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=1.444032 matz1=2.301801 note=attached-tail
G1 X134.284521 Y201.256019 Z3.000722 E11418.759868 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.301801 matz1=2.368064 note=attached-tail
G1 X134.162 Y202.5 Z3.148401 E11421.879827 F1200 ; clayline kind=print page=0 layer=0 stroke=stroke-0000 matz0=2.368064 matz1=2.481781 note=attached-tail
; CLAYLINE_STROKE_END page=0 layer=0 id=stroke-0000
G1 X134.162 Y202.5 Z5.148401 E11426.837284 F1200 ; clayline kind=thread_release page=0 layer=0 stroke=stroke-0000 note=thread release
; CLAYLINE_PAGE index=1
G0 X134.162 Y202.5 Z7.018367 F2400 ; clayline kind=travel_lift page=1 layer=0 stroke=stroke-0000 note=inter-page clearance above completed material
G0 X135.764611 Y187.252172 Z7.018367 F2400 ; clayline kind=travel_xy page=1 layer=0 stroke=stroke-0000 note=inter-page XY within common stack footprint
G0 X135.764611 Y187.252172 Z3.95 F2400 ; clayline kind=travel_approach page=1 layer=0 stroke=stroke-0000 note=inter-page approach
; CLAYLINE_MARKER page=1 layer=0 text=layer 0 page_id=page-02-zellige-rosette page_name=zellige-rosette z_mode=calibrated
; CLAYLINE_STROKE_BEGIN page=1 layer=0 id=stroke-0000
G1 X136.215652 Y185.83246 Z3.773992 E11427.106076 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X136.363636 Y185.366662 Z3.716246 E11427.311388 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X136.847367 Y184.48948 Z3.605165 E11427.740363 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X137.318995 Y183.634245 Z3.496865 E11428.32537 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X137.650858 Y183.240495 Z3.447015 E11428.5685 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X138.593976 Y182.121498 Z3.305347 E11429.42135 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X138.617134 Y182.102995 Z3.303071 E11429.432639 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X139.785568 Y181.169411 Z3.188255 E11430.075011 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X140.13958 Y180.886554 Z3.153468 E11430.297814 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X141.066774 Y180.406455 Z3.099161 E11430.57575 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X141.896411 Y179.976871 Z3.050568 E11430.853501 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X142.438525 Y179.820142 Z3.036992 E11430.948771 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X143.796956 Y179.427409 Z3.002973 E11431.210615 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X143.882173 Y179.42014 Z3.003433 E11431.230899 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X145.376725 Y179.292669 Z3.011498 E11431.610236 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X145.768177 Y179.259282 Z3.01361 E11431.716966 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X146.112231 Y179.297722 Z3.021465 E11431.825507 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X146.867847 Y179.382144 Z3.049583 E11432.282724 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=prime ramp
G1 X147.734322 Y179.478952 Z3.081826 E11432.820662 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X149.619832 Y180.077976 Z3.203425 E11435.170097 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X151.352249 Y181.033336 Z3.37093 E11439.079016 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.307731 Y181.838639 Z3.495828 E11442.28504 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.864996 Y182.308316 Z3.574042 E11444.424439 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.09994 Y183.85392 Z3.800271 E11452.343513 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.366724 Y184.369149 Z3.869008 E11454.854888 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.679058 Y184.972345 Z3.95 E11458.054443 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.009623 Y185.610752 Z4.035707 E11461.730994 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.115227 Y185.976026 Z4.0808 E11463.756136 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.276854 Y185.834005 Z4.10619 E11464.927731 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.850637 Y185.467288 Z4.185708 E11468.890203 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X157.1822 Y184.878264 Z4.349221 E11478.478982 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X157.944039 Y184.660909 Z4.432924 E11484.004484 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.673964 Y184.395787 Z4.599767 E11497.570187 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.856277 Y184.387805 Z4.615488 E11498.996998 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X160.647087 Y184.35318 Z4.679524 E11503.27979 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X160.912832 Y184.366644 Z4.69946 E11504.735372 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.825747 Y184.463561 Z4.817016 E11521.492644 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.329776 Y184.851659 Z4.894999 E11544.555089 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X168.180448 Y185.542442 Z4.866604 E11570.850335 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X168.210317 Y185.545463 Z4.865656 E11571.119462 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.364249 Y185.763306 Z4.763961 E11589.507482 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.799833 Y185.845195 Z4.73543 E11593.216352 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.47336 Y185.971817 Z4.682814 E11598.553334 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.404093 Y186.146794 Z5.083625 E11606.53822 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.682814 matz1=5.083625 note=collision lift
G1 X173.146565 Y186.341363 Z5.398534 E11612.712825 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.083625 matz1=5.398534 note=collision lift
G1 X172.743049 Y186.458022 Z5.5685 E11616.000359 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.398534 matz1=5.5685 note=collision lift
G1 X170.956996 Y186.610356 Z6.278022 E11628.303475 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.5685 matz1=5.814442 note=collision lift
G1 X170.615561 Y186.572209 Z6.294294 E11630.436997 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.814442 matz1=5.776238 note=collision lift
G1 X170.286164 Y186.535407 Z6.309992 E11632.236176 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.776238 matz1=5.738047 note=collision lift
G1 X170.286161 Y186.535406 Z6.309994 E11632.236197 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.738047 matz1=5.738047 note=collision lift
G1 X169.175543 Y186.411321 Z6.362915 E11638.302441 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.738047 matz1=5.60928 note=collision lift
G1 X169.126558 Y186.395759 Z6.365657 E11638.550872 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.60928 matz1=5.603181 note=collision lift
G1 X169.126557 Y186.395758 Z6.365656 E11638.55088 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.603181 matz1=5.60318 note=collision lift
G1 X169.101324 Y186.387742 Z6.366604 E11638.678754 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.60318 matz1=5.600038 note=collision lift
G1 X169.101305 Y186.387736 Z6.366611 E11638.678852 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.600038 matz1=5.600036 note=collision lift
G1 X168.153066 Y186.086481 Z6.376563 E11643.48135 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.600036 matz1=5.481954 note=collision lift
G1 X168.153056 Y186.086478 Z6.376557 E11643.481403 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.481954 matz1=5.481953 note=collision lift
G1 X168.056087 Y186.055671 Z6.377572 E11643.931645 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.481953 matz1=5.469812 note=collision lift
G1 X168.056081 Y186.055669 Z6.377574 E11643.931674 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.469812 matz1=5.469811 note=collision lift
G1 X167.467396 Y185.868644 Z6.383724 E11646.665026 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.469811 matz1=5.396102 note=collision lift
G1 X167.46715 Y185.868566 Z6.383822 E11646.666249 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.396102 matz1=5.396071 note=collision lift
G1 X166.485725 Y185.327349 Z6.39509 E11650.522421 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.396071 matz1=5.264468 note=collision lift
G1 X166.485595 Y185.327278 Z6.394999 E11650.52302 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.264468 matz1=5.264451 note=collision lift
G1 X165.897469 Y185.002949 Z6.394999 E11652.833744 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.264451 matz1=5.185587 note=collision lift
G1 X164.554544 Y183.871099 Z6.394999 E11657.256946 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.185587 matz1=4.992449 note=collision lift
G1 X164.554538 Y183.871095 Z6.395001 E11657.256965 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.992449 matz1=4.992448 note=collision lift
G1 X164.527493 Y183.8483 Z6.393536 E11657.346121 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.992448 matz1=4.988559 note=collision lift
G1 X164.526823 Y183.847735 Z6.393877 E11657.34849 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.988559 matz1=4.988462 note=collision lift
G1 X164.352281 Y183.629287 Z6.380482 E11657.825943 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.988462 matz1=4.961351 note=collision lift
G1 X164.35107 Y183.62777 Z6.381264 E11657.829511 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.961351 matz1=4.961163 note=collision lift
G1 X164.175317 Y183.407806 Z6.360738 E11658.311002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.961163 matz1=4.933863 note=collision lift
G1 X163.407884 Y182.447319 Z5.62682 E11660.753094 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.933863 matz1=4.814658 note=collision lift
G1 X162.714762 Y181.108721 Z4.751494 E11662.734518 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.814658 matz1=4.693032 note=collision lift
G1 X162.583653 Y180.855517 Z4.588848 E11662.962726 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.693032 matz1=4.588848 note=collision lift
G1 X162.430824 Y180.326893 Z4.282265 E11663.199434 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.588848 matz1=4.282265 note=collision lift
G1 X162.417328 Y180.280213 Z4.303784 E11663.219404 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.282265 matz1=4.303784 note=collision lift
G1 X162.415263 Y180.273071 Z4.299641 E11663.222602 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.303784 matz1=4.299641 note=collision lift
G1 X162.085805 Y179.133501 Z4.299641 E11663.668362 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.299641 matz1=4.299641 note=collision lift
G1 X161.933471 Y177.347448 Z4.299641 E11664.017748 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.299641 matz1=4.299641 note=collision lift
G1 X161.934745 Y177.336045 Z4.299641 E11664.019604 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.299641 matz1=4.299641 note=collision lift
G1 X161.936475 Y177.320564 Z4.307338 E11664.022414 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.299641 matz1=4.307338 note=collision lift
G1 X162.03449 Y176.44328 Z4.008219 E11664.173169 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.307338 matz1=4.008219 note=collision lift
G1 X162.040487 Y176.389603 Z3.980894 E11664.182959 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.008219 matz1=3.980894 note=collision lift
G1 X162.083444 Y176.005117 Z3.826952 E11664.250307 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.980894 matz1=3.826952 note=collision lift
G1 X162.083498 Y176.004637 Z3.82719 E11664.250394 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.826952 matz1=3.82719 note=collision lift
G1 X162.132506 Y175.565995 Z3.629744 E11664.328602 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.82719 matz1=3.629744 note=collision lift
G1 X162.215395 Y175.305091 Z3.498558 E11664.41298 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.629744 matz1=3.498558 note=collision lift
G1 X162.259847 Y175.165173 Z3.491 E11664.453841 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.498558 matz1=3.491 note=collision lift
G1 X162.261237 Y175.160798 Z3.4888 E11664.455256 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.491 matz1=3.4888 note=collision lift
G1 X162.323517 Y174.964763 Z3.465711 E11664.512788 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.4888 matz1=3.465711 note=collision lift
G1 X162.324656 Y174.961177 Z3.463908 E11664.513948 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.465711 matz1=3.463908 note=collision lift
G1 X162.355352 Y174.864557 Z3.444338 E11664.542647 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.463908 matz1=3.444338 note=collision lift
G1 X162.356599 Y174.860632 Z3.442364 E11664.543916 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.444338 matz1=3.442364 note=collision lift
G1 X162.37127 Y174.814454 Z3.427661 E11664.55799 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.442364 matz1=3.427661 note=collision lift
G1 X162.377674 Y174.794297 Z3.417526 E11664.564509 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.427661 matz1=3.417526 note=collision lift
G1 X162.378846 Y174.790605 Z3.415761 E11664.565692 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.417526 matz1=3.415761 note=collision lift
G1 X162.379228 Y174.789403 Z3.416418 E11664.566088 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.415761 matz1=3.416418 note=collision lift
G1 X162.620006 Y174.031524 Z3.035348 E11664.81119 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.416418 matz1=3.035348 note=collision lift
G1 X162.675261 Y173.857602 Z3.039142 E11664.861925 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.934245 Y173.387968 Z3.064062 E11665.150595 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X163.540878 Y172.287921 Z3.750548 E11665.920307 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.064062 matz1=3.750548 note=collision lift
G1 X163.556641 Y172.269218 Z3.764485 E11665.946425 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.750548 matz1=3.764485 note=collision lift
G1 X163.557383 Y172.268337 Z3.763989 E11665.947589 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.764485 matz1=3.763989 note=collision lift
G1 X163.570423 Y172.252865 Z3.771524 E11665.967621 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.763989 matz1=3.771524 note=collision lift
G1 X163.57154 Y172.25154 Z3.772511 E11665.969471 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.771524 matz1=3.772511 note=collision lift
G1 X163.600336 Y172.217375 Z3.783752 E11666.012217 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.772511 matz1=3.783752 note=collision lift
G1 X163.601338 Y172.216185 Z3.784638 E11666.013878 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.783752 matz1=3.784638 note=collision lift
G1 X163.659767 Y172.14686 Z3.799595 E11666.09913 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.784638 matz1=3.799595 note=collision lift
G1 X163.660935 Y172.145475 Z3.800628 E11666.101065 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.799595 matz1=3.800628 note=collision lift
G1 X163.776513 Y172.008343 Z3.818929 E11666.268317 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.800628 matz1=3.818929 note=collision lift
G1 X163.780127 Y172.004054 Z3.822125 E11666.274306 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.818929 matz1=3.822125 note=collision lift
G1 X164.236167 Y171.462969 Z3.842398 E11666.931097 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.822125 matz1=3.842398 note=collision lift
G1 X164.237489 Y171.461401 Z3.841516 E11666.933168 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.842398 matz1=3.841516 note=collision lift
G1 X164.692207 Y170.921884 Z3.844902 E11667.587794 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.841516 matz1=3.844902 note=collision lift
G1 X164.694465 Y170.919204 Z3.843395 E11667.591333 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.844902 matz1=3.843395 note=collision lift
G1 X164.695587 Y170.917873 Z3.843389 E11667.592949 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.843395 matz1=3.843389 note=collision lift
G1 X164.696092 Y170.917274 Z3.843835 E11667.593784 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.843389 matz1=3.843835 note=collision lift
G1 X164.999163 Y170.67512 Z3.844952 E11668.147962 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.843835 matz1=3.844952 note=collision lift
G1 X165.005572 Y170.669998 Z3.849789 E11668.161567 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.844952 matz1=3.849789 note=collision lift
G1 X165.988046 Y169.884998 Z3.829083 E11669.958297 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.849789 matz1=3.829083 note=collision lift
G1 X166.096508 Y169.798336 Z3.851276 E11670.159142 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.829083 matz1=3.851276 note=collision lift
G1 X166.109101 Y169.791815 Z3.845672 E11670.189861 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.851276 matz1=3.845672 note=collision lift
G1 X166.119454 Y169.786454 Z3.852724 E11670.217313 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.845672 matz1=3.852724 note=collision lift
G1 X166.593455 Y169.541018 Z3.8426 E11671.29289 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.852724 matz1=3.8426 note=collision lift
G1 X166.610923 Y169.531973 Z3.834828 E11671.335502 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.8426 matz1=3.834828 note=collision lift
G1 X166.828682 Y169.419218 Z3.804155 E11671.833391 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.834828 matz1=3.804155 note=collision lift
G1 X166.830455 Y169.4183 Z3.805363 E11671.838092 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.804155 matz1=3.805363 note=collision lift
G1 X166.944914 Y169.359034 Z3.7738 E11672.105441 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.805363 matz1=3.7738 note=collision lift
G1 X167.136842 Y169.259654 Z3.755639 E11672.54241 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.7738 matz1=3.755639 note=collision lift
G1 X167.225265 Y169.213869 Z3.764182 E11672.743755 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.755639 matz1=3.764182 note=collision lift
G1 X167.227418 Y169.212754 Z3.763224 E11672.749007 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.764182 matz1=3.763224 note=collision lift
G1 X167.68831 Y168.974105 Z3.759076 E11673.794686 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.763224 matz1=3.759076 note=collision lift
G1 X167.710622 Y168.967655 Z3.750131 E11673.860803 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.759076 matz1=3.750131 note=collision lift
G1 X167.946554 Y168.899445 Z3.698165 E11674.527687 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.750131 matz1=3.698165 note=collision lift
G1 X167.948299 Y168.89894 Z3.699282 E11674.533353 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.698165 matz1=3.699282 note=collision lift
G1 X168.208289 Y168.823775 Z3.658276 E11675.260524 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.699282 matz1=3.658276 note=collision lift
G1 X169.410326 Y168.476257 Z3.801973 E11678.606443 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.196379 Y168.323923 Z4.01531 E11684.602885 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.479893 Y168.355599 Z4.049237 E11685.587585 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.977832 Y168.522958 Z4.225347 E11694.639644 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.686225 Y169.065713 Z4.421471 E11707.050184 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.229855 Y169.916963 Z4.591158 E11720.643948 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X175.911109 Y169.455192 Z4.638952 E11725.092441 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.650577 Y167.257078 Z4.809095 E11747.175252 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.359605 Y166.599743 Z4.842176 E11753.543936 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.875448 Y165.50598 Z4.88099 E11764.352623 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.767884 Y165.262981 Z4.886784 E11766.760485 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.458347 Y164.33842 Z4.899061 E11775.649445 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.195487 Y163.132325 Z4.889437 E11786.824068 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.0857 Y162.628578 Z5.143204 E11792.025914 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.889437 matz1=5.143204 note=collision lift
G1 X173.049643 Y162.219646 Z5.337525 E11796.092564 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.143204 matz1=5.337525 note=collision lift
G1 X173.048688 Y162.20882 Z5.331801 E11796.202549 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.337525 matz1=5.331801 note=collision lift
G1 X173.016159 Y161.839885 Z5.331801 E11799.518684 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331801 matz1=5.331801 note=collision lift
G1 X173.056237 Y161.041561 Z5.331801 E11806.561707 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331801 matz1=5.331801 note=collision lift
G1 X173.089183 Y160.385281 Z5.331801 E11812.254026 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331801 matz1=5.331801 note=collision lift
G1 X173.225881 Y159.718123 Z5.331801 E11818.029207 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331801 matz1=5.331801 note=collision lift
G1 X173.543573 Y158.860032 Z5.331801 E11825.398182 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331801 matz1=5.331801 note=collision lift
G1 X173.546229 Y158.852858 Z5.335092 E11825.465244 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331801 matz1=5.335092 note=collision lift
G1 X173.67958 Y158.492674 Z5.187198 E11828.779766 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.335092 matz1=5.187198 note=collision lift
G1 X173.684879 Y158.483112 Z5.180845 E11828.878519 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.187198 matz1=5.180845 note=collision lift
G1 X173.834216 Y158.213599 Z5.032649 E11831.548972 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.180845 matz1=5.032649 note=collision lift
G1 X173.834658 Y158.2128 Z5.033032 E11831.556701 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.032649 matz1=5.033032 note=collision lift
G1 X173.989736 Y157.932927 Z4.853647 E11834.421729 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.033032 matz1=4.853647 note=collision lift
G1 X174.270456 Y157.559088 Z4.57774 E11838.410471 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.853647 matz1=4.57774 note=collision lift
G1 X174.353808 Y157.448086 Z4.565223 E11839.43458 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.648417 Y157.055752 Z4.766298 E11843.330662 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.565223 matz1=4.766298 note=collision lift
G1 X174.758343 Y156.909362 Z4.840215 E11844.76505 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.766298 matz1=4.840215 note=collision lift
G1 X174.913171 Y156.760893 Z4.926456 E11846.422071 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.840215 matz1=4.926456 note=collision lift
G1 X175.173 Y156.511736 Z5.070323 E11849.135045 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.926456 matz1=5.070323 note=collision lift
G1 X175.147651 Y156.738626 Z5.161032 E11850.827288 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.070323 matz1=5.161032 note=collision lift
G1 X175.09242 Y157.232971 Z5.357346 E11854.379926 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.161032 matz1=5.357346 note=collision lift
G1 X175.051704 Y157.59739 Z5.501001 E11856.923152 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.357346 matz1=5.501001 note=collision lift
G1 X174.45268 Y159.4829 Z6.264321 E11868.376915 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.501001 matz1=5.604829 note=collision lift
G1 X174.233658 Y159.880066 Z6.302739 E11870.334367 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.604829 matz1=5.550865 note=collision lift
G1 X174.233036 Y159.881196 Z6.30323 E11870.340302 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.550865 matz1=5.550711 note=collision lift
G1 X174.027239 Y160.25438 Z6.33461 E11872.177958 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.550711 matz1=5.500006 note=collision lift
G1 X174.027214 Y160.254426 Z6.334578 E11872.178225 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.500006 matz1=5.499999 note=collision lift
G1 X173.721859 Y160.808146 Z6.364892 E11874.900645 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.499999 matz1=5.424764 note=collision lift
G1 X173.721675 Y160.80848 Z6.364655 E11874.902577 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.424764 matz1=5.424718 note=collision lift
G1 X173.49732 Y161.215317 Z6.379258 E11876.901526 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.424718 matz1=5.36944 note=collision lift
G1 X173.497046 Y161.215642 Z6.378994 E11876.903674 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.36944 matz1=5.369389 note=collision lift
G1 X173.492787 Y161.220696 Z6.379177 E11876.932083 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.369389 matz1=5.368603 note=collision lift
G1 X173.492609 Y161.220907 Z6.379282 E11876.933347 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.368603 matz1=5.36857 note=collision lift
G1 X173.338995 Y161.403168 Z6.385471 E11877.701755 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.36857 matz1=5.340809 note=collision lift
G1 X173.338031 Y161.404312 Z6.386045 E11877.706918 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.340809 matz1=5.340635 note=collision lift
G1 X172.62994 Y162.244453 Z6.39166 E11881.247783 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.340635 matz1=5.212667 note=collision lift
G1 X172.629591 Y162.244867 Z6.391326 E11881.249832 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.212667 matz1=5.212604 note=collision lift
G1 X172.22234 Y162.728065 Z6.392128 E11883.286295 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.212604 matz1=5.139004 note=collision lift
G1 X172.221989 Y162.728345 Z6.391856 E11883.28747 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.139004 matz1=5.138956 note=collision lift
G1 X172.070261 Y162.849577 Z6.390931 E11883.721397 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.138956 matz1=5.118212 note=collision lift
G1 X172.069729 Y162.850002 Z6.391199 E11883.723031 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.118212 matz1=5.11814 note=collision lift
G1 X171.886518 Y162.996388 Z6.38827 E11884.247029 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.11814 matz1=5.093091 note=collision lift
G1 X170.676736 Y163.963009 Z5.448608 E11888.294003 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.093091 matz1=4.927692 note=collision lift
G1 X169.371282 Y164.63897 Z4.579406 E11890.766073 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.927692 matz1=4.579406 note=collision lift
G1 X169.039962 Y164.810526 Z4.731907 E11891.349509 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.579406 matz1=4.731907 note=collision lift
G1 X168.919904 Y164.872691 Z4.788521 E11891.485932 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.731907 matz1=4.748495 note=collision lift
G1 X168.767803 Y164.916665 Z4.856798 E11891.573264 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.748495 matz1=4.737606 note=collision lift
G1 X168.657615 Y164.948521 Z4.892378 E11891.634089 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.737606 matz1=4.729718 note=collision lift
G1 X168.615701 Y164.960639 Z4.911193 E11891.658155 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.729718 matz1=4.726717 note=collision lift
G1 X168.311497 Y165.048587 Z4.938985 E11891.819158 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.726717 matz1=4.704939 note=collision lift
G1 X168.305383 Y165.050354 Z4.935366 E11891.822867 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.704939 matz1=4.704501 note=collision lift
G1 X168.040812 Y165.126844 Z4.921136 E11891.962544 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.704501 matz1=4.685561 note=collision lift
G1 X168.039229 Y165.127302 Z4.920199 E11891.963504 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.685561 matz1=4.685447 note=collision lift
G1 X167.77803 Y165.202816 Z4.884161 E11892.102422 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.685447 matz1=4.666748 note=collision lift
G1 X167.770127 Y165.205101 Z4.887709 E11892.10696 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.666748 matz1=4.666182 note=collision lift
G1 X167.228756 Y165.361616 Z4.766732 E11892.398892 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.666182 matz1=4.627425 note=collision lift
G1 X167.212071 Y165.36644 Z4.756853 E11892.409013 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.627425 matz1=4.626231 note=collision lift
G1 X167.01936 Y165.422154 Z4.702794 E11892.514241 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.626231 matz1=4.612434 note=collision lift
G1 X167.018637 Y165.422216 Z4.702399 E11892.514449 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.612434 matz1=4.612403 note=collision lift
G1 X166.888056 Y165.433353 Z4.680885 E11892.547891 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.612403 matz1=4.60671 note=collision lift
G1 X166.882593 Y165.433819 Z4.683389 E11892.549409 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.60671 matz1=4.606472 note=collision lift
G1 X166.600191 Y165.457905 Z4.623052 E11892.622376 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.606472 matz1=4.594161 note=collision lift
G1 X165.145668 Y165.581963 Z4.623052 E11892.989958 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.594161 matz1=4.530754 note=collision lift
G1 X165.048139 Y165.590281 Z4.623052 E11893.025611 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.530754 matz1=4.527875 note=collision lift
G1 X163.214552 Y165.385421 Z4.623052 E11893.457218 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.527875 matz1=4.501894 note=collision lift
G1 X163.209443 Y165.38485 Z4.62555 E11893.458555 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501894 matz1=4.501822 note=collision lift
G1 X163.081994 Y165.370611 Z4.559623 E11893.492288 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501822 matz1=4.500016 note=collision lift
G1 X161.196484 Y164.771586 Z3.600989 E11894.320748 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.500016 matz1=3.600989 note=collision lift
G1 X160.197482 Y164.220676 Z3.080792 E11895.303991 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.600989 matz1=3.080792 note=collision lift
G1 X159.464067 Y163.816227 Z3.117661 E11895.961416 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X157.95132 Y162.541247 Z3.255931 E11898.799193 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X157.590647 Y162.089844 Z3.304817 E11899.761505 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.395735 Y162.533818 Z3.389733 E11901.682034 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.443041 Y162.559906 Z3.421734 E11901.81264 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.389733 matz1=3.421734 note=collision lift
G1 X159.430703 Y163.392331 Z4.202546 E11906.411592 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.421734 matz1=4.202546 note=collision lift
G1 X159.955789 Y163.834886 Z4.961016 E11909.529163 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.202546 matz1=4.961016 note=collision lift
G1 X159.964475 Y163.845757 Z4.954059 E11909.593168 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.961016 matz1=4.954059 note=collision lift
G1 X160.153601 Y164.082459 Z5.105549 E11910.986825 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.954059 matz1=5.105549 note=collision lift
G1 X160.191977 Y164.130489 Z5.07481 E11911.269611 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.105549 matz1=5.07481 note=collision lift
G1 X160.22466 Y164.171393 Z5.100989 E11911.510449 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.07481 matz1=5.100989 note=collision lift
G1 X160.270561 Y164.228841 Z5.100989 E11911.812982 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.100989 matz1=5.100989 note=collision lift
G1 X160.316462 Y164.286289 Z5.100989 E11912.115515 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.100989 matz1=5.100989 note=collision lift
G1 X160.407971 Y164.400818 Z5.100989 E11912.718649 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.100989 matz1=5.100989 note=collision lift
G1 X160.499481 Y164.515347 Z5.100989 E11913.321783 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.100989 matz1=5.100989 note=collision lift
G1 X160.499912 Y164.515888 Z5.101069 E11913.324646 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.100989 matz1=5.101069 note=collision lift
G1 X160.995467 Y165.136103 Z4.668948 E11917.043336 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.101069 matz1=4.668948 note=collision lift
G1 X160.996154 Y165.136963 Z4.667975 E11917.049381 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.668948 matz1=4.667975 note=collision lift
G1 X161.102887 Y165.270545 Z4.574342 E11917.851423 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.667975 matz1=4.574342 note=collision lift
G1 X161.190733 Y165.38049 Z4.567641 E11918.431071 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.574342 matz1=4.567641 note=collision lift
G1 X161.869426 Y166.691221 Z4.005385 E11926.669711 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.567641 matz1=4.005385 note=collision lift
G1 X162.100416 Y167.137322 Z4.065202 E11929.308525 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.566991 Y168.751165 Z4.26024 E11939.672768 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.649878 Y169.037866 Z4.293689 E11940.931012 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.818005 Y171.009087 Z4.501043 E11950.551584 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.598335 Y172.975232 Z4.674514 E11961.230679 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.999311 Y174.860742 Z4.803435 E11972.688502 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.043951 Y176.593159 Z4.879879 E11984.602529 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.768971 Y178.105906 Z4.899145 E11996.627092 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.223367 Y179.340851 Z4.860049 E12008.412206 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.466535 Y180.250533 Z4.764994 E12019.621556 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.875557 Y180.42139 Z4.724861 E12023.033363 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.565991 Y180.799996 Z4.619826 E12033.711656 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.466523 Y180.89377 Z4.515884 E12041.401898 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.59477 Y180.968123 Z4.87093 E12047.953325 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.515884 matz1=4.87093 note=collision lift
G1 X150.628625 Y180.748453 Z4.87093 E12059.680814 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.87093 matz1=4.87093 note=collision lift
G1 X149.631947 Y180.431809 Z4.225133 E12065.629975 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.87093 matz1=4.225133 note=collision lift
G1 X148.743115 Y180.149428 Z4.581826 E12070.462948 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.225133 matz1=4.581826 note=collision lift
G1 X147.010698 Y179.194069 Z4.581826 E12077.86736 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.581826 matz1=4.581826 note=collision lift
G1 X146.363931 Y178.648958 Z4.061498 E12081.131674 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.581826 matz1=4.061498 note=collision lift
G1 X145.738898 Y178.122165 Z3.562584 E12082.857064 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.061498 matz1=3.562584 note=collision lift
G1 X145.497951 Y177.919088 Z3.52781 E12083.428246 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X144.379081 Y176.518759 Z3.34985 E12085.570315 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X144.263006 Y176.373484 Z3.424363 E12085.808546 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.34985 matz1=3.424363 note=collision lift
G1 X144.075425 Y176.011216 Z3.59568 E12086.116215 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.424363 matz1=3.59568 note=collision lift
G1 X144.07467 Y176.009759 Z3.594727 E12086.117535 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.59568 matz1=3.594727 note=collision lift
G1 X144.055101 Y175.971965 Z3.608287 E12086.148594 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.594727 matz1=3.608287 note=collision lift
G1 X144.052131 Y175.966231 Z3.610999 E12086.153465 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.608287 matz1=3.610999 note=collision lift
G1 X144.00778 Y175.880577 Z3.631953 E12086.2221 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.610999 matz1=3.631953 note=collision lift
G1 X144.005544 Y175.876259 Z3.633995 E12086.225767 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.631953 matz1=3.633995 note=collision lift
G1 X143.914967 Y175.70133 Z3.6619 E12086.364111 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.633995 matz1=3.6619 note=collision lift
G1 X143.91237 Y175.696315 Z3.664272 E12086.36837 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.6619 matz1=3.664272 note=collision lift
G1 X143.729943 Y175.344002 Z3.697536 E12086.645215 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.664272 matz1=3.697536 note=collision lift
G1 X143.726021 Y175.336428 Z3.701118 E12086.651648 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.697536 matz1=3.701118 note=collision lift
G1 X143.353324 Y174.616653 Z3.730463 E12087.215632 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.701118 matz1=3.730463 note=collision lift
G1 X143.351496 Y174.610331 Z3.726805 E12087.21827 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.730463 matz1=3.726805 note=collision lift
G1 X143.307753 Y174.459028 Z3.731717 E12087.273496 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.726805 matz1=3.731717 note=collision lift
G1 X143.306317 Y174.454061 Z3.734013 E12087.275478 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.731717 matz1=3.734013 note=collision lift
G1 X143.093782 Y173.718921 Z3.741576 E12087.543684 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.734013 matz1=3.741576 note=collision lift
G1 X143.093675 Y173.718548 Z3.74136 E12087.54384 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.741576 matz1=3.74136 note=collision lift
G1 X142.881248 Y172.983782 Z3.733549 E12087.81191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.74136 matz1=3.733549 note=collision lift
G1 X142.880501 Y172.981198 Z3.732054 E12087.812989 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.733549 matz1=3.732054 note=collision lift
G1 X142.805693 Y172.722445 Z3.722933 E12087.907441 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.732054 matz1=3.722933 note=collision lift
G1 X142.803861 Y172.716108 Z3.725863 E12087.90997 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.722933 matz1=3.725863 note=collision lift
G1 X142.742019 Y171.991037 Z3.695898 E12088.037979 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.725863 matz1=3.695898 note=collision lift
G1 X142.741523 Y171.985217 Z3.692812 E12088.039141 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.695898 matz1=3.692812 note=collision lift
G1 X142.711098 Y171.628501 Z3.660672 E12088.102317 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.692812 matz1=3.660672 note=collision lift
G1 X142.710773 Y171.624683 Z3.658647 E12088.103079 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.660672 matz1=3.658647 note=collision lift
G1 X142.695638 Y171.447233 Z3.63194 E12088.134731 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.658647 matz1=3.63194 note=collision lift
G1 X142.695375 Y171.444155 Z3.630308 E12088.135345 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63194 matz1=3.630308 note=collision lift
G1 X142.687908 Y171.356599 Z3.610132 E12088.151191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.630308 matz1=3.610132 note=collision lift
G1 X142.687632 Y171.353367 Z3.608418 E12088.151836 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.610132 matz1=3.608418 note=collision lift
G1 X142.684199 Y171.313118 Z3.594776 E12088.15933 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.608418 matz1=3.594776 note=collision lift
G1 X142.684043 Y171.311282 Z3.595645 E12088.159688 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.594776 matz1=3.595645 note=collision lift
G1 X142.635734 Y170.744887 Z3.29532 E12088.272685 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.595645 matz1=3.29532 note=collision lift
G1 X142.699902 Y170.170554 Z3.006949 E12088.390217 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.29532 matz1=3.006949 note=collision lift
G1 X142.855404 Y168.778742 Z3.008361 E12088.645072 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X143.44352 Y166.92757 Z3.067165 E12089.36162 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X143.454429 Y166.893232 Z3.086271 E12089.376658 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.067165 matz1=3.086271 note=collision lift
G1 X143.830566 Y166.211158 Z3.520654 E12090.022854 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.086271 matz1=3.520654 note=collision lift
G1 X143.831217 Y166.209977 Z3.520057 E12090.023923 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.520654 matz1=3.520057 note=collision lift
G1 X143.841895 Y166.190615 Z3.527635 E12090.040859 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.520057 matz1=3.527635 note=collision lift
G1 X143.842769 Y166.189029 Z3.528644 E12090.042361 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.527635 matz1=3.528644 note=collision lift
G1 X143.866384 Y166.146206 Z3.539233 E12090.078615 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.528644 matz1=3.539233 note=collision lift
G1 X143.867176 Y166.14477 Z3.540147 E12090.079975 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.539233 matz1=3.540147 note=collision lift
G1 X143.915076 Y166.057911 Z3.552693 E12090.152418 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.540147 matz1=3.552693 note=collision lift
G1 X143.91599 Y166.056253 Z3.553749 E12090.153989 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.552693 matz1=3.553749 note=collision lift
G1 X144.012419 Y165.881392 Z3.566054 E12090.298948 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.553749 matz1=3.566054 note=collision lift
G1 X144.013618 Y165.879217 Z3.567439 E12090.301008 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.566054 matz1=3.567439 note=collision lift
G1 X144.208874 Y165.525147 Z3.573094 E12090.594005 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.567439 matz1=3.573094 note=collision lift
G1 X144.20953 Y165.523957 Z3.572493 E12090.595081 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.573094 matz1=3.572493 note=collision lift
G1 X144.405583 Y165.168441 Z3.566826 E12090.889274 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.572493 matz1=3.566826 note=collision lift
G1 X144.409788 Y165.160815 Z3.571683 E12090.896499 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.566826 matz1=3.571683 note=collision lift
G1 X145.08943 Y164.354429 Z3.550955 E12092.191327 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.571683 matz1=3.550955 note=collision lift
G1 X145.092874 Y164.350344 Z3.548719 E12092.198437 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.550955 matz1=3.548719 note=collision lift
G1 X145.681535 Y163.651905 Z3.505205 E12093.320987 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.548719 matz1=3.505205 note=collision lift
G1 X145.684768 Y163.648068 Z3.508123 E12093.328112 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.505205 matz1=3.508123 note=collision lift
G1 X146.668747 Y162.861865 Z3.470116 E12095.655218 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.508123 matz1=3.470116 note=collision lift
G1 X147.230373 Y162.413124 Z3.542279 E12096.98953 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X148.987204 Y161.503441 Z3.765946 E12102.055049 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X150.887749 Y160.953979 Z4.00093 E12108.583655 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.85897 Y160.785852 Z4.232783 E12116.551111 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.825115 Y161.005522 Z4.447247 E12125.841521 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.203329 Y161.443379 Z4.58535 E12133.249071 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.710625 Y161.604546 Z4.631136 E12137.449867 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X157.590647 Y162.089844 Z4.709121 E12145.743337 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.716375 Y160.995643 Z4.797403 E12157.869328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.656406 Y160.879826 Z4.804327 E12159.002076 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.806693 Y159.238811 Z4.877013 E12170.114466 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.25723 Y157.338266 Z4.899623 E12182.142191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.089103 Y155.367045 Z4.86384 E12193.950325 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.308773 Y153.400901 Z4.771866 E12205.201293 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.907798 Y151.51539 Z4.629356 E12215.587841 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.863157 Y149.782974 Z4.445073 E12224.850655 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.138137 Y148.270226 Z4.230348 E12232.795321 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.683742 Y147.035282 Z3.998385 E12239.306956 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.440573 Y146.125599 Z3.763446 E12244.360246 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X163.341118 Y145.576137 Z3.539979 E12248.022882 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.312339 Y145.40801 Z3.341723 E12250.451468 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.278484 Y145.62768 Z3.18087 E12251.880373 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.163994 Y146.226705 Z3.06731 E12252.605236 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.896411 Y147.182064 Z3.008027 E12252.963356 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.579247 Y147.757575 Z3.000152 E12253.103012 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.409158 Y148.457044 Z3.006665 E12253.390673 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.644102 Y150.002648 Z3.063308 E12254.439571 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.946725 Y150.587091 Z3.099349 E12255.085706 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.452523 Y151.563917 Z3.709592 E12256.318844 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.099349 matz1=3.709592 note=collision lift
G1 X174.553785 Y151.75948 Z3.834589 E12256.584707 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.709592 matz1=3.834589 note=collision lift
G1 X175.103247 Y153.660025 Z4.98263 E12260.685672 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.834589 matz1=4.833324 note=collision lift
G1 X175.240012 Y155.263534 Z5.947361 E12265.776606 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.833324 matz1=4.99339 note=collision lift
G1 X175.26543 Y155.561554 Z5.983309 E12266.593979 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.99339 matz1=5.023139 note=collision lift
G1 X175.265585 Y155.563365 Z5.982581 E12266.59929 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.023139 matz1=5.023319 note=collision lift
G1 X175.271365 Y155.631137 Z5.989571 E12266.784811 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.023319 matz1=5.030084 note=collision lift
G1 X175.271374 Y155.631246 Z5.989636 E12266.785156 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.030084 matz1=5.030095 note=collision lift
G1 X175.256656 Y155.762977 Z6.003457 E12267.207382 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.030095 matz1=5.044649 note=collision lift
G1 X175.256656 Y155.762983 Z6.003461 E12267.207406 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.044649 matz1=5.04465 note=collision lift
G1 X175.235654 Y155.950955 Z6.02096 E12267.809204 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.04465 matz1=5.065417 note=collision lift
G1 X175.235515 Y155.952204 Z6.021727 E12267.813872 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.065417 matz1=5.065556 note=collision lift
G1 X175.173 Y156.511736 Z6.066493 E12269.60325 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.065556 matz1=5.127374 note=collision lift
G1 X175.174661 Y156.510143 Z6.065605 E12269.612027 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.127374 matz1=5.127636 note=collision lift
G1 X175.529911 Y156.169485 Z6.02104 E12271.37046 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.127636 matz1=5.18374 note=collision lift
G1 X175.530037 Y156.169365 Z6.020973 E12271.371124 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.18374 matz1=5.18376 note=collision lift
G1 X175.660561 Y156.044202 Z6.003374 E12272.017607 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.18376 matz1=5.204374 note=collision lift
G1 X175.660583 Y156.044181 Z6.003362 E12272.01772 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.204374 matz1=5.204377 note=collision lift
G1 X175.700843 Y156.005574 Z5.997898 E12272.217144 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.204377 matz1=5.210736 note=collision lift
G1 X175.700848 Y156.00557 Z5.997902 E12272.21717 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.210736 matz1=5.210736 note=collision lift
G1 X175.829901 Y155.911163 Z5.982358 E12272.907861 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.210736 matz1=5.229528 note=collision lift
G1 X175.829923 Y155.911148 Z5.982374 E12272.907993 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.229528 matz1=5.229531 note=collision lift
G1 X176.121642 Y155.697747 Z5.946248 E12274.469687 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.229531 matz1=5.272008 note=collision lift
G1 X176.789154 Y155.209444 Z5.629919 E12278.276639 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.272008 matz1=5.369204 note=collision lift
G1 X177.959105 Y154.53904 Z5.116493 E12285.564962 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.369204 matz1=5.116493 note=collision lift
G1 X178.969504 Y154.12668 Z4.6995 E12292.16924 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.116493 matz1=4.6995 note=collision lift
G1 X179.168111 Y154.045625 Z4.61715 E12293.494942 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.6995 matz1=4.61715 note=collision lift
G1 X179.346556 Y154.004745 Z4.546736 E12294.645973 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.61715 matz1=4.546736 note=collision lift
G1 X179.481077 Y153.973927 Z4.493566 E12295.524822 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.546736 matz1=4.493566 note=collision lift
G1 X180.01341 Y153.851974 Z4.281734 E12299.300256 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.493566 matz1=4.281734 note=collision lift
G1 X180.415805 Y153.759789 Z4.328017 E12301.97766 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X181.053311 Y153.704117 Z4.396807 E12306.333038 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X182.357351 Y153.788077 Z4.527847 E12316.025042 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X183.02243 Y153.934556 Z4.590185 E12321.271305 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.327672 Y154.438888 Z4.7031 E12332.782222 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X183.614701 Y154.645013 Z4.753757 E12339.058133 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X181.64348 Y154.81314 Z4.853657 E12356.695654 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X180.328274 Y154.666197 Z4.884482 E12368.750153 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X180.263756 Y154.658989 Z4.918454 E12369.417386 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.884482 matz1=4.918454 note=collision lift
G1 X179.795866 Y154.606713 Z5.400221 E12375.55152 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.918454 matz1=5.400221 note=collision lift
G1 X179.677336 Y154.59347 Z5.520521 E12377.094964 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.400221 matz1=5.520521 note=collision lift
G1 X179.327862 Y154.482443 Z5.889044 E12381.836085 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.520521 matz1=5.889044 note=collision lift
G1 X178.853791 Y154.331831 Z6.385735 E12388.244351 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.889044 matz1=6.385735 note=collision lift
G1 X177.791825 Y153.994445 Z6.94287 E12399.513645 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.385735 matz1=6.384036 note=collision lift
G1 X177.330169 Y153.73986 Z6.923846 E12404.109597 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.384036 matz1=6.365012 note=collision lift
G1 X176.43521 Y153.246326 Z5.864945 E12416.930714 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.365012 matz1=5.864945 note=collision lift
G1 X176.242753 Y153.140193 Z5.747124 E12419.103227 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.864945 matz1=5.747124 note=collision lift
G1 X176.095624 Y153.059057 Z5.82507 E12420.71684 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.747124 matz1=5.82507 note=collision lift
G1 X176.059409 Y153.039086 Z5.864934 E12421.217272 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.82507 matz1=5.864934 note=collision lift
G1 X175.345124 Y152.437069 Z6.332007 E12429.708274 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.864934 matz1=6.253891 note=collision lift
G1 X175.339845 Y152.43262 Z6.338477 E12429.785196 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.253891 matz1=6.253457 note=collision lift
G1 X175.134044 Y152.259166 Z6.188736 E12432.289206 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.253457 matz1=6.188736 note=collision lift
G1 X174.948846 Y152.103077 Z6.296189 E12434.443391 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.188736 matz1=6.221295 note=collision lift
G1 X174.68126 Y151.877549 Z6.101494 E12437.69916 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.221295 matz1=6.101494 note=collision lift
G1 X174.601239 Y151.810106 Z6.095596 E12438.551321 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.101494 matz1=6.095596 note=collision lift
G1 X174.557848 Y151.773535 Z6.092399 E12439.013408 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.095596 matz1=6.092399 note=collision lift
G1 X174.556102 Y151.772063 Z6.08883 E12439.047851 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.092399 matz1=6.08883 note=collision lift
G1 X174.553691 Y151.770031 Z6.087055 E12439.07727 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.08883 matz1=6.087055 note=collision lift
G1 X174.546661 Y151.764106 Z6.077246 E12439.186568 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.087055 matz1=6.077246 note=collision lift
G1 X174.525891 Y151.738111 Z6.024789 E12439.686157 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.077246 matz1=6.024789 note=collision lift
G1 X174.438267 Y151.628444 Z5.873668 E12441.344946 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.024789 matz1=5.873668 note=collision lift
G1 X174.393824 Y151.572821 Z5.832619 E12442.005895 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.873668 matz1=5.832619 note=collision lift
G1 X173.311717 Y150.218502 Z4.814771 E12456.752508 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.832619 matz1=4.814771 note=collision lift
G1 X173.039155 Y149.692114 Z4.457032 E12461.168256 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.814771 matz1=4.457032 note=collision lift
G1 X172.579571 Y148.804538 Z4.353576 E12467.577047 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.402034 Y148.46167 Z4.506665 E12470.22609 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.353576 matz1=4.506665 note=collision lift
G1 X172.100593 Y147.419009 Z4.506665 E12476.525479 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506665 matz1=4.506665 note=collision lift
G1 X171.925196 Y146.812328 Z4.117055 E12479.155039 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506665 matz1=4.117055 note=collision lift
G1 X171.852572 Y146.561126 Z4.086478 E12480.087992 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.684445 Y144.589904 Z3.850953 E12485.685085 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.904115 Y142.62376 Z3.621517 E12489.855343 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.000775 Y142.31951 Z3.587754 E12490.318073 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.097435 Y142.01526 Z3.596015 E12490.77839 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.587754 matz1=3.596015 note=collision lift
G1 X172.097633 Y142.014636 Z3.595619 E12490.779493 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.596015 matz1=3.595619 note=collision lift
G1 X172.194095 Y141.71101 Z3.627755 E12491.241043 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.595619 matz1=3.627755 note=collision lift
G1 X172.194216 Y141.710628 Z3.627513 E12491.241717 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.627755 matz1=3.627513 note=collision lift
G1 X172.290345 Y141.408049 Z3.632674 E12491.699414 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.627513 matz1=3.632674 note=collision lift
G1 X172.290755 Y141.406759 Z3.633207 E12491.701511 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.632674 matz1=3.633207 note=collision lift
G1 X172.396947 Y141.072505 Z3.610278 E12492.208134 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.633207 matz1=3.610278 note=collision lift
G1 X172.396952 Y141.07249 Z3.610269 E12492.20816 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.610278 matz1=3.610269 note=collision lift
G1 X172.49995 Y140.74829 Z3.559829 E12492.703858 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.610269 matz1=3.559829 note=collision lift
G1 X172.50314 Y140.73825 Z3.563983 E12492.72018 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.559829 matz1=3.563983 note=collision lift
G1 X172.762608 Y140.267739 Z3.487894 E12493.204311 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.563983 matz1=3.487894 note=collision lift
G1 X172.772986 Y140.248919 Z3.475234 E12493.226563 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.487894 matz1=3.475234 note=collision lift
G1 X172.892064 Y140.032986 Z3.411692 E12493.453738 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.475234 matz1=3.411692 note=collision lift
G1 X172.892342 Y140.032483 Z3.411928 E12493.454292 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.411692 matz1=3.411928 note=collision lift
G1 X173.022076 Y139.797228 Z3.317747 E12493.708267 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.411928 matz1=3.317747 note=collision lift
G1 X173.023198 Y139.795193 Z3.316379 E12493.710672 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.317747 matz1=3.316379 note=collision lift
G1 X173.458499 Y139.005833 Z3.236107 E12494.518041 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.733479 Y137.493085 Z3.103831 E12495.469122 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X175.677986 Y136.73842 Z3.054794 E12495.746749 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.279083 Y136.258141 Z3.408288 E12495.94103 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.054794 matz1=3.408288 note=collision lift
G1 X177.260418 Y135.750009 Z3.947827 E12496.133926 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.408288 matz1=3.947827 note=collision lift
G1 X177.272936 Y135.743527 Z3.949356 E12496.13615 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947827 matz1=3.949356 note=collision lift
G1 X177.273146 Y135.743418 Z3.949234 E12496.136191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949356 matz1=3.949234 note=collision lift
G1 X178.035915 Y135.348459 Z3.949234 E12496.270924 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949234 matz1=3.949234 note=collision lift
G1 X179.93646 Y134.798996 Z3.949234 E12496.797865 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949234 matz1=3.949234 note=collision lift
G1 X181.015806 Y134.706938 Z3.949234 E12497.394958 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949234 matz1=3.949234 note=collision lift
G1 X181.016537 Y134.706876 Z3.949635 E12497.395419 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949234 matz1=3.949635 note=collision lift
G1 X181.905565 Y134.63105 Z3.936742 E12497.88728 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949635 matz1=3.936742 note=collision lift
G1 X181.907681 Y134.630869 Z3.937902 E12497.888614 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.936742 matz1=3.937902 note=collision lift
G1 X183.282906 Y134.784518 Z3.912716 E12499.264164 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937902 matz1=3.912716 note=collision lift
G1 X183.286403 Y134.784909 Z3.91121 E12499.267968 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.912716 matz1=3.91121 note=collision lift
G1 X183.870075 Y134.85012 Z3.877388 E12499.852648 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.91121 matz1=3.877388 note=collision lift
G1 X183.873825 Y134.850539 Z3.879546 E12499.856968 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.877388 matz1=3.879546 note=collision lift
G1 X184.584944 Y135.076461 Z3.821829 E12501.029813 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.879546 matz1=3.821829 note=collision lift
G1 X184.60077 Y135.081489 Z3.815069 E12501.057911 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.821829 matz1=3.815069 note=collision lift
G1 X184.890637 Y135.173579 Z3.772419 E12501.539228 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.815069 matz1=3.772419 note=collision lift
G1 X184.894559 Y135.174825 Z3.770744 E12501.54619 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.772419 matz1=3.770744 note=collision lift
G1 X185.043484 Y135.222139 Z3.741867 E12501.795226 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.770744 matz1=3.741867 note=collision lift
G1 X185.047058 Y135.223274 Z3.740341 E12501.801571 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.741867 matz1=3.740341 note=collision lift
G1 X185.119908 Y135.246418 Z3.721577 E12501.92492 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.740341 matz1=3.721577 note=collision lift
G1 X185.12502 Y135.248042 Z3.719394 E12501.933997 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.721577 matz1=3.719394 note=collision lift
G1 X185.15697 Y135.258193 Z3.708341 E12501.989316 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.719394 matz1=3.708341 note=collision lift
G1 X185.158119 Y135.258558 Z3.709057 E12501.991514 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.708341 matz1=3.709057 note=collision lift
G1 X185.758694 Y135.44936 Z3.452543 E12503.057775 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.709057 matz1=3.452543 note=collision lift
G1 X185.759335 Y135.449564 Z3.452605 E12503.058834 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.491752 Y136.404923 Z3.667052 E12507.508134 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X189.0045 Y137.679903 Z3.898897 E12513.401798 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.158032 Y139.123616 Z4.118584 E12520.18281 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.239444 Y139.225507 Z4.133884 E12520.909941 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.149126 Y140.982339 Z4.357564 E12534.017511 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.698589 Y142.882884 Z4.556183 E12548.954691 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.866716 Y144.854105 Z4.717529 E12565.364434 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.647046 Y146.820249 Z4.831679 E12582.805103 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.048021 Y148.70576 Z4.891616 E12600.779667 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.000753 Y148.791474 Z4.893094 E12601.669358 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.092662 Y150.438176 Z4.893653 E12613.066243 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.817682 Y151.950924 Z4.837666 E12624.715641 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.712059 Y152.035317 Z4.831788 E12625.509685 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.289374 Y152.373044 Z4.801057 E12630.013954 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.272078 Y153.185868 Z5.378168 E12641.852525 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.801057 matz1=5.378168 note=collision lift
G1 X185.52773 Y154.089086 Z6.2031 E12657.983025 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.378168 matz1=6.069869 note=collision lift
G1 X185.515246 Y154.095551 Z6.204042 E12658.089702 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.069869 matz1=6.068744 note=collision lift
G1 X184.815672 Y154.297803 Z6.253746 E12663.209841 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.068744 matz1=5.998652 note=collision lift
G1 X184.815524 Y154.297846 Z6.253808 E12663.211008 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.998652 matz1=5.998637 note=collision lift
G1 X184.327672 Y154.438888 Z6.279747 E12666.77792 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.998637 matz1=5.949758 note=collision lift
G1 X184.327752 Y154.438919 Z6.279695 E12666.778619 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.949758 matz1=5.949749 note=collision lift
G1 X184.379978 Y154.459098 Z6.277286 E12667.170201 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.949749 matz1=5.944052 note=collision lift
G1 X184.380979 Y154.459485 Z6.277713 E12667.17827 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.944052 matz1=5.943943 note=collision lift
G1 X184.862038 Y154.726567 Z6.254237 E12670.812554 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.943943 matz1=5.886228 note=collision lift
G1 X184.862405 Y154.726771 Z6.253982 E12670.815794 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.886228 matz1=5.886184 note=collision lift
G1 X185.071371 Y154.842788 Z6.237305 E12672.396877 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.886184 matz1=5.861114 note=collision lift
G1 X185.073201 Y154.843804 Z6.238132 E12672.411728 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.861114 matz1=5.860894 note=collision lift
G1 X185.398925 Y155.083028 Z6.204702 E12674.71458 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.860894 matz1=5.815459 note=collision lift
G1 X186.48365 Y155.879689 Z5.380472 E12683.676808 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.815459 matz1=5.380472 note=collision lift
G1 X187.202378 Y156.538518 Z4.77825 E12689.569794 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.380472 matz1=4.77825 note=collision lift
G1 X187.380618 Y156.73562 Z4.613779 E12691.130671 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.77825 matz1=4.613779 note=collision lift
G1 X188.180059 Y157.619655 Z3.875675 E12697.197142 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.613779 matz1=3.875675 note=collision lift
G1 X188.182896 Y157.622793 Z3.875171 E12697.215577 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.665053 Y158.155971 Z3.790041 E12700.059735 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.160425 Y160.201578 Z3.504916 E12706.677869 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.688125 Y162.70593 Z3.232384 E12710.569079 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.707173 Y162.729288 Z3.230031 E12710.608676 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.074879 Y164.406412 Z3.090008 E12712.028796 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.3256 Y164.772778 Z3.06884 E12712.275838 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X194.133493 Y165.953305 Z3.021649 E12712.710978 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X194.247305 Y166.119611 Z3.115761 E12712.778597 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.021649 matz1=3.115761 note=collision lift
G1 X194.634766 Y166.782584 Z3.487856 E12712.990718 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.115761 matz1=3.487856 note=collision lift
G1 X194.266821 Y166.579677 Z3.695188 E12713.101148 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.487856 matz1=3.695188 note=collision lift
G1 X192.896175 Y165.424463 Z4.60937 E12713.743973 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.695188 matz1=4.518302 note=collision lift
G1 X192.681802 Y165.156163 Z4.631767 E12713.868202 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.518302 matz1=4.527176 note=collision lift
G1 X192.47417 Y164.896299 Z4.653458 E12714.076011 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.527176 matz1=4.540057 note=collision lift
G1 X192.474168 Y164.896296 Z4.65346 E12714.076014 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.540057 matz1=4.540057 note=collision lift
G1 X191.777236 Y164.024046 Z4.726259 E12714.773538 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.540057 matz1=4.583291 note=collision lift
G1 X191.753614 Y163.978425 Z4.730033 E12714.820142 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.583291 matz1=4.586171 note=collision lift
G1 X191.753613 Y163.978424 Z4.730032 E12714.820144 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.586171 matz1=4.586171 note=collision lift
G1 X191.741442 Y163.954918 Z4.732372 E12714.844185 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.586171 matz1=4.587655 note=collision lift
G1 X191.741378 Y163.954796 Z4.732449 E12714.844328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.587655 matz1=4.587663 note=collision lift
G1 X191.283996 Y163.071473 Z4.827945 E12715.748398 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.587663 matz1=4.64343 note=collision lift
G1 X191.283942 Y163.071368 Z4.827894 E12715.748543 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.64343 matz1=4.643438 note=collision lift
G1 X191.237184 Y162.981067 Z4.837629 E12715.864202 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.643438 matz1=4.650309 note=collision lift
G1 X191.237163 Y162.981025 Z4.837656 E12715.864264 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.650309 matz1=4.650313 note=collision lift
G1 X190.953901 Y162.433975 Z4.896521 E12716.564927 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.650313 matz1=4.691939 note=collision lift
G1 X190.953005 Y162.432244 Z4.897627 E12716.567464 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.691939 matz1=4.692071 note=collision lift
G1 X190.641635 Y161.35524 Z5.005796 E12718.617491 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.692071 matz1=4.784056 note=collision lift
G1 X190.641501 Y161.354777 Z5.005594 E12718.618443 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.784056 matz1=4.784096 note=collision lift
G1 X190.455306 Y160.710744 Z5.080167 E12719.846189 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.784096 matz1=4.839102 note=collision lift
G1 X190.455157 Y160.710228 Z5.08048 E12719.84732 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.839102 matz1=4.839146 note=collision lift
G1 X190.409958 Y160.180295 Z5.12973 E12721.264042 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.839146 matz1=4.891942 note=collision lift
G1 X190.409819 Y160.178655 Z5.129071 E12721.268744 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.891942 matz1=4.892105 note=collision lift
G1 X190.397803 Y160.037776 Z5.140954 E12721.645087 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.892105 matz1=4.906141 note=collision lift
G1 X190.397022 Y160.028621 Z5.14646 E12721.673499 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.906141 matz1=4.907053 note=collision lift
G1 X190.302823 Y158.924175 Z5.21904 E12724.619838 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.907053 matz1=5.017086 note=collision lift
G1 X190.304293 Y158.91102 Z5.213897 E12724.670776 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.017086 matz1=5.018561 note=collision lift
G1 X190.334123 Y158.644031 Z5.211401 E12725.634451 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018561 matz1=5.048508 note=collision lift
G1 X190.334459 Y158.641017 Z5.210223 E12725.646124 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.048508 matz1=5.048846 note=collision lift
G1 X190.349772 Y158.503959 Z5.201645 E12726.141757 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.048846 matz1=5.064219 note=collision lift
G1 X190.350044 Y158.50153 Z5.200695 E12726.151164 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.064219 matz1=5.064491 note=collision lift
G1 X190.357597 Y158.433923 Z5.191694 E12726.3973 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.064491 matz1=5.072074 note=collision lift
G1 X190.357888 Y158.431318 Z5.190675 E12726.407389 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.072074 matz1=5.072366 note=collision lift
G1 X190.361364 Y158.400212 Z5.183526 E12726.522551 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.072366 matz1=5.075855 note=collision lift
G1 X190.36151 Y158.398905 Z5.18433 E12726.528078 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.075855 matz1=5.076002 note=collision lift
G1 X190.501858 Y157.142722 Z4.693228 E12731.392159 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.076002 matz1=4.693228 note=collision lift
G1 X190.958235 Y155.706215 Z4.117163 E12738.520129 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.693228 matz1=4.117163 note=collision lift
G1 X191.044613 Y155.434329 Z4.008551 E12739.45148 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.117163 matz1=4.008551 note=collision lift
G1 X191.121935 Y155.294115 Z3.947488 E12740.087982 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.008551 matz1=3.947488 note=collision lift
G1 X191.91023 Y153.864648 Z4.141168 E12746.193675 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.065444 Y152.494002 Z4.344187 E12754.036135 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X194.46586 Y151.375063 Z4.527289 E12762.898075 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X196.057663 Y150.550832 Z4.681223 E12772.610148 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X197.779678 Y150.052984 Z4.79821 E12782.962472 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X199.565731 Y149.90065 Z4.872341 E12793.716346 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X201.347184 Y150.099685 Z4.899868 E12804.616184 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X203.055578 Y150.64244 Z4.879403 E12815.401049 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X204.625258 Y151.508057 Z4.811977 E12825.815706 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.995905 Y152.663271 Z4.701 E12835.621445 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.173892 Y152.886032 Z4.679675 E12837.163578 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.114843 Y154.063687 Z4.552076 E12848.499303 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.939074 Y155.65549 Z4.372732 E12860.48714 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.428621 Y157.348789 Z4.175497 E12870.653509 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.529613 Y156.797356 Z4.109979 E12873.71575 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.193549 Y154.351958 Z3.808769 E12883.965275 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.883063 Y152.565004 Z3.5889 E12889.726499 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.962286 Y152.359691 Z3.564772 E12890.147402 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.978852 Y152.316758 Z3.582735 E12890.241321 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.564772 matz1=3.582735 note=collision lift
G1 X210.332135 Y151.608399 Z3.894435 E12891.635685 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.582735 matz1=3.894435 note=collision lift
G1 X210.41358 Y151.445095 Z3.96693 E12892.101224 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.894435 matz1=3.96693 note=collision lift
G1 X210.844725 Y150.773857 Z4.290483 E12893.476802 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.96693 matz1=4.290483 note=collision lift
G1 X210.845102 Y150.77327 Z4.290068 E12893.478099 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.290483 matz1=4.290068 note=collision lift
G1 X211.003867 Y150.526093 Z4.334352 E12893.952809 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.290068 matz1=4.334352 note=collision lift
G1 X211.003897 Y150.526046 Z4.334318 E12893.952914 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334352 matz1=4.334318 note=collision lift
G1 X211.004171 Y150.525619 Z4.334524 E12893.953787 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334318 matz1=4.334524 note=collision lift
G1 X211.359405 Y149.972565 Z4.334524 E12895.004078 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334524 matz1=4.334524 note=collision lift
G1 X211.867836 Y149.364997 Z4.334524 E12896.029809 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334524 matz1=4.334524 note=collision lift
G1 X212.947532 Y148.388131 Z4.334524 E12897.233833 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334524 matz1=4.334524 note=collision lift
G1 X213.515923 Y148.013112 Z4.334524 E12897.677455 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334524 matz1=4.334524 note=collision lift
G1 X214.421681 Y147.596614 Z4.334524 E12898.07438 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334524 matz1=4.334524 note=collision lift
G1 X214.422316 Y147.596322 Z4.33417 E12898.074692 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.334524 matz1=4.33417 note=collision lift
G1 X214.703401 Y147.46707 Z4.33417 E12898.197871 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.33417 matz1=4.33417 note=collision lift
G1 X215.219912 Y147.319283 Z4.33417 E12898.367552 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.33417 matz1=4.33417 note=collision lift
G1 X215.318428 Y147.291096 Z4.280116 E12898.404143 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.33417 matz1=4.280116 note=collision lift
G1 X216.585643 Y147.11062 Z3.62306 E12898.743799 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.280116 matz1=3.62306 note=collision lift
G1 X217.830531 Y147.137395 Z3.00797 E12899.122739 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.62306 matz1=3.00797 note=collision lift
G1 X217.891336 Y147.138703 Z3.008336 E12899.139334 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X218.667002 Y147.258343 Z3.025278 E12899.415732 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X219.223724 Y147.344213 Z3.04299 E12899.579147 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X219.767242 Y147.492207 Z3.065246 E12899.78173 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X220.52451 Y147.698401 Z3.103614 E12900.346296 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X221.728743 Y148.20382 Z3.185473 E12901.787487 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X222.812995 Y148.884115 Z3.285657 E12903.803155 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.303275 Y149.295029 Z3.342333 E12904.981632 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.309898 Y149.302567 Z3.343304 E12905.005108 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.971403 Y150.055397 Z3.941304 E12907.722976 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.343304 matz1=3.941304 note=collision lift
G1 X224.023974 Y150.115227 Z3.942783 E12907.908492 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.941304 matz1=3.942783 note=collision lift
G1 X224.023969 Y150.115228 Z3.942781 E12907.908509 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942783 matz1=3.942781 note=collision lift
G1 X223.357065 Y150.308035 Z3.947247 E12910.08044 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942781 matz1=3.947247 note=collision lift
G1 X223.356853 Y150.308097 Z3.94716 E12910.081184 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947247 matz1=3.94716 note=collision lift
G1 X222.488704 Y150.559085 Z3.94716 E12912.908459 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94716 matz1=3.94716 note=collision lift
G1 X221.168876 Y150.671654 Z3.94716 E12918.473083 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94716 matz1=3.94716 note=collision lift
G1 X221.167014 Y150.671813 Z3.948311 E12918.482301 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94716 matz1=3.948311 note=collision lift
G1 X220.519979 Y150.726999 Z3.921219 E12921.212686 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.948311 matz1=3.921219 note=collision lift
G1 X220.517483 Y150.727212 Z3.920257 E12921.223963 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921219 matz1=3.920257 note=collision lift
G1 X220.374198 Y150.711204 Z3.865354 E12921.999581 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.920257 matz1=3.865354 note=collision lift
G1 X219.044028 Y150.562589 Z4.024891 E12928.776244 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X218.551338 Y150.507542 Z4.083707 E12930.541056 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X218.078854 Y150.357435 Z4.142004 E12932.396391 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X216.719505 Y149.925571 Z4.304603 E12941.53474 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X216.665828 Y149.908518 Z4.339185 E12941.955456 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.304603 matz1=4.339185 note=collision lift
G1 X214.933411 Y148.953158 Z5.533491 E12958.883328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.339185 matz1=5.533491 note=collision lift
G1 X214.811752 Y148.850621 Z5.62674 E12960.381122 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.533491 matz1=5.62674 note=collision lift
G1 X214.767571 Y148.813384 Z5.689495 E12961.073939 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.62674 matz1=5.689495 note=collision lift
G1 X214.676556 Y148.736674 Z5.765818 E12962.222332 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.689495 matz1=5.765818 note=collision lift
G1 X214.67521 Y148.735541 Z5.76597 E12962.236675 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.765818 matz1=5.76597 note=collision lift
G1 X214.585541 Y148.659965 Z5.834459 E12963.339652 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.76597 matz1=5.834459 note=collision lift
G1 X214.584968 Y148.659482 Z5.834524 E12963.345756 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.834459 matz1=5.834524 note=collision lift
G1 X214.530184 Y148.613309 Z5.802738 E12963.982345 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.834524 matz1=5.802738 note=collision lift
G1 X214.098952 Y148.249856 Z5.834524 E12968.569995 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.802738 matz1=5.834524 note=collision lift
G1 X213.711405 Y147.923222 Z5.863089 E12972.692908 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.834524 matz1=5.863089 note=collision lift
G1 X213.697946 Y147.911878 Z5.847002 E12972.886583 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.863089 matz1=5.847002 note=collision lift
G1 X213.674895 Y147.89245 Z5.834524 E12973.151569 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.847002 matz1=5.834524 note=collision lift
G1 X213.651843 Y147.873022 Z5.822046 E12973.416554 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.834524 matz1=5.822046 note=collision lift
G1 X213.541006 Y147.779606 Z5.834524 E12974.598178 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.822046 matz1=5.834524 note=collision lift
G1 X213.420664 Y147.678178 Z5.848072 E12975.881142 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.834524 matz1=5.848072 note=collision lift
G1 X213.403749 Y147.657009 Z5.822789 E12976.198353 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.848072 matz1=5.822789 note=collision lift
G1 X212.547894 Y146.585856 Z5.228997 E12988.98717 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.822789 matz1=5.228997 note=collision lift
G1 X212.185719 Y146.132574 Z4.970357 E12994.51787 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.228997 matz1=4.970357 note=collision lift
G1 X212.039603 Y145.850385 Z4.823043 E12997.68544 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.970357 matz1=4.823043 note=collision lift
G1 X211.276037 Y144.375743 Z4.883521 E13012.713021 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X211.073626 Y143.675621 Z4.895721 E13019.346368 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.726574 Y142.475198 Z4.89817 E13030.732592 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.558447 Y140.503977 Z4.854517 E13048.359914 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.711145 Y139.13726 Z4.785511 E13059.986208 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.778117 Y138.537832 Z5.056824 E13065.570485 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.785511 matz1=5.056824 note=collision lift
G1 X210.857218 Y138.288853 Z5.170467 E13067.953331 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.056824 matz1=5.170467 note=collision lift
G1 X210.980315 Y139.732118 Z5.785715 E13080.313992 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.170467 matz1=5.785715 note=collision lift
G1 X210.813163 Y141.2282 Z6.39817 E13091.67783 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.785715 matz1=5.989022 note=collision lift
G1 X210.760645 Y141.698262 Z6.39817 E13094.985062 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.989022 matz1=5.944959 note=collision lift
G1 X210.16162 Y143.583773 Z6.39817 E13106.831303 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.944959 matz1=5.73022 note=collision lift
G1 X210.158947 Y143.58862 Z6.39817 E13106.858443 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.73022 matz1=5.729571 note=collision lift
G1 X210.158833 Y143.588827 Z6.39826 E13106.859684 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.729571 matz1=5.729544 note=collision lift
G1 X209.928381 Y144.00672 Z6.396656 E13109.199472 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.729544 matz1=5.673588 note=collision lift
G1 X209.928259 Y144.006943 Z6.396499 E13109.200938 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.673588 matz1=5.673558 note=collision lift
G1 X209.889746 Y144.07678 Z6.395889 E13109.591966 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.673558 matz1=5.664207 note=collision lift
G1 X209.889519 Y144.077192 Z6.395599 E13109.594678 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.664207 matz1=5.664152 note=collision lift
G1 X209.888872 Y144.078366 Z6.395087 E13109.601713 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.664152 matz1=5.663995 note=collision lift
G1 X209.206261 Y145.316189 Z5.522562 E13117.746211 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.663995 matz1=5.498251 note=collision lift
G1 X208.327738 Y146.358545 Z4.678521 E13124.389048 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.498251 matz1=4.678521 note=collision lift
G1 X207.931281 Y146.828937 Z4.298437 E13126.222916 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.678521 matz1=4.298437 note=collision lift
G1 X207.864658 Y146.882168 Z4.246166 E13126.406882 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.298437 matz1=4.246166 note=collision lift
G1 X206.385677 Y148.063881 Z4.978892 E13130.140495 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.246166 matz1=4.978892 note=collision lift
G1 X204.628845 Y148.973564 Z5.769843 E13132.742264 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.978892 matz1=4.84162 note=collision lift
G1 X203.216312 Y149.381938 Z6.222088 E13133.849329 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.84162 matz1=4.722088 note=collision lift
G1 X202.7283 Y149.523026 Z6.180792 E13134.21611 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.722088 matz1=4.680792 note=collision lift
G1 X202.727236 Y149.523117 Z6.18073 E13134.216501 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.680792 matz1=4.68073 note=collision lift
G1 X202.467507 Y149.545269 Z6.165772 E13134.311969 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.68073 matz1=4.665772 note=collision lift
G1 X202.467446 Y149.545275 Z6.165768 E13134.311992 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.665772 matz1=4.665768 note=collision lift
G1 X200.757079 Y149.691153 Z6.067261 E13134.940667 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.665768 matz1=4.567261 note=collision lift
G1 X200.189692 Y149.627761 Z6.050162 E13135.043982 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.567261 matz1=4.550162 note=collision lift
G1 X198.790953 Y149.471485 Z6.00801 E13135.298678 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.550162 matz1=4.50801 note=collision lift
G1 X198.790935 Y149.471483 Z6.00801 E13135.298681 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50801 matz1=4.50801 note=collision lift
G1 X198.440133 Y149.360034 Z6.007762 E13135.363735 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50801 matz1=4.507762 note=collision lift
G1 X198.438876 Y149.359635 Z6.007761 E13135.363968 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.507762 matz1=4.507761 note=collision lift
G1 X197.700535 Y149.125064 Z6.007241 E13135.500888 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.507761 matz1=4.507241 note=collision lift
G1 X197.700501 Y149.125053 Z6.007241 E13135.500894 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.507241 matz1=4.507241 note=collision lift
G1 X197.175999 Y148.95842 Z6.006871 E13135.598159 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.507241 matz1=4.506871 note=collision lift
G1 X197.174749 Y148.958023 Z6.00687 E13135.598391 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506871 matz1=4.50687 note=collision lift
G1 X197.123101 Y148.941614 Z6.006834 E13135.607969 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50687 matz1=4.506834 note=collision lift
G1 X196.905424 Y148.872458 Z6.006681 E13135.648336 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506834 matz1=4.506681 note=collision lift
G1 X195.173008 Y147.917099 Z5.23675 E13136.398698 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506681 matz1=4.563356 note=collision lift
G1 X194.944807 Y147.724766 Z5.100943 E13136.528308 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.563356 matz1=4.576769 note=collision lift
G1 X194.66739 Y147.490952 Z4.940656 E13136.944882 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.576769 matz1=4.597886 note=collision lift
G1 X193.66026 Y146.642119 Z5.675885 E13138.529145 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.597886 matz1=4.67455 note=collision lift
G1 X193.014959 Y145.834487 Z6.257568 E13140.656409 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.67455 matz1=4.757568 note=collision lift
G1 X192.941254 Y145.742241 Z6.26705 E13140.868843 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.757568 matz1=4.76705 note=collision lift
G1 X192.939811 Y145.740435 Z6.267236 E13140.873001 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.76705 matz1=4.767236 note=collision lift
G1 X192.868085 Y145.650666 Z6.276464 E13141.07973 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.767236 matz1=4.776464 note=collision lift
G1 X192.867548 Y145.649994 Z6.276533 E13141.081278 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.776464 matz1=4.776533 note=collision lift
G1 X192.721022 Y145.466607 Z6.295383 E13141.503599 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.776533 matz1=4.795383 note=collision lift
G1 X192.720138 Y145.465501 Z6.295497 E13141.506147 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.795383 matz1=4.795497 note=collision lift
G1 X192.425316 Y145.096515 Z6.292802 E13142.353173 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.795497 matz1=4.833426 note=collision lift
G1 X192.424049 Y145.094068 Z6.291699 E13142.361227 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.833426 matz1=4.8337 note=collision lift
G1 X192.326413 Y144.905508 Z6.284642 E13142.937786 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.8337 matz1=4.854821 note=collision lift
G1 X192.32639 Y144.905462 Z6.284673 E13142.937949 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.854821 matz1=4.854827 note=collision lift
G1 X192.209982 Y144.680649 Z6.275202 E13143.625461 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.854827 matz1=4.880009 note=collision lift
G1 X192.208232 Y144.677269 Z6.277484 E13143.637506 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.880009 matz1=4.880387 note=collision lift
G1 X191.661346 Y143.621091 Z6.2201 E13146.868951 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.880387 matz1=4.998694 note=collision lift
G1 X191.657839 Y143.614319 Z6.217046 E13146.891243 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.998694 matz1=4.999452 note=collision lift
G1 X191.515633 Y143.339683 Z6.192494 E13147.733174 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.999452 matz1=5.030215 note=collision lift
G1 X191.515581 Y143.339502 Z6.19242 E13147.733936 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.030215 matz1=5.030236 note=collision lift
G1 X191.391314 Y142.909673 Z6.155088 E13149.41985 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.030236 matz1=5.08058 note=collision lift
G1 X191.39115 Y142.909105 Z6.15545 E13149.422453 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.08058 matz1=5.080647 note=collision lift
G1 X191.071029 Y141.801834 Z6.056696 E13153.766318 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.080647 matz1=5.210336 note=collision lift
G1 X191.070533 Y141.800118 Z6.056004 E13153.773512 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.210336 matz1=5.210537 note=collision lift
G1 X190.966196 Y141.439225 Z6.018288 E13155.191229 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.210537 matz1=5.252806 note=collision lift
G1 X190.966171 Y141.439139 Z6.018344 E13155.191627 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.252806 matz1=5.252816 note=collision lift
G1 X190.93255 Y141.044953 Z5.981063 E13157.119982 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.252816 matz1=5.299755 note=collision lift
G1 X190.932532 Y141.044734 Z5.98098 E13157.121122 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.299755 matz1=5.299781 note=collision lift
G1 X190.928883 Y141.001952 Z5.976903 E13157.330428 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.299781 matz1=5.304875 note=collision lift
G1 X190.928813 Y141.00113 Z5.977413 E13157.335135 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.304875 matz1=5.304973 note=collision lift
G1 X190.82426 Y139.775292 Z5.858144 E13163.333467 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.304973 matz1=5.450941 note=collision lift
G1 X190.82413 Y139.773761 Z5.857558 E13163.341451 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.450941 matz1=5.451124 note=collision lift
G1 X190.79817 Y139.46939 Z5.822084 E13164.833825 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.451124 matz1=5.487367 note=collision lift
G1 X190.798044 Y139.467917 Z5.822999 E13164.842259 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.487367 matz1=5.487542 note=collision lift
G1 X190.857146 Y138.938927 Z5.757219 E13167.603913 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.487542 matz1=5.550906 note=collision lift
G1 X190.857785 Y138.933211 Z5.755015 E13167.628306 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.550906 matz1=5.551578 note=collision lift
G1 X190.860441 Y138.909434 Z5.751771 E13167.723913 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.551578 matz1=5.554375 note=collision lift
G1 X190.861091 Y138.90362 Z5.755379 E13167.75113 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.554375 matz1=5.555059 note=collision lift
G1 X190.940735 Y138.190766 Z5.641279 E13170.627245 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.555059 matz1=5.638913 note=collision lift
G1 X191.017714 Y137.501773 Z5.375686 E13173.567133 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.638913 matz1=5.375686 note=collision lift
G1 X191.616739 Y135.616263 Z4.602315 E13183.408097 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.375686 matz1=4.602315 note=collision lift
G1 X191.77758 Y135.324598 Z4.467083 E13185.28195 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.602315 matz1=4.467083 note=collision lift
G1 X192.572098 Y133.883846 Z4.621725 E13193.896175 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.847078 Y132.371098 Z4.766369 E13205.131 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X195.392682 Y131.136154 Z4.860815 E13216.931964 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X197.149514 Y130.226472 Z4.899255 E13228.958904 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X199.050058 Y129.677009 Z4.879326 E13240.861241 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X201.02128 Y129.508882 Z4.802253 E13252.29619 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X202.987424 Y129.728552 Z4.672776 E13262.946482 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X204.872934 Y130.327577 Z4.498856 E13272.537999 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.605351 Y131.282936 Z4.291187 E13280.857043 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.860302 Y132.340639 Z4.101504 E13286.58845 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.118099 Y132.557916 Z4.231112 E13287.841475 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.101504 matz1=4.231112 note=collision lift
G1 X209.353043 Y134.10352 Z4.984732 E13293.63059 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.231112 matz1=4.984732 note=collision lift
G1 X210.262725 Y135.860352 Z5.745918 E13297.920068 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.984732 matz1=5.098967 note=collision lift
G1 X210.577268 Y136.948329 Z6.190524 E13299.920544 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.098967 matz1=4.977305 note=collision lift
G1 X210.610546 Y137.063433 Z6.238426 E13300.18764 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.977305 matz1=4.965299 note=collision lift
G1 X210.676589 Y137.291873 Z6.25539 E13300.681099 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.965299 matz1=4.941471 note=collision lift
G1 X210.676615 Y137.29196 Z6.255426 E13300.681302 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.941471 matz1=4.941462 note=collision lift
G1 X210.812188 Y137.760897 Z6.279157 E13301.692893 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.941462 matz1=4.892548 note=collision lift
G1 X210.812204 Y137.761088 Z6.279042 E13301.693304 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.892548 matz1=4.89253 note=collision lift
G1 X210.857185 Y138.288474 Z6.305094 E13302.666419 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.89253 matz1=4.842636 note=collision lift
G1 X210.857218 Y138.288853 Z6.305248 E13302.667173 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.842636 matz1=4.8426 note=collision lift
G1 X211.156599 Y137.346509 Z6.255438 E13303.94691 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.8426 matz1=4.758773 note=collision lift
G1 X211.156712 Y137.346155 Z6.255221 E13303.947466 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.758773 matz1=4.758742 note=collision lift
G1 X211.2357 Y137.097529 Z6.236625 E13304.285537 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.758742 matz1=4.736625 note=collision lift
G1 X211.272319 Y136.982266 Z6.167543 E13304.465577 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.736625 matz1=4.726372 note=collision lift
G1 X211.377142 Y136.652322 Z5.968361 E13304.777285 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.726372 matz1=4.700287 note=collision lift
G1 X212.332501 Y134.919905 Z4.858656 E13305.695163 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.700287 matz1=4.579771 note=collision lift
G1 X213.460651 Y133.58137 Z3.924096 E13306.08353 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.579771 matz1=3.924096 note=collision lift
G1 X213.603337 Y133.412075 Z3.927125 E13306.126865 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.924096 matz1=3.927125 note=collision lift
G1 X213.607481 Y133.407158 Z3.930123 E13306.128254 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.927125 matz1=3.930123 note=collision lift
G1 X214.884286 Y132.386985 Z3.936972 E13306.400327 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.930123 matz1=3.936972 note=collision lift
G1 X214.88757 Y132.384362 Z3.93485 E13306.401111 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.936972 matz1=3.93485 note=collision lift
G1 X215.148898 Y132.17556 Z3.934225 E13306.456797 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.93485 matz1=3.934225 note=collision lift
G1 X215.153086 Y132.172213 Z3.93688 E13306.457793 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.934225 matz1=3.93688 note=collision lift
G1 X216.801346 Y131.318748 Z3.926208 E13307.04941 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.93688 matz1=3.926208 note=collision lift
G1 X216.809603 Y131.314473 Z3.921788 E13307.052691 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.926208 matz1=3.921788 note=collision lift
G1 X216.909812 Y131.262585 Z3.913266 E13307.088761 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921788 matz1=3.913266 note=collision lift
G1 X216.909917 Y131.262531 Z3.913327 E13307.088804 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.913266 matz1=3.913327 note=collision lift
G1 X217.01432 Y131.232347 Z3.903398 E13307.158989 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.913327 matz1=3.903398 note=collision lift
G1 X217.015342 Y131.232052 Z3.902922 E13307.159738 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.903398 matz1=3.902922 note=collision lift
G1 X217.065331 Y131.2176 Z3.895644 E13307.19353 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.902922 matz1=3.895644 note=collision lift
G1 X217.066521 Y131.217255 Z3.896329 E13307.194441 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.895644 matz1=3.896329 note=collision lift
G1 X217.118723 Y131.202163 Z3.882267 E13307.230539 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.896329 matz1=3.882267 note=collision lift
G1 X218.691546 Y130.747448 Z3.149744 E13308.384075 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.882267 matz1=3.149744 note=collision lift
G1 X218.810462 Y130.713068 Z3.156254 E13308.463795 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X220.781683 Y130.544941 Z3.309095 E13310.6856 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X221.322978 Y130.605418 Z3.362023 E13311.626379 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X222.243053 Y130.708215 Z3.914888 E13313.480187 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.362023 matz1=3.914888 note=collision lift
G1 X222.487388 Y130.735513 Z3.927126 E13313.903376 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.914888 matz1=3.927126 note=collision lift
G1 X222.488192 Y130.735603 Z3.9268 E13313.904877 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.927126 matz1=3.9268 note=collision lift
G1 X222.74734 Y130.764557 Z3.936255 E13314.353463 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.9268 matz1=3.936255 note=collision lift
G1 X222.747828 Y130.764611 Z3.936547 E13314.354445 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.936255 matz1=3.936547 note=collision lift
G1 X223.126415 Y130.884888 Z3.949891 E13315.310195 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.936547 matz1=3.949891 note=collision lift
G1 X223.127246 Y130.885152 Z3.949552 E13315.312444 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949891 matz1=3.949552 note=collision lift
G1 X224.633338 Y131.363636 Z3.949552 E13319.112451 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949552 matz1=3.949552 note=collision lift
G1 X224.987285 Y131.558824 Z3.949552 E13320.379215 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949552 matz1=3.949552 note=collision lift
G1 X226.365755 Y132.318995 Z3.95509 E13325.312737 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949552 matz1=3.95509 note=collision lift
G1 X227.878502 Y133.593976 Z4.188685 E13333.007084 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X229.113446 Y135.13958 Z4.407603 E13342.053706 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.023129 Y136.896411 Z4.598383 E13352.269512 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.572591 Y138.796956 Z4.749294 E13363.401344 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.740718 Y140.768177 Z4.851058 E13375.144198 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.702278 Y141.112231 Z4.863295 E13377.210858 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.521048 Y142.734322 Z4.897416 E13392.08079 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X229.922024 Y144.619832 Z4.885518 E13409.991005 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X228.966664 Y146.352249 Z4.816095 E13427.269138 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X228.161361 Y147.307731 Z4.744394 E13437.773836 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X227.691684 Y147.864996 Z4.693417 E13443.731176 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X226.14608 Y149.09994 Z4.525026 E13458.358037 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.667445 Y149.347776 Z4.472433 E13462.204111 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.630851 Y149.366724 Z4.489017 E13462.51958 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.472433 matz1=4.489017 note=collision lift
G1 X224.69454 Y149.851544 Z4.905253 E13469.790013 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.489017 matz1=4.905253 note=collision lift
G1 X224.389248 Y150.009623 Z5.212865 E13472.748815 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.905253 matz1=5.212865 note=collision lift
G1 X224.033781 Y150.112391 Z5.437464 E13475.439619 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.212865 matz1=5.437464 note=collision lift
G1 X224.025362 Y150.114825 Z5.447165 E13475.520889 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.437464 matz1=5.447165 note=collision lift
G1 X224.024128 Y150.115182 Z5.447664 E13475.529456 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.447165 matz1=5.447664 note=collision lift
G1 X224.023974 Y150.115227 Z5.447887 E13475.531161 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.447664 matz1=5.447887 note=collision lift
G1 X224.087446 Y150.187461 Z5.442783 E13476.11886 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.447887 matz1=5.442783 note=collision lift
G1 X224.157656 Y150.267364 Z5.437137 E13476.768949 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.442783 matz1=5.437137 note=collision lift
G1 X224.165995 Y150.276854 Z5.442783 E13476.853401 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.437137 matz1=5.442783 note=collision lift
G1 X224.532712 Y150.850637 Z4.683806 E13482.704629 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.442783 matz1=4.683806 note=collision lift
G1 X224.558334 Y150.908559 Z4.613004 E13483.17348 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.683806 matz1=4.613004 note=collision lift
G1 X224.917253 Y151.71994 Z4.064806 E13488.3208 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.613004 matz1=4.064806 note=collision lift
G1 X225.121736 Y152.1822 Z4.005221 E13490.832805 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.158565 Y152.311288 Z3.989203 E13491.440264 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.338589 Y152.942282 Z3.946422 E13494.394919 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.989203 matz1=3.946422 note=collision lift
G1 X225.339091 Y152.944039 Z3.947118 E13494.403702 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946422 matz1=3.947118 note=collision lift
G1 X225.604213 Y154.673964 Z3.941846 E13500.580319 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947118 matz1=3.941846 note=collision lift
G1 X225.604341 Y154.676909 Z3.940034 E13500.592191 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.941846 matz1=3.940034 note=collision lift
G1 X225.606246 Y154.720399 Z3.939638 E13500.741561 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.940034 matz1=3.939638 note=collision lift
G1 X225.606265 Y154.720843 Z3.939809 E13500.743195 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939638 matz1=3.939809 note=collision lift
G1 X225.612175 Y154.855819 Z3.932469 E13501.207439 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939809 matz1=3.932469 note=collision lift
G1 X225.612195 Y154.856277 Z3.932645 E13501.209123 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.932469 matz1=3.932645 note=collision lift
G1 X225.618643 Y155.003554 Z3.922109 E13501.506065 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.932645 matz1=3.922109 note=collision lift
G1 X225.618745 Y155.005887 Z3.923013 E13501.511095 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.922109 matz1=3.923013 note=collision lift
G1 X225.625296 Y155.155497 Z3.904098 E13501.814362 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923013 matz1=3.904098 note=collision lift
G1 X225.64682 Y155.647087 Z3.602594 E13502.973812 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.904098 matz1=3.602594 note=collision lift
G1 X225.645985 Y155.663573 Z3.592526 E13503.010894 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.602594 matz1=3.592526 note=collision lift
G1 X225.633356 Y155.912832 Z3.56509 E13503.492455 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.536439 Y157.825747 Z3.36915 E13507.267037 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.148341 Y160.329776 Z3.163003 E13509.799819 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.457558 Y163.180448 Z3.024142 E13510.818117 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.454537 Y163.210317 Z3.023346 E13510.82842 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.236694 Y165.364249 Z3.001182 E13511.34671 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.154805 Y165.799833 Z3.005291 E13511.461334 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.853206 Y167.404093 Z3.045493 E13512.190638 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.658637 Y168.146565 Z3.07767 E13512.649369 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.541978 Y167.743049 Z3.098733 E13512.941941 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.389644 Y165.956996 Z3.214433 E13515.163576 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.427791 Y165.615561 Z3.241066 E13515.632693 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.588679 Y164.175543 Z3.367297 E13518.471499 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.913519 Y163.153066 Z3.473432 E13521.110844 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.131434 Y162.46715 Z3.549604 E13523.140496 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.997051 Y160.897469 Z3.752141 E13529.908498 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X226.152265 Y159.526823 Z3.964676 E13538.475197 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X227.552681 Y158.407884 Z4.176469 E13548.829519 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X228.891279 Y157.714762 Z4.346141 E13558.735074 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X229.144483 Y157.583653 Z4.376819 E13560.010967 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.866499 Y157.085805 Z4.555603 E13569.029819 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X232.652552 Y156.933471 Z4.703789 E13578.865848 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X234.434005 Y157.132506 Z4.813888 E13589.303458 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X236.142398 Y157.675261 Z4.880338 E13600.100259 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X237.712079 Y158.540878 Z4.899781 E13610.998967 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X239.082726 Y159.696092 Z4.871236 E13621.738842 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.201664 Y161.096508 Z4.796143 E13632.066684 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.025895 Y162.68831 Z4.678298 E13641.747647 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.523743 Y164.410326 Z4.523654 E13650.576067 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.676077 Y166.196379 Z4.340026 E13658.386106 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.644401 Y166.479893 Z4.308728 E13659.601995 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.477042 Y167.977832 Z4.136691 E13668.022204 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.934287 Y169.686225 Z3.923923 E13676.244961 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.083037 Y171.229855 Z3.715913 E13682.603667 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.544808 Y170.911109 Z3.65163 E13684.457051 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.742922 Y169.650577 Z3.384266 E13689.632352 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.400257 Y169.359605 Z3.317725 E13690.874017 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.49402 Y168.875448 Z3.21868 E13692.382302 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.737019 Y168.767884 Z3.198843 E13692.692457 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.646814 Y168.46329 Z3.134438 E13693.517273 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.66158 Y168.458347 Z3.141178 E13693.531827 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.134438 matz1=3.141178 note=collision lift
G1 X246.739049 Y168.223521 Z3.638222 E13694.08154 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.141178 matz1=3.638222 note=collision lift
G1 X246.744095 Y168.222421 Z3.635385 E13694.084218 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.638222 matz1=3.635385 note=collision lift
G1 X246.76066 Y168.21881 Z3.63673 E13694.091947 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.635385 matz1=3.63673 note=collision lift
G1 X246.763752 Y168.218137 Z3.638156 E13694.093524 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63673 matz1=3.638156 note=collision lift
G1 X246.912699 Y168.185675 Z3.647383 E13694.16293 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.638156 matz1=3.647383 note=collision lift
G1 X247.371422 Y168.0857 Z3.858994 E13694.396965 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.647383 matz1=3.858994 note=collision lift
G1 X247.480281 Y168.076101 Z3.910199 E13694.437757 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.858994 matz1=3.910199 note=collision lift
G1 X247.513226 Y168.073196 Z3.923485 E13694.449803 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.910199 matz1=3.923485 note=collision lift
G1 X247.523149 Y168.072321 Z3.928153 E13694.453522 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923485 matz1=3.928153 note=collision lift
G1 X247.603755 Y168.065214 Z3.950545 E13694.4819 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.928153 matz1=3.950545 note=collision lift
G1 X247.608884 Y168.064762 Z3.952957 E13694.483822 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.950545 matz1=3.952957 note=collision lift
G1 X247.760994 Y168.05135 Z3.981328 E13694.536319 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.952957 matz1=3.981328 note=collision lift
G1 X247.780354 Y168.049643 Z3.990434 E13694.543573 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.981328 matz1=3.990434 note=collision lift
G1 X248.160115 Y168.016159 Z4.045302 E13694.673759 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.990434 matz1=4.045302 note=collision lift
G1 X248.166772 Y168.016493 Z4.041837 E13694.675742 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.045302 matz1=4.041837 note=collision lift
G1 X248.263836 Y168.021366 Z4.049431 E13694.701474 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.041837 matz1=4.049431 note=collision lift
G1 X248.264167 Y168.021382 Z4.049258 E13694.701573 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.049431 matz1=4.049258 note=collision lift
G1 X248.958439 Y168.056237 Z4.049258 E13694.885072 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.049258 matz1=4.049258 note=collision lift
G1 X249.614719 Y168.089183 Z4.049258 E13695.040422 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.049258 matz1=4.049258 note=collision lift
G1 X250.281877 Y168.225881 Z4.049258 E13695.203723 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.049258 matz1=4.049258 note=collision lift
G1 X250.330494 Y168.24388 Z4.049258 E13695.221194 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.049258 matz1=4.049258 note=collision lift
G1 X250.335023 Y168.245557 Z4.051749 E13695.223025 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.049258 matz1=4.051749 note=collision lift
G1 X251.147142 Y168.546229 Z3.986149 E13695.515697 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.051749 matz1=3.986149 note=collision lift
G1 X251.151485 Y168.547837 Z3.983907 E13695.517431 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.986149 matz1=3.983907 note=collision lift
G1 X251.504458 Y168.678518 Z3.948441 E13695.644834 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.983907 matz1=3.948441 note=collision lift
G1 X251.507326 Y168.67958 Z3.950019 E13695.645994 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.948441 matz1=3.950019 note=collision lift
G1 X252.067073 Y168.989736 Z3.869065 E13695.921731 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.950019 matz1=3.869065 note=collision lift
G1 X252.076372 Y168.996719 Z3.863745 E13695.929993 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.869065 matz1=3.863745 note=collision lift
G1 X252.092444 Y169.008787 Z3.860706 E13695.943125 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.863745 matz1=3.860706 note=collision lift
G1 X252.095367 Y169.010982 Z3.862689 E13695.945812 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.860706 matz1=3.862689 note=collision lift
G1 X252.311162 Y169.173025 Z3.806813 E13696.123858 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.862689 matz1=3.806813 note=collision lift
G1 X252.944248 Y169.648417 Z3.44469 E13696.686313 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.806813 matz1=3.44469 note=collision lift
G1 X253.090638 Y169.758343 Z3.362577 E13696.824779 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.44469 matz1=3.362577 note=collision lift
G1 X253.239107 Y169.913171 Z3.266933 E13696.999621 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.362577 matz1=3.266933 note=collision lift
G1 X253.323679 Y170.001365 Z3.212916 E13697.112106 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.266933 matz1=3.212916 note=collision lift
G1 X253.457503 Y170.140922 Z3.224118 E13697.275177 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.212916 matz1=3.224118 note=collision lift
G1 X253.488264 Y170.173 Z3.248914 E13697.318027 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.224118 matz1=3.248914 note=collision lift
G1 X253.261374 Y170.147651 Z3.377163 E13697.555771 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.248914 matz1=3.377163 note=collision lift
G1 X253.21547 Y170.142522 Z3.403322 E13697.612158 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.377163 matz1=3.403322 note=collision lift
G1 X252.767029 Y170.09242 Z3.884487 E13698.312862 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.403322 matz1=3.884487 note=collision lift
G1 X252.40261 Y170.051704 Z4.277438 E13698.949812 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.884487 matz1=4.277438 note=collision lift
G1 X252.197291 Y169.986475 Z4.511109 E13699.575446 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.277438 matz1=4.511109 note=collision lift
G1 X252.116148 Y169.960696 Z4.585963 E13699.798607 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.511109 matz1=4.585963 note=collision lift
G1 X252.11372 Y169.959924 Z4.586179 E13699.80364 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.585963 matz1=4.586179 note=collision lift
G1 X252.035005 Y169.934917 Z4.646053 E13700.004449 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.586179 matz1=4.646053 note=collision lift
G1 X252.033968 Y169.934587 Z4.646145 E13700.006598 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.646053 matz1=4.646145 note=collision lift
G1 X252.014379 Y169.928364 Z4.660293 E13700.055717 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.646145 matz1=4.660293 note=collision lift
G1 X252.013923 Y169.928219 Z4.660812 E13700.057107 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.660293 matz1=4.660812 note=collision lift
G1 X251.960568 Y169.911268 Z4.698234 E13700.189662 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.660812 matz1=4.698234 note=collision lift
G1 X251.952469 Y169.908695 Z4.70745 E13700.214338 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.698234 matz1=4.70745 note=collision lift
G1 X251.460364 Y169.752354 Z5.021872 E13701.404374 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.70745 matz1=4.787078 note=collision lift
G1 X251.456474 Y169.751118 Z5.0263 E13701.416229 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.787078 matz1=4.787423 note=collision lift
G1 X250.577392 Y169.471835 Z5.551749 E13703.505873 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.787423 matz1=4.865513 note=collision lift
G1 X250.5171 Y169.45268 Z5.524526 E13703.641446 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.865513 matz1=4.870869 note=collision lift
G1 X250.514572 Y169.451286 Z5.521936 E13703.652762 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.870869 matz1=4.871165 note=collision lift
G1 X249.670311 Y168.98571 Z5.093839 E13706.731414 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.871165 matz1=4.970143 note=collision lift
G1 X249.669465 Y168.985243 Z5.093938 E13706.734251 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.970143 matz1=4.970242 note=collision lift
G1 X249.018869 Y168.626465 Z4.749966 E13709.123659 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.970242 matz1=4.749966 note=collision lift
G1 X248.784683 Y168.49732 Z4.893585 E13710.009577 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.749966 matz1=4.893585 note=collision lift
G1 X248.77931 Y168.492792 Z4.894356 E13710.030234 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.893585 matz1=4.894356 note=collision lift
G1 X248.779093 Y168.492609 Z4.89467 E13710.031469 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.894356 matz1=4.89467 note=collision lift
G1 X248.346836 Y168.128293 Z5.19838 E13712.58332 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.89467 matz1=5.139424 note=collision lift
G1 X248.345957 Y168.127552 Z5.198511 E13712.58792 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.139424 matz1=5.139556 note=collision lift
G1 X248.05378 Y167.881298 Z5.397365 E13714.30084 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.139556 matz1=5.183256 note=collision lift
G1 X248.052008 Y167.879804 Z5.39763 E13714.310119 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.183256 matz1=5.183521 note=collision lift
G1 X247.819862 Y167.684146 Z5.549431 E13715.659899 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.183521 matz1=5.218243 note=collision lift
G1 X247.818063 Y167.68263 Z5.5497 E13715.669316 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.218243 matz1=5.218512 note=collision lift
G1 X247.593294 Y167.493189 Z5.393507 E13716.993002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.218512 matz1=5.25213 note=collision lift
G1 X247.590683 Y167.490988 Z5.390482 E13717.011145 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.25213 matz1=5.252521 note=collision lift
G1 X247.48091 Y167.398469 Z5.30634 E13717.672852 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.252521 matz1=5.268939 note=collision lift
G1 X247.478573 Y167.396499 Z5.303633 E13717.689084 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.268939 matz1=5.269289 note=collision lift
G1 X247.426322 Y167.352461 Z5.258505 E13718.014726 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.269289 matz1=5.258505 note=collision lift
G1 X247.424717 Y167.351109 Z5.258745 E13718.023126 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.258505 matz1=5.258745 note=collision lift
G1 X247.368525 Y167.303748 Z5.197392 E13718.40381 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.258745 matz1=5.197392 note=collision lift
G1 X247.271935 Y167.22234 Z5.085518 E13719.074804 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.197392 matz1=5.085518 note=collision lift
G1 X247.092857 Y166.998214 Z4.832776 E13721.016195 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.085518 matz1=4.832776 note=collision lift
G1 X246.036991 Y165.676736 Z4.188324 E13730.207395 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.832776 matz1=4.188324 note=collision lift
G1 X245.896571 Y165.405548 Z4.071237 E13732.196873 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.188324 matz1=4.071237 note=collision lift
G1 X245.189474 Y164.039962 Z4.250534 E13741.614438 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.127309 Y163.919904 Z4.265801 E13742.172658 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.577846 Y162.01936 Z4.476553 E13751.643022 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.418037 Y160.145668 Z4.64704 E13761.634668 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.409719 Y160.048139 Z4.654927 E13762.41775 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.629389 Y158.081994 Z4.789956 E13779.48299 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.228414 Y156.196484 Z4.873336 E13797.295962 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X246.183773 Y154.464067 Z4.899941 E13815.340949 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.458753 Y152.95132 Z4.868135 E13833.092287 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.520385 Y152.902076 Z4.865388 E13833.793035 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.910156 Y152.590647 Z5.097471 E13838.677813 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.865388 matz1=5.097471 note=collision lift
G1 X247.440094 Y153.443041 Z5.539649 E13847.946325 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.097471 matz1=5.539649 note=collision lift
G1 X246.165114 Y154.955789 Z6.399941 E13865.34794 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.539649 matz1=6.17459 note=collision lift
G1 X245.484359 Y155.499715 Z6.399941 E13871.669721 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.17459 matz1=6.098194 note=collision lift
G1 X245.484112 Y155.499912 Z6.400071 E13871.672194 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.098194 matz1=6.098167 note=collision lift
G1 X244.863897 Y155.995467 Z6.389324 E13877.432306 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.098167 matz1=6.028565 note=collision lift
G1 X244.863742 Y155.995591 Z6.389208 E13877.433969 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.028565 matz1=6.028547 note=collision lift
G1 X244.620042 Y156.190308 Z6.384671 E13879.69731 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.028547 matz1=6.001199 note=collision lift
G1 X244.61951 Y156.190733 Z6.384952 E13879.702656 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.001199 matz1=6.001139 note=collision lift
G1 X244.016561 Y156.502938 Z6.373751 E13883.970802 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.001139 matz1=5.929979 note=collision lift
G1 X244.016416 Y156.503014 Z6.373651 E13883.972008 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.929979 matz1=5.929962 note=collision lift
G1 X243.900151 Y156.563215 Z6.362243 E13884.798025 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.929962 matz1=5.916241 note=collision lift
G1 X243.898623 Y156.564007 Z6.362923 E13884.809659 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.916241 matz1=5.91606 note=collision lift
G1 X243.780684 Y156.625075 Z6.344935 E13885.652031 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.91606 matz1=5.902141 note=collision lift
G1 X242.862678 Y157.100416 Z5.719707 E13893.245438 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.902141 matz1=5.719707 note=collision lift
G1 X241.973427 Y157.357505 Z5.150413 E13899.093689 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.719707 matz1=5.150413 note=collision lift
G1 X241.248835 Y157.566991 Z5.4408 E13903.443254 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.150413 matz1=5.4408 note=collision lift
G1 X240.962134 Y157.649878 Z5.554746 E13904.554227 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.4408 matz1=5.554746 note=collision lift
G1 X238.990913 Y157.818005 Z6.308364 E13910.361674 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.554746 matz1=5.329747 note=collision lift
G1 X238.763927 Y157.792645 Z6.39622 E13910.858853 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.329747 matz1=5.303405 note=collision lift
G1 X238.708767 Y157.786482 Z6.400053 E13910.971886 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.303405 matz1=5.297003 note=collision lift
G1 X238.708329 Y157.786433 Z6.399781 E13910.972939 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.297003 matz1=5.296953 note=collision lift
G1 X237.024768 Y157.598335 Z6.399781 E13914.414688 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.296953 matz1=5.10157 note=collision lift
G1 X236.927852 Y157.567545 Z6.399781 E13914.555732 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.10157 matz1=5.090943 note=collision lift
G1 X236.927801 Y157.567529 Z6.399802 E13914.555812 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.090943 matz1=5.090938 note=collision lift
G1 X236.310039 Y157.371267 Z6.393383 E13915.454896 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.090938 matz1=5.023198 note=collision lift
G1 X236.310007 Y157.371256 Z6.393363 E13915.454951 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.023198 matz1=5.023194 note=collision lift
G1 X236.245631 Y157.350804 Z6.392685 E13915.548643 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.023194 matz1=5.016135 note=collision lift
G1 X236.245492 Y157.35076 Z6.392743 E13915.548861 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.016135 matz1=5.01612 note=collision lift
G1 X235.139258 Y156.999311 Z6.380835 E13917.158869 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.01612 matz1=4.894818 note=collision lift
G1 X235.13917 Y156.999262 Z6.380777 E13917.158967 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.894818 matz1=4.894809 note=collision lift
G1 X235.103893 Y156.979808 Z6.38034 E13917.193163 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.894809 matz1=4.891294 note=collision lift
G1 X235.103769 Y156.97974 Z6.380398 E13917.193292 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.891294 matz1=4.891282 note=collision lift
G1 X234.575459 Y156.688398 Z6.338642 E13917.706594 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.891282 matz1=4.838642 note=collision lift
G1 X234.575152 Y156.688228 Z6.338612 E13917.706893 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.838642 matz1=4.838612 note=collision lift
G1 X233.63604 Y156.170346 Z6.245041 E13918.620607 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.838612 matz1=4.745041 note=collision lift
G1 X233.635941 Y156.170291 Z6.245031 E13918.620704 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.745041 matz1=4.745031 note=collision lift
G1 X233.407564 Y156.04435 Z6.222276 E13918.842904 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.745031 matz1=4.722276 note=collision lift
G1 X233.406841 Y156.043951 Z6.222204 E13918.843607 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.722276 matz1=4.722204 note=collision lift
G1 X233.212624 Y155.88026 Z6.205788 E13918.958164 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.722204 matz1=4.705788 note=collision lift
G1 X233.211855 Y155.879612 Z6.205723 E13918.958618 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.705788 matz1=4.705723 note=collision lift
G1 X233.116932 Y155.799609 Z6.197699 E13919.014607 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.705723 matz1=4.697699 note=collision lift
G1 X233.115515 Y155.798415 Z6.19758 E13919.015443 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.697699 matz1=4.69758 note=collision lift
G1 X233.018406 Y155.716569 Z6.189372 E13919.072721 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.69758 matz1=4.689372 note=collision lift
G1 X231.894094 Y154.768971 Z5.396786 E13919.824524 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.689372 matz1=4.594341 note=collision lift
G1 X230.659149 Y153.223367 Z4.332348 E13920.30852 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.594341 matz1=4.332348 note=collision lift
G1 X230.263596 Y152.459451 Z3.894393 E13920.462283 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.332348 matz1=3.894393 note=collision lift
G1 X229.749467 Y151.466535 Z4.44328 E13920.660691 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.894393 matz1=4.44328 note=collision lift
G1 X229.57861 Y150.875557 Z4.757209 E13920.784355 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.44328 matz1=4.507423 note=collision lift
G1 X229.200004 Y149.565991 Z5.472809 E13921.442712 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.507423 matz1=4.541425 note=collision lift
G1 X229.079723 Y148.155735 Z6.110254 E13922.805007 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.541425 matz1=4.610254 note=collision lift
G1 X229.074111 Y148.089943 Z6.113466 E13922.863024 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.610254 matz1=4.613466 note=collision lift
G1 X229.072923 Y148.076018 Z6.114145 E13922.875303 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.613466 matz1=4.614145 note=collision lift
G1 X229.032368 Y147.600521 Z6.137352 E13923.294609 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.614145 matz1=4.637352 note=collision lift
G1 X229.03197 Y147.59585 Z6.13758 E13923.298728 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.637352 matz1=4.63758 note=collision lift
G1 X229.031877 Y147.59477 Z6.137633 E13923.299681 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.63758 matz1=4.637633 note=collision lift
G1 X229.158858 Y146.458236 Z6.222121 E13925.089967 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.637633 matz1=4.722121 note=collision lift
G1 X229.159003 Y146.456941 Z6.222218 E13925.092006 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.722121 matz1=4.722218 note=collision lift
G1 X229.22254 Y145.888252 Z6.264493 E13925.987814 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.722218 matz1=4.764493 note=collision lift
G1 X229.222575 Y145.887936 Z6.264516 E13925.988312 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.764493 matz1=4.764516 note=collision lift
G1 X229.246732 Y145.671726 Z6.280589 E13926.32889 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.764516 matz1=4.780589 note=collision lift
G1 X229.246738 Y145.67167 Z6.280593 E13926.328978 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.780589 matz1=4.780593 note=collision lift
G1 X229.251547 Y145.628625 Z6.283793 E13926.396783 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.780593 matz1=4.783793 note=collision lift
G1 X229.838392 Y143.781451 Z6.397416 E13931.127087 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.783793 matz1=4.967113 note=collision lift
G1 X229.850572 Y143.743115 Z6.397416 E13931.225093 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.967113 matz1=4.970918 note=collision lift
G1 X230.805931 Y142.010698 Z6.397416 E13938.049402 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.970918 matz1=5.187501 note=collision lift
G1 X231.1204 Y141.637586 Z6.397416 E13939.957038 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.187501 matz1=5.244235 note=collision lift
G1 X231.120517 Y141.637446 Z6.397528 E13939.957878 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.244235 matz1=5.244257 note=collision lift
G1 X231.351042 Y141.363931 Z6.389167 E13941.356675 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.244257 matz1=5.285846 note=collision lift
G1 X231.35117 Y141.36378 Z6.389091 E13941.357315 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.285846 matz1=5.28587 note=collision lift
G1 X231.488364 Y141.201 Z6.383604 E13942.001566 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.28587 matz1=5.311129 note=collision lift
G1 X231.48909 Y141.200139 Z6.384301 E13942.005575 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.311129 matz1=5.311263 note=collision lift
G1 X231.890441 Y140.723941 Z6.364698 E13943.890582 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.311263 matz1=5.385157 note=collision lift
G1 X231.892494 Y140.721506 Z6.363484 E13943.900896 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.385157 matz1=5.385535 note=collision lift
G1 X231.98142 Y140.615996 Z6.351855 E13944.319824 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.385535 matz1=5.401908 note=collision lift
G1 X232.080912 Y140.497951 Z6.292983 E13944.819678 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.401908 matz1=5.420225 note=collision lift
G1 X233.626516 Y139.263006 Z5.538349 E13952.774115 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.420225 matz1=5.538349 note=collision lift
G1 X235.383347 Y138.353324 Z4.771123 E13962.21415 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.538349 matz1=4.771123 note=collision lift
G1 X236.141075 Y138.134259 Z4.454776 E13966.513517 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.771123 matz1=4.454776 note=collision lift
G1 X237.283892 Y137.803861 Z4.572466 E13972.561268 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X239.255113 Y137.635734 Z4.729914 E13983.576018 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.221258 Y137.855404 Z4.839406 E13995.249324 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.106768 Y138.454429 Z4.894208 E14007.247461 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.839185 Y139.409788 Z4.890951 E14019.220926 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X246.351932 Y140.684768 Z4.829837 E14030.822897 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.586876 Y142.230373 Z4.714621 E14041.727032 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X248.496559 Y143.987204 Z4.552389 E14051.645118 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.046021 Y145.887749 Z4.353117 E14060.344541 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.077632 Y146.258377 Z4.310989 E14061.72083 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.214148 Y147.85897 Z4.93226 E14068.05301 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.310989 matz1=4.93226 note=collision lift
G1 X248.994478 Y149.825115 Z5.686379 E14074.28505 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.93226 matz1=5.393988 note=collision lift
G1 X248.556621 Y151.203329 Z6.238961 E14078.018928 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.393988 matz1=5.223521 note=collision lift
G1 X248.47081 Y151.473432 Z6.3481 E14079.030798 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.223521 matz1=5.190958 note=collision lift
G1 X248.395454 Y151.710625 Z6.357181 E14079.860568 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.190958 matz1=5.162362 note=collision lift
G1 X248.395434 Y151.71066 Z6.357157 E14079.8607 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.162362 matz1=5.162357 note=collision lift
G1 X248.246483 Y151.980762 Z6.368188 E14080.727753 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.162357 matz1=5.128059 note=collision lift
G1 X248.246465 Y151.980795 Z6.368165 E14080.727877 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.128059 matz1=5.128055 note=collision lift
G1 X247.910156 Y152.590647 Z6.379068 E14082.684542 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.128055 matz1=5.050615 note=collision lift
G1 X247.910158 Y152.590645 Z6.379067 E14082.684548 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.050615 matz1=5.050614 note=collision lift
G1 X248.435313 Y152.171044 Z6.368164 E14084.117962 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.050614 matz1=4.981139 note=collision lift
G1 X248.435353 Y152.171012 Z6.368133 E14084.118088 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.981139 matz1=4.981134 note=collision lift
G1 X248.886717 Y151.810371 Z6.348016 E14085.350673 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.981134 matz1=4.921421 note=collision lift
G1 X249.004357 Y151.716375 Z6.257163 E14085.725645 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.921421 matz1=4.905858 note=collision lift
G1 X249.120174 Y151.656406 Z6.179263 E14086.040533 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.905858 matz1=4.893169 note=collision lift
G1 X250.761189 Y150.806693 Z5.093093 E14087.918531 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.893169 matz1=4.730977 note=collision lift
G1 X252.661734 Y150.25723 Z3.973235 E14088.984004 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.730977 matz1=3.973235 note=collision lift
G1 X252.896208 Y150.237232 Z3.846244 E14089.043943 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.973235 matz1=3.846244 note=collision lift
G1 X253.647344 Y150.173167 Z3.873349 E14089.213033 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.846244 matz1=3.873349 note=collision lift
G1 X253.651001 Y150.172855 Z3.871369 E14089.213968 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.873349 matz1=3.871369 note=collision lift
G1 X254.632955 Y150.089103 Z3.877236 E14089.434879 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.871369 matz1=3.877236 note=collision lift
G1 X254.637432 Y150.089604 Z3.874935 E14089.435676 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.877236 matz1=3.874935 note=collision lift
G1 X254.899288 Y150.11886 Z3.875712 E14089.477194 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.874935 matz1=3.875712 note=collision lift
G1 X254.90261 Y150.119231 Z3.877347 E14089.477781 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.875712 matz1=3.877347 note=collision lift
G1 X255.749621 Y150.213864 Z3.870476 E14089.612081 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.877347 matz1=3.870476 note=collision lift
G1 X255.750855 Y150.214002 Z3.871083 E14089.612299 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.870476 matz1=3.871083 note=collision lift
G1 X256.599099 Y150.308773 Z3.846617 E14089.746846 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.871083 matz1=3.846617 note=collision lift
G1 X256.600797 Y150.309313 Z3.84576 E14089.747386 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.846617 matz1=3.84576 note=collision lift
G1 X257.114213 Y150.472424 Z3.817814 E14089.894669 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.84576 matz1=3.817814 note=collision lift
G1 X257.130684 Y150.477657 Z3.809496 E14089.899906 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.817814 matz1=3.809496 note=collision lift
G1 X257.155569 Y150.485563 Z3.802326 E14089.907299 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.809496 matz1=3.802326 note=collision lift
G1 X257.159836 Y150.486919 Z3.800172 E14089.908656 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.802326 matz1=3.800172 note=collision lift
G1 X257.175285 Y150.491827 Z3.793618 E14089.91343 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.800172 matz1=3.793618 note=collision lift
G1 X257.176247 Y150.492133 Z3.794142 E14089.91374 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.793618 matz1=3.794142 note=collision lift
G1 X258.48461 Y150.907798 Z3.133435 E14090.329717 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.794142 matz1=3.133435 note=collision lift
G1 X258.652513 Y151.00039 Z3.04659 E14090.448317 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.133435 matz1=3.04659 note=collision lift
G1 X260.217026 Y151.863157 Z3.130698 E14091.4561 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.176751 Y152.672037 Z3.221747 E14092.728293 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.729774 Y153.138137 Z3.635834 E14093.570805 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.221747 matz1=3.635834 note=collision lift
G1 X261.758191 Y153.173703 Z3.662855 E14093.654872 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.635834 matz1=3.662855 note=collision lift
G1 X261.758973 Y153.174682 Z3.662345 E14093.657021 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.662855 matz1=3.662345 note=collision lift
G1 X261.776973 Y153.19721 Z3.67333 E14093.706022 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.662345 matz1=3.67333 note=collision lift
G1 X261.778042 Y153.198548 Z3.674347 E14093.709184 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.67333 matz1=3.674347 note=collision lift
G1 X261.816674 Y153.246898 Z3.69213 E14093.811439 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.674347 matz1=3.69213 note=collision lift
G1 X261.817744 Y153.248238 Z3.693148 E14093.814607 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.69213 matz1=3.693148 note=collision lift
G1 X261.895856 Y153.345999 Z3.720726 E14094.018089 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.693148 matz1=3.720726 note=collision lift
G1 X261.897149 Y153.347618 Z3.721955 E14094.021915 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.720726 matz1=3.721955 note=collision lift
G1 X262.053619 Y153.543448 Z3.765046 E14094.425809 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.721955 matz1=3.765046 note=collision lift
G1 X262.055959 Y153.546377 Z3.767271 E14094.432731 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.765046 matz1=3.767271 note=collision lift
G1 X262.964718 Y154.683742 Z3.874728 E14096.750879 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.767271 matz1=3.874728 note=collision lift
G1 X262.966727 Y154.687622 Z3.873018 E14096.76148 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.874728 matz1=3.873018 note=collision lift
G1 X263.011439 Y154.773972 Z3.879718 E14096.981678 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.873018 matz1=3.879718 note=collision lift
G1 X263.01222 Y154.775481 Z3.880752 E14096.986172 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.879718 matz1=3.880752 note=collision lift
G1 X263.874401 Y156.440573 Z3.938631 E14101.224257 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.880752 matz1=3.938631 note=collision lift
G1 X263.874992 Y156.442618 Z3.937816 E14101.231056 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.938631 matz1=3.937816 note=collision lift
G1 X263.908325 Y156.557914 Z3.940951 E14101.589206 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937816 matz1=3.940951 note=collision lift
G1 X263.908345 Y156.557983 Z3.940995 E14101.589457 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.940951 matz1=3.940995 note=collision lift
G1 X264.423863 Y158.341118 Z3.943405 E14107.126612 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.940995 matz1=3.943405 note=collision lift
G1 X264.423866 Y158.341157 Z3.94339 E14107.126769 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943405 matz1=3.94339 note=collision lift
G1 X264.437446 Y158.500378 Z3.955979 E14107.722323 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94339 matz1=3.955979 note=collision lift
G1 X264.541948 Y159.725622 Z4.071643 E14112.311282 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.955979 matz1=4.071643 note=collision lift
G1 X264.59199 Y160.312339 Z4.141542 E14114.51444 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X264.37232 Y162.278484 Z4.364607 E14123.296241 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X263.773295 Y164.163994 Z4.562178 E14133.291003 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.817936 Y165.896411 Z4.722107 E14144.258532 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.242425 Y166.579247 Z4.779232 E14149.362527 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.542956 Y167.409158 Z4.834559 E14158.941838 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.997352 Y168.644102 Z4.89262 E14176.925186 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.436083 Y169.452523 Z4.895607 E14192.924419 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.24052 Y169.553785 Z4.89272 E14194.925658 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.339975 Y170.103247 Z4.834852 E14212.374189 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X254.368754 Y170.271374 Z4.722576 E14228.802728 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X253.488264 Y170.173 Z4.656371 E14235.893404 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X253.99443 Y170.700848 Z4.595092 E14241.540211 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X254.790556 Y171.789154 Z4.468247 E14251.157798 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.46096 Y172.959105 Z4.326558 E14259.887298 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.87332 Y173.969504 Z4.203788 E14266.327328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.954375 Y174.168111 Z4.179021 E14267.568608 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.995255 Y174.346556 Z4.157752 E14268.609694 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.026073 Y174.481077 Z4.141645 E14269.384102 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.240211 Y175.415805 Z4.028401 E14274.254529 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.295883 Y176.053311 Z3.952095 E14277.275141 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.234177 Y177.011705 Z3.837938 E14281.105504 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.230275 Y177.07232 Z3.861089 E14281.362948 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.837938 matz1=3.861089 note=collision lift
G1 X256.23023 Y177.073011 Z3.86066 E14281.366172 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.861089 matz1=3.86066 note=collision lift
G1 X256.211923 Y177.357351 Z3.86066 E14282.494635 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.86066 matz1=3.86066 note=collision lift
G1 X256.065444 Y178.02243 Z3.86066 E14284.93834 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.86066 matz1=3.86066 note=collision lift
G1 X256.022003 Y178.134858 Z3.86066 E14285.282028 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.86066 matz1=3.86066 note=collision lift
G1 X255.561112 Y179.327672 Z4.356079 E14289.192507 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.86066 matz1=4.356079 note=collision lift
G1 X255.354987 Y178.614701 Z4.648201 E14291.172271 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.356079 matz1=4.648201 note=collision lift
G1 X255.18686 Y176.64348 Z5.448578 E14294.584922 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.648201 matz1=4.791886 note=collision lift
G1 X255.1881 Y176.632377 Z5.453318 E14294.59634 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.791886 matz1=4.79104 note=collision lift
G1 X255.2393 Y176.174118 Z5.527945 E14295.035823 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.79104 matz1=4.756135 note=collision lift
G1 X255.240227 Y176.165825 Z5.531486 E14295.044351 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.756135 matz1=4.755504 note=collision lift
G1 X255.299957 Y175.631209 Z5.624284 E14295.557951 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.755504 matz1=4.714783 note=collision lift
G1 X255.300249 Y175.628593 Z5.622768 E14295.56081 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.714783 matz1=4.714584 note=collision lift
G1 X255.313698 Y175.50822 Z5.641713 E14295.676153 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.714584 matz1=4.705415 note=collision lift
G1 X255.313702 Y175.508189 Z5.641695 E14295.676187 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.705415 matz1=4.705413 note=collision lift
G1 X255.325551 Y175.40213 Z5.657779 E14295.777728 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.705413 matz1=4.697335 note=collision lift
G1 X255.325563 Y175.402024 Z5.657825 E14295.777837 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.697335 matz1=4.697327 note=collision lift
G1 X255.341631 Y175.258208 Z5.67901 E14295.91544 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.697327 matz1=4.686373 note=collision lift
G1 X255.341692 Y175.257661 Z5.679243 E14295.916002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.686373 matz1=4.686331 note=collision lift
G1 X255.35816 Y175.11027 Z5.703695 E14296.057422 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.686331 matz1=4.675104 note=collision lift
G1 X255.358357 Y175.108501 Z5.70445 E14296.059242 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.675104 matz1=4.67497 note=collision lift
G1 X255.393287 Y174.795866 Z5.750623 E14296.358386 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.67497 matz1=4.651157 note=collision lift
G1 X255.393367 Y174.795153 Z5.750219 E14296.359132 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.651157 matz1=4.651111 note=collision lift
G1 X255.406201 Y174.680281 Z5.766096 E14296.464747 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.651111 matz1=4.64373 note=collision lift
G1 X255.40653 Y174.677336 Z5.767388 E14296.467674 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.64373 matz1=4.643541 note=collision lift
G1 X255.517557 Y174.327862 Z5.812975 E14296.763672 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.643541 matz1=4.621268 note=collision lift
G1 X255.517901 Y174.326779 Z5.812345 E14296.764546 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.621268 matz1=4.621206 note=collision lift
G1 X255.55566 Y174.207928 Z5.826356 E14296.848992 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.621206 matz1=4.614338 note=collision lift
G1 X255.556447 Y174.205452 Z5.827512 E14296.850905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.614338 matz1=4.614195 note=collision lift
G1 X255.66581 Y173.861218 Z5.862649 E14297.095108 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.614195 matz1=4.594304 note=collision lift
G1 X255.668169 Y173.853791 Z5.866116 E14297.100848 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.594304 matz1=4.593874 note=collision lift
G1 X255.907354 Y173.100924 Z5.920994 E14297.4519 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.593874 matz1=4.559073 note=collision lift
G1 X255.908864 Y173.096172 Z5.918281 E14297.454417 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.559073 matz1=4.558854 note=collision lift
G1 X256.005555 Y172.791825 Z5.931773 E14297.596115 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.558854 matz1=4.544785 note=collision lift
G1 X256.005618 Y172.791709 Z5.931704 E14297.596151 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.544785 matz1=4.544782 note=collision lift
G1 X256.12149 Y172.581591 Z5.931444 E14297.654163 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.544782 matz1=4.539556 note=collision lift
G1 X256.122283 Y172.580154 Z5.932229 E14297.654603 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.539556 matz1=4.53952 note=collision lift
G1 X256.26014 Y172.330169 Z5.922174 E14297.723665 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.53952 matz1=4.533301 note=collision lift
G1 X256.261395 Y172.327893 Z5.920818 E14297.724373 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.533301 matz1=4.533245 note=collision lift
G1 X256.329069 Y172.205176 Z5.90785 E14297.7584 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.533245 matz1=4.530192 note=collision lift
G1 X256.329997 Y172.203492 Z5.906847 E14297.758924 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.530192 matz1=4.53015 note=collision lift
G1 X256.363533 Y172.14268 Z5.89525 E14297.775946 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.53015 matz1=4.528637 note=collision lift
G1 X256.36439 Y172.141126 Z5.894324 E14297.77643 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.528637 matz1=4.528599 note=collision lift
G1 X256.380765 Y172.111431 Z5.885233 E14297.784918 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.528599 matz1=4.52786 note=collision lift
G1 X256.382074 Y172.109058 Z5.883819 E14297.785657 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.52786 matz1=4.527801 note=collision lift
G1 X256.383711 Y172.10609 Z5.882435 E14297.786542 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.527801 matz1=4.527727 note=collision lift
G1 X256.852329 Y171.256313 Z6.006589 E14298.023072 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.527727 matz1=4.506589 note=collision lift
G1 X256.960092 Y171.0609 Z6.001728 E14298.077037 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506589 matz1=4.501728 note=collision lift
G1 X256.960914 Y171.059409 Z6.001691 E14298.077449 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501728 matz1=4.501691 note=collision lift
G1 X257.42875 Y170.504327 Z6.007274 E14298.304628 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501691 matz1=4.507274 note=collision lift
G1 X257.43018 Y170.502631 Z6.007291 E14298.305322 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.507274 matz1=4.507291 note=collision lift
G1 X257.562059 Y170.346158 Z6.008865 E14298.369363 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.507291 matz1=4.508865 note=collision lift
G1 X257.562072 Y170.346142 Z6.008865 E14298.369369 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.508865 matz1=4.508865 note=collision lift
G1 X258.235894 Y169.546661 Z6.016907 E14298.696575 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.508865 matz1=4.516907 note=collision lift
G1 X258.427179 Y169.393824 Z6.022837 E14298.780012 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.516907 matz1=4.522837 note=collision lift
G1 X259.379718 Y168.632741 Z6.069722 E14299.576117 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.522837 matz1=4.569722 note=collision lift
G1 X259.379721 Y168.632739 Z6.069722 E14299.576119 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.569722 matz1=4.569722 note=collision lift
G1 X259.781498 Y168.311717 Z6.089498 E14299.911913 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.569722 matz1=4.589498 note=collision lift
G1 X259.781502 Y168.311715 Z6.089499 E14299.911919 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.589498 matz1=4.589499 note=collision lift
G1 X260.869209 Y167.748504 Z6.167201 E14301.43316 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.589499 matz1=4.667201 note=collision lift
G1 X260.869309 Y167.748451 Z6.167209 E14301.4333 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.667201 matz1=4.667209 note=collision lift
G1 X261.537576 Y167.402425 Z6.214948 E14302.367923 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.667209 matz1=4.714948 note=collision lift
G1 X261.537714 Y167.402353 Z6.214958 E14302.368116 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.714948 matz1=4.714958 note=collision lift
G1 X261.53833 Y167.402034 Z6.215002 E14302.368977 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.714958 matz1=4.715002 note=collision lift
G1 X261.539888 Y167.401584 Z6.215134 E14302.371669 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.715002 matz1=4.715134 note=collision lift
G1 X261.540698 Y167.40135 Z6.215203 E14302.373069 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.715134 matz1=4.715203 note=collision lift
G1 X262.580991 Y167.100593 Z6.303666 E14304.170329 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.715203 matz1=4.803666 note=collision lift
G1 X262.582338 Y167.100203 Z6.303795 E14304.172242 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.803666 matz1=4.803795 note=collision lift
G1 X262.741496 Y167.05419 Z6.319014 E14304.398271 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.803795 matz1=4.819014 note=collision lift
G1 X262.741517 Y167.054183 Z6.319016 E14304.398302 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.819014 matz1=4.819016 note=collision lift
G1 X262.786838 Y167.041081 Z6.32335 E14304.462665 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.819016 matz1=4.82335 note=collision lift
G1 X262.789479 Y167.040317 Z6.323602 E14304.466416 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.82335 matz1=4.823602 note=collision lift
G1 X263.438874 Y166.852572 Z6.284624 E14305.386322 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.823602 matz1=4.885699 note=collision lift
G1 X263.448822 Y166.851724 Z6.280669 E14305.407787 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.885699 matz1=4.886736 note=collision lift
G1 X263.462049 Y166.850595 Z6.279306 E14305.434465 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.886736 matz1=4.888114 note=collision lift
G1 X263.462629 Y166.850546 Z6.279657 E14305.435824 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.888114 matz1=4.888175 note=collision lift
G1 X263.561327 Y166.842128 Z6.265034 E14305.635985 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.888175 matz1=4.898459 note=collision lift
G1 X263.562775 Y166.842004 Z6.265912 E14305.63938 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.898459 matz1=4.89861 note=collision lift
G1 X263.662921 Y166.833463 Z6.242708 E14305.845587 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.89861 matz1=4.909045 note=collision lift
G1 X265.410096 Y166.684445 Z5.548 E14309.615985 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.909045 matz1=5.091096 note=collision lift
G1 X267.37624 Y166.904115 Z4.786277 E14315.35744 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.091096 matz1=4.786277 note=collision lift
G1 X269.22082 Y167.490136 Z4.048995 E14322.487763 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.786277 matz1=4.048995 note=collision lift
G1 X269.26175 Y167.50314 Z4.054108 E14322.636663 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X270.994167 Y168.458499 Z4.283254 E14330.916298 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X272.506915 Y169.733479 Z4.491908 E14340.480861 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X273.741859 Y171.279083 Z4.667241 E14351.11579 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X274.651541 Y173.035915 Z4.79847 E14362.543795 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X275.201004 Y174.93646 Z4.877528 E14374.443928 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X275.369131 Y176.907681 Z4.899553 E14386.471183 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X275.149461 Y178.873825 Z4.86319 E14398.27537 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X274.550436 Y180.759335 Z4.770676 E14409.519131 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X273.595077 Y182.491752 Z4.627699 E14419.895604 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X272.320097 Y184.0045 Z4.44305 E14429.146046 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X270.876384 Y185.158032 Z4.242934 E14436.639726 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X270.774493 Y185.239444 Z4.228085 E14437.424407 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X269.017661 Y186.149126 Z3.99602 E14447.169884 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X267.117116 Y186.698589 Z3.761125 E14454.728169 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X265.145895 Y186.866716 Z3.537844 E14460.202188 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X263.179751 Y186.647046 Z3.339906 E14463.828112 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.880037 Y186.234128 Z3.229323 E14465.296659 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.29424 Y186.048021 Z3.486807 E14466.011932 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.229323 matz1=3.486807 note=collision lift
G1 X261.208526 Y186.000753 Z3.528972 E14466.122949 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.486807 matz1=3.528972 note=collision lift
G1 X260.58797 Y185.658541 Z3.843255 E14466.404409 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.528972 matz1=3.843255 note=collision lift
G1 X260.539283 Y185.631692 Z3.860136 E14466.425506 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.843255 matz1=3.860136 note=collision lift
G1 X260.538278 Y185.631138 Z3.859497 E14466.425983 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.860136 matz1=3.859497 note=collision lift
G1 X260.4917 Y185.605452 Z3.869502 E14466.445634 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.859497 matz1=3.869502 note=collision lift
G1 X260.490596 Y185.604843 Z3.870061 E14466.446134 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.869502 matz1=3.870061 note=collision lift
G1 X260.394599 Y185.551904 Z3.885538 E14466.486331 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.870061 matz1=3.885538 note=collision lift
G1 X260.393221 Y185.551145 Z3.886236 E14466.486956 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.885538 matz1=3.886236 note=collision lift
G1 X260.205804 Y185.447791 Z3.909169 E14466.565107 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.886236 matz1=3.909169 note=collision lift
G1 X260.198471 Y185.443748 Z3.912882 E14466.568433 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.909169 matz1=3.912882 note=collision lift
G1 X259.561824 Y185.092662 Z3.939242 E14466.832571 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.912882 matz1=3.939242 note=collision lift
G1 X259.559876 Y185.091021 Z3.937893 E14466.833089 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939242 matz1=3.937893 note=collision lift
G1 X259.231442 Y184.814208 Z3.949242 E14466.910426 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937893 matz1=3.949242 note=collision lift
G1 X259.231158 Y184.813969 Z3.949045 E14466.910502 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949242 matz1=3.949045 note=collision lift
G1 X258.049076 Y183.817682 Z3.949045 E14467.18875 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949045 matz1=3.949045 note=collision lift
G1 X257.964683 Y183.712059 Z3.949045 E14467.212276 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949045 matz1=3.949045 note=collision lift
G1 X256.907017 Y182.388328 Z3.949045 E14467.663584 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949045 matz1=3.949045 note=collision lift
G1 X256.814132 Y182.272078 Z4.023538 E14467.707907 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949045 matz1=4.023538 note=collision lift
G1 X255.904449 Y180.515246 Z5.06994 E14468.902926 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.023538 matz1=4.56416 note=collision lift
G1 X255.561112 Y179.327672 Z5.207145 E14469.938029 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.56416 matz1=4.627929 note=collision lift
G1 X255.553665 Y179.346947 Z5.198058 E14469.957178 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.627929 matz1=4.629173 note=collision lift
G1 X255.540587 Y179.380793 Z5.193973 E14469.988153 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.629173 matz1=4.631357 note=collision lift
G1 X255.540515 Y179.380979 Z5.194084 E14469.988347 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.631357 matz1=4.631369 note=collision lift
G1 X255.156196 Y180.073201 Z5.105262 E14470.857711 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.631369 matz1=4.683297 note=collision lift
G1 X255.156184 Y180.073217 Z5.105254 E14470.857748 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.683297 matz1=4.683299 note=collision lift
G1 X254.916972 Y180.398925 Z5.05979 E14471.569358 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.683299 matz1=4.71582 note=collision lift
G1 X254.120311 Y181.48365 Z4.495175 E14474.123266 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.71582 matz1=4.495175 note=collision lift
G1 X253.461482 Y182.202378 Z4.099714 E14476.417323 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.495175 matz1=4.099714 note=collision lift
G1 X253.26438 Y182.380618 Z3.993377 E14477.076925 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.099714 matz1=3.993377 note=collision lift
G1 X252.447503 Y183.119327 Z3.558714 E14480.503221 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.993377 matz1=3.558714 note=collision lift
G1 X252.377207 Y183.182896 Z3.568697 E14480.778999 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X251.844029 Y183.665053 Z3.648747 E14483.142875 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.798422 Y185.160425 Z3.945953 E14495.027397 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.29407 Y186.688125 Z4.288551 E14513.518165 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.270712 Y186.707173 Z4.29191 E14513.708508 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.593588 Y188.074879 Z4.517424 E14529.659857 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.227222 Y188.3256 Z4.559026 E14533.015491 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.880389 Y189.247305 Z4.694745 E14546.379641 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.217416 Y189.634766 Z4.748105 E14552.85327 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.420323 Y189.266821 Z4.774188 E14556.445223 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.575537 Y187.896175 Z4.858893 E14572.467367 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.843837 Y187.681802 Z4.869972 E14575.552965 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.975954 Y186.777236 Z4.897674 E14588.756317 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X246.928527 Y186.283996 Z4.898006 E14598.529913 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.567756 Y185.953005 Z4.888572 E14605.05733 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.289772 Y185.455157 Z4.832048 E14620.844393 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X251.075825 Y185.302823 Z4.730957 E14635.799785 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.857278 Y185.501858 Z4.590407 E14649.595283 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X254.293785 Y185.958235 Z4.44684 E14660.195418 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X254.565671 Y186.044613 Z4.4175 E14661.507696 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.135352 Y186.91023 Z4.220971 E14668.654203 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X257.505998 Y188.065444 Z4.010751 E14674.623775 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.501944 Y189.311927 Z3.820906 E14678.869636 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.624937 Y189.46586 Z3.800724 E14679.393025 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.820906 matz1=3.800724 note=collision lift
G1 X258.62494 Y189.465866 Z3.80072 E14679.393041 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.800724 matz1=3.80072 note=collision lift
G1 X259.445335 Y191.050261 Z3.668663 E14682.973822 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.80072 matz1=3.668663 note=collision lift
G1 X259.449168 Y191.057663 Z3.671874 E14682.991699 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.668663 matz1=3.671874 note=collision lift
G1 X259.824023 Y192.354256 Z3.506429 E14684.918335 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.671874 matz1=3.506429 note=collision lift
G1 X259.947016 Y192.779678 Z3.681532 E14685.593051 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.506429 matz1=3.681532 note=collision lift
G1 X259.954627 Y192.86891 Z3.71832 E14685.681949 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.681532 matz1=3.71832 note=collision lift
G1 X259.986738 Y193.245396 Z3.773894 E14686.032628 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.71832 matz1=3.773894 note=collision lift
G1 X259.987667 Y193.256296 Z3.778387 E14686.043486 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.773894 matz1=3.778387 note=collision lift
G1 X260.098128 Y194.551407 Z3.864631 E14687.239605 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.778387 matz1=3.864631 note=collision lift
G1 X260.098682 Y194.5579 Z3.860792 E14687.24655 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.864631 matz1=3.860792 note=collision lift
G1 X260.099042 Y194.562116 Z3.86096 E14687.250438 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.860792 matz1=3.86096 note=collision lift
G1 X260.09935 Y194.565731 Z3.862451 E14687.25404 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.86096 matz1=3.862451 note=collision lift
G1 X259.991522 Y195.530835 Z3.890365 E14687.769627 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.862451 matz1=3.890365 note=collision lift
G1 X259.991379 Y195.532117 Z3.889631 E14687.770414 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.890365 matz1=3.889631 note=collision lift
G1 X259.977888 Y195.652869 Z3.922104 E14687.837161 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.889631 matz1=3.922104 note=collision lift
G1 X259.977836 Y195.653332 Z3.921839 E14687.837445 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.922104 matz1=3.921839 note=collision lift
G1 X259.936366 Y196.024511 Z3.921839 E14688.035658 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921839 matz1=3.921839 note=collision lift
G1 X259.936251 Y196.025536 Z3.922069 E14688.036219 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921839 matz1=3.922069 note=collision lift
G1 X259.93621 Y196.025905 Z3.921858 E14688.036445 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.922069 matz1=3.921858 note=collision lift
G1 X259.923004 Y196.144106 Z3.92333 E14688.09957 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921858 matz1=3.92333 note=collision lift
G1 X259.923001 Y196.144132 Z3.923315 E14688.099586 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.92333 matz1=3.923315 note=collision lift
G1 X259.900315 Y196.347184 Z3.923315 E14688.208018 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923315 matz1=3.923315 note=collision lift
G1 X259.683524 Y197.029564 Z3.923315 E14688.404158 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923315 matz1=3.923315 note=collision lift
G1 X259.683488 Y197.029675 Z3.923368 E14688.404193 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923315 matz1=3.923368 note=collision lift
G1 X259.648777 Y197.138934 Z3.921914 E14688.435601 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923368 matz1=3.921914 note=collision lift
G1 X259.648338 Y197.140315 Z3.922572 E14688.436037 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921914 matz1=3.922572 note=collision lift
G1 X259.647534 Y197.142848 Z3.921839 E14688.436792 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.922572 matz1=3.921839 note=collision lift
G1 X259.569717 Y197.387786 Z3.921839 E14688.507196 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921839 matz1=3.921839 note=collision lift
G1 X259.569293 Y197.38912 Z3.922474 E14688.507617 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.921839 matz1=3.922474 note=collision lift
G1 X259.545931 Y197.462656 Z3.89067 E14688.530479 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.922474 matz1=3.89067 note=collision lift
G1 X259.545219 Y197.464897 Z3.891737 E14688.531187 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.89067 matz1=3.891737 note=collision lift
G1 X259.41832 Y197.864327 Z3.866318 E14688.646208 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.891737 matz1=3.866318 note=collision lift
G1 X259.41447 Y197.876445 Z3.859377 E14688.650176 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.866318 matz1=3.859377 note=collision lift
G1 X259.388559 Y197.958003 Z3.84771 E14688.673836 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.859377 matz1=3.84771 note=collision lift
G1 X259.38794 Y197.959952 Z3.848639 E14688.674451 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.84771 matz1=3.848639 note=collision lift
G1 X259.35756 Y198.055578 Z3.824547 E14688.702719 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.848639 matz1=3.824547 note=collision lift
G1 X258.597772 Y199.433352 Z3.00603 E14688.98806 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.824547 matz1=3.00603 note=collision lift
G1 X258.491943 Y199.625258 Z3.001597 E14689.023326 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X257.336729 Y200.995905 Z3.013259 E14689.37691 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X257.113968 Y201.173892 Z3.019526 E14689.438739 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.936313 Y202.114843 Z3.072251 E14690.301186 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X254.34451 Y202.939074 Z3.175592 E14692.195707 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.651211 Y203.428621 Z3.315402 E14695.217634 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X253.202644 Y203.529613 Z3.366738 E14696.31492 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.648042 Y204.193549 Z3.630819 E14704.427484 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X257.434996 Y204.883063 Z3.853312 E14712.574288 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X257.683242 Y204.978852 Z3.884961 E14713.355486 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X257.795957 Y205.035067 Z3.899989 E14713.762649 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.391601 Y205.332135 Z4.31221 E14716.275688 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.899989 matz1=4.31221 note=collision lift
G1 X258.554905 Y205.41358 Z4.425219 E14717.331 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.31221 matz1=4.425219 note=collision lift
G1 X259.009872 Y205.705812 Z4.759147 E14721.067118 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.425219 matz1=4.759147 note=collision lift
G1 X259.017271 Y205.710564 Z4.755784 E14721.122465 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.759147 matz1=4.755784 note=collision lift
G1 X259.226143 Y205.844725 Z4.793109 E14722.598244 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.755784 matz1=4.793109 note=collision lift
G1 X259.226482 Y205.844943 Z4.792955 E14722.600778 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.793109 matz1=4.792955 note=collision lift
G1 X259.29344 Y205.887951 Z4.804553 E14723.073549 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.792955 matz1=4.804553 note=collision lift
G1 X259.293472 Y205.887971 Z4.804538 E14723.073792 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.804553 matz1=4.804538 note=collision lift
G1 X259.293797 Y205.88818 Z4.804594 E14723.076086 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.804538 matz1=4.804594 note=collision lift
G1 X259.294627 Y205.888714 Z4.805203 E14723.082905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.804594 matz1=4.805203 note=collision lift
G1 X259.634296 Y206.106887 Z4.861707 E14725.479281 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.805203 matz1=4.861707 note=collision lift
G1 X259.634779 Y206.107197 Z4.861487 E14725.482893 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.861707 matz1=4.861487 note=collision lift
G1 X259.635409 Y206.107602 Z4.86195 E14725.488068 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.861487 matz1=4.86195 note=collision lift
G1 X260.027435 Y206.359405 Z4.923185 E14728.250681 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.86195 matz1=4.923185 note=collision lift
G1 X260.028116 Y206.359975 Z4.922841 E14728.256677 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.923185 matz1=4.922841 note=collision lift
G1 X260.065017 Y206.390855 Z4.928909 E14728.562117 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.922841 matz1=4.928909 note=collision lift
G1 X260.119591 Y206.436524 Z4.972541 E14729.087823 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.928909 matz1=4.972541 note=collision lift
G1 X260.218368 Y206.519184 Z5.013073 E14729.93822 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.972541 matz1=5.013073 note=collision lift
G1 X260.219946 Y206.520504 Z5.012278 E14729.952108 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.013073 matz1=5.012278 note=collision lift
G1 X260.317146 Y206.601843 Z5.038486 E14730.767221 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.012278 matz1=5.038486 note=collision lift
G1 X260.318352 Y206.602853 Z5.037878 E14730.777842 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.038486 matz1=5.037878 note=collision lift
G1 X260.342161 Y206.622777 Z5.043265 E14730.976294 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.037878 matz1=5.043265 note=collision lift
G1 X260.342906 Y206.623401 Z5.043861 E14730.98347 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.043265 matz1=5.043861 note=collision lift
G1 X260.399302 Y206.670595 Z5.057765 E14731.454811 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.043861 matz1=5.057765 note=collision lift
G1 X260.404212 Y206.674703 Z5.06169 E14731.5021 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.057765 matz1=5.06169 note=collision lift
G1 X260.635003 Y206.867836 Z5.098908 E14733.411846 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.06169 matz1=5.098908 note=collision lift
G1 X260.637936 Y206.871077 Z5.097189 E14733.444835 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.098908 matz1=5.097189 note=collision lift
G1 X260.704476 Y206.944622 Z5.104367 E14734.143258 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.097189 matz1=5.104367 note=collision lift
G1 X260.704748 Y206.944922 Z5.104208 E14734.146311 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.104367 matz1=5.104208 note=collision lift
G1 X261.611869 Y207.947532 Z5.104208 E14743.642789 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.104208 matz1=5.104208 note=collision lift
G1 X261.986888 Y208.515923 Z5.104208 E14748.639389 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.104208 matz1=5.104208 note=collision lift
G1 X262.009558 Y208.565222 Z5.104208 E14749.067165 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.104208 matz1=5.104208 note=collision lift
G1 X262.010538 Y208.567354 Z5.10559 E14749.088633 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.104208 matz1=5.10559 note=collision lift
G1 X262.291816 Y209.179049 Z5.06 E14754.4086 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.10559 matz1=5.06 note=collision lift
G1 X262.293452 Y209.182607 Z5.058393 E14754.441968 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.06 matz1=5.058393 note=collision lift
G1 X262.372319 Y209.35412 Z5.043514 E14755.934844 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.058393 matz1=5.043514 note=collision lift
G1 X262.372458 Y209.354422 Z5.043377 E14755.937677 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.043514 matz1=5.043377 note=collision lift
G1 X262.39772 Y209.409358 Z5.037662 E14756.416494 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.043377 matz1=5.037662 note=collision lift
G1 X262.398094 Y209.410172 Z5.03819 E14756.42469 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.037662 matz1=5.03819 note=collision lift
G1 X262.53293 Y209.703401 Z5.004749 E14758.982722 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.03819 matz1=5.004749 note=collision lift
G1 X262.533092 Y209.703968 Z5.004501 E14758.987917 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.004749 matz1=5.004501 note=collision lift
G1 X262.610644 Y209.97501 Z4.968829 E14761.295434 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.004501 matz1=4.968829 note=collision lift
G1 X262.610648 Y209.975022 Z4.968824 E14761.295547 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.968829 matz1=4.968824 note=collision lift
G1 X262.610648 Y209.975025 Z4.968826 E14761.295574 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.968824 matz1=4.968826 note=collision lift
G1 X262.680717 Y210.219912 Z4.932328 E14763.385058 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.968826 matz1=4.932328 note=collision lift
G1 X262.708904 Y210.318428 Z4.889198 E14764.287846 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.932328 matz1=4.889198 note=collision lift
G1 X262.766163 Y210.720474 Z4.713644 E14768.059811 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.889198 matz1=4.713644 note=collision lift
G1 X262.88938 Y211.585643 Z4.772817 E14775.527464 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.861297 Y212.891336 Z4.83934 E14787.083295 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.741657 Y213.667002 Z4.867909 E14794.128311 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.655787 Y214.223724 Z4.882926 E14797.524636 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.507793 Y214.767242 Z4.893272 E14800.938502 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.301599 Y215.52451 Z4.899801 E14808.096175 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.79618 Y216.728743 Z4.890214 E14819.948123 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.115885 Y217.812995 Z4.856296 E14831.364802 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X260.704971 Y218.303275 Z4.830497 E14836.9959 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.884773 Y219.023974 Z4.773436 E14846.320524 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.440915 Y217.488704 Z4.662379 E14859.151171 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.272788 Y215.517483 Z4.485829 E14873.41911 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.437411 Y214.044028 Z4.331245 E14883.049323 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.441632 Y214.00625 Z4.327035 E14883.207493 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.492458 Y213.551338 Z4.505203 E14885.238919 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.327035 matz1=4.505203 note=collision lift
G1 X259.642565 Y213.078854 Z4.696901 E14887.344039 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.505203 matz1=4.696901 note=collision lift
G1 X260.091482 Y211.665828 Z5.264829 E14895.488516 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.696901 matz1=5.264829 note=collision lift
G1 X261.046842 Y209.933411 Z6.018504 E14904.016659 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.264829 matz1=5.311255 note=collision lift
G1 X261.206982 Y209.743406 Z6.114239 E14904.806652 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.311255 matz1=5.282745 note=collision lift
G1 X261.210958 Y209.738689 Z6.119701 E14904.831095 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.282745 matz1=5.282038 note=collision lift
G1 X261.211756 Y209.737743 Z6.119559 E14904.834789 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.282038 matz1=5.281896 note=collision lift
G1 X261.233543 Y209.711892 Z6.144424 E14904.959289 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.281896 matz1=5.278017 note=collision lift
G1 X261.235301 Y209.709807 Z6.146838 E14904.970095 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.278017 matz1=5.277704 note=collision lift
G1 X261.266354 Y209.672962 Z6.178115 E14905.140517 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.277704 matz1=5.272175 note=collision lift
G1 X261.283986 Y209.652043 Z6.202334 E14905.248913 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.272175 matz1=5.269037 note=collision lift
G1 X261.530691 Y209.35933 Z6.41315 E14906.545389 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.269037 matz1=5.225116 note=collision lift
G1 X261.532499 Y209.357185 Z6.412828 E14906.553767 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.225116 matz1=5.224794 note=collision lift
G1 X261.768522 Y209.077146 Z6.59638 E14907.76907 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.224794 matz1=5.182775 note=collision lift
G1 X261.773521 Y209.071216 Z6.604145 E14907.801628 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.182775 matz1=5.181886 note=collision lift
G1 X261.777396 Y209.066618 Z6.612475 E14907.832105 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.181886 matz1=5.181196 note=collision lift
G1 X261.917614 Y208.900251 Z6.60559 E14908.477892 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.181196 matz1=5.156233 note=collision lift
G1 X262.064674 Y208.725767 Z6.59837 E14909.15519 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.156233 matz1=5.130052 note=collision lift
G1 X262.066705 Y208.723356 Z6.599846 E14909.165518 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.130052 matz1=5.129691 note=collision lift
G1 X262.070528 Y208.718821 Z6.60559 E14909.190012 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.129691 matz1=5.12901 note=collision lift
G1 X262.076382 Y208.711875 Z6.609845 E14909.21977 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.12901 matz1=5.127968 note=collision lift
G1 X262.076778 Y208.711405 Z6.610439 E14909.222305 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.127968 matz1=5.127897 note=collision lift
G1 X262.175537 Y208.594228 Z6.60559 E14909.677152 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.127897 matz1=5.110315 note=collision lift
G1 X262.270805 Y208.481194 Z6.593355 E14910.117198 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.110315 matz1=5.093355 note=collision lift
G1 X262.274528 Y208.476777 Z6.591585 E14910.135121 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.093355 matz1=5.092692 note=collision lift
G1 X262.280547 Y208.469636 Z6.581699 E14910.175466 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.092692 matz1=5.091621 note=collision lift
G1 X262.321178 Y208.421427 Z6.546482 E14910.389708 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.091621 matz1=5.084387 note=collision lift
G1 X262.321822 Y208.420664 Z6.546367 E14910.392689 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.084387 matz1=5.084273 note=collision lift
G1 X262.492962 Y208.283922 Z6.424765 E14910.962971 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.084273 matz1=5.061143 note=collision lift
G1 X262.495049 Y208.282254 Z6.424483 E14910.969085 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.061143 matz1=5.060861 note=collision lift
G1 X262.768434 Y208.063819 Z6.220202 E14911.891366 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.060861 matz1=5.023913 note=collision lift
G1 X262.770493 Y208.062174 Z6.217288 E14911.90031 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.023913 matz1=5.023634 note=collision lift
G1 X262.902203 Y207.956936 Z6.110715 E14912.354285 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.023634 matz1=5.005834 note=collision lift
G1 X262.905126 Y207.954601 Z6.11032 E14912.362847 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.005834 matz1=5.005439 note=collision lift
G1 X262.970199 Y207.902608 Z6.049566 E14912.597509 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.005439 matz1=4.996644 note=collision lift
G1 X263.041818 Y207.845384 Z6.028536 E14912.811589 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.996644 matz1=4.986965 note=collision lift
G1 X263.414144 Y207.547894 Z5.739927 E14914.079751 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.986965 matz1=4.936644 note=collision lift
G1 X263.867426 Y207.185719 Z5.39296 E14915.438688 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.936644 matz1=4.879779 note=collision lift
G1 X264.305265 Y206.959007 Z5.104208 E14916.134462 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.879779 matz1=4.837553 note=collision lift
G1 X265.620653 Y206.277903 Z5.104208 E14917.938196 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.837553 matz1=4.710695 note=collision lift
G1 X265.624257 Y206.276037 Z5.10589 E14917.943547 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.710695 matz1=4.710347 note=collision lift
G1 X265.627376 Y206.275135 Z5.107284 E14917.946999 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.710347 matz1=4.710118 note=collision lift
G1 X266.324379 Y206.073626 Z4.693316 E14918.763277 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.710118 matz1=4.658925 note=collision lift
G1 X267.524802 Y205.726574 Z3.995996 E14919.676182 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.658925 matz1=3.995996 note=collision lift
G1 X269.33742 Y205.571975 Z3.021249 E14920.308937 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.995996 matz1=3.021249 note=collision lift
G1 X269.496023 Y205.558447 Z3.015549 E14920.357771 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X271.462168 Y205.778117 Z3.002159 E14920.840427 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X271.711147 Y205.857218 Z3.004771 E14920.907355 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X271.197391 Y205.901036 Z3.016458 E14921.118673 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X270.267882 Y205.980315 Z3.504043 E14921.549962 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.016458 matz1=3.504043 note=collision lift
G1 X270.109687 Y205.96264 Z3.591128 E14921.703369 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.504043 matz1=3.591128 note=collision lift
G1 X268.301738 Y205.760645 Z5.495996 E14923.930373 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.591128 matz1=4.630766 note=collision lift
G1 X268.177248 Y205.721095 Z5.495996 E14924.128505 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.630766 matz1=4.640243 note=collision lift
G1 X268.052758 Y205.681545 Z5.495996 E14924.326637 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.640243 matz1=4.64972 note=collision lift
G1 X267.779454 Y205.594716 Z5.495996 E14924.761615 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.64972 matz1=4.670526 note=collision lift
G1 X267.50615 Y205.507888 Z5.495996 E14925.196593 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.670526 matz1=4.691332 note=collision lift
G1 X266.961189 Y205.334754 Z5.210095 E14926.166303 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.691332 matz1=4.732819 note=collision lift
G1 X266.416227 Y205.16162 Z5.495996 E14927.136013 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.732819 matz1=4.774305 note=collision lift
G1 X266.321773 Y205.109532 Z5.398223 E14927.48287 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.774305 matz1=4.784397 note=collision lift
G1 X266.062725 Y204.966678 Z5.425899 E14928.190766 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.784397 matz1=4.812073 note=collision lift
G1 X265.89036 Y204.871625 Z5.42646 E14928.659736 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.812073 matz1=4.830488 note=collision lift
G1 X265.888499 Y204.870599 Z5.424533 E14928.666572 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.830488 matz1=4.830687 note=collision lift
G1 X265.733215 Y204.784966 Z5.398694 E14929.093529 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.830687 matz1=4.847277 note=collision lift
G1 X265.717996 Y204.776573 Z5.400319 E14929.135118 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.847277 matz1=4.848903 note=collision lift
G1 X265.373268 Y204.586469 Z5.296046 E14930.105399 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.848903 matz1=4.885733 note=collision lift
G1 X265.371029 Y204.585235 Z5.293729 E14930.11362 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.885733 matz1=4.885972 note=collision lift
G1 X265.028539 Y204.396365 Z5.153087 E14931.103881 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.885972 matz1=4.922563 note=collision lift
G1 X265.027489 Y204.395786 Z5.152 E14931.107738 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.922563 matz1=4.922675 note=collision lift
G1 X264.8232 Y204.283129 Z5.052595 E14931.71192 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.922675 matz1=4.944501 note=collision lift
G1 X264.683811 Y204.206261 Z5.06436 E14932.092205 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.944501 matz1=4.959393 note=collision lift
G1 X264.679992 Y204.203042 Z5.062397 E14932.10865 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.959393 matz1=4.959927 note=collision lift
G1 X264.490017 Y204.042926 Z5.054307 E14932.870493 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.959927 matz1=4.986511 note=collision lift
G1 X264.48613 Y204.039651 Z5.057392 E14932.888716 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.986511 matz1=4.987055 note=collision lift
G1 X264.063817 Y203.683715 Z5.014039 E14934.586592 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.987055 matz1=5.014039 note=collision lift
G1 X264.063792 Y203.683695 Z5.014059 E14934.586706 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.014039 matz1=5.014059 note=collision lift
G1 X263.643111 Y203.329134 Z4.937811 E14936.288951 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.014059 matz1=4.937811 note=collision lift
G1 X263.641455 Y203.327738 Z4.939125 E14936.296715 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.937811 matz1=4.939125 note=collision lift
G1 X263.171063 Y202.931281 Z4.811494 E14937.716347 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.939125 matz1=4.811494 note=collision lift
G1 X263.127926 Y202.877292 Z4.785052 E14937.937103 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.811494 matz1=4.785052 note=collision lift
G1 X262.98714 Y202.701091 Z4.714873 E14938.64183 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.785052 matz1=4.714873 note=collision lift
G1 X262.984676 Y202.698006 Z4.71731 E14938.655675 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.714873 matz1=4.71731 note=collision lift
G1 X261.936119 Y201.385677 Z4.07456 E14944.021737 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.71731 matz1=4.07456 note=collision lift
G1 X261.811906 Y201.145788 Z3.971557 E14945.096015 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.07456 matz1=3.971557 note=collision lift
G1 X261.368425 Y200.289314 Z4.053387 E14948.692711 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.971557 matz1=4.053387 note=collision lift
G1 X261.026436 Y199.628845 Z4.141673 E14951.475768 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X260.476974 Y197.7283 Z4.364727 E14960.258309 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X260.308847 Y195.757079 Z4.56228 E14970.253696 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X260.528517 Y193.790935 Z4.722184 E14981.221696 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.127542 Y191.905424 Z4.834607 E14992.866321 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.082901 Y190.173008 Z4.892636 E15004.855317 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.275234 Y189.944807 Z4.8964 E15006.666749 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X263.357881 Y188.66026 Z4.892703 E15021.931396 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X264.437735 Y187.797453 Z4.852251 E15034.121699 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X264.903485 Y187.425316 Z5.132885 E15039.93041 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.852251 matz1=5.132885 note=collision lift
G1 X265.178641 Y187.282841 Z5.170706 E15042.518277 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.132885 matz1=5.170706 note=collision lift
G1 X265.181271 Y187.281479 Z5.172019 E15042.545128 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.170706 matz1=5.172019 note=collision lift
G1 X265.886247 Y186.916445 Z5.262215 E15049.16899 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.172019 matz1=5.262215 note=collision lift
G1 X265.887987 Y186.915544 Z5.261125 E15049.187578 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.262215 matz1=5.261125 note=collision lift
G1 X266.660317 Y186.515633 Z5.261125 E15056.397897 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.261125 matz1=5.261125 note=collision lift
G1 X267.132968 Y186.378986 Z4.975379 E15060.689548 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.261125 matz1=4.975379 note=collision lift
G1 X268.560861 Y185.966171 Z5.5985 E15072.846435 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.975379 matz1=5.5985 note=collision lift
G1 X268.905965 Y185.936737 Z5.63996 E15075.155421 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.5985 matz1=5.63996 note=collision lift
G1 X268.907613 Y185.936596 Z5.640622 E15075.167214 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.63996 matz1=5.640622 note=collision lift
G1 X269.530755 Y185.883448 Z5.711098 E15079.333112 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.640622 matz1=5.711098 note=collision lift
G1 X269.531642 Y185.883372 Z5.710564 E15079.339989 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.711098 matz1=5.710564 note=collision lift
G1 X269.694867 Y185.869451 Z5.728131 E15080.430553 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.710564 matz1=5.728131 note=collision lift
G1 X269.694945 Y185.869444 Z5.728085 E15080.431154 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.728131 matz1=5.728085 note=collision lift
G1 X270.532083 Y185.798044 Z5.728085 E15085.992491 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.728085 matz1=5.728085 note=collision lift
G1 X270.639587 Y185.810055 Z5.662203 E15086.796479 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.728085 matz1=5.662203 note=collision lift
G1 X271.061073 Y185.857146 Z5.828013 E15089.687059 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.662203 matz1=5.807173 note=collision lift
G1 X271.471629 Y185.903016 Z5.832874 E15091.222884 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.807173 matz1=5.760045 note=collision lift
G1 X271.473842 Y185.903263 Z5.831507 E15091.232597 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.760045 matz1=5.759791 note=collision lift
G1 X271.679933 Y185.926289 Z5.824453 E15092.003941 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.759791 matz1=5.736134 note=collision lift
G1 X271.681456 Y185.926459 Z5.823512 E15092.010625 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.736134 matz1=5.735959 note=collision lift
G1 X271.784084 Y185.937925 Z5.813944 E15092.396161 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.735959 matz1=5.724178 note=collision lift
G1 X271.78525 Y185.938056 Z5.813223 E15092.401277 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.724178 matz1=5.724044 note=collision lift
G1 X271.83616 Y185.943744 Z5.804435 E15092.594493 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.724044 matz1=5.7182 note=collision lift
G1 X271.837209 Y185.943861 Z5.803787 E15092.599097 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.7182 matz1=5.71808 note=collision lift
G1 X271.860802 Y185.946497 Z5.797128 E15092.690755 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.71808 matz1=5.715372 note=collision lift
G1 X271.862198 Y185.946653 Z5.79767 E15092.696352 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.715372 matz1=5.715211 note=collision lift
G1 X271.888236 Y185.949562 Z5.783289 E15092.807457 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.715211 matz1=5.712222 note=collision lift
G1 X272.498227 Y186.017714 Z5.406374 E15095.485048 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.712222 matz1=5.406374 note=collision lift
G1 X274.383737 Y186.616739 Z4.182356 E15102.429897 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.406374 matz1=4.182356 note=collision lift
G1 X274.865331 Y186.882318 Z3.84282 E15103.891364 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.182356 matz1=3.84282 note=collision lift
G1 X276.116154 Y187.572098 Z3.675163 E15107.143399 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X277.628902 Y188.847078 Z3.459855 E15110.30719 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X278.863846 Y190.392682 Z3.274685 E15112.318876 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X279.773528 Y192.149514 Z3.131039 E15113.438621 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X279.939417 Y192.72331 Z3.102875 E15113.602235 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X280.322991 Y194.050058 Z3.728293 E15114.01707 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.102875 matz1=3.728293 note=collision lift
G1 X280.356044 Y194.437588 Z3.915449 E15114.085112 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.728293 matz1=3.915449 note=collision lift
G1 X280.370544 Y194.607601 Z3.927307 E15114.112076 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.915449 matz1=3.927307 note=collision lift
G1 X280.370695 Y194.60937 Z3.926386 E15114.112391 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.927307 matz1=3.926386 note=collision lift
G1 X280.384972 Y194.776766 Z3.930825 E15114.138885 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.926386 matz1=3.930825 note=collision lift
G1 X280.385045 Y194.777615 Z3.931235 E15114.139034 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.930825 matz1=3.931235 note=collision lift
G1 X280.413936 Y195.11635 Z3.934132 E15114.19263 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.931235 matz1=3.934132 note=collision lift
G1 X280.414046 Y195.117642 Z3.934756 E15114.192857 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.934132 matz1=3.934756 note=collision lift
G1 X280.472048 Y195.797696 Z3.931347 E15114.300454 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.934756 matz1=3.931347 note=collision lift
G1 X280.472181 Y195.799255 Z3.930535 E15114.300731 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.931347 matz1=3.930535 note=collision lift
G1 X280.49086 Y196.018259 Z3.928114 E15114.335384 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.930535 matz1=3.928114 note=collision lift
G1 X280.491118 Y196.02128 Z3.929573 E15114.335914 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.928114 matz1=3.929573 note=collision lift
G1 X280.378212 Y197.03184 Z3.91938 E15114.5634 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.929573 matz1=3.91938 note=collision lift
G1 X280.378124 Y197.032628 Z3.918992 E15114.563598 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.91938 matz1=3.918992 note=collision lift
G1 X280.271748 Y197.984735 Z3.901037 E15114.777953 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.918992 matz1=3.901037 note=collision lift
G1 X280.271448 Y197.987424 Z3.902418 E15114.778632 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.901037 matz1=3.902418 note=collision lift
G1 X279.858629 Y199.286829 Z3.870588 E15115.416531 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.902418 matz1=3.870588 note=collision lift
G1 X279.857278 Y199.291081 Z3.868534 E15115.418829 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.870588 matz1=3.868534 note=collision lift
G1 X279.67464 Y199.865956 Z3.834762 E15115.70141 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.868534 matz1=3.834762 note=collision lift
G1 X279.672423 Y199.872934 Z3.838713 E15115.705301 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.834762 matz1=3.838713 note=collision lift
G1 X279.086037 Y200.936268 Z3.753856 E15116.770108 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.838713 matz1=3.753856 note=collision lift
G1 X279.07507 Y200.956154 Z3.743999 E15116.791763 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.753856 matz1=3.743999 note=collision lift
G1 X279.043551 Y201.01331 Z3.736695 E15116.849216 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.743999 matz1=3.736695 note=collision lift
G1 X279.041329 Y201.017339 Z3.739299 E15116.85384 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.736695 matz1=3.739299 note=collision lift
G1 X278.717064 Y201.605351 Z3.651065 E15117.446283 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.739299 matz1=3.651065 note=collision lift
G1 X278.713449 Y201.60964 Z3.648756 E15117.454895 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.651065 matz1=3.648756 note=collision lift
G1 X278.516284 Y201.843574 Z3.585501 E15117.898428 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.648756 matz1=3.585501 note=collision lift
G1 X278.495453 Y201.86829 Z3.572195 E15117.948054 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.585501 matz1=3.572195 note=collision lift
G1 X278.40211 Y201.97904 Z3.536105 E15118.159971 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.572195 matz1=3.536105 note=collision lift
G1 X278.394965 Y201.987518 Z3.531541 E15118.176992 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.536105 matz1=3.531541 note=collision lift
G1 X278.345023 Y202.046773 Z3.505928 E15118.292866 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.531541 matz1=3.505928 note=collision lift
G1 X278.055799 Y202.389933 Z3.321181 E15118.981886 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.505928 matz1=3.321181 note=collision lift
G1 X277.442084 Y203.118099 Z3.405307 E15120.339138 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X275.89648 Y204.353043 Z3.613569 E15124.455215 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X274.139648 Y205.262725 Z3.842518 E15129.997772 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X273.051671 Y205.577268 Z3.977486 E15133.651905 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X272.239103 Y205.812188 Z4.078076 E15138.146234 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X271.711147 Y205.857218 Z4.140424 E15141.116847 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X273.017734 Y206.272319 Z4.297156 E15149.811309 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X273.347678 Y206.377142 Z4.335286 E15151.315745 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X275.080095 Y207.332501 Z4.537107 E15161.157192 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X276.592842 Y208.607481 Z4.702828 E15172.008002 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X277.827787 Y210.153086 Z4.822258 E15183.578715 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X278.737469 Y211.909917 Z4.888053 E15195.540892 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X279.286932 Y213.810462 Z4.896168 E15207.54662 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X279.455059 Y215.781683 Z4.846103 E15219.247151 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X279.235389 Y217.747828 Z4.740938 E15230.310786 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X278.636364 Y219.633338 Z4.587138 E15240.440528 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X277.681005 Y221.365755 Z4.394162 E15249.391633 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X276.406024 Y222.878502 Z4.173874 E15256.988191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X274.86042 Y224.113446 Z3.93982 E15263.136827 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X273.103589 Y225.023129 Z3.706392 E15267.835265 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X271.203044 Y225.572591 Z3.487943 E15271.173926 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X269.231823 Y225.740718 Z3.297906 E15273.329987 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X268.887769 Y225.702278 Z3.268478 E15273.675018 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X267.265678 Y225.521048 Z3.147966 E15275.190415 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X265.380168 Y224.922024 Z3.047342 E15276.092315 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X265.027591 Y224.727591 Z3.036586 E15276.202794 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X264.111748 Y224.22254 Z3.53158 E15276.520174 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.036586 matz1=3.53158 note=collision lift
G1 X264.371375 Y224.251547 Z3.658511 E15276.594829 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.53158 matz1=3.658511 note=collision lift
G1 X266.256885 Y224.850572 Z4.652913 E15277.217947 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.658511 matz1=4.510167 note=collision lift
G1 X267.277694 Y225.413507 Z4.741486 E15277.891453 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510167 matz1=4.547291 note=collision lift
G1 X267.280114 Y225.414842 Z4.740192 E15277.893212 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.547291 matz1=4.547379 note=collision lift
G1 X267.525305 Y225.550056 Z4.759635 E15278.054907 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.547379 matz1=4.556296 note=collision lift
G1 X267.525416 Y225.550117 Z4.759575 E15278.054987 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.556296 matz1=4.5563 note=collision lift
G1 X267.640577 Y225.613623 Z4.768471 E15278.130923 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.5563 matz1=4.560488 note=collision lift
G1 X267.640904 Y225.613804 Z4.76867 E15278.131166 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.560488 matz1=4.5605 note=collision lift
G1 X267.982804 Y225.802348 Z4.798053 E15278.356732 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.5605 matz1=4.572933 note=collision lift
G1 X267.989302 Y225.805931 Z4.802 E15278.361574 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.572933 matz1=4.57317 note=collision lift
G1 X268.636069 Y226.351042 Z4.847311 E15279.022835 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.57317 matz1=4.616906 note=collision lift
G1 X268.642464 Y226.356432 Z4.84367 E15279.029663 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.616906 matz1=4.617447 note=collision lift
G1 X268.681461 Y226.3893 Z4.845322 E15279.067864 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.617447 matz1=4.620742 note=collision lift
G1 X268.683637 Y226.391134 Z4.846928 E15279.07031 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.620742 matz1=4.620926 note=collision lift
G1 X269.005685 Y226.662563 Z4.853998 E15279.385658 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.620926 matz1=4.648142 note=collision lift
G1 X269.008845 Y226.665227 Z4.856331 E15279.389211 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.648142 matz1=4.648409 note=collision lift
G1 X269.334053 Y226.93932 Z4.840119 E15279.70784 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.648409 matz1=4.675891 note=collision lift
G1 X269.502049 Y227.080912 Z4.744463 E15279.887232 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.675891 matz1=4.690088 note=collision lift
G1 X270.736994 Y228.626516 Z3.918918 E15282.58594 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.690088 matz1=3.918918 note=collision lift
G1 X270.922142 Y228.984085 Z3.758357 E15283.402417 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.918918 matz1=3.758357 note=collision lift
G1 X271.099691 Y229.326978 Z3.990519 E15284.251028 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.758357 matz1=3.990519 note=collision lift
G1 X271.100737 Y229.328997 Z3.989612 E15284.255639 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.990519 matz1=3.989612 note=collision lift
G1 X271.190855 Y229.503039 Z4.075556 E15284.658715 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.989612 matz1=4.075556 note=collision lift
G1 X271.191318 Y229.503933 Z4.075155 E15284.660757 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.075556 matz1=4.075155 note=collision lift
G1 X271.274747 Y229.665056 Z4.134919 E15285.02056 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.075155 matz1=4.134919 note=collision lift
G1 X271.282019 Y229.679101 Z4.144428 E15285.055319 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.134919 matz1=4.144428 note=collision lift
G1 X271.464348 Y230.031224 Z4.23191 E15285.820133 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.144428 matz1=4.23191 note=collision lift
G1 X271.465326 Y230.033112 Z4.231062 E15285.824445 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.23191 matz1=4.231062 note=collision lift
G1 X271.646676 Y230.383347 Z4.278633 E15286.572678 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.231062 matz1=4.278633 note=collision lift
G1 X271.64844 Y230.389448 Z4.276178 E15286.590271 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.278633 matz1=4.276178 note=collision lift
G1 X271.689331 Y230.530887 Z4.297568 E15286.974711 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.276178 matz1=4.297568 note=collision lift
G1 X271.693683 Y230.545939 Z4.307182 E15287.022211 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.297568 matz1=4.307182 note=collision lift
G1 X271.906218 Y231.281079 Z4.333765 E15289.000794 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.307182 matz1=4.333765 note=collision lift
G1 X271.906808 Y231.283121 Z4.332943 E15289.006685 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.333765 matz1=4.332943 note=collision lift
G1 X272.118752 Y232.016218 Z4.305552 E15290.97985 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.332943 matz1=4.305552 note=collision lift
G1 X272.124172 Y232.034966 Z4.29801 E15291.033914 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.305552 matz1=4.29801 note=collision lift
G1 X272.195565 Y232.281907 Z4.257463 E15291.706352 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.29801 matz1=4.257463 note=collision lift
G1 X272.196139 Y232.283892 Z4.258731 E15291.712616 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.257463 matz1=4.258731 note=collision lift
G1 X272.226286 Y232.637352 Z4.207671 E15292.901552 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.258731 matz1=4.207671 note=collision lift
G1 X272.226404 Y232.638737 Z4.208531 E15292.906972 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.207671 matz1=4.208531 note=collision lift
G1 X272.256669 Y232.993581 Z4.121542 E15294.123121 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.208531 matz1=4.121542 note=collision lift
G1 X272.269545 Y233.144547 Z4.063797 E15294.661012 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.121542 matz1=4.063797 note=collision lift
G1 X272.27174 Y233.170292 Z4.054616 E15294.751977 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.063797 matz1=4.054616 note=collision lift
G1 X272.271801 Y233.171004 Z4.055058 E15294.754764 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.054616 matz1=4.055058 note=collision lift
G1 X272.296682 Y233.462727 Z3.943473 E15295.794172 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.055058 matz1=3.943473 note=collision lift
G1 X272.302066 Y233.525849 Z3.926878 E15296.01142 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943473 matz1=3.926878 note=collision lift
G1 X272.364266 Y234.255113 Z4.013887 E15298.456523 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X272.144596 Y236.221258 Z4.245148 E15306.500506 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X271.545571 Y238.106768 Z4.458261 E15315.858574 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X270.590212 Y239.839185 Z4.640121 E15326.32864 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X269.315232 Y241.351932 Z4.779545 E15337.642833 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X267.769627 Y242.586876 Z4.867962 E15349.486271 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X266.012796 Y243.496559 Z4.899933 E15361.516698 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X264.112251 Y244.046021 Z4.873494 E15373.383514 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.14103 Y244.214148 Z4.79027 E15384.745912 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X260.174885 Y243.994478 Z4.655378 E15395.290566 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.796671 Y243.556621 Z4.52876 E15402.436631 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.289375 Y243.395454 Z4.477112 E15406.256372 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.556959 Y242.440094 Z4.266435 E15418.506594 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.044211 Y241.165114 Z4.036301 E15428.626222 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X253.809267 Y239.61951 Z3.80086 E15436.555024 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.899584 Y237.862678 Z3.574589 E15442.372201 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.457904 Y236.334943 Z3.409372 E15445.737842 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.433009 Y236.248835 Z3.444878 E15445.940789 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.409372 matz1=3.444878 note=collision lift
G1 X252.359351 Y235.994056 Z3.552017 E15446.316638 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.444878 matz1=3.552017 note=collision lift
G1 X252.350122 Y235.962134 Z3.553114 E15446.360324 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.552017 matz1=3.553114 note=collision lift
G1 X252.34548 Y235.907708 Z3.552735 E15446.403552 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.553114 matz1=3.552735 note=collision lift
G1 X252.313873 Y235.537132 Z3.335265 E15446.744499 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.552735 matz1=3.335265 note=collision lift
G1 X252.222024 Y234.460239 Z3.243699 E15447.602869 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.181995 Y233.990913 Z3.274812 E15447.976437 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.243699 matz1=3.274812 note=collision lift
G1 X252.182282 Y233.988343 Z3.27336 E15447.977658 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.274812 matz1=3.27336 note=collision lift
G1 X252.208324 Y233.755256 Z3.306528 E15448.075202 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.27336 matz1=3.306528 note=collision lift
G1 X252.20836 Y233.754933 Z3.306346 E15448.075356 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.306528 matz1=3.306346 note=collision lift
G1 X252.219737 Y233.6531 Z3.319673 E15448.117908 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.306346 matz1=3.319673 note=collision lift
G1 X252.221327 Y233.638871 Z3.325951 E15448.124346 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.319673 matz1=3.325951 note=collision lift
G1 X252.311496 Y232.831819 Z3.420242 E15448.461009 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.325951 matz1=3.420242 note=collision lift
G1 X252.311641 Y232.830518 Z3.419507 E15448.461627 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.420242 matz1=3.419507 note=collision lift
G1 X252.401665 Y232.024768 Z3.488252 E15448.796702 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.419507 matz1=3.488252 note=collision lift
G1 X252.402515 Y232.022093 Z3.486751 E15448.797334 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.488252 matz1=3.486751 note=collision lift
G1 X252.570441 Y231.493522 Z3.531304 E15448.907867 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.486751 matz1=3.531304 note=collision lift
G1 X252.574569 Y231.480527 Z3.53765 E15448.910854 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.531304 matz1=3.53765 note=collision lift
G1 X252.856419 Y230.593367 Z3.581126 E15449.095979 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.53765 matz1=3.581126 note=collision lift
G1 X253.000689 Y230.139258 Z3.802901 E15449.200387 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.581126 matz1=3.802901 note=collision lift
G1 X253.054845 Y230.041054 Z3.858363 E15449.221034 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.802901 matz1=3.858363 note=collision lift
G1 X253.373122 Y229.463901 Z3.874667 E15449.329838 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.858363 matz1=3.874667 note=collision lift
G1 X253.374841 Y229.460783 Z3.872867 E15449.330497 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.874667 matz1=3.872867 note=collision lift
G1 X253.691399 Y228.886749 Z3.872036 E15449.43868 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.872867 matz1=3.872036 note=collision lift
G1 X253.691924 Y228.885796 Z3.871486 E15449.438881 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.872036 matz1=3.871486 note=collision lift
G1 X253.956049 Y228.406841 Z3.865298 E15449.529152 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.871486 matz1=3.865298 note=collision lift
G1 X253.95633 Y228.406507 Z3.86509 E15449.529303 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.865298 matz1=3.86509 note=collision lift
G1 X254.329125 Y227.964191 Z3.850804 E15449.71041 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.86509 matz1=3.850804 note=collision lift
G1 X254.329486 Y227.963762 Z3.850537 E15449.710604 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.850804 matz1=3.850537 note=collision lift
G1 X254.414472 Y227.862928 Z3.844424 E15449.751922 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.850537 matz1=3.844424 note=collision lift
G1 X254.415544 Y227.861656 Z3.845296 E15449.75251 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.844424 matz1=3.845296 note=collision lift
G1 X255.231029 Y226.894094 Z3.782236 E15450.14905 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.845296 matz1=3.782236 note=collision lift
G1 X255.232655 Y226.892795 Z3.781304 E15450.150494 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.782236 matz1=3.781304 note=collision lift
G1 X255.837472 Y226.409543 Z3.73462 E15450.641766 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.781304 matz1=3.73462 note=collision lift
G1 X255.837624 Y226.409422 Z3.734533 E15450.641901 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.73462 matz1=3.734533 note=collision lift
G1 X256.527534 Y225.85818 Z3.658635 E15451.203337 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.734533 matz1=3.658635 note=collision lift
G1 X256.770547 Y225.664012 Z3.668233 E15451.400464 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.658635 matz1=3.668233 note=collision lift
G1 X256.776633 Y225.659149 Z3.672533 E15451.4061 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.668233 matz1=3.672533 note=collision lift
G1 X257.902032 Y225.076421 Z3.691292 E15452.808739 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.672533 matz1=3.691292 note=collision lift
G1 X257.90892 Y225.072854 Z3.688008 E15452.818061 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.691292 matz1=3.688008 note=collision lift
G1 X258.533465 Y224.749467 Z3.682678 E15453.596397 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.688008 matz1=3.682678 note=collision lift
G1 X258.534027 Y224.749304 Z3.682438 E15453.597207 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.682678 matz1=3.682438 note=collision lift
G1 X259.124443 Y224.57861 Z3.674517 E15454.384325 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.682438 matz1=3.674517 note=collision lift
G1 X259.124518 Y224.578589 Z3.674486 E15454.384541 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.674517 matz1=3.674486 note=collision lift
G1 X259.618783 Y224.435693 Z3.657681 E15455.699988 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.674486 matz1=3.657681 note=collision lift
G1 X259.621303 Y224.434964 Z3.659253 E15455.707803 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.657681 matz1=3.659253 note=collision lift
G1 X260.118163 Y224.291318 Z3.622773 E15457.032735 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.659253 matz1=3.622773 note=collision lift
G1 X260.137677 Y224.285676 Z3.614638 E15457.088648 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.622773 matz1=3.614638 note=collision lift
G1 X260.212398 Y224.264074 Z3.60502 E15457.288921 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.614638 matz1=3.60502 note=collision lift
G1 X260.215097 Y224.263293 Z3.603895 E15457.296655 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.60502 matz1=3.603895 note=collision lift
G1 X260.218156 Y224.262409 Z3.603714 E15457.304803 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.603895 matz1=3.603714 note=collision lift
G1 X260.220563 Y224.261713 Z3.605216 E15457.312268 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.603714 matz1=3.605216 note=collision lift
G1 X260.423134 Y224.203148 Z3.587459 E15457.853015 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.605216 matz1=3.587459 note=collision lift
G1 X260.434009 Y224.200004 Z3.582925 E15457.884177 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.587459 matz1=3.582925 note=collision lift
G1 X260.606551 Y224.185288 Z3.515539 E15458.549623 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.582925 matz1=3.515539 note=collision lift
G1 X261.398916 Y224.117707 Z3.603701 E15461.414984 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X261.829943 Y224.080944 Z3.867955 E15463.230351 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.603701 matz1=3.867955 note=collision lift
G1 X262.40523 Y224.031877 Z4.50934 E15466.320854 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.867955 matz1=4.50934 note=collision lift
G1 X262.869477 Y224.083746 Z5.03158 E15469.493929 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50934 matz1=5.03158 note=collision lift
G1 X262.878427 Y224.084746 Z5.027317 E15469.539045 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.03158 matz1=5.027317 note=collision lift
G1 X263.129104 Y224.112753 Z5.160165 E15470.830065 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.027317 matz1=5.160165 note=collision lift
G1 X263.16009 Y224.116215 Z5.145407 E15470.986275 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.160165 matz1=5.145407 note=collision lift
G1 X263.648282 Y224.170759 Z5.158511 E15473.211639 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.145407 matz1=5.158511 note=collision lift
G1 X264.111748 Y224.22254 Z5.170951 E15475.324292 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.158511 matz1=5.170951 note=collision lift
G1 X264.111562 Y224.222438 Z5.170658 E15475.326036 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.170951 matz1=5.170658 note=collision lift
G1 X264.110193 Y224.221682 Z5.170063 E15475.33411 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.170658 matz1=5.170063 note=collision lift
G1 X264.089961 Y224.210526 Z5.146342 E15475.493861 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.170063 matz1=5.146342 note=collision lift
G1 X263.647751 Y223.966664 Z4.880354 E15478.24743 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.146342 matz1=4.880354 note=collision lift
G1 X263.108724 Y223.512359 Z4.258958 E15483.431928 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.880354 matz1=4.258958 note=collision lift
G1 X262.812129 Y223.262382 Z4.110985 E15485.722361 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.258958 matz1=4.110985 note=collision lift
G1 X262.692269 Y223.161361 Z4.129563 E15486.593231 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.44458 Y222.952603 Z4.167149 E15488.521333 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X262.135004 Y222.691684 Z4.416559 E15491.332898 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.167149 matz1=4.416559 note=collision lift
G1 X260.90006 Y221.14608 Z5.622166 E15507.376156 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.416559 matz1=5.622166 note=collision lift
G1 X260.633276 Y220.630851 Z5.970687 E15512.24803 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.622166 matz1=5.970687 note=collision lift
G1 X260.392653 Y220.166147 Z6.280416 E15516.990475 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.970687 matz1=6.03704 note=collision lift
G1 X260.191515 Y219.777698 Z6.314014 E15520.412005 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.03704 matz1=6.077227 note=collision lift
G1 X260.189914 Y219.774606 Z6.312593 E15520.441329 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.077227 matz1=6.077546 note=collision lift
G1 X259.990377 Y219.389248 Z6.328994 E15523.828078 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.077546 matz1=6.117413 note=collision lift
G1 X259.989651 Y219.386736 Z6.327903 E15523.850599 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.117413 matz1=6.11763 note=collision lift
G1 X259.968504 Y219.313591 Z6.330512 E15524.455986 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.11763 matz1=6.123944 note=collision lift
G1 X259.968391 Y219.313201 Z6.330749 E15524.459721 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.123944 matz1=6.123977 note=collision lift
G1 X259.884773 Y219.023974 Z6.337194 E15526.852676 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.123977 matz1=6.148943 note=collision lift
G1 X259.884276 Y219.024411 Z6.336916 E15526.85844 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.148943 matz1=6.148995 note=collision lift
G1 X259.765969 Y219.128366 Z6.330499 E15528.123582 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.148995 matz1=6.16154 note=collision lift
G1 X259.765964 Y219.128371 Z6.330496 E15528.123638 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.16154 matz1=6.161541 note=collision lift
G1 X259.723212 Y219.165936 Z6.327522 E15528.581059 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.161541 matz1=6.166074 note=collision lift
G1 X259.723146 Y219.165995 Z6.327573 E15528.581878 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.166074 matz1=6.166081 note=collision lift
G1 X259.149371 Y219.532707 Z6.292175 E15534.216706 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.166081 matz1=6.216816 note=collision lift
G1 X259.149363 Y219.532712 Z6.29218 E15534.216799 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.216816 matz1=6.216817 note=collision lift
G1 X258.819825 Y219.678485 Z6.273499 E15537.349165 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.216817 matz1=6.238902 note=collision lift
G1 X257.8178 Y220.121736 Z5.792809 E15547.736074 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.238902 matz1=5.792809 note=collision lift
G1 X257.055961 Y220.339091 Z5.433391 E15555.437621 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.792809 matz1=5.433391 note=collision lift
G1 X255.888323 Y220.518039 Z4.876066 E15567.302163 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.433391 matz1=4.876066 note=collision lift
G1 X255.326036 Y220.604213 Z4.892107 E15572.471458 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.143723 Y220.612195 Z4.894662 E15574.13145 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X254.352913 Y220.64682 Z4.899979 E15578.944536 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X254.087168 Y220.633356 Z4.899658 E15580.562153 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.174253 Y220.536439 Z4.866203 E15597.731211 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.670224 Y220.148341 Z4.741521 E15618.989455 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X246.819552 Y219.457558 Z4.499072 E15640.313743 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X246.789683 Y219.454537 Z4.496143 E15640.53188 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.635751 Y219.236694 Z4.267184 E15653.943773 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.200167 Y219.154805 Z4.216843 E15656.586833 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.843834 Y219.087814 Z4.174349 E15658.423245 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.595907 Y218.853206 Z4.660425 E15665.262904 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.174349 matz1=4.660425 note=collision lift
G1 X241.853435 Y218.658637 Z4.952647 E15669.042711 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.660425 matz1=4.952647 note=collision lift
G1 X242.256951 Y218.541978 Z5.112576 E15671.005938 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.952647 matz1=5.112576 note=collision lift
G1 X244.043004 Y218.389644 Z5.79884 E15677.504611 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.112576 matz1=5.173885 note=collision lift
G1 X244.384439 Y218.427791 Z5.835477 E15678.611435 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.173885 matz1=5.134911 note=collision lift
G1 X244.71383 Y218.464593 Z5.870819 E15679.434326 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.134911 matz1=5.09898 note=collision lift
G1 X244.713839 Y218.464594 Z5.870823 E15679.434351 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.09898 matz1=5.098979 note=collision lift
G1 X245.824457 Y218.588679 Z5.989973 E15682.208916 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.098979 matz1=4.977832 note=collision lift
G1 X245.873442 Y218.604241 Z5.996145 E15682.310927 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.977832 matz1=4.972729 note=collision lift
G1 X245.873444 Y218.604242 Z5.996144 E15682.310933 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.972729 matz1=4.972728 note=collision lift
G1 X245.898508 Y218.612205 Z5.99905 E15682.36307 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.972728 matz1=4.970117 note=collision lift
G1 X245.898695 Y218.612264 Z5.999129 E15682.363487 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.970117 matz1=4.970098 note=collision lift
G1 X246.846934 Y218.913519 Z6.084109 E15684.331243 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.970098 matz1=4.871316 note=collision lift
G1 X246.847012 Y218.913543 Z6.084061 E15684.331401 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.871316 matz1=4.871309 note=collision lift
G1 X246.943861 Y218.944312 Z6.092716 E15684.501044 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.871309 matz1=4.862035 note=collision lift
G1 X246.943919 Y218.944331 Z6.092741 E15684.501153 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.862035 matz1=4.862029 note=collision lift
G1 X247.530444 Y219.130669 Z6.145059 E15685.528513 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.862029 matz1=4.805866 note=collision lift
G1 X247.53285 Y219.131434 Z6.146091 E15685.53305 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.805866 matz1=4.805635 note=collision lift
G1 X248.514275 Y219.672651 Z6.218328 E15686.667663 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.805635 matz1=4.718328 note=collision lift
G1 X248.514984 Y219.673042 Z6.218265 E15686.668484 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.718328 matz1=4.718265 note=collision lift
G1 X249.102274 Y219.996909 Z6.16602 E15687.348089 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.718265 matz1=4.66602 note=collision lift
G1 X249.102531 Y219.997051 Z6.165997 E15687.348387 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.66602 matz1=4.665997 note=collision lift
G1 X249.508999 Y220.339632 Z6.136334 E15687.637176 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.665997 matz1=4.636334 note=collision lift
G1 X249.50945 Y220.340012 Z6.136301 E15687.637496 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.636334 matz1=4.636301 note=collision lift
G1 X249.621482 Y220.434435 Z6.128125 E15687.717093 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.636301 matz1=4.628125 note=collision lift
G1 X249.625374 Y220.437716 Z6.127841 E15687.719858 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.628125 matz1=4.627841 note=collision lift
G1 X250.473177 Y221.152265 Z6.065971 E15688.322208 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.627841 matz1=4.565971 note=collision lift
G1 X250.475786 Y221.155529 Z6.065842 E15688.323393 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.565971 matz1=4.565842 note=collision lift
G1 X250.64893 Y221.37223 Z6.057276 E15688.402065 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.565842 matz1=4.557276 note=collision lift
G1 X250.649466 Y221.372901 Z6.057249 E15688.402309 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.557276 matz1=4.557249 note=collision lift
G1 X250.735579 Y221.480675 Z6.052989 E15688.441436 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.557249 matz1=4.552989 note=collision lift
G1 X250.736807 Y221.482212 Z6.052928 E15688.441994 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.552989 matz1=4.552928 note=collision lift
G1 X250.824683 Y221.592194 Z6.04858 E15688.481923 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.552928 matz1=4.54858 note=collision lift
G1 X251.592116 Y222.552681 Z5.664426 E15688.847077 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.54858 matz1=4.510612 note=collision lift
G1 X252.285238 Y223.891279 Z4.900866 E15689.248196 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510612 matz1=4.500753 note=collision lift
G1 X252.416347 Y224.144483 Z4.760262 E15689.300454 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.500753 matz1=4.502717 note=collision lift
G1 X252.914195 Y225.866499 Z3.903961 E15689.87458 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.502717 matz1=3.903961 note=collision lift
G1 X252.920014 Y225.934717 Z3.873006 E15689.9164 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.903961 matz1=3.873006 note=collision lift
G1 X253.026063 Y227.178108 Z3.898476 E15690.611099 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.873006 matz1=3.898476 note=collision lift
G1 X253.066529 Y227.652552 Z4.146277 E15690.909862 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.898476 matz1=4.146277 note=collision lift
G1 X253.064911 Y227.667033 Z4.147312 E15690.923791 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.146277 matz1=4.147312 note=collision lift
G1 X253.029161 Y227.987014 Z4.311934 E15691.26862 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.147312 matz1=4.311934 note=collision lift
G1 X253.028303 Y227.994696 Z4.320212 E15691.279419 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.311934 matz1=4.320212 note=collision lift
G1 X252.867494 Y229.434005 Z5.039835 E15692.821537 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.320212 matz1=4.755815 note=collision lift
G1 X252.863319 Y229.447148 Z5.041084 E15692.841751 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.755815 matz1=4.757064 note=collision lift
G1 X252.740153 Y229.834827 Z5.236155 E15693.500373 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.757064 matz1=4.793916 note=collision lift
G1 X252.739598 Y229.836574 Z5.236321 E15693.503061 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.793916 matz1=4.794082 note=collision lift
G1 X252.676483 Y230.035237 Z5.331254 E15693.837456 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.794082 matz1=4.812966 note=collision lift
G1 X252.676094 Y230.036462 Z5.33137 E15693.83934 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.812966 matz1=4.813083 note=collision lift
G1 X252.645127 Y230.133935 Z5.374667 E15694.001482 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.813083 matz1=4.822348 note=collision lift
G1 X252.644648 Y230.135443 Z5.37481 E15694.003802 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.822348 matz1=4.822491 note=collision lift
G1 X252.612813 Y230.235648 Z5.306102 E15694.18717 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.822491 matz1=4.832017 note=collision lift
G1 X252.369819 Y231.000504 Z4.576279 E15695.770847 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.832017 matz1=4.576279 note=collision lift
G1 X252.351357 Y231.058615 Z4.542207 E15695.872819 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.576279 matz1=4.542207 note=collision lift
G1 X252.351352 Y231.058631 Z4.542192 E15695.872853 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.542207 matz1=4.542192 note=collision lift
G1 X252.327101 Y231.134964 Z4.49727 E15696.006919 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.542192 matz1=4.49727 note=collision lift
G1 X252.324739 Y231.142398 Z4.497977 E15696.018354 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.49727 matz1=4.497977 note=collision lift
G1 X251.487385 Y232.660828 Z3.710277 E15699.922824 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.497977 matz1=3.710277 note=collision lift
G1 X251.459122 Y232.712079 Z3.716457 E15700.043478 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.710277 matz1=3.716457 note=collision lift
G1 X251.45476 Y232.717255 Z3.717237 E15700.061837 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.716457 matz1=3.717237 note=collision lift
G1 X251.360884 Y232.828638 Z3.664897 E15700.47886 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.717237 matz1=3.664897 note=collision lift
G1 X251.337316 Y232.8566 Z3.670041 E15700.578354 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.664897 matz1=3.670041 note=collision lift
G1 X251.334994 Y232.859355 Z3.668655 E15700.588755 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.670041 matz1=3.668655 note=collision lift
G1 X251.219873 Y232.995946 Z3.681016 E15701.071181 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.668655 matz1=3.681016 note=collision lift
G1 X251.218952 Y232.997039 Z3.680466 E15701.075307 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.681016 matz1=3.680466 note=collision lift
G1 X250.303908 Y234.082726 Z3.814042 E15704.917605 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.680466 matz1=3.814042 note=collision lift
G1 X248.903492 Y235.201664 Z4.027482 E15710.982601 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.31169 Y236.025895 Z4.237006 E15718.225142 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.589674 Y236.523743 Z4.432029 E15726.557647 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.803621 Y236.676077 Z4.602697 E15735.836974 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.520107 Y236.644401 Z4.627019 E15737.334152 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.022168 Y236.477042 Z4.740387 E15749.991611 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.313775 Y235.934287 Z4.838141 E15765.845433 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X238.744094 Y235.06867 Z4.89102 E15782.126156 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X237.373447 Y233.913456 Z4.896353 E15798.444583 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X236.924109 Y233.351083 Z4.884971 E15804.96013 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X236.254509 Y232.51304 Z4.85387 E15814.516299 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.588189 Y231.226205 Z4.785966 E15826.973759 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.430278 Y230.921238 Z4.765717 E15829.895356 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X234.93243 Y229.199222 Z4.63635 E15844.0706 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X234.780096 Y227.413169 Z4.472303 E15856.887029 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X234.979131 Y225.631716 Z4.281866 E15868.116328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.521886 Y223.923323 Z4.074662 E15877.608355 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.575117 Y223.826794 Z4.061604 E15878.185487 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X236.057109 Y222.952767 Z3.942679 E15881.041316 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X236.387503 Y222.353642 Z4.203251 E15883.121372 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942679 matz1=4.203251 note=collision lift
G1 X236.954061 Y221.681427 Z4.540134 E15885.219308 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.203251 matz1=4.540134 note=collision lift
G1 X236.954979 Y221.680338 Z4.539256 E15885.223036 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.540134 matz1=4.539256 note=collision lift
G1 X236.978915 Y221.651939 Z4.551472 E15885.310162 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.539256 matz1=4.551472 note=collision lift
G1 X236.988575 Y221.640477 Z4.557216 E15885.345935 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.551472 matz1=4.557216 note=collision lift
G1 X237.052819 Y221.564252 Z4.578733 E15885.573191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.557216 matz1=4.578733 note=collision lift
G1 X237.057603 Y221.558576 Z4.581578 E15885.590907 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.578733 matz1=4.581578 note=collision lift
G1 X237.190675 Y221.400689 Z4.608001 E15886.054787 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.581578 matz1=4.608001 note=collision lift
G1 X237.19566 Y221.394774 Z4.610965 E15886.073246 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.608001 matz1=4.610965 note=collision lift
G1 X237.471772 Y221.06717 Z4.636516 E15887.029673 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.610965 matz1=4.636516 note=collision lift
G1 X237.474396 Y221.064057 Z4.634018 E15887.045362 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.636516 matz1=4.634018 note=collision lift
G1 X237.535562 Y220.991485 Z4.636895 E15887.357197 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.634018 matz1=4.636895 note=collision lift
G1 X237.542716 Y220.982996 Z4.641185 E15887.396285 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.636895 matz1=4.641185 note=collision lift
G1 X238.046275 Y220.58065 Z4.65987 E15888.928946 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.641185 matz1=4.65987 note=collision lift
G1 X238.047275 Y220.579851 Z4.659092 E15888.932508 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.65987 matz1=4.659092 note=collision lift
G1 X238.549833 Y220.178305 Z4.654185 E15890.461527 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.659092 matz1=4.654185 note=collision lift
G1 X238.551269 Y220.177158 Z4.653068 E15890.466639 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.654185 matz1=4.653068 note=collision lift
G1 X238.904996 Y219.894529 Z4.638206 E15891.543392 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.653068 matz1=4.638206 note=collision lift
G1 X238.943133 Y219.864057 Z4.657332 E15891.668008 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.638206 matz1=4.657332 note=collision lift
G1 X240.534935 Y219.039826 Z5.384485 E15894.735733 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.657332 matz1=4.789064 note=collision lift
G1 X240.652612 Y219.005805 Z5.436156 E15894.879846 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.789064 matz1=4.779487 note=collision lift
G1 X241.346833 Y218.8051 Z5.527447 E15895.66941 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.779487 matz1=4.722987 note=collision lift
G1 X241.348582 Y218.804594 Z5.526395 E15895.67169 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.722987 matz1=4.722845 note=collision lift
G1 X241.853435 Y218.658637 Z5.582823 E15896.244626 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.722845 matz1=4.681758 note=collision lift
G1 X241.851983 Y218.658257 Z5.581998 E15896.245234 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.681758 matz1=4.681683 note=collision lift
G1 X241.386736 Y218.536337 Z5.525544 E15896.417297 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.681683 matz1=4.657819 note=collision lift
G1 X241.386706 Y218.536329 Z5.525527 E15896.41731 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.657819 matz1=4.657817 note=collision lift
G1 X240.644264 Y218.341768 Z5.433981 E15896.69195 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.657817 matz1=4.619734 note=collision lift
G1 X238.829251 Y217.866134 Z4.402732 E15897.452684 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.619734 matz1=4.402732 note=collision lift
G1 X238.816245 Y217.862726 Z4.408787 E15897.457923 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.402732 matz1=4.408787 note=collision lift
G1 X237.640762 Y217.449316 Z4.302322 E15897.750389 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.408787 matz1=4.302322 note=collision lift
G1 X237.057657 Y217.244241 Z3.984654 E15897.912914 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.302322 matz1=3.984654 note=collision lift
G1 X236.956249 Y217.208577 Z3.933182 E15897.953978 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.984654 matz1=3.933182 note=collision lift
G1 X236.128543 Y216.917478 Z3.946173 E15898.256311 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.933182 matz1=3.946173 note=collision lift
G1 X236.128012 Y216.917291 Z3.945903 E15898.256526 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946173 matz1=3.945903 note=collision lift
G1 X234.36353 Y216.296734 Z3.945903 E15898.90096 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.945903 matz1=3.945903 note=collision lift
G1 X232.340447 Y215.417839 Z3.945903 E15901.238741 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.945903 matz1=3.945903 note=collision lift
G1 X232.340269 Y215.417761 Z3.946013 E15901.238977 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.945903 matz1=3.946013 note=collision lift
G1 X231.18741 Y214.916921 Z3.903698 E15902.571922 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946013 matz1=3.903698 note=collision lift
G1 X231.187169 Y214.916816 Z3.903584 E15902.572226 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.903698 matz1=3.903584 note=collision lift
G1 X231.124323 Y214.889514 Z3.901253 E15902.644889 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.903584 matz1=3.901253 note=collision lift
G1 X231.107472 Y214.880912 Z3.900589 E15902.687814 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.901253 matz1=3.900589 note=collision lift
G1 X231.107265 Y214.880806 Z3.900729 E15902.68843 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.900589 matz1=3.900729 note=collision lift
G1 X228.98833 Y213.799138 Z3.816648 E15908.086057 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.900729 matz1=3.816648 note=collision lift
G1 X228.987987 Y213.798964 Z3.816495 E15908.086995 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.816648 matz1=3.816495 note=collision lift
G1 X227.756808 Y213.170475 Z3.703722 E15911.231672 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.816495 matz1=3.703722 note=collision lift
G1 X227.756745 Y213.170443 Z3.703694 E15911.231843 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.703722 matz1=3.703694 note=collision lift
G1 X227.744215 Y213.164047 Z3.702545 E15911.263848 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.703694 matz1=3.702545 note=collision lift
G1 X227.744205 Y213.164042 Z3.702551 E15911.263876 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.702545 matz1=3.702551 note=collision lift
G1 X225.676907 Y211.926899 Z3.961504 E15920.353674 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.702551 matz1=3.961504 note=collision lift
G1 X224.284105 Y211.093398 Z4.153072 E15926.484934 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X220.807469 Y208.653242 Z4.596987 E15948.416977 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X217.829332 Y206.190906 Z4.83185 E15971.56414 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X217.382306 Y205.821304 Z4.87634 E15975.042371 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.83185 matz1=4.87634 note=collision lift
G1 X217.377183 Y205.817068 Z4.880068 E15975.087942 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.87634 matz1=4.880068 note=collision lift
G1 X216.859005 Y205.330998 Z5.24523 E15979.944214 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.880068 matz1=5.24523 note=collision lift
G1 X216.857639 Y205.329717 Z5.24432 E15979.956877 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.24523 matz1=5.24432 note=collision lift
G1 X216.762373 Y205.240354 Z5.31022 E15980.846288 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.24432 matz1=5.31022 note=collision lift
G1 X216.762288 Y205.240274 Z5.310163 E15980.847079 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.31022 matz1=5.310163 note=collision lift
G1 X215.698833 Y204.242716 Z5.310163 E15989.711307 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.310163 matz1=5.310163 note=collision lift
G1 X214.953485 Y204.084287 Z5.310163 E15994.327596 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.310163 matz1=5.310163 note=collision lift
G1 X214.755345 Y204.707958 Z5.310163 E15998.213913 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.310163 matz1=5.310163 note=collision lift
G1 X214.754615 Y204.710255 Z5.311307 E15998.229759 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.310163 matz1=5.311307 note=collision lift
G1 X214.746732 Y204.73507 Z5.298412 E15998.402311 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.311307 matz1=5.298412 note=collision lift
G1 X214.733009 Y204.778264 Z5.274591 E15998.706387 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.298412 matz1=5.274591 note=collision lift
G1 X214.675234 Y204.960119 Z5.234879 E15999.863868 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.274591 matz1=5.234879 note=collision lift
G1 X214.66975 Y204.977379 Z5.22536 E15999.985373 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.234879 matz1=5.22536 note=collision lift
G1 X214.501329 Y205.507508 Z5.178096 E16003.300703 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.22536 matz1=5.178096 note=collision lift
G1 X214.501189 Y205.507948 Z5.178316 E16003.303742 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.178096 matz1=5.178316 note=collision lift
G1 X214.172519 Y206.103947 Z5.120952 E16007.211003 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.178316 matz1=5.120952 note=collision lift
G1 X214.17222 Y206.104489 Z5.120614 E16007.215039 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.120952 matz1=5.120614 note=collision lift
G1 X214.057715 Y206.312128 Z5.100008 E16008.576585 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.120614 matz1=5.100008 note=collision lift
G1 X214.057419 Y206.312667 Z5.100286 E16008.580446 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.100008 matz1=5.100286 note=collision lift
G1 X213.78143 Y206.813135 Z4.805297 E16012.259645 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.100286 matz1=4.805297 note=collision lift
G1 X213.779842 Y206.816016 Z4.806787 E16012.2803 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.805297 matz1=4.806787 note=collision lift
G1 X213.187605 Y207.518696 Z4.723462 E16017.272954 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.806787 matz1=4.723462 note=collision lift
G1 X212.817163 Y207.958221 Z4.685231 E16020.389954 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X211.650149 Y208.89067 Z4.560046 E16027.915541 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.323648 Y209.577529 Z4.413429 E16034.764679 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.888635 Y209.992402 Z4.25053 E16040.858221 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.400257 Y210.119347 Z4.092939 E16046.13705 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.25053 matz1=4.092939 note=collision lift
G1 X206.487164 Y210.017331 Z4.092939 E16048.856238 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.092939 matz1=4.092939 note=collision lift
G1 X206.486971 Y210.017309 Z4.093014 E16048.856855 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.092939 matz1=4.093014 note=collision lift
G1 X205.915752 Y209.953489 Z4.03413 E16050.566846 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.093014 matz1=4.03413 note=collision lift
G1 X205.915713 Y209.953485 Z4.034106 E16050.566982 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.03413 matz1=4.034106 note=collision lift
G1 X205.915634 Y209.95346 Z4.034055 E16050.567217 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.034106 matz1=4.034055 note=collision lift
G1 X205.803308 Y209.917774 Z4.022298 E16050.852709 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.034055 matz1=4.022298 note=collision lift
G1 X205.803287 Y209.917767 Z4.022285 E16050.852771 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.022298 matz1=4.022285 note=collision lift
G1 X205.80165 Y209.917247 Z4.022113 E16050.856931 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.022285 matz1=4.022113 note=collision lift
G1 X205.80163 Y209.917241 Z4.022121 E16050.856986 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.022113 matz1=4.022121 note=collision lift
G1 X205.695359 Y209.883478 Z4.010913 E16051.127109 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.022121 matz1=4.010913 note=collision lift
G1 X205.69534 Y209.883472 Z4.0109 E16051.127166 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.010913 matz1=4.0109 note=collision lift
G1 X205.691816 Y209.882353 Z4.010527 E16051.136123 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.0109 matz1=4.010527 note=collision lift
G1 X205.691732 Y209.882326 Z4.010561 E16051.136351 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.010527 matz1=4.010561 note=collision lift
G1 X205.476737 Y209.814023 Z3.987626 E16051.682893 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.010561 matz1=3.987626 note=collision lift
G1 X205.476658 Y209.813997 Z3.987575 E16051.683129 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.987626 matz1=3.987575 note=collision lift
G1 X205.471467 Y209.812348 Z3.987017 E16051.696325 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.987575 matz1=3.987017 note=collision lift
G1 X205.471134 Y209.812242 Z3.98715 E16051.697228 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.987017 matz1=3.98715 note=collision lift
G1 X205.04885 Y209.678083 Z3.941072 E16052.77098 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.98715 matz1=3.941072 note=collision lift
G1 X205.048529 Y209.677981 Z3.940864 E16052.771934 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.941072 matz1=3.940864 note=collision lift
G1 X205.040008 Y209.675274 Z3.93992 E16052.793605 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.940864 matz1=3.93992 note=collision lift
G1 X205.039881 Y209.675234 Z3.939971 E16052.793947 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.93992 matz1=3.939971 note=collision lift
G1 X204.492099 Y209.501204 Z3.88866 E16054.184844 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939971 matz1=3.88866 note=collision lift
G1 X204.492052 Y209.501189 Z3.888679 E16054.184973 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.88866 matz1=3.888679 note=collision lift
G1 X204.185152 Y209.331946 Z3.85798 E16054.848501 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.888679 matz1=3.85798 note=collision lift
G1 X204.184872 Y209.331792 Z3.858104 E16054.849147 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.85798 matz1=3.858104 note=collision lift
G1 X204.152668 Y209.314032 Z3.854783 E16054.918791 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.858104 matz1=3.854783 note=collision lift
G1 X203.955972 Y209.205562 Z3.941807 E16055.373114 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.854783 matz1=3.941807 note=collision lift
G1 X203.949791 Y209.202154 Z3.942041 E16055.386434 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.941807 matz1=3.942041 note=collision lift
G1 X203.949763 Y209.202138 Z3.942021 E16055.386505 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942041 matz1=3.942021 note=collision lift
G1 X203.183984 Y208.779842 Z3.942021 E16057.035829 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942021 matz1=3.942021 note=collision lift
G1 X202.041779 Y207.817163 Z3.942021 E16059.134529 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942021 matz1=3.942021 note=collision lift
G1 X201.10933 Y206.650149 Z3.942021 E16060.60454 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942021 matz1=3.942021 note=collision lift
G1 X200.79895 Y206.050726 Z3.942021 E16061.035329 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942021 matz1=3.942021 note=collision lift
G1 X200.798562 Y206.049975 Z3.942381 E16061.035915 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942021 matz1=3.942381 note=collision lift
G1 X200.571325 Y205.611122 Z3.658584 E16061.399612 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942381 matz1=3.658584 note=collision lift
G1 X200.422471 Y205.323648 Z3.675691 E16061.6065 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.658584 matz1=3.675691 note=collision lift
G1 X200.422425 Y205.323487 Z3.675598 E16061.606573 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.675691 matz1=3.675598 note=collision lift
G1 X200.317736 Y204.961379 Z3.695851 E16061.749799 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.675598 matz1=3.695851 note=collision lift
G1 X200.317731 Y204.96136 Z3.69584 E16061.749808 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.695851 matz1=3.69584 note=collision lift
G1 X200.315604 Y204.954004 Z3.696414 E16061.752722 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.69584 matz1=3.696414 note=collision lift
G1 X200.315523 Y204.953724 Z3.696543 E16061.752842 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.696414 matz1=3.696543 note=collision lift
G1 X200.192546 Y204.528355 Z3.729324 E16061.921308 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.696543 matz1=3.729324 note=collision lift
G1 X200.192499 Y204.528194 Z3.72923 E16061.921381 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.729324 matz1=3.72923 note=collision lift
G1 X200.191221 Y204.523772 Z3.729567 E16061.923132 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.72923 matz1=3.729567 note=collision lift
G1 X200.191202 Y204.523705 Z3.729598 E16061.923161 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.729567 matz1=3.729598 note=collision lift
G1 X200.129681 Y204.310912 Z3.745677 E16062.007428 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.729598 matz1=3.745677 note=collision lift
G1 X200.12967 Y204.310872 Z3.745654 E16062.007446 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.745677 matz1=3.745654 note=collision lift
G1 X200.128714 Y204.307565 Z3.745903 E16062.008756 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.745654 matz1=3.745903 note=collision lift
G1 X200.128693 Y204.307492 Z3.745936 E16062.008787 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.745903 matz1=3.745936 note=collision lift
G1 X200.063979 Y204.083653 Z3.762626 E16062.097422 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.745936 matz1=3.762626 note=collision lift
G1 X200.063976 Y204.083642 Z3.76262 E16062.097427 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.762626 matz1=3.76262 note=collision lift
G1 X200.007598 Y203.888635 Z3.776978 E16062.174641 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.76262 matz1=3.776978 note=collision lift
G1 X200.007597 Y203.888629 Z3.776975 E16062.174642 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.776978 matz1=3.776975 note=collision lift
G1 X199.975724 Y203.514929 Z3.804221 E16062.256199 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.776975 matz1=3.804221 note=collision lift
G1 X199.97555 Y203.512894 Z3.805171 E16062.256687 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.804221 matz1=3.805171 note=collision lift
G1 X199.880653 Y202.400257 Z3.904535 E16062.499829 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.805171 matz1=3.904535 note=collision lift
G1 X199.880795 Y202.398984 Z3.903877 E16062.500054 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.904535 matz1=3.903877 note=collision lift
G1 X199.922525 Y202.025484 Z3.937327 E16062.559014 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.903877 matz1=3.937327 note=collision lift
G1 X199.922529 Y202.025443 Z3.937306 E16062.559021 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937327 matz1=3.937306 note=collision lift
G1 X200.046515 Y200.915713 Z3.937306 E16062.733511 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937306 matz1=3.937306 note=collision lift
G1 X200.498811 Y199.492052 Z3.937306 E16063.031832 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937306 matz1=3.937306 note=collision lift
G1 X201.220158 Y198.183984 Z3.937306 E16063.548213 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937306 matz1=3.937306 note=collision lift
G1 X201.812062 Y197.481698 Z3.937306 E16064.089246 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937306 matz1=3.937306 note=collision lift
G1 X201.812395 Y197.481304 Z3.937591 E16064.089593 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937306 matz1=3.937591 note=collision lift
G1 X202.18118 Y197.043744 Z3.71239 E16064.451848 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937591 matz1=3.71239 note=collision lift
G1 X202.182837 Y197.041779 Z3.713809 E16064.453577 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.71239 matz1=3.713809 note=collision lift
G1 X202.90078 Y196.46814 Z3.352239 E16065.363406 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.713809 matz1=3.352239 note=collision lift
G1 X202.908741 Y196.461779 Z3.347871 E16065.373621 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.352239 matz1=3.347871 note=collision lift
G1 X203.349851 Y196.10933 Z3.245467 E16065.902298 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.347871 matz1=3.245467 note=collision lift
G1 X203.682918 Y195.936869 Z3.284774 E16066.404146 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.245467 matz1=3.284774 note=collision lift
G1 X203.684726 Y195.935933 Z3.28597 E16066.407288 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.284774 matz1=3.28597 note=collision lift
G1 X204.676352 Y195.422471 Z3.408622 E16067.902216 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.28597 matz1=3.408622 note=collision lift
G1 X204.678152 Y195.421951 Z3.407875 E16067.905851 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.408622 matz1=3.407875 note=collision lift
G1 X205.036886 Y195.318238 Z3.448901 E16068.583169 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.407875 matz1=3.448901 note=collision lift
G1 X205.038621 Y195.317736 Z3.449987 E16068.586967 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.448901 matz1=3.449987 note=collision lift
G1 X206.111365 Y195.007598 Z3.560847 E16070.61017 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.449987 matz1=3.560847 note=collision lift
G1 X206.113123 Y195.007448 Z3.560161 E16070.614563 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.560847 matz1=3.560161 note=collision lift
G1 X206.485625 Y194.975677 Z3.597286 E16071.486686 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.560161 matz1=3.597286 note=collision lift
G1 X206.487106 Y194.97555 Z3.598194 E16071.490729 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.597286 matz1=3.598194 note=collision lift
G1 X207.599743 Y194.880653 Z3.694472 E16074.092563 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.598194 matz1=3.694472 note=collision lift
G1 X209.084287 Y195.046515 Z3.869711 E16078.405782 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.507948 Y195.498811 Z4.04777 E16083.55519 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X211.816016 Y196.220158 Z4.222394 E16089.522124 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X212.958221 Y197.182837 Z4.387448 E16096.258239 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X213.89067 Y198.349851 Z4.537133 E16103.687835 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X214.251884 Y199.047448 Z4.605003 E16107.907322 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X214.577529 Y199.676352 Z5.020296 E16112.300729 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.605003 matz1=5.020296 note=collision lift
G1 X214.682264 Y200.038621 Z5.235077 E16114.763686 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.020296 matz1=5.235077 note=collision lift
G1 X214.749509 Y200.271219 Z5.285517 E16116.167305 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.235077 matz1=5.285517 note=collision lift
G1 X214.751266 Y200.277294 Z5.282795 E16116.206376 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.285517 matz1=5.282795 note=collision lift
G1 X214.885702 Y200.742299 Z5.310563 E16118.958003 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.282795 matz1=5.310563 note=collision lift
G1 X214.885961 Y200.743192 Z5.310163 E16118.963745 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.310563 matz1=5.310163 note=collision lift
G1 X214.927189 Y200.885799 Z5.310163 E16119.806224 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.310163 matz1=5.310163 note=collision lift
G1 X214.992402 Y201.111365 Z5.443896 E16121.339784 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.310163 matz1=5.443896 note=collision lift
G1 X215.119347 Y202.599743 Z6.26587 E16131.415299 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.443896 matz1=6.26587 note=collision lift
G1 X215.092279 Y202.842017 Z6.394881 E16133.082716 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.26587 matz1=6.352289 note=collision lift
G1 X215.055527 Y203.170962 Z6.400195 E16135.083967 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.352289 matz1=6.361957 note=collision lift
G1 X215.0554 Y203.172098 Z6.399657 E16135.091608 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.361957 matz1=6.36199 note=collision lift
G1 X214.953485 Y204.084287 Z6.399657 E16140.640512 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.36199 matz1=6.388801 note=collision lift
G1 X215.698833 Y204.242716 Z6.399657 E16145.269965 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.388801 matz1=6.398406 note=collision lift
G1 X216.878495 Y203.832636 Z6.399657 E16152.765312 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.398406 matz1=6.385548 note=collision lift
G1 X216.879528 Y203.832277 Z6.400192 E16152.77262 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.385548 matz1=6.385537 note=collision lift
G1 X217.031901 Y203.779308 Z6.393498 E16153.741605 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.385537 matz1=6.383876 note=collision lift
G1 X217.872429 Y203.48712 Z5.939404 E16159.737312 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.383876 matz1=5.939404 note=collision lift
G1 X219.492272 Y203.035337 Z5.001684 E16169.753318 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.939404 matz1=5.001684 note=collision lift
G1 X219.499303 Y203.033376 Z4.998482 E16169.794781 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.001684 matz1=4.998482 note=collision lift
G1 X219.654277 Y202.990153 Z4.908768 E16170.753036 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.998482 matz1=4.908768 note=collision lift
G1 X219.849131 Y202.935807 Z4.803565 E16171.939135 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.908768 matz1=4.803565 note=collision lift
G1 X219.850087 Y202.935541 Z4.804004 E16171.944776 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.803565 matz1=4.804004 note=collision lift
G1 X220.20087 Y202.837705 Z4.735445 E16173.872446 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.804004 matz1=4.735445 note=collision lift
G1 X222.159727 Y202.29137 Z4.618281 E16184.468729 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X226.328293 Y201.476251 Z4.181799 E16200.868988 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.331459 Y200.991973 Z3.705559 E16210.434985 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X234.121163 Y200.790494 Z3.31144 E16214.735086 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X237.652693 Y200.822439 Z3.071285 E16216.073795 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.499286 Y201.052647 Z3.000456 E16216.523244 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.357397 Y201.202916 Z3.019561 E16217.12979 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X246.213155 Y201.835394 Z3.219915 E16222.069016 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.80139 Y202.212382 Z3.359035 E16225.203282 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X248.232623 Y202.31474 Z3.401358 E16226.143206 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X250.288942 Y202.991813 Z3.629935 E16233.066345 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X250.317458 Y203.001203 Z3.633312 E16233.1629 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.651211 Y203.428621 Z3.910382 E16243.892686 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.622495 Y203.436923 Z3.913948 E16244.028413 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X250.836442 Y203.589256 Z4.126895 E16253.964961 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X250.121192 Y203.509344 Z4.210472 E16258.236459 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.054989 Y203.390221 Z4.330904 E16265.209194 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.674028 Y202.951492 Z4.482199 E16275.649617 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.346595 Y202.847467 Z4.515667 E16278.177398 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.776915 Y201.98185 Z4.671849 E16292.668191 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.406268 Y200.826636 Z4.791559 E16308.142337 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.28733 Y199.426219 Z4.868747 E16324.244154 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.463099 Y197.834417 Z4.899515 E16340.591427 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.432525 Y197.728664 Z4.899844 E16341.59538 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.96525 Y196.112401 Z4.882307 E16351.733046 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.822285 Y194.436183 Z4.823258 E16361.565563 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.812917 Y194.326349 Z4.817992 E16362.529767 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.847772 Y194.014374 Z4.799049 E16365.118321 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.011952 Y192.544895 Z5.449132 E16378.413265 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.799049 matz1=5.449132 note=collision lift
G1 X242.554706 Y190.836502 Z6.198839 E16393.074267 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.449132 matz1=6.063259 note=collision lift
G1 X242.613791 Y190.72936 Z6.248105 E16393.9871 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.063259 matz1=6.051348 note=collision lift
G1 X242.816516 Y190.361745 Z6.274165 E16396.898039 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.051348 matz1=6.010479 note=collision lift
G1 X242.816698 Y190.361415 Z6.274317 E16396.900849 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.010479 matz1=6.010442 note=collision lift
G1 X243.217041 Y189.635447 Z6.313744 E16402.644832 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.010442 matz1=5.929734 note=collision lift
G1 X243.217416 Y189.634766 Z6.314057 E16402.650636 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.929734 matz1=5.929658 note=collision lift
G1 X242.465872 Y190.073991 Z6.274595 E16407.246306 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.929658 matz1=5.832051 note=collision lift
G1 X242.465716 Y190.074082 Z6.274485 E16407.247422 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.832051 matz1=5.83203 note=collision lift
G1 X242.138208 Y190.265487 Z6.248441 E16409.252778 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.83203 matz1=5.789495 note=collision lift
G1 X240.506735 Y191.218968 Z5.091719 E16420.937891 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.789495 matz1=5.091719 note=collision lift
G1 X238.825857 Y192.025206 Z3.937591 E16430.224874 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.091719 matz1=3.937591 note=collision lift
G1 X238.677993 Y192.096129 Z3.836875 E16430.572639 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937591 matz1=3.836875 note=collision lift
G1 X237.548378 Y192.637952 Z3.693866 E16432.851253 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X237.541556 Y192.641224 Z3.696786 E16432.865908 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.693866 matz1=3.696786 note=collision lift
G1 X236.45988 Y193.160053 Z3.556062 E16435.048608 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.696786 matz1=3.556062 note=collision lift
G1 X236.250239 Y193.260608 Z3.529521 E16435.471486 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X232.966123 Y194.556112 Z3.204572 E16438.28573 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X229.355003 Y195.72588 Z3.017392 E16439.084356 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.444295 Y196.708265 Z3.04676 E16440.300955 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.105123 Y197.118165 Z3.200746 E16443.062733 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X221.472903 Y197.404183 Z3.318334 E16444.990634 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.200746 matz1=3.318334 note=collision lift
G1 X221.467167 Y197.405188 Z3.315799 E16444.998004 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.318334 matz1=3.315799 note=collision lift
G1 X221.261113 Y197.441295 Z3.329604 E16445.241302 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.315799 matz1=3.329604 note=collision lift
G1 X221.260438 Y197.441414 Z3.329992 E16445.242217 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.329604 matz1=3.329992 note=collision lift
G1 X220.871437 Y197.478275 Z3.36379 E16446.277034 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.329992 matz1=3.36379 note=collision lift
G1 X219.174761 Y197.639051 Z3.545281 E16450.79915 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X216.829307 Y197.861305 Z4.974151 E16458.069204 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.545281 matz1=4.974151 note=collision lift
G1 X215.074382 Y197.917403 Z6.060909 E16465.279506 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.974151 matz1=5.505018 note=collision lift
G1 X215.027947 Y197.918887 Z6.078705 E16465.453222 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.505018 matz1=5.510544 note=collision lift
G1 X215.026004 Y197.918949 Z6.077964 E16465.460486 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.510544 matz1=5.510775 note=collision lift
G1 X214.982572 Y197.920338 Z6.086618 E16465.615197 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.510775 matz1=5.515944 note=collision lift
G1 X214.981512 Y197.920372 Z6.087274 E16465.619552 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.515944 matz1=5.51607 note=collision lift
G1 X214.890042 Y197.923295 Z6.098543 E16465.941525 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.51607 matz1=5.526955 note=collision lift
G1 X214.888643 Y197.92334 Z6.099409 E16465.947271 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.526955 matz1=5.527122 note=collision lift
G1 X214.702905 Y197.929277 Z6.11172 E16466.597583 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.527122 matz1=5.549226 note=collision lift
G1 X214.701892 Y197.92931 Z6.111334 E16466.601369 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.549226 matz1=5.549346 note=collision lift
G1 X214.530575 Y197.934786 Z6.116982 E16467.200202 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.549346 matz1=5.569734 note=collision lift
G1 X214.529773 Y197.934812 Z6.117478 E16467.203494 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.569734 matz1=5.56983 note=collision lift
G1 X214.645403 Y197.69595 Z6.086134 E16468.35631 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.56983 matz1=5.600248 note=collision lift
G1 X214.646133 Y197.694441 Z6.087164 E16468.364801 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.600248 matz1=5.60044 note=collision lift
G1 X214.762493 Y197.454069 Z6.041737 E16469.533442 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.60044 matz1=5.63105 note=collision lift
G1 X215.532229 Y195.863981 Z5.360929 E16477.70104 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.63105 matz1=5.360929 note=collision lift
G1 X216.541336 Y194.074066 Z4.51946 E16490.068302 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.360929 matz1=4.51946 note=collision lift
G1 X217.718123 Y191.986727 Z4.736272 E16503.469319 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X220.089615 Y188.462781 Z4.898168 E16529.29081 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X222.577697 Y185.289744 Z4.807647 E16552.652863 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.115109 Y182.466609 Z4.524324 E16571.338412 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X227.63438 Y179.993349 Z4.143909 E16584.557379 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X229.810574 Y178.142888 Z3.804833 E16592.224994 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X231.230784 Y176.935256 Z3.590864 E16597.849639 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X234.404177 Y174.655218 Z3.218577 E16602.780509 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.233232 Y174.144895 Z3.154074 E16603.512681 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.794002 Y173.799715 Z3.439691 E16604.051317 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.154074 matz1=3.439691 note=collision lift
G1 X236.172062 Y173.567001 Z3.63818 E16604.362838 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.439691 matz1=3.63818 note=collision lift
G1 X238.103671 Y172.591168 Z4.645294 E16605.055277 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63818 matz1=4.512022 note=collision lift
G1 X238.130573 Y172.577577 Z4.6598 E16605.064892 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.512022 matz1=4.511458 note=collision lift
G1 X239.054315 Y171.939948 Z5.220165 E16605.414907 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.511458 matz1=4.510603 note=collision lift
G1 X239.992018 Y171.292682 Z5.354218 E16605.73499 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510603 matz1=4.509735 note=collision lift
G1 X240.083037 Y171.229855 Z5.422529 E16605.771257 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.509735 matz1=4.50965 note=collision lift
G1 X240.077985 Y171.239015 Z5.422708 E16605.774201 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50965 matz1=4.50983 note=collision lift
G1 X240.069183 Y171.254977 Z5.429672 E16605.779692 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50983 matz1=4.510144 note=collision lift
G1 X240.06867 Y171.255906 Z5.430751 E16605.780118 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510144 matz1=4.510162 note=collision lift
G1 X239.281912 Y172.189385 Z5.897177 E16606.482192 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510162 matz1=4.547413 note=collision lift
G1 X238.913456 Y172.626553 Z5.914623 E16606.789476 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.547413 matz1=4.564858 note=collision lift
G1 X238.351083 Y173.075891 Z5.949407 E16607.293885 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.564858 matz1=4.599642 note=collision lift
G1 X237.51304 Y173.745491 Z6.014042 E16608.370914 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.599642 matz1=4.664277 note=collision lift
G1 X236.226205 Y174.411811 Z4.674624 E16611.361041 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.664277 matz1=4.674624 note=collision lift
G1 X235.921238 Y174.569722 Z4.360623 E16612.130197 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.674624 matz1=4.360623 note=collision lift
G1 X235.746812 Y174.62015 Z4.196455 E16612.731483 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.360623 matz1=4.196455 note=collision lift
G1 X234.199222 Y175.06757 Z3.54536 E16616.999652 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.196455 matz1=3.54536 note=collision lift
G1 X234.059383 Y175.079497 Z3.490515 E16617.507771 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.54536 matz1=3.490515 note=collision lift
G1 X232.413169 Y175.219904 Z3.670966 E16623.112268 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.631716 Y175.020869 Z3.880845 E16630.96985 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X228.923323 Y174.478114 Z4.094218 E16640.63078 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X228.826794 Y174.424883 Z4.107211 E16641.231549 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X227.353642 Y173.612497 Z4.300305 E16648.361289 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X226.06717 Y172.528228 Z4.477815 E16656.420879 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.982996 Y172.457284 Z4.488691 E16657.216988 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.864057 Y171.056867 Z4.64986 E16671.526215 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.039826 Y169.465065 Z4.775666 E16686.870379 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.658637 Y168.146565 Z4.844054 E16699.044247 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X222.862726 Y171.183755 Z4.898829 E16727.667614 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X222.244241 Y172.942343 Z4.861968 E16744.341589 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X221.296734 Y175.63647 Z4.710402 E16760.040118 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X219.889514 Y178.875677 Z4.392224 E16775.986571 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X218.164042 Y182.255795 Z3.956932 E16787.980235 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X218.151396 Y182.276926 Z3.954111 E16788.02236 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X217.308183 Y183.685957 Z3.826948 E16790.821354 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.954111 matz1=3.826948 note=collision lift
G1 X217.308044 Y183.68619 Z3.827052 E16790.821848 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.826948 matz1=3.827052 note=collision lift
G1 X216.112874 Y185.68335 Z3.890465 E16794.778765 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.827052 matz1=3.890465 note=collision lift
G1 X216.112696 Y185.683647 Z3.890252 E16794.779455 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.890465 matz1=3.890252 note=collision lift
G1 X216.093399 Y185.715893 Z3.891261 E16794.843341 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.890252 matz1=3.891261 note=collision lift
G1 X216.093398 Y185.715895 Z3.891262 E16794.843346 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.891261 matz1=3.891262 note=collision lift
G1 X216.032448 Y185.802735 Z3.893978 E16794.904241 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.891262 matz1=3.893978 note=collision lift
G1 X216.031663 Y185.803852 Z3.894545 E16794.905089 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.893978 matz1=3.894545 note=collision lift
G1 X214.728682 Y187.660286 Z3.950436 E16796.206857 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.894545 matz1=3.950436 note=collision lift
G1 X214.728088 Y187.661134 Z3.94983 E16796.207545 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.950436 matz1=3.94983 note=collision lift
G1 X213.653242 Y189.192531 Z3.94983 E16797.281065 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94983 matz1=3.94983 note=collision lift
G1 X212.81224 Y190.209703 Z3.94983 E16797.487755 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94983 matz1=3.94983 note=collision lift
G1 X212.811798 Y190.210238 Z3.950156 E16797.487875 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94983 matz1=3.950156 note=collision lift
G1 X212.683952 Y190.364864 Z3.935345 E16797.51938 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.950156 matz1=3.935345 note=collision lift
G1 X212.682941 Y190.366087 Z3.936091 E16797.519655 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.935345 matz1=3.936091 note=collision lift
G1 X212.554084 Y190.521936 Z3.914635 E16797.551501 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.936091 matz1=3.914635 note=collision lift
G1 X212.105488 Y191.064502 Z3.541474 E16797.676282 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.914635 matz1=3.541474 note=collision lift
G1 X210.817068 Y192.622817 Z4.491681 E16798.026154 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.541474 matz1=4.491681 note=collision lift
G1 X209.599637 Y193.920669 Z5.416464 E16798.623578 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.491681 matz1=4.535265 note=collision lift
G1 X209.598802 Y193.921558 Z5.415878 E16798.623981 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.535265 matz1=4.535289 note=collision lift
G1 X209.586558 Y193.934611 Z5.423377 E16798.629762 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.535289 matz1=4.535642 note=collision lift
G1 X209.583742 Y193.937613 Z5.425517 E16798.631144 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.535642 matz1=4.535723 note=collision lift
G1 X209.553669 Y193.969673 Z5.437593 E16798.644724 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.535723 matz1=4.536588 note=collision lift
G1 X209.551953 Y193.971502 Z5.438896 E16798.645566 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.536588 matz1=4.536638 note=collision lift
G1 X209.490247 Y194.037284 Z5.454217 E16798.67282 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.536638 matz1=4.538414 note=collision lift
G1 X209.488375 Y194.03928 Z5.455639 E16798.673738 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.538414 matz1=4.538468 note=collision lift
G1 X209.361219 Y194.174836 Z5.472624 E16798.729337 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.538468 matz1=4.542128 note=collision lift
G1 X209.360465 Y194.175639 Z5.472095 E16798.729701 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.542128 matz1=4.542149 note=collision lift
G1 X209.243651 Y194.30017 Z5.479856 E16798.780619 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.542149 matz1=4.545511 note=collision lift
G1 X209.242716 Y194.301167 Z5.480566 E16798.781078 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.545511 matz1=4.545538 note=collision lift
G1 X209.155799 Y194.051137 Z5.437433 E16798.96168 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.545538 matz1=4.559391 note=collision lift
G1 X209.155021 Y194.048899 Z5.438742 E16798.963504 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.559391 matz1=4.559515 note=collision lift
G1 X209.067326 Y193.79663 Z5.376063 E16799.148238 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.559515 matz1=4.573491 note=collision lift
G1 X208.48712 Y192.127571 Z4.585018 E16800.45194 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.573491 matz1=4.585018 note=collision lift
G1 X207.724655 Y189.393794 Z3.423648 E16806.381111 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.585018 matz1=3.423648 note=collision lift
G1 X207.29137 Y187.840273 Z3.570083 E16809.512318 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.476251 Y183.671707 Z4.06593 E16824.392432 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.991973 Y179.668541 Z4.508963 E16844.1119 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.790494 Y175.878837 Z4.799199 E16866.058312 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.822439 Y172.347307 Z4.89979 E16887.538592 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.052647 Y169.500714 Z4.846297 E16904.428171 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.202916 Y167.642603 Z4.748725 E16920.13297 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.835394 Y163.786845 Z4.411849 E16946.947651 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.208649 Y162.214336 Z4.234835 E16956.704727 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.212382 Y162.19861 Z4.241146 E16956.808855 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.234835 matz1=4.241146 note=collision lift
G1 X207.31474 Y161.767377 Z4.411833 E16959.545962 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.241146 matz1=4.411833 note=collision lift
G1 X207.991813 Y159.711058 Z5.23822 E16970.125023 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.411833 matz1=5.23822 note=collision lift
G1 X208.001203 Y159.682542 Z5.249649 E16970.271138 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.23822 matz1=5.249649 note=collision lift
G1 X208.203433 Y158.578338 Z5.679527 E16974.177282 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.249649 matz1=5.291082 note=collision lift
G1 X208.428621 Y157.348789 Z5.818986 E16978.264397 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.291082 matz1=5.144759 note=collision lift
G1 X208.430626 Y157.355724 Z5.814561 E16978.291779 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.144759 matz1=5.143943 note=collision lift
G1 X208.436567 Y157.376275 Z5.812167 E16978.361387 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.143943 matz1=5.141526 note=collision lift
G1 X208.436923 Y157.377505 Z5.812663 E16978.365828 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.141526 matz1=5.141382 note=collision lift
G1 X208.540658 Y158.593758 Z5.676148 E16981.229657 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.141382 matz1=5.010033 note=collision lift
G1 X208.589256 Y159.163558 Z5.328678 E16982.789846 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.010033 matz1=4.948498 note=collision lift
G1 X208.545903 Y159.551588 Z5.095035 E16983.700021 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.948498 matz1=4.910077 note=collision lift
G1 X208.509344 Y159.878808 Z5.227262 E16984.409767 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.910077 matz1=4.877676 note=collision lift
G1 X208.390221 Y160.945011 Z5.666958 E16986.204518 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.877676 matz1=4.780954 note=collision lift
G1 X208.351056 Y161.06829 Z5.682133 E16986.338461 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.780954 matz1=4.771039 note=collision lift
G1 X208.351029 Y161.068374 Z5.682171 E16986.33856 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.771039 matz1=4.771032 note=collision lift
G1 X208.224934 Y161.465275 Z5.733058 E16986.770044 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.771032 matz1=4.73911 note=collision lift
G1 X208.224852 Y161.465532 Z5.733172 E16986.770345 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.73911 matz1=4.739089 note=collision lift
G1 X207.951492 Y162.325972 Z5.837687 E16987.705053 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.739089 matz1=4.669886 note=collision lift
G1 X207.951447 Y162.326114 Z5.837603 E16987.70521 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.669886 matz1=4.669876 note=collision lift
G1 X207.937299 Y162.370646 Z5.842991 E16987.748596 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.669876 matz1=4.666793 note=collision lift
G1 X207.937289 Y162.370676 Z5.843004 E16987.748628 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.666793 matz1=4.666791 note=collision lift
G1 X207.847558 Y162.653117 Z5.877126 E16988.023792 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.666791 matz1=4.647234 note=collision lift
G1 X207.847467 Y162.653405 Z5.877257 E16988.024096 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.647234 matz1=4.647214 note=collision lift
G1 X207.715559 Y162.892602 Z5.911337 E16988.158045 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.647214 matz1=4.633015 note=collision lift
G1 X207.713183 Y162.896909 Z5.91354 E16988.160667 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.633015 matz1=4.632759 note=collision lift
G1 X207.190313 Y163.845064 Z6.016508 E16988.689919 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.632759 matz1=4.576476 note=collision lift
G1 X207.189372 Y163.846771 Z6.015433 E16988.691002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.576476 matz1=4.576375 note=collision lift
G1 X206.982137 Y164.222564 Z6.053224 E16988.900633 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.576375 matz1=4.554067 note=collision lift
G1 X206.98185 Y164.223085 Z6.053491 E16988.90095 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.554067 matz1=4.554036 note=collision lift
G1 X206.717882 Y164.53628 Z6.043089 E16989.008514 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.554036 matz1=4.543089 note=collision lift
G1 X206.711151 Y164.544266 Z6.04281 E16989.011257 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.543089 matz1=4.54281 note=collision lift
G1 X205.826636 Y165.593732 Z6.006128 E16989.371698 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.54281 matz1=4.506128 note=collision lift
G1 X205.8205 Y165.598634 Z6.006127 E16989.373752 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506128 matz1=4.506127 note=collision lift
G1 X205.50766 Y165.848595 Z6.006079 E16989.478469 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506127 matz1=4.506079 note=collision lift
G1 X205.50601 Y165.849913 Z6.006078 E16989.479021 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506079 matz1=4.506078 note=collision lift
G1 X205.348172 Y165.976026 Z6.006054 E16989.531854 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506078 matz1=4.506054 note=collision lift
G1 X205.347077 Y165.976901 Z6.006054 E16989.53222 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506054 matz1=4.506054 note=collision lift
G1 X205.268428 Y166.039742 Z6.006042 E16989.558547 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506054 matz1=4.506042 note=collision lift
G1 X205.267592 Y166.04041 Z6.006041 E16989.558826 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506042 matz1=4.506041 note=collision lift
G1 X205.229812 Y166.070596 Z6.006036 E16989.571472 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506041 matz1=4.506036 note=collision lift
G1 X205.228556 Y166.0716 Z6.006035 E16989.571893 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506036 matz1=4.506035 note=collision lift
G1 X205.188684 Y166.103458 Z6.006029 E16989.585239 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506035 matz1=4.506029 note=collision lift
G1 X204.426219 Y166.71267 Z5.652774 E16989.856663 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506029 matz1=4.505911 note=collision lift
G1 X202.834417 Y167.536901 Z4.803989 E16990.815803 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.505911 matz1=4.553395 note=collision lift
G1 X202.728664 Y167.567475 Z4.753377 E16990.876907 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.553395 matz1=4.557824 note=collision lift
G1 X201.112401 Y168.03475 Z4.000507 E16992.004443 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.557824 matz1=4.000507 note=collision lift
G1 X200.112595 Y168.120024 Z3.572835 E16993.093919 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.000507 matz1=3.572835 note=collision lift
G1 X199.958199 Y168.133192 Z3.582034 E16993.248963 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.572835 matz1=3.582034 note=collision lift
G1 X199.955358 Y168.133435 Z3.580818 E16993.252059 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.582034 matz1=3.580818 note=collision lift
G1 X199.436183 Y168.177715 Z3.592506 E16993.77263 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.580818 matz1=3.592506 note=collision lift
G1 X199.433436 Y168.17795 Z3.591359 E16993.777233 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.592506 matz1=3.591359 note=collision lift
G1 X199.329892 Y168.186781 Z3.592536 E16993.937438 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.591359 matz1=3.592536 note=collision lift
G1 X199.326349 Y168.187083 Z3.594613 E16993.943787 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.592536 matz1=3.594613 note=collision lift
G1 X198.594941 Y168.105366 Z3.581623 E16995.654347 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.594613 matz1=3.581623 note=collision lift
G1 X198.588632 Y168.104661 Z3.585389 E16995.671501 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.581623 matz1=3.585389 note=collision lift
G1 X198.022841 Y168.041447 Z3.551682 E16996.996839 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.585389 matz1=3.551682 note=collision lift
G1 X197.544895 Y167.988048 Z3.763668 E16998.218206 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.551682 matz1=3.763668 note=collision lift
G1 X197.530211 Y167.983383 Z3.765324 E16998.268184 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.763668 matz1=3.765324 note=collision lift
G1 X197.110668 Y167.850095 Z3.964101 E16999.825963 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.765324 matz1=3.964101 note=collision lift
G1 X195.836502 Y167.445294 Z4.776281 E17004.871077 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.964101 matz1=4.776281 note=collision lift
G1 X194.634766 Y166.782584 Z5.621134 E17011.264693 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.776281 matz1=5.298229 note=collision lift
G1 X196.218968 Y169.493265 Z4.423438 E17030.445246 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.298229 matz1=4.423438 note=collision lift
G1 X196.437865 Y169.949629 Z4.22697 E17034.073734 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.423438 matz1=4.22697 note=collision lift
G1 X197.025206 Y171.174143 Z4.378854 E17043.206482 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X198.260608 Y173.749761 Z4.64932 E17058.410355 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X199.556112 Y177.033877 Z4.857619 E17079.446491 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X200.72588 Y180.644997 Z4.885128 E17102.351285 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X201.708265 Y184.555705 Z4.68637 E17124.209147 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X202.441414 Y188.739562 Z4.278558 E17141.886312 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X202.861305 Y193.170693 Z3.755512 E17153.142757 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X202.934812 Y195.470227 Z3.498471 E17157.10193 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X200.863981 Y194.467771 Z3.278911 E17159.472232 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X196.986727 Y192.281877 Z3.024383 E17160.50627 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.462781 Y189.910385 Z3.044335 E17161.755722 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.289744 Y187.422303 Z3.29733 E17166.131291 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.466609 Y184.884891 Z3.687116 E17174.901684 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.993349 Y182.36562 Z4.104413 E17187.698261 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X183.142888 Y180.189426 Z4.423875 E17200.908199 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X181.935256 Y178.769216 Z4.602061 E17215.378841 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X179.655218 Y175.595823 Z4.850795 E17250.188934 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X178.799715 Y174.205998 Z4.893374 E17265.02836 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X178.567001 Y173.827938 Z4.898152 E17269.073757 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X177.591168 Y171.896329 Z4.879216 E17288.601985 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X177.577577 Y171.869427 Z4.87846 E17288.87393 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.342623 Y170.080332 Z4.78679 E17307.48168 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.229855 Y169.916963 Z4.877674 E17309.348771 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.78679 matz1=4.877674 note=collision lift
G1 X176.255906 Y169.93133 Z4.890805 E17309.626606 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.877674 matz1=4.890805 note=collision lift
G1 X177.626553 Y171.086544 Z5.661638 E17325.152794 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.890805 matz1=5.661638 note=collision lift
G1 X178.075891 Y171.648917 Z5.960795 E17331.13399 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.661638 matz1=5.960795 note=collision lift
G1 X178.745491 Y172.48696 Z6.39704 E17339.477052 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.960795 matz1=5.990373 note=collision lift
G1 X178.804377 Y172.600684 Z6.398152 E17340.309638 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.990373 matz1=5.977078 note=collision lift
G1 X179.411811 Y173.773795 Z6.398152 E17348.897815 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.977078 matz1=5.83994 note=collision lift
G1 X179.569722 Y174.078762 Z6.398152 E17351.069818 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.83994 matz1=5.802203 note=collision lift
G1 X179.668185 Y174.419336 Z6.398152 E17352.970476 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.802203 matz1=5.761468 note=collision lift
G1 X179.668208 Y174.419415 Z6.398183 E17352.970947 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.761468 matz1=5.761458 note=collision lift
G1 X179.816632 Y174.932803 Z6.393405 E17355.836153 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.761458 matz1=5.700054 note=collision lift
G1 X179.816651 Y174.932869 Z6.393431 E17355.836542 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.700054 matz1=5.700046 note=collision lift
G1 X179.954972 Y175.41131 Z6.382142 E17358.50729 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.700046 matz1=5.642821 note=collision lift
G1 X179.954997 Y175.411395 Z6.382087 E17358.507846 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.642821 matz1=5.642811 note=collision lift
G1 X179.981068 Y175.501572 Z6.379912 E17359.011235 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.642811 matz1=5.632025 note=collision lift
G1 X179.98108 Y175.501614 Z6.379929 E17359.011487 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.632025 matz1=5.63202 note=collision lift
G1 X180.067258 Y175.799695 Z6.372634 E17360.675463 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.63202 matz1=5.596367 note=collision lift
G1 X180.06757 Y175.800778 Z6.373068 E17360.681937 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.596367 matz1=5.596238 note=collision lift
G1 X180.147866 Y176.742213 Z6.351325 E17364.805693 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.596238 matz1=5.483778 note=collision lift
G1 X180.148066 Y176.744562 Z6.352223 E17364.816702 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.483778 matz1=5.483497 note=collision lift
G1 X180.219904 Y177.586831 Z6.294362 E17368.513737 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.483497 matz1=5.382883 note=collision lift
G1 X180.21977 Y177.588028 Z6.293619 E17368.518522 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.382883 matz1=5.382742 note=collision lift
G1 X180.174595 Y177.992367 Z6.258652 E17369.899272 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.382742 matz1=5.335086 note=collision lift
G1 X180.174432 Y177.993828 Z6.257745 E17369.905111 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.335086 matz1=5.334914 note=collision lift
G1 X180.151941 Y178.195135 Z6.235014 E17370.594316 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.334914 matz1=5.311188 note=collision lift
G1 X180.151836 Y178.196074 Z6.234431 E17370.59807 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.311188 matz1=5.311077 note=collision lift
G1 X180.140837 Y178.294517 Z6.219973 E17370.936549 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.311077 matz1=5.299475 note=collision lift
G1 X180.140613 Y178.29652 Z6.220744 E17370.943845 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.299475 matz1=5.299239 note=collision lift
G1 X180.129286 Y178.397904 Z6.197701 E17371.297473 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.299239 matz1=5.28729 note=collision lift
G1 X180.020869 Y179.368284 Z5.595122 E17375.177066 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.28729 matz1=5.17292 note=collision lift
G1 X179.478114 Y181.076677 Z4.50289 E17380.350654 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.17292 matz1=4.50289 note=collision lift
G1 X179.424883 Y181.173206 Z4.436407 E17380.661089 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50289 matz1=4.436407 note=collision lift
G1 X178.917535 Y182.093213 Z3.810737 E17382.014271 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.436407 matz1=3.810737 note=collision lift
G1 X178.783529 Y182.336215 Z3.922981 E17382.345526 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.810737 matz1=3.922981 note=collision lift
G1 X178.746868 Y182.402695 Z3.923409 E17382.42954 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.922981 matz1=3.923409 note=collision lift
G1 X178.746839 Y182.402748 Z3.923373 E17382.429618 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923409 matz1=3.923373 note=collision lift
G1 X178.612497 Y182.646358 Z3.923373 E17382.737474 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923373 matz1=3.923373 note=collision lift
G1 X178.100047 Y183.254374 Z3.923373 E17383.290172 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923373 matz1=3.923373 note=collision lift
G1 X177.528228 Y183.93283 Z4.297412 E17383.95946 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.923373 matz1=4.297412 note=collision lift
G1 X177.457284 Y184.017004 Z4.344969 E17384.080289 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.297412 matz1=4.344969 note=collision lift
G1 X176.056867 Y185.135943 Z5.141413 E17385.140867 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.344969 matz1=4.565602 note=collision lift
G1 X174.465065 Y185.960174 Z5.982541 E17385.70082 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.565602 matz1=4.510462 note=collision lift
G1 X174.347388 Y185.994195 Z6.009553 E17385.730314 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510462 matz1=4.509553 note=collision lift
G1 X173.653167 Y186.1949 Z6.004187 E17385.900238 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.509553 matz1=4.504187 note=collision lift
G1 X173.651498 Y186.195383 Z6.004174 E17385.900646 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.504187 matz1=4.504174 note=collision lift
G1 X173.146565 Y186.341363 Z6.000272 E17386.024238 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.504174 matz1=4.500272 note=collision lift
G1 X173.1476 Y186.341634 Z6.0003 E17386.024898 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.500272 matz1=4.5003 note=collision lift
G1 X173.613264 Y186.463663 Z6.012827 E17386.322151 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.5003 matz1=4.512827 note=collision lift
G1 X173.613286 Y186.463669 Z6.012827 E17386.322165 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.512827 matz1=4.512827 note=collision lift
G1 X174.355736 Y186.658232 Z6.0328 E17386.796103 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.512827 matz1=4.5328 note=collision lift
G1 X176.183755 Y187.137274 Z5.145548 E17388.084785 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.5328 matz1=4.581977 note=collision lift
G1 X177.942343 Y187.755759 Z4.32678 E17390.420765 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.581977 matz1=4.32678 note=collision lift
G1 X179.025733 Y188.13678 Z3.85339 E17392.342051 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.32678 matz1=3.85339 note=collision lift
G1 X179.286063 Y188.228336 Z3.847212 E17392.768987 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.85339 matz1=3.847212 note=collision lift
G1 X179.286663 Y188.228548 Z3.847587 E17392.77013 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.847212 matz1=3.847587 note=collision lift
G1 X180.418937 Y188.626761 Z3.788803 E17394.6288 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.847587 matz1=3.788803 note=collision lift
G1 X180.421679 Y188.627726 Z3.787605 E17394.633663 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.788803 matz1=3.787605 note=collision lift
G1 X180.63647 Y188.703266 Z3.775532 E17394.986322 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.787605 matz1=3.775532 note=collision lift
G1 X180.636546 Y188.703299 Z3.7755 E17394.986569 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.775532 matz1=3.7755 note=collision lift
G1 X180.746738 Y188.75117 Z3.768478 E17395.320786 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.7755 matz1=3.768478 note=collision lift
G1 X180.748585 Y188.751973 Z3.76971 E17395.327342 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.768478 matz1=3.76971 note=collision lift
G1 X182.659731 Y189.582239 Z3.69251 E17401.11803 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.76971 matz1=3.69251 note=collision lift
G1 X183.875677 Y190.110486 Z3.840637 E17404.822674 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.255795 Y191.835958 Z4.286017 E17420.740946 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.715895 Y193.906602 Z4.675037 E17442.531282 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X194.192531 Y196.346758 Z4.886499 E17468.210675 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X197.622817 Y199.182932 Z4.828473 E17494.283463 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X199.301167 Y200.757284 Z4.688871 E17506.783505 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X197.127571 Y201.51288 Z4.487913 E17517.86065 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X192.840273 Y202.70863 Z3.990455 E17532.390625 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.671707 Y203.523749 Z3.501933 E17539.748796 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.668541 Y204.008027 Z3.151692 E17542.294305 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X180.878837 Y204.209506 Z3.004376 E17542.938244 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X177.347307 Y204.177561 Z3.056878 E17544.115338 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.500714 Y203.947353 Z3.227498 E17546.590878 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.642603 Y203.797084 Z3.390414 E17550.445551 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X168.786845 Y203.164606 Z3.818504 E17566.412605 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.19861 Y202.787618 Z4.012907 E17574.585141 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X166.767377 Y202.68526 Z4.065577 E17576.914012 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X164.711058 Y202.008187 Z4.314703 E17590.823882 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X164.682542 Y201.998797 Z4.31801 E17591.017137 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.348789 Y201.571379 Z4.559046 E17608.964631 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.377505 Y201.563077 Z4.561781 E17609.190917 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X164.163558 Y201.410744 Z4.708659 E17623.985046 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X164.878808 Y201.490656 Z4.7572 E17630.082237 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.945011 Y201.609779 Z4.817204 E17639.466292 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.325972 Y202.048508 Z4.873106 E17652.509203 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.653405 Y202.152533 Z4.881933 E17655.614652 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.223085 Y203.01815 Z4.899575 E17671.960811 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.593732 Y204.173364 Z4.869238 E17688.054134 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.71267 Y205.573781 Z4.792455 E17703.515565 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.536901 Y207.165583 Z4.673105 E17717.994184 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.567475 Y207.271336 Z4.664513 E17718.879649 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.929713 Y208.524286 Z4.55033 E17725.277708 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.967085 Y208.653553 Z4.605829 E17725.989016 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.55033 matz1=4.605829 note=collision lift
G1 X172.967635 Y208.655453 Z4.604667 E17726.000228 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.605829 matz1=4.604667 note=collision lift
G1 X172.991007 Y208.736297 Z4.628476 E17726.427618 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.604667 matz1=4.628476 note=collision lift
G1 X172.992298 Y208.740761 Z4.630393 E17726.452179 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.628476 matz1=4.630393 note=collision lift
G1 X173.031209 Y208.875353 Z4.65783 E17727.149845 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.630393 matz1=4.65783 note=collision lift
G1 X173.03475 Y208.887599 Z4.663088 E17727.21723 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.65783 matz1=4.663088 note=collision lift
G1 X173.065096 Y209.243403 Z4.714731 E17728.786331 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.663088 matz1=4.714731 note=collision lift
G1 X173.06591 Y209.252939 Z4.718535 E17728.831118 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.714731 matz1=4.718535 note=collision lift
G1 X173.121813 Y209.908378 Z4.770529 E17731.700771 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.718535 matz1=4.770529 note=collision lift
G1 X173.121962 Y209.910125 Z4.769472 E17731.709675 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.770529 matz1=4.769472 note=collision lift
G1 X173.177715 Y210.563817 Z4.792378 E17734.564519 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.769472 matz1=4.792378 note=collision lift
G1 X173.178091 Y210.568221 Z4.789687 E17734.597983 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.792378 matz1=4.789687 note=collision lift
G1 X173.186566 Y210.667588 Z4.791214 E17735.243004 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.789687 matz1=4.791214 note=collision lift
G1 X173.187083 Y210.673651 Z4.793594 E17735.285263 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.791214 matz1=4.793594 note=collision lift
G1 X173.117431 Y211.297075 Z4.806401 E17738.744595 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.793594 matz1=4.806401 note=collision lift
G1 X173.115612 Y211.31335 Z4.812727 E17738.841389 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.806401 matz1=4.812727 note=collision lift
G1 X172.988048 Y212.455105 Z4.78688 E17745.177189 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.812727 matz1=4.78688 note=collision lift
G1 X172.983674 Y212.468874 Z4.77794 E17745.25394 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.78688 matz1=4.77794 note=collision lift
G1 X172.864719 Y212.843302 Z4.758245 E17747.031009 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.77794 matz1=4.758245 note=collision lift
G1 X172.863864 Y212.845991 Z4.759321 E17747.044651 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.758245 matz1=4.759321 note=collision lift
G1 X172.73968 Y213.236877 Z4.717767 E17748.90699 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.759321 matz1=4.717767 note=collision lift
G1 X172.737408 Y213.244029 Z4.713124 E17748.946853 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.717767 matz1=4.713124 note=collision lift
G1 X172.693347 Y213.382717 Z4.686389 E17749.615258 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.713124 matz1=4.686389 note=collision lift
G1 X172.692135 Y213.386532 Z4.687915 E17749.63461 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.686389 matz1=4.687915 note=collision lift
G1 X172.6449 Y213.535209 Z4.637474 E17750.375284 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.687915 matz1=4.637474 note=collision lift
G1 X172.445294 Y214.163498 Z4.229554 E17753.877504 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.637474 matz1=4.229554 note=collision lift
G1 X172.142348 Y214.712849 Z3.841638 E17756.649373 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.229554 matz1=3.841638 note=collision lift
G1 X171.782584 Y215.365234 Z3.753471 E17759.468651 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X172.950741 Y214.682528 Z3.606015 E17762.40524 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.843145 Y214.160981 Z3.581387 E17764.636048 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.606015 matz1=3.581387 note=collision lift
G1 X173.847518 Y214.158426 Z3.578302 E17764.648842 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.581387 matz1=3.578302 note=collision lift
G1 X174.484339 Y213.786249 Z3.557189 E17766.240952 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.578302 matz1=3.557189 note=collision lift
G1 X174.493265 Y213.781032 Z3.561232 E17766.264905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.557189 matz1=3.561232 note=collision lift
G1 X174.999523 Y213.538204 Z3.522138 E17767.039858 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.561232 matz1=3.522138 note=collision lift
G1 X175.661068 Y213.220892 Z3.823295 E17768.13186 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.522138 matz1=3.823295 note=collision lift
G1 X175.813545 Y213.147756 Z3.842214 E17768.366152 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.823295 matz1=3.842214 note=collision lift
G1 X175.828764 Y213.140456 Z3.849142 E17768.391275 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.842214 matz1=3.849142 note=collision lift
G1 X176.174143 Y212.974794 Z3.81523 E17768.920749 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.849142 matz1=3.81523 note=collision lift
G1 X176.181628 Y212.971204 Z3.81056 E17768.924191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.81523 matz1=3.81056 note=collision lift
G1 X176.499554 Y212.81871 Z3.74047 E17769.054106 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.81056 matz1=3.74047 note=collision lift
G1 X176.501723 Y212.817669 Z3.741523 E17769.055055 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.74047 matz1=3.741523 note=collision lift
G1 X176.980084 Y212.588222 Z3.59873 E17769.253601 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.741523 matz1=3.59873 note=collision lift
G1 X176.983736 Y212.58647 Z3.596451 E17769.25528 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.59873 matz1=3.596451 note=collision lift
G1 X177.458444 Y212.358776 Z3.427648 E17769.455079 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.596451 matz1=3.427648 note=collision lift
G1 X177.46871 Y212.353851 Z3.421244 E17769.4598 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.427648 matz1=3.421244 note=collision lift
G1 X177.680879 Y212.252084 Z3.330945 E17769.550882 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.421244 matz1=3.330945 note=collision lift
G1 X177.690424 Y212.247506 Z3.335577 E17769.555057 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.330945 matz1=3.335577 note=collision lift
G1 X178.749761 Y211.739392 Z3.065893 E17769.990672 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.335577 matz1=3.065893 note=collision lift
G1 X182.033877 Y210.443888 Z3.002261 E17770.566065 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X185.644997 Y209.27412 Z3.138123 E17772.79412 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X189.555705 Y208.291735 Z3.479538 E17779.47582 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.739562 Y207.558586 Z3.964894 E17793.005181 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X198.170693 Y207.138695 Z4.466647 E17814.187706 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X200.470227 Y207.065188 Z4.672498 E17826.594142 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X199.467771 Y209.136019 Z4.818377 E17840.024653 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X197.281877 Y213.013273 Z4.890469 E17866.959519 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X194.910385 Y216.537219 Z4.691353 E17890.048409 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X192.422303 Y219.710256 Z4.309911 E17907.222881 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X189.884891 Y222.533391 Z3.866087 E17918.139561 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.36562 Y225.006651 Z3.468033 E17923.878344 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X185.189426 Y226.857112 Z3.211151 E17926.213851 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X183.769216 Y228.064744 Z3.092714 E17927.460737 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X180.595823 Y230.344782 Z3.000986 E17928.392837 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X179.205998 Y231.200285 Z3.029686 E17929.001202 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X178.827938 Y231.432999 Z3.044257 E17929.197022 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.896329 Y232.408832 Z3.154522 E17931.269878 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.869427 Y232.422423 Z3.156495 E17931.29905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.916963 Y233.770145 Z3.34493 E17935.695147 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.93133 Y233.744094 Z3.347672 E17935.750717 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.086544 Y232.373447 Z3.526976 E17940.612267 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X176.648917 Y231.924109 Z3.605546 E17942.832491 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X177.48696 Y231.254509 Z3.727655 E17946.759362 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X178.773795 Y230.588189 Z3.898594 E17953.233318 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X179.078762 Y230.430278 Z3.939567 E17954.834103 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X180.800778 Y229.93243 Z4.152007 E17964.982337 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X182.586831 Y229.780096 Z4.35424 E17976.83027 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.368284 Y229.979131 Z4.536048 E17990.196026 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X186.076677 Y230.521886 Z4.688245 E18004.82203 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X186.173206 Y230.575117 Z4.696457 E18005.724969 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.646358 Y231.387503 Z4.803142 E18015.46544 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.93283 Y232.471772 Z4.871844 E18025.55607 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X189.017004 Y232.542716 Z4.874932 E18026.547581 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.135943 Y233.943133 Z4.899988 E18042.898012 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.960174 Y235.534935 Z4.877045 E18059.055813 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.341363 Y236.853435 Z4.827667 E18071.117196 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X192.137274 Y233.816245 Z4.620471 E18095.701819 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X192.755759 Y232.057657 Z4.445933 E18108.802114 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.703266 Y229.36353 Z4.129746 E18119.372001 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X195.110486 Y226.124323 Z3.711792 E18127.819592 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X196.835958 Y222.744205 Z3.316226 E18132.176807 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X196.848604 Y222.723074 Z3.314615 E18132.184688 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X197.691268 Y221.314959 Z3.297426 E18132.708749 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.314615 matz1=3.297426 note=collision lift
G1 X197.691956 Y221.31381 Z3.298008 E18132.709215 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.297426 matz1=3.298008 note=collision lift
G1 X198.887126 Y219.31665 Z3.513377 E18133.455637 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.298008 matz1=3.513377 note=collision lift
G1 X198.887716 Y219.315665 Z3.512728 E18133.456058 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.513377 matz1=3.512728 note=collision lift
G1 X198.906597 Y219.284114 Z3.516081 E18133.467849 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.512728 matz1=3.516081 note=collision lift
G1 X198.906602 Y219.284105 Z3.516085 E18133.467852 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.516081 matz1=3.516085 note=collision lift
G1 X198.965776 Y219.199796 Z3.52504 E18133.490079 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.516085 matz1=3.52504 note=collision lift
G1 X198.968337 Y219.196148 Z3.527234 E18133.491146 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.52504 matz1=3.527234 note=collision lift
G1 X200.271318 Y217.339714 Z3.717058 E18133.980424 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.527234 matz1=3.717058 note=collision lift
G1 X200.272251 Y217.338384 Z3.716233 E18133.980816 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.717058 matz1=3.716233 note=collision lift
G1 X201.223247 Y215.983443 Z3.775738 E18134.336906 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.716233 matz1=3.775738 note=collision lift
G1 X201.22474 Y215.981316 Z3.774418 E18134.337533 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.775738 matz1=3.774418 note=collision lift
G1 X201.346552 Y215.807763 Z3.781134 E18134.383138 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.774418 matz1=3.781134 note=collision lift
G1 X201.346758 Y215.807469 Z3.78131 E18134.383224 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.781134 matz1=3.78131 note=collision lift
G1 X201.595499 Y215.506623 Z3.790536 E18134.761855 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.78131 matz1=3.790536 note=collision lift
G1 X201.596359 Y215.505584 Z3.791284 E18134.76335 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.790536 matz1=3.791284 note=collision lift
G1 X202.021137 Y214.991824 Z3.801954 E18135.409847 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.791284 matz1=3.801954 note=collision lift
G1 X202.022085 Y214.990678 Z3.801292 E18135.411426 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.801954 matz1=3.801292 note=collision lift
G1 X202.233527 Y214.734944 Z3.801468 E18135.733191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.801292 matz1=3.801468 note=collision lift
G1 X202.234181 Y214.734152 Z3.80101 E18135.734281 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.801468 matz1=3.80101 note=collision lift
G1 X202.338468 Y214.60802 Z3.797662 E18135.893014 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.80101 matz1=3.797662 note=collision lift
G1 X202.339721 Y214.606504 Z3.798752 E18135.895195 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.797662 matz1=3.798752 note=collision lift
G1 X202.445916 Y214.478064 Z3.786809 E18136.057213 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.798752 matz1=3.786809 note=collision lift
G1 X203.045677 Y213.752667 Z3.367377 E18137.056429 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.786809 matz1=3.367377 note=collision lift
G1 X204.182932 Y212.377183 Z4.356802 E18139.03522 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.367377 matz1=4.356802 note=collision lift
G1 X205.391845 Y211.088413 Z5.405498 E18142.405969 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.356802 matz1=4.926162 note=collision lift
G1 X205.574564 Y210.893623 Z5.468128 E18142.855975 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.926162 matz1=4.951128 note=collision lift
G1 X205.5766 Y210.891453 Z5.466919 E18142.861243 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.951128 matz1=4.951407 note=collision lift
G1 X205.757284 Y210.698833 Z5.509921 E18143.300189 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.951407 matz1=4.976094 note=collision lift
G1 X205.757903 Y210.700612 Z5.509187 E18143.305108 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.976094 matz1=4.976303 note=collision lift
G1 X205.813869 Y210.861609 Z5.501446 E18143.720386 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.976303 matz1=4.995151 note=collision lift
G1 X205.814159 Y210.862442 Z5.501985 E18143.722901 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.995151 matz1=4.995248 note=collision lift
G1 X205.875186 Y211.037997 Z5.485013 E18144.177148 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.995248 matz1=5.015801 note=collision lift
G1 X205.876616 Y211.04211 Z5.483317 E18144.18852 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.015801 matz1=5.016282 note=collision lift
G1 X205.9057 Y211.125775 Z5.468283 E18144.407189 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.016282 matz1=5.026077 note=collision lift
G1 X205.907454 Y211.130821 Z5.466202 E18144.421143 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.026077 matz1=5.026668 note=collision lift
G1 X205.920957 Y211.169664 Z5.454913 E18144.524934 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.026668 matz1=5.031215 note=collision lift
G1 X205.928585 Y211.191607 Z5.445867 E18144.585612 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.031215 matz1=5.033784 note=collision lift
G1 X205.928585 Y211.191608 Z5.445868 E18144.585616 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.033784 matz1=5.033784 note=collision lift
G1 X206.51288 Y212.872429 Z4.752903 E18149.233502 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.033784 matz1=4.752903 note=collision lift
G1 X207.062189 Y214.841945 Z3.971226 E18158.137169 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.752903 matz1=3.971226 note=collision lift
G1 X207.70863 Y217.159727 Z4.254447 E18167.99199 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.523749 Y221.328293 Z4.669941 E18190.880175 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.008027 Y225.331459 Z4.880283 E18215.18345 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.209506 Y229.121163 Z4.864867 E18237.843228 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.177561 Y232.652693 Z4.666333 E18256.773761 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.947353 Y235.499286 Z4.401533 E18269.755176 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.797084 Y237.357397 Z4.195184 E18280.678421 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.164606 Y241.213155 Z3.733457 E18295.095879 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.787618 Y242.80139 Z3.549583 E18299.702585 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.68526 Y243.232623 Z3.502247 E18300.853907 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.008187 Y245.288942 Z3.293573 E18304.348976 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.998797 Y245.317458 Z3.290987 E18304.397035 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.636635 Y247.294905 Z3.145311 E18305.99086 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.571379 Y247.651211 Z3.300179 E18306.302372 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.145311 matz1=3.300179 note=collision lift
G1 X206.563077 Y247.622495 Z3.313401 E18306.327954 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.300179 matz1=3.313401 note=collision lift
G1 X206.410744 Y245.836442 Z4.128551 E18307.122069 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.313401 matz1=4.128551 note=collision lift
G1 X206.490656 Y245.121192 Z4.46867 E18307.369618 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.128551 matz1=4.46867 note=collision lift
G1 X206.609779 Y244.054989 Z4.989872 E18307.655653 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.46867 matz1=4.501273 note=collision lift
G1 X206.648952 Y243.931684 Z5.002241 E18307.690944 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501273 matz1=4.501878 note=collision lift
G1 X206.648971 Y243.931626 Z5.002272 E18307.690963 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501878 matz1=4.501879 note=collision lift
G1 X206.775081 Y243.534678 Z5.049582 E18307.804784 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501879 matz1=4.503828 note=collision lift
G1 X206.775148 Y243.534468 Z5.049693 E18307.804851 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.503828 matz1=4.503829 note=collision lift
G1 X207.048508 Y242.674028 Z5.157184 E18308.051729 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.503829 matz1=4.508055 note=collision lift
G1 X207.048561 Y242.673863 Z5.157101 E18308.051787 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.508055 matz1=4.508058 note=collision lift
G1 X207.062703 Y242.629349 Z5.162639 E18308.065924 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.508058 matz1=4.508902 note=collision lift
G1 X207.062711 Y242.629324 Z5.162652 E18308.065932 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.508902 matz1=4.508902 note=collision lift
G1 X207.152458 Y242.346832 Z5.197752 E18308.155643 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.508902 matz1=4.514256 note=collision lift
G1 X207.152533 Y242.346595 Z5.197881 E18308.155727 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.514256 matz1=4.514261 note=collision lift
G1 X207.284179 Y242.107874 Z5.232861 E18308.315811 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.514261 matz1=4.523426 note=collision lift
G1 X207.286817 Y242.103091 Z5.235776 E18308.319417 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.523426 matz1=4.52361 note=collision lift
G1 X207.809687 Y241.154936 Z5.376905 E18308.955404 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.52361 matz1=4.560014 note=collision lift
G1 X207.811093 Y241.152386 Z5.375547 E18308.957275 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.560014 matz1=4.560112 note=collision lift
G1 X208.017807 Y240.777538 Z5.427214 E18309.208409 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.560112 matz1=4.574504 note=collision lift
G1 X208.01815 Y240.776915 Z5.427594 E18309.208879 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.574504 matz1=4.574528 note=collision lift
G1 X208.280771 Y240.465319 Z5.471084 E18309.647888 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.574528 matz1=4.598285 note=collision lift
G1 X208.288849 Y240.455734 Z5.478082 E18309.663266 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.598285 matz1=4.599016 note=collision lift
G1 X209.173364 Y239.406268 Z5.593042 E18311.138661 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.599016 matz1=4.67903 note=collision lift
G1 X209.183237 Y239.39838 Z5.587734 E18311.16254 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.67903 matz1=4.680041 note=collision lift
G1 X209.49234 Y239.151405 Z5.594042 E18311.851933 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.680041 matz1=4.711705 note=collision lift
G1 X209.495121 Y239.149183 Z5.592548 E18311.858658 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.711705 matz1=4.71199 note=collision lift
G1 X209.651828 Y239.023974 Z5.585965 E18312.208306 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.71199 matz1=4.728043 note=collision lift
G1 X209.653818 Y239.022384 Z5.584895 E18312.213118 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.728043 matz1=4.728247 note=collision lift
G1 X209.731572 Y238.960258 Z5.575396 E18312.3873 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.728247 matz1=4.736212 note=collision lift
G1 X209.733332 Y238.958852 Z5.57445 E18312.391557 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.736212 matz1=4.736392 note=collision lift
G1 X209.771444 Y238.9284 Z5.565667 E18312.477914 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.736392 matz1=4.740296 note=collision lift
G1 X209.773783 Y238.926531 Z5.56441 E18312.483569 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.740296 matz1=4.740536 note=collision lift
G1 X209.790506 Y238.913169 Z5.558051 E18312.522474 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.740536 matz1=4.742249 note=collision lift
G1 X209.79138 Y238.912471 Z5.5587 E18312.524727 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.742249 matz1=4.742338 note=collision lift
G1 X210.573781 Y238.28733 Z5.13811 E18314.417114 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.742338 matz1=4.822486 note=collision lift
G1 X212.165583 Y237.463099 Z4.417004 E18319.366239 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.822486 matz1=4.417004 note=collision lift
G1 X212.271336 Y237.432525 Z4.373561 E18319.6758 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.417004 matz1=4.373561 note=collision lift
G1 X213.308877 Y237.132563 Z3.953215 E18322.370458 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.373561 matz1=3.953215 note=collision lift
G1 X213.563953 Y237.058819 Z4.115397 E18323.093877 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.953215 matz1=4.115397 note=collision lift
G1 X213.566035 Y237.058217 Z4.114554 E18323.099284 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.115397 matz1=4.114554 note=collision lift
G1 X213.887599 Y236.96525 Z4.114554 E18323.877567 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114554 matz1=4.114554 note=collision lift
G1 X215.563817 Y236.822285 Z4.114554 E18328.826289 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114554 matz1=4.114554 note=collision lift
G1 X215.673651 Y236.812917 Z4.114554 E18329.319463 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114554 matz1=4.114554 note=collision lift
G1 X216.040753 Y236.853932 Z4.114554 E18331.340174 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114554 matz1=4.114554 note=collision lift
G1 X217.455105 Y237.011952 Z4.1196 E18339.125522 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114554 matz1=4.1196 note=collision lift
G1 X219.163498 Y237.554706 Z4.324096 E18350.72076 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X220.365234 Y238.217416 Z4.468396 E18360.520745 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X218.781032 Y235.506735 Z4.734576 E18386.821006 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X217.974794 Y233.825857 Z4.83749 E18403.303859 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X216.739392 Y231.250239 Z4.899984 E18420.676904 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X215.443888 Y227.966123 Z4.810392 E18441.163225 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X214.27412 Y224.355003 Z4.529432 E18459.908537 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X213.291735 Y220.444295 Z4.091278 E18474.34228 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X213.285107 Y220.406476 Z4.08678 E18474.419867 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X212.908115 Y218.255091 Z3.941657 E18478.813177 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.08678 matz1=3.941657 note=collision lift
G1 X212.907719 Y218.252835 Z3.942534 E18478.818101 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.941657 matz1=3.942534 note=collision lift
G1 X212.558586 Y216.260438 Z3.833469 E18482.88369 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942534 matz1=3.833469 note=collision lift
G1 X212.558367 Y216.258122 Z3.83209 E18482.885635 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.833469 matz1=3.83209 note=collision lift
G1 X212.537571 Y216.038664 Z3.818799 E18483.044485 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.83209 matz1=3.818799 note=collision lift
G1 X212.537303 Y216.03583 Z3.819958 E18483.046695 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.818799 matz1=3.819958 note=collision lift
G1 X212.485059 Y215.484499 Z3.783588 E18483.445898 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.819958 matz1=3.783588 note=collision lift
G1 X212.138695 Y211.829307 Z5.278711 E18486.297397 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.783588 matz1=4.68068 note=collision lift
G1 X212.082253 Y210.063609 Z6.064512 E18486.922618 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.68068 matz1=4.583182 note=collision lift
G1 X212.07372 Y209.796691 Z6.068443 E18487.008983 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.583182 matz1=4.568443 note=collision lift
G1 X212.073664 Y209.794913 Z6.068345 E18487.009559 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.568443 matz1=4.568345 note=collision lift
G1 X212.065188 Y209.529773 Z6.053704 E18487.09547 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.568345 matz1=4.553704 note=collision lift
G1 X212.066024 Y209.530178 Z6.053683 E18487.095618 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.553704 matz1=4.553683 note=collision lift
G1 X212.220381 Y209.6049 Z6.049764 E18487.122965 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.553683 matz1=4.549764 note=collision lift
G1 X212.221101 Y209.605248 Z6.049746 E18487.123093 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.549764 matz1=4.549746 note=collision lift
G1 X212.388366 Y209.686219 Z6.045499 E18487.152727 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.549746 matz1=4.545499 note=collision lift
G1 X212.389867 Y209.686945 Z6.045461 E18487.152993 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.545499 matz1=4.545461 note=collision lift
G1 X212.471999 Y209.726704 Z6.043376 E18487.167544 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.545461 matz1=4.543376 note=collision lift
G1 X212.473178 Y209.727275 Z6.043346 E18487.167753 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.543376 matz1=4.543346 note=collision lift
G1 X212.512346 Y209.746236 Z6.042351 E18487.174692 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.543346 matz1=4.542351 note=collision lift
G1 X212.513815 Y209.746947 Z6.042314 E18487.174953 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.542351 matz1=4.542314 note=collision lift
G1 X212.555632 Y209.767189 Z6.041253 E18487.182361 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.542314 matz1=4.541253 note=collision lift
G1 X214.136019 Y210.532229 Z5.165074 E18487.495198 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.541253 matz1=4.501128 note=collision lift
G1 X217.90605 Y212.657673 Z3.117847 E18490.050481 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501128 matz1=3.117847 note=collision lift
G1 X218.013273 Y212.718123 Z3.121167 E18490.1162 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X221.537219 Y215.089615 Z3.472668 E18497.062403 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.710256 Y217.577697 Z3.931255 E18509.479238 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X227.533391 Y220.115109 Z4.369424 E18526.391116 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.006651 Y222.63438 Z4.694699 E18545.678605 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X231.857112 Y224.810574 Z4.854451 E18562.668428 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X233.064744 Y226.230784 Z4.897211 E18579.651419 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X233.982296 Y227.507847 Z4.865976 E18593.404928 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.344782 Y229.404177 Z5.987117 E18616.055316 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.865976 matz1=5.987117 note=collision lift
G1 X235.699975 Y229.981213 Z6.286006 E18622.19841 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.987117 matz1=6.279687 note=collision lift
G1 X236.200285 Y230.794002 Z6.32834 E18630.123097 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.279687 matz1=6.223474 note=collision lift
G1 X236.200321 Y230.794061 Z6.328301 E18630.123744 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.223474 matz1=6.22347 note=collision lift
G1 X236.225029 Y230.8342 Z6.330382 E18630.508044 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.22347 matz1=6.220076 note=collision lift
G1 X236.254078 Y230.881392 Z6.332829 E18630.959874 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.220076 matz1=6.216087 note=collision lift
G1 X236.254086 Y230.881405 Z6.332835 E18630.960007 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.216087 matz1=6.216086 note=collision lift
G1 X236.432999 Y231.172062 Z6.347875 E18633.742807 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.216086 matz1=6.191516 note=collision lift
G1 X236.433003 Y231.172071 Z6.347869 E18633.742887 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.191516 matz1=6.191515 note=collision lift
G1 X236.489993 Y231.28488 Z6.353838 E18634.662987 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.191515 matz1=6.180608 note=collision lift
G1 X236.490296 Y231.28548 Z6.354116 E18634.668277 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.180608 matz1=6.18055 note=collision lift
G1 X236.864305 Y232.02581 Z6.382383 E18640.703383 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.18055 matz1=6.108968 note=collision lift
G1 X236.864453 Y232.026103 Z6.38219 E18640.706151 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.108968 matz1=6.10894 note=collision lift
G1 X236.90237 Y232.101157 Z6.384969 E18641.317965 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.10894 matz1=6.101683 note=collision lift
G1 X236.902428 Y232.101271 Z6.385022 E18641.318971 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.101683 matz1=6.101672 note=collision lift
G1 X237.19305 Y232.676542 Z6.396399 E18646.006536 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.101672 matz1=6.04605 note=collision lift
G1 X237.193085 Y232.676613 Z6.396353 E18646.007202 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.04605 matz1=6.046043 note=collision lift
G1 X237.408832 Y233.103671 Z6.396353 E18649.48652 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.046043 matz1=6.004751 note=collision lift
G1 X237.422423 Y233.130573 Z6.396353 E18649.705284 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.004751 matz1=6.001826 note=collision lift
G1 X238.42707 Y234.586019 Z6.396353 E18659.929927 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.001826 matz1=5.811487 note=collision lift
G1 X238.42708 Y234.586033 Z6.39636 E18659.930036 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.811487 matz1=5.811485 note=collision lift
G1 X238.752964 Y235.058146 Z6.394745 E18663.246687 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.811485 matz1=5.749744 note=collision lift
G1 X238.75297 Y235.058155 Z6.394739 E18663.246763 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.749744 matz1=5.749742 note=collision lift
G1 X238.755012 Y235.061112 Z6.394728 E18663.267537 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.749742 matz1=5.749356 note=collision lift
G1 X238.755022 Y235.061127 Z6.394735 E18663.267649 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.749356 matz1=5.749354 note=collision lift
G1 X239.088878 Y235.544789 Z6.393025 E18666.665436 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.749354 matz1=5.686102 note=collision lift
G1 X239.088891 Y235.544808 Z6.393034 E18666.665577 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.686102 matz1=5.686099 note=collision lift
G1 X239.417874 Y236.118488 Z6.391044 E18669.561203 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.686099 matz1=5.607816 note=collision lift
G1 X239.419151 Y236.120715 Z6.392024 E18669.573236 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.607816 matz1=5.607512 note=collision lift
G1 X239.822802 Y236.8246 Z6.361082 E18673.128638 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.607512 matz1=5.511462 note=collision lift
G1 X239.823333 Y236.825527 Z6.360422 E18673.134137 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.511462 matz1=5.511335 note=collision lift
G1 X240.00717 Y237.146102 Z6.340031 E18674.754679 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.511335 matz1=5.46759 note=collision lift
G1 X240.349423 Y237.742922 Z5.914595 E18678.296522 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.46759 matz1=5.38615 note=collision lift
G1 X240.640395 Y238.400257 Z5.46992 E18681.660592 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.38615 matz1=5.300903 note=collision lift
G1 X241.124552 Y239.49402 Z4.733043 E18686.339702 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.300903 matz1=4.733043 note=collision lift
G1 X241.232116 Y239.737019 Z4.570105 E18687.334069 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.733043 matz1=4.570105 note=collision lift
G1 X241.541653 Y240.66158 Z3.975581 E18690.405258 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.570105 matz1=3.975581 note=collision lift
G1 X241.653678 Y241.175588 Z3.659904 E18691.55278 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.975581 matz1=3.659904 note=collision lift
G1 X241.723341 Y241.495232 Z3.790743 E18692.211794 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.659904 matz1=3.790743 note=collision lift
G1 X241.723605 Y241.496441 Z3.79 E18692.214494 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.790743 matz1=3.79 note=collision lift
G1 X241.730892 Y241.529879 Z3.799753 E18692.281052 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.79 matz1=3.799753 note=collision lift
G1 X241.731657 Y241.533387 Z3.80119 E18692.288286 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.799753 matz1=3.80119 note=collision lift
G1 X241.747641 Y241.606729 Z3.816155 E18692.431446 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.80119 matz1=3.816155 note=collision lift
G1 X241.748289 Y241.609699 Z3.817371 E18692.437571 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.816155 matz1=3.817371 note=collision lift
G1 X241.780787 Y241.758814 Z3.838323 E18692.725699 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.817371 matz1=3.838323 note=collision lift
G1 X241.781552 Y241.762323 Z3.839759 E18692.732932 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.838323 matz1=3.839759 note=collision lift
G1 X241.848078 Y242.06757 Z3.868192 E18693.319681 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.839759 matz1=3.868192 note=collision lift
G1 X241.848404 Y242.069067 Z3.867272 E18693.323023 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.868192 matz1=3.867272 note=collision lift
G1 X241.883258 Y242.228987 Z3.873728 E18693.629396 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.867272 matz1=3.873728 note=collision lift
G1 X241.9143 Y242.371422 Z3.93203 E18693.923056 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.873728 matz1=3.93203 note=collision lift
G1 X241.983841 Y243.160115 Z4.257721 E18695.243302 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.93203 matz1=4.257721 note=collision lift
G1 X241.978634 Y243.263836 Z4.301315 E18695.383208 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.257721 matz1=4.301315 note=collision lift
G1 X241.961199 Y243.611137 Z4.397081 E18695.831242 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.301315 matz1=4.397081 note=collision lift
G1 X241.961043 Y243.614244 Z4.395276 E18695.835709 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.397081 matz1=4.395276 note=collision lift
G1 X241.94413 Y243.95114 Z4.438877 E18696.258205 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.395276 matz1=4.438877 note=collision lift
G1 X241.943763 Y243.958439 Z4.441945 E18696.268051 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.438877 matz1=4.441945 note=collision lift
G1 X241.919927 Y244.433249 Z4.45074 E18696.75372 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.441945 matz1=4.45074 note=collision lift
G1 X241.919421 Y244.44332 Z4.444974 E18696.765584 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.45074 matz1=4.444974 note=collision lift
G1 X241.911575 Y244.599618 Z4.437368 E18696.925618 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.444974 matz1=4.437368 note=collision lift
G1 X241.910817 Y244.614719 Z4.443842 E18696.942417 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.437368 matz1=4.443842 note=collision lift
G1 X241.774119 Y245.281877 Z4.316073 E18697.509844 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.443842 matz1=4.316073 note=collision lift
G1 X241.763944 Y245.309361 Z4.29994 E18697.526924 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.316073 matz1=4.29994 note=collision lift
G1 X241.755774 Y245.331428 Z4.293008 E18697.539448 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.29994 matz1=4.293008 note=collision lift
G1 X241.754443 Y245.335023 Z4.294732 E18697.541594 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.293008 matz1=4.294732 note=collision lift
G1 X241.604169 Y245.740915 Z4.152099 E18697.774258 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.294732 matz1=4.152099 note=collision lift
G1 X241.604107 Y245.741082 Z4.152179 E18697.774358 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.152099 matz1=4.152179 note=collision lift
G1 X241.453771 Y246.147142 Z3.985526 E18698.011232 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.152179 matz1=3.985526 note=collision lift
G1 X241.44194 Y246.179098 Z3.966769 E18698.031091 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.985526 matz1=3.966769 note=collision lift
G1 X241.427755 Y246.217413 Z3.947881 E18698.054071 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.966769 matz1=3.947881 note=collision lift
G1 X241.32042 Y246.507326 Z3.947881 E18698.211905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947881 matz1=3.947881 note=collision lift
G1 X241.010264 Y247.067073 Z3.947881 E18698.467896 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947881 matz1=3.947881 note=collision lift
G1 X240.989514 Y247.094706 Z3.947881 E18698.477406 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947881 matz1=3.947881 note=collision lift
G1 X240.989018 Y247.095367 Z3.948274 E18698.477657 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947881 matz1=3.948274 note=collision lift
G1 X240.826975 Y247.311162 Z3.939663 E18698.551959 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.948274 matz1=3.939663 note=collision lift
G1 X240.826699 Y247.31153 Z3.939423 E18698.552101 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939663 matz1=3.939423 note=collision lift
G1 X240.812669 Y247.330213 Z3.932746 E18698.558788 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939423 matz1=3.932746 note=collision lift
G1 X240.351583 Y247.944248 Z3.530122 E18698.797387 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.932746 matz1=3.530122 note=collision lift
G1 X240.241657 Y248.090638 Z3.435863 E18698.851427 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.530122 matz1=3.435863 note=collision lift
G1 X240.086829 Y248.239107 Z3.326051 E18698.91179 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.435863 matz1=3.326051 note=collision lift
G1 X239.906818 Y248.411724 Z3.199449 E18698.978259 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.326051 matz1=3.199449 note=collision lift
G1 X239.827 Y248.488264 Z3.253899 E18699.007553 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.199449 matz1=3.253899 note=collision lift
G1 X239.852349 Y248.261374 Z3.367315 E18699.067259 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.253899 matz1=3.367315 note=collision lift
G1 X239.90758 Y247.767029 Z3.617132 E18699.200511 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.367315 matz1=3.617132 note=collision lift
G1 X239.948296 Y247.40261 Z3.803665 E18699.305135 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.617132 matz1=3.803665 note=collision lift
G1 X240.012151 Y247.201618 Z3.914598 E18699.423103 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.803665 matz1=3.914598 note=collision lift
G1 X240.051728 Y247.077044 Z3.930962 E18699.488317 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.914598 matz1=3.930962 note=collision lift
G1 X240.05224 Y247.07543 Z3.93016 E18699.489245 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.930962 matz1=3.93016 note=collision lift
G1 X240.09116 Y246.952926 Z3.939316 E18699.55304 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.93016 matz1=3.939316 note=collision lift
G1 X240.091305 Y246.952469 Z3.939568 E18699.553308 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939316 matz1=3.939568 note=collision lift
G1 X240.153938 Y246.755323 Z3.94304 E18699.655729 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.939568 matz1=3.94304 note=collision lift
G1 X240.54732 Y245.5171 Z4.626448 E18700.382475 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94304 matz1=4.555846 note=collision lift
G1 X240.766076 Y245.120416 Z4.669024 E18700.834277 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.555846 matz1=4.580221 note=collision lift
G1 X240.766964 Y245.118804 Z4.670043 E18700.836366 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.580221 matz1=4.58032 note=collision lift
G1 X240.972332 Y244.746398 Z4.716612 E18701.26118 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.58032 matz1=4.603204 note=collision lift
G1 X240.972761 Y244.74562 Z4.717105 E18701.262189 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.603204 matz1=4.603252 note=collision lift
G1 X241.278141 Y244.191854 Z4.780909 E18701.893319 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.603252 matz1=4.63728 note=collision lift
G1 X241.278255 Y244.191647 Z4.780803 E18701.893576 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.63728 matz1=4.637293 note=collision lift
G1 X241.50268 Y243.784683 Z4.8294 E18702.35757 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.637293 matz1=4.6623 note=collision lift
G1 X241.503802 Y243.783351 Z4.828646 E18702.359459 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.6623 matz1=4.662416 note=collision lift
G1 X241.506952 Y243.779614 Z4.829095 E18702.364344 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.662416 matz1=4.662743 note=collision lift
G1 X241.507391 Y243.779093 Z4.829481 E18702.365122 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.662743 matz1=4.662788 note=collision lift
G1 X241.65183 Y243.607718 Z4.848842 E18702.751475 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.662788 matz1=4.680345 note=collision lift
G1 X241.661969 Y243.595688 Z4.85794 E18702.782687 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.680345 matz1=4.681577 note=collision lift
G1 X242.37006 Y242.755547 Z4.930007 E18704.673744 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.681577 matz1=4.767646 note=collision lift
G1 X242.376377 Y242.748052 Z4.925874 E18704.692013 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.767646 matz1=4.768414 note=collision lift
G1 X242.77766 Y242.271935 Z4.93602 E18705.761539 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.768414 matz1=4.81719 note=collision lift
G1 X242.785614 Y242.26558 Z4.931927 E18705.790333 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.81719 matz1=4.818187 note=collision lift
G1 X242.930271 Y242.149998 Z4.920616 E18706.277077 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.818187 matz1=4.836326 note=collision lift
G1 X242.931551 Y242.148976 Z4.919957 E18706.281709 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.836326 matz1=4.836486 note=collision lift
G1 X243.021876 Y242.076805 Z4.906449 E18706.587136 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.836486 matz1=4.847812 note=collision lift
G1 X243.024119 Y242.075013 Z4.905295 E18706.595256 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.847812 matz1=4.848093 note=collision lift
G1 X243.067679 Y242.040209 Z4.894364 E18706.744339 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.848093 matz1=4.853555 note=collision lift
G1 X243.070828 Y242.037693 Z4.892743 E18706.755738 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.853555 matz1=4.85395 note=collision lift
G1 X243.089687 Y242.022624 Z4.885398 E18706.821944 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.85395 matz1=4.856314 note=collision lift
G1 X243.09058 Y242.021911 Z4.886082 E18706.825439 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.856314 matz1=4.856426 note=collision lift
G1 X244.323264 Y241.036991 Z4.251727 E18711.287548 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.856426 matz1=4.251727 note=collision lift
G1 X245.582134 Y240.385152 Z3.700677 E18716.737515 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.251727 matz1=3.700677 note=collision lift
G1 X245.960038 Y240.189474 Z3.960816 E18718.524743 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.700677 matz1=3.960816 note=collision lift
G1 X246.080096 Y240.127309 Z4.044091 E18718.911818 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.960816 matz1=4.044091 note=collision lift
G1 X246.169417 Y240.101485 Z4.101588 E18719.258152 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.044091 matz1=4.101588 note=collision lift
G1 X246.171812 Y240.100793 Z4.100637 E18719.266605 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.101588 matz1=4.100637 note=collision lift
G1 X246.243853 Y240.079965 Z4.137501 E18719.53133 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.100637 matz1=4.137501 note=collision lift
G1 X246.258739 Y240.075661 Z4.147083 E18719.589051 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.137501 matz1=4.147083 note=collision lift
G1 X246.409219 Y240.032156 Z4.190031 E18720.103613 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.147083 matz1=4.190031 note=collision lift
G1 X246.411221 Y240.031578 Z4.189236 E18720.110678 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.190031 matz1=4.189236 note=collision lift
G1 X246.552432 Y239.990752 Z4.207541 E18720.579957 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.189236 matz1=4.207541 note=collision lift
G1 X246.559699 Y239.988651 Z4.212218 E18720.608133 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.207541 matz1=4.212218 note=collision lift
G1 X246.860659 Y239.901642 Z4.210322 E18721.600646 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.212218 matz1=4.210322 note=collision lift
G1 X246.865287 Y239.900303 Z4.208483 E18721.616984 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.210322 matz1=4.208483 note=collision lift
G1 X247.161619 Y239.814632 Z4.174351 E18722.600179 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.208483 matz1=4.174351 note=collision lift
G1 X247.164536 Y239.813788 Z4.173192 E18722.610478 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.174351 matz1=4.173192 note=collision lift
G1 X247.458907 Y239.728683 Z4.117911 E18723.596916 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.173192 matz1=4.117911 note=collision lift
G1 X247.462578 Y239.727622 Z4.120274 E18723.61115 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.117911 matz1=4.120274 note=collision lift
G1 X247.962994 Y239.582948 Z3.990858 E18725.311569 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.120274 matz1=3.990858 note=collision lift
G1 X247.97718 Y239.578847 Z3.991878 E18725.358462 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.990858 matz1=3.991878 note=collision lift
G1 X247.98064 Y239.577846 Z3.994105 E18725.37188 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.991878 matz1=3.994105 note=collision lift
G1 X248.474542 Y239.535721 Z4.029762 E18727.290232 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.994105 matz1=4.029762 note=collision lift
G1 X248.611851 Y239.52401 Z4.040765 E18727.823867 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.029762 matz1=4.040765 note=collision lift
G1 X249.854332 Y239.418037 Z4.187934 E18732.670723 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.951861 Y239.409719 Z4.199228 E18733.246441 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X251.918006 Y239.629389 Z4.417133 E18746.904335 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X252.10238 Y239.687964 Z4.435632 E18748.409854 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X253.803516 Y240.228414 Z5.498775 E18764.504485 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.435632 matz1=5.498775 note=collision lift
G1 X254.073654 Y240.377384 Z5.536483 E18767.128458 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.498775 matz1=5.536483 note=collision lift
G1 X254.074029 Y240.377591 Z5.536301 E18767.132389 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.536483 matz1=5.536301 note=collision lift
G1 X255.535933 Y241.183773 Z5.536301 E18781.227634 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.536301 matz1=5.536301 note=collision lift
G1 X256.056182 Y241.622251 Z5.230265 E18787.873031 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.536301 matz1=5.230265 note=collision lift
G1 X257.04868 Y242.458753 Z5.944423 E18801.069441 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.230265 matz1=5.944423 note=collision lift
G1 X257.246493 Y242.706327 Z5.977272 E18803.972439 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.944423 matz1=5.977272 note=collision lift
G1 X257.246701 Y242.706588 Z5.977112 E18803.975812 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.977272 matz1=5.977112 note=collision lift
G1 X258.283625 Y244.004357 Z5.977112 E18819.112094 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.977112 matz1=5.977112 note=collision lift
G1 X258.343594 Y244.120174 Z5.912744 E18820.437917 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.977112 matz1=5.912744 note=collision lift
G1 X259.193307 Y245.761189 Z4.973324 E18832.936421 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.912744 matz1=4.973324 note=collision lift
G1 X259.243169 Y245.933658 Z4.877024 E18834.118984 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.973324 matz1=4.877024 note=collision lift
G1 X259.74277 Y247.661734 Z4.811555 E18844.567451 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.910897 Y249.632955 Z4.686576 E18855.30149 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.691227 Y251.599099 Z4.516305 E18864.999516 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X259.092202 Y253.48461 Z4.311212 E18873.441634 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X258.136843 Y255.217026 Z4.083908 E18880.482566 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X256.861863 Y256.729774 Z3.848371 E18886.063622 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X255.316258 Y257.964718 Z3.619082 E18890.218721 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X253.559427 Y258.874401 Z3.410142 E18893.073056 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X251.658882 Y259.423863 Z3.234397 E18894.834368 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X249.687661 Y259.59199 Z3.102654 E18895.778154 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X247.721516 Y259.37232 Z3.023014 E18896.228932 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X245.836006 Y258.773295 Z3.000374 E18896.5397 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X244.103589 Y257.817936 Z3.036125 E18897.071081 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.420753 Y257.242425 Z3.070932 E18897.408078 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.590842 Y256.542956 Z3.128071 E18898.313298 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.355898 Y254.997352 Z3.270556 E18901.287175 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.547477 Y253.436083 Z3.432576 E18905.272328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X240.446215 Y253.24052 Z3.45482 E18905.794955 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X239.896753 Y251.339975 Z3.669532 E18912.492083 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X239.728626 Y249.368754 Z3.90149 E18921.356796 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X239.827 Y248.488264 Z4.007201 E18925.768765 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X239.299152 Y248.99443 Z4.093984 E18929.709252 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X238.210846 Y249.790556 Z4.250277 E18937.964768 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X237.040895 Y250.46096 Z4.397968 E18947.151459 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X236.030496 Y250.87332 Z4.50829 E18955.145918 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.831889 Y250.954375 Z4.528804 E18956.737174 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.653444 Y250.995255 Z4.545979 E18958.109723 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.518923 Y251.026073 Z4.558719 E18959.152538 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X234.584195 Y251.240211 Z4.641983 E18966.769929 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X233.946689 Y251.295883 Z4.692032 E18971.999919 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X232.642649 Y251.211923 Z4.779023 E18983.203455 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X231.97757 Y251.065444 Z4.815642 E18989.154602 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X230.672328 Y250.561112 Z4.870757 E19001.735243 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X231.385299 Y250.354987 Z4.888538 E19008.466379 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X233.35652 Y250.18686 Z4.895885 E19026.472325 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X233.790321 Y250.235327 Z4.885051 E19030.352039 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X235.204134 Y250.393287 Z5.561046 E19044.347125 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.885051 matz1=5.561046 note=collision lift
G1 X235.322664 Y250.40653 Z5.616009 E19045.511127 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.561046 matz1=5.616009 note=collision lift
G1 X235.672138 Y250.517557 Z5.783738 E19049.055735 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.616009 matz1=5.783738 note=collision lift
G1 X236.146209 Y250.668169 Z6.00829 E19053.791605 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.783738 matz1=6.00829 note=collision lift
G1 X237.208175 Y251.005555 Z6.00829 E19063.116426 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.00829 matz1=6.00829 note=collision lift
G1 X238.673675 Y251.81372 Z5.040912 E19077.89737 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=6.00829 matz1=5.040912 note=collision lift
G1 X238.940591 Y251.960914 Z5.169532 E19080.427108 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.040912 matz1=5.169532 note=collision lift
G1 X239.652402 Y252.560845 Z5.169532 E19086.703132 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.169532 matz1=5.169532 note=collision lift
G1 X239.660155 Y252.56738 Z5.173611 E19086.776822 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.169532 matz1=5.173611 note=collision lift
G1 X240.442152 Y253.226465 Z5.095715 E19093.691648 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.173611 matz1=5.095715 note=collision lift
G1 X240.447645 Y253.231095 Z5.09142 E19093.748077 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.095715 matz1=5.09142 note=collision lift
G1 X240.453339 Y253.235894 Z5.090747 E19093.798482 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.09142 matz1=5.090747 note=collision lift
G1 X240.606176 Y253.427179 Z4.942237 E19095.69416 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.090747 matz1=4.942237 note=collision lift
G1 X241.326405 Y254.328587 Z4.235898 E19103.419192 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.942237 matz1=4.235898 note=collision lift
G1 X241.688283 Y254.781498 Z4.170863 E19106.750333 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X241.962185 Y255.310474 Z4.100364 E19109.518657 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X242.597966 Y256.53833 Z4.628071 E19116.348892 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.100364 matz1=4.628071 note=collision lift
G1 X242.899407 Y257.580991 Z4.628071 E19120.702917 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.628071 matz1=4.628071 note=collision lift
G1 X243.147428 Y258.438874 Z4.077273 E19123.167741 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.628071 matz1=4.077273 note=collision lift
G1 X243.210973 Y259.183916 Z3.620944 E19124.629728 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.077273 matz1=3.620944 note=collision lift
G1 X243.315555 Y260.410096 Z3.485239 E19126.69604 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.244032 Y261.050257 Z3.423513 E19127.393484 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X243.230373 Y261.172516 Z3.473234 E19127.536495 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.423513 matz1=3.473234 note=collision lift
G1 X243.225444 Y261.216632 Z3.488658 E19127.587146 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.473234 matz1=3.488658 note=collision lift
G1 X243.223791 Y261.231421 Z3.494672 E19127.604445 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.488658 matz1=3.494672 note=collision lift
G1 X243.211457 Y261.341822 Z3.520575 E19127.727388 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.494672 matz1=3.520575 note=collision lift
G1 X243.210629 Y261.349232 Z3.523588 E19127.736056 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.520575 matz1=3.523588 note=collision lift
G1 X243.185205 Y261.576785 Z3.557743 E19127.985571 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.523588 matz1=3.557743 note=collision lift
G1 X243.184304 Y261.584854 Z3.561024 E19127.995009 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.557743 matz1=3.561024 note=collision lift
G1 X243.131654 Y262.056097 Z3.601219 E19128.507912 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.561024 matz1=3.601219 note=collision lift
G1 X243.131348 Y262.058827 Z3.599582 E19128.511358 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.601219 matz1=3.599582 note=collision lift
G1 X243.098627 Y262.351697 Z3.613151 E19128.829316 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.599582 matz1=3.613151 note=collision lift
G1 X243.095885 Y262.37624 Z3.623132 E19128.858025 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.613151 matz1=3.623132 note=collision lift
G1 X242.709245 Y263.593241 Z3.648618 E19129.639826 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.623132 matz1=3.648618 note=collision lift
G1 X242.706181 Y263.602885 Z3.642795 E19129.646972 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.648618 matz1=3.642795 note=collision lift
G1 X242.499216 Y264.254336 Z3.632915 E19130.065425 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.642795 matz1=3.632915 note=collision lift
G1 X242.49686 Y264.26175 Z3.636217 E19130.070598 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.632915 matz1=3.636217 note=collision lift
G1 X241.977924 Y265.202772 Z3.604721 E19130.393695 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.636217 matz1=3.604721 note=collision lift
G1 X241.973598 Y265.210617 Z3.599789 E19130.396768 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.604721 matz1=3.599789 note=collision lift
G1 X241.799841 Y265.525702 Z3.562486 E19130.505485 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.599789 matz1=3.562486 note=collision lift
G1 X241.79765 Y265.529675 Z3.559988 E19130.507041 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.562486 matz1=3.559988 note=collision lift
G1 X241.7108 Y265.687167 Z3.528721 E19130.561903 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.559988 matz1=3.528721 note=collision lift
G1 X241.708945 Y265.690531 Z3.526607 E19130.563221 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.528721 matz1=3.526607 note=collision lift
G1 X241.666279 Y265.767899 Z3.502999 E19130.590705 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.526607 matz1=3.502999 note=collision lift
G1 X241.664002 Y265.772028 Z3.500404 E19130.592322 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.502999 matz1=3.500404 note=collision lift
G1 X241.644018 Y265.808266 Z3.484044 E19130.605696 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.500404 matz1=3.484044 note=collision lift
G1 X241.541501 Y265.994167 Z3.367173 E19130.678526 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.484044 matz1=3.367173 note=collision lift
G1 X241.128028 Y266.484747 Z3.031994 E19130.795931 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.367173 matz1=3.031994 note=collision lift
G1 X240.266521 Y267.506915 Z3.002016 E19131.012804 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X239.080422 Y268.454612 Z3.012702 E19131.324977 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X238.720917 Y268.741859 Z3.246025 E19131.431061 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.012702 matz1=3.246025 note=collision lift
G1 X237.727064 Y269.256473 Z3.845985 E19131.974715 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.246025 matz1=3.845985 note=collision lift
G1 X237.067932 Y269.59777 Z3.899877 E19132.293328 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.845985 matz1=3.899877 note=collision lift
G1 X237.064974 Y269.599301 Z3.898332 E19132.2949 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.899877 matz1=3.898332 note=collision lift
G1 X236.964559 Y269.651296 Z3.905456 E19132.343407 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.898332 matz1=3.905456 note=collision lift
G1 X236.964085 Y269.651541 Z3.905742 E19132.343666 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.905456 matz1=3.905742 note=collision lift
G1 X236.67998 Y269.733679 Z3.924887 E19132.585508 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.905742 matz1=3.924887 note=collision lift
G1 X236.679553 Y269.733802 Z3.925137 E19132.585924 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.924887 matz1=3.925137 note=collision lift
G1 X235.06354 Y270.201004 Z3.9495 E19133.958808 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.925137 matz1=3.9495 note=collision lift
G1 X235.062634 Y270.201081 Z3.949123 E19133.960132 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.9495 matz1=3.949123 note=collision lift
G1 X235.00677 Y270.205846 Z3.94986 E19134.035577 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949123 matz1=3.94986 note=collision lift
G1 X235.006768 Y270.205846 Z3.94986 E19134.03558 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94986 matz1=3.94986 note=collision lift
G1 X233.092319 Y270.369131 Z3.94986 E19136.62085 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94986 matz1=3.94986 note=collision lift
G1 X231.126175 Y270.149461 Z3.94986 E19140.545918 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94986 matz1=3.94986 note=collision lift
G1 X230.417677 Y269.924372 Z3.94986 E19142.547276 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94986 matz1=3.94986 note=collision lift
G1 X230.415056 Y269.923539 Z3.95155 E19142.555968 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94986 matz1=3.95155 note=collision lift
G1 X229.803669 Y269.729302 Z3.927301 E19144.284241 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.95155 matz1=3.927301 note=collision lift
G1 X229.457286 Y269.619257 Z3.787303 E19145.332783 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.927301 matz1=3.787303 note=collision lift
G1 X229.240665 Y269.550436 Z3.813397 E19145.948711 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X227.508248 Y268.595077 Z4.048922 E19152.775673 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.9955 Y267.320097 Z4.278364 E19161.025085 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.841968 Y265.876384 Z4.474707 E19169.860178 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.760556 Y265.774493 Z4.487616 E19170.80272 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.850874 Y264.017661 Z4.663809 E19186.723851 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.301411 Y262.117116 Z4.796111 E19203.844597 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.133284 Y260.145895 Z4.876387 E19221.684665 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.352954 Y258.179751 Z4.899699 E19239.72703 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.951979 Y256.29424 Z4.864614 E19257.446284 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.999247 Y256.208526 Z4.861386 E19258.321833 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.907338 Y254.561824 Z4.773291 E19269.024682 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X225.969884 Y253.301126 Z4.654995 E19277.690718 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X226.182318 Y253.049076 Z4.79616 E19279.570673 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.654995 matz1=4.79616 note=collision lift
G1 X226.287941 Y252.964683 Z4.852414 E19280.333195 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.79616 matz1=4.852414 note=collision lift
G1 X227.727922 Y251.814132 Z5.601507 E19294.268507 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.852414 matz1=5.601507 note=collision lift
G1 X229.47227 Y250.910914 Z6.370757 E19306.92842 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.601507 matz1=5.734592 note=collision lift
G1 X229.484754 Y250.904449 Z6.371087 E19307.01281 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.734592 matz1=5.733068 note=collision lift
G1 X230.184466 Y250.702157 Z6.388537 E19310.895375 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.733068 matz1=5.64839 note=collision lift
G1 X230.184476 Y250.702154 Z6.388541 E19310.895435 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.64839 matz1=5.648389 note=collision lift
G1 X230.672328 Y250.561112 Z6.390449 E19313.601671 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.648389 matz1=5.58935 note=collision lift
G1 X230.672322 Y250.56111 Z6.390445 E19313.601706 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.58935 matz1=5.589349 note=collision lift
G1 X230.619106 Y250.540548 Z6.390265 E19313.90393 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.589349 matz1=5.582608 note=collision lift
G1 X230.619021 Y250.540515 Z6.390299 E19313.904443 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.582608 matz1=5.582598 note=collision lift
G1 X230.138085 Y250.273501 Z6.388573 E19316.576387 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.582598 matz1=5.517222 note=collision lift
G1 X230.137962 Y250.273433 Z6.388627 E19316.577121 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.517222 matz1=5.517206 note=collision lift
G1 X229.927535 Y250.156605 Z6.382732 E19317.746536 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.517206 matz1=5.488602 note=collision lift
G1 X229.926799 Y250.156196 Z6.383053 E19317.750913 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.488602 matz1=5.488501 note=collision lift
G1 X229.601075 Y249.916972 Z6.371319 E19319.321423 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.488501 matz1=5.440469 note=collision lift
G1 X228.51635 Y249.120311 Z5.538439 E19325.469433 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.440469 matz1=5.280511 note=collision lift
G1 X227.797622 Y248.461482 Z4.937967 E19329.312388 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.280511 matz1=4.937967 note=collision lift
G1 X227.619382 Y248.26438 Z4.774969 E19330.314713 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.937967 matz1=4.774969 note=collision lift
G1 X226.817104 Y247.377207 Z4.046094 E19333.961231 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.774969 matz1=4.046094 note=collision lift
G1 X226.334947 Y246.844029 Z3.61268 E19335.856016 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.046094 matz1=3.61268 note=collision lift
G1 X226.122418 Y246.553299 Z3.400861 E19336.362509 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.61268 matz1=3.400861 note=collision lift
G1 X224.839575 Y244.798422 Z3.209188 E19339.007945 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.41301 Y244.099156 Z3.163246 E19339.37113 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.311875 Y242.29407 Z4.101867 E19340.395268 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.163246 matz1=4.101867 note=collision lift
G1 X223.292827 Y242.270712 Z4.115854 E19340.40981 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.101867 matz1=4.115854 note=collision lift
G1 X221.925121 Y240.593588 Z5.15483 E19340.976697 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.115854 matz1=4.500488 note=collision lift
G1 X221.6744 Y240.227222 Z5.37658 E19341.093369 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.500488 matz1=4.500267 note=collision lift
G1 X221.025396 Y239.278871 Z5.968406 E19341.545343 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.500267 matz1=4.517512 note=collision lift
G1 X220.752695 Y238.880389 Z6.009279 E19341.714784 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.517512 matz1=4.524758 note=collision lift
G1 X220.752686 Y238.880373 Z6.009271 E19341.714793 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.524758 matz1=4.524759 note=collision lift
G1 X220.365679 Y238.218178 Z6.049794 E19342.073394 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.524759 matz1=4.549794 note=collision lift
G1 X220.365234 Y238.217416 Z6.049823 E19342.073807 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.549794 matz1=4.549823 note=collision lift
G1 X220.732712 Y238.420066 Z6.042637 E19342.303686 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.549823 matz1=4.567079 note=collision lift
G1 X220.733179 Y238.420323 Z6.042926 E19342.304018 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.567079 matz1=4.567101 note=collision lift
G1 X221.371806 Y238.958574 Z5.969179 E19343.157894 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.567101 matz1=4.61399 note=collision lift
G1 X221.741309 Y239.27 Z5.75469 E19343.696324 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.61399 matz1=4.64112 note=collision lift
G1 X222.103825 Y239.575537 Z5.781307 E19344.179908 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.64112 matz1=4.667737 note=collision lift
G1 X222.318198 Y239.843837 Z5.805291 E19344.569123 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.667737 matz1=4.691721 note=collision lift
G1 X223.222764 Y240.975954 Z5.921467 E19347.002665 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.691721 matz1=4.807898 note=collision lift
G1 X223.714941 Y241.926475 Z6.021171 E19349.304607 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.807898 matz1=4.907601 note=collision lift
G1 X223.716004 Y241.928527 Z6.019075 E19349.311289 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.907601 matz1=4.907816 note=collision lift
G1 X224.046995 Y242.567756 Z5.371921 E19351.713093 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.907816 matz1=4.980502 note=collision lift
G1 X224.371378 Y243.689771 Z4.331877 E19357.029664 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.980502 matz1=4.331877 note=collision lift
G1 X224.544843 Y244.289772 Z4.087996 E19359.309041 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.331877 matz1=4.087996 note=collision lift
G1 X224.614727 Y245.109133 Z3.773225 E19363.167783 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.087996 matz1=3.773225 note=collision lift
G1 X224.697177 Y246.075825 Z3.886956 E19367.448645 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.498142 Y247.857278 Z4.10027 E19377.160634 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X224.041765 Y249.293785 Z4.274194 E19386.557839 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.955387 Y249.565671 Z4.305991 E19387.77151 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X223.08977 Y251.135352 Z4.493726 E19396.44717 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X221.934556 Y252.505998 Z4.653987 E19406.00939 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X220.53414 Y253.624937 Z4.778679 E19416.255269 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X218.942337 Y254.449168 Z4.861501 E19426.950768 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X217.220322 Y254.947016 Z4.898267 E19437.842661 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X215.434269 Y255.09935 Z4.887121 E19448.670173 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X213.652816 Y254.900315 Z4.828626 E19459.176112 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X211.944422 Y254.35756 Z4.725736 E19469.117711 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.374742 Y253.491943 Z4.583652 E19478.277448 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X209.004095 Y252.336729 Z4.409551 E19486.473819 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.826108 Y252.113968 Z4.37947 E19487.7518 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.885157 Y250.936313 Z4.212231 E19496.705674 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.702614 Y250.583775 Z4.165596 E19498.67185 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.060926 Y249.34451 Z4.699432 E19506.02139 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.165596 matz1=4.699432 note=collision lift
G1 X206.571379 Y247.651211 Z5.371093 E19513.449932 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.699432 matz1=5.291998 note=collision lift
G1 X206.470387 Y248.202644 Z5.025243 E19515.842093 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.291998 matz1=5.025243 note=collision lift
G1 X205.806451 Y250.648042 Z3.480454 E19522.763254 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.025243 matz1=3.480454 note=collision lift
G1 X205.783535 Y250.707431 Z3.442713 E19522.874269 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.480454 matz1=3.442713 note=collision lift
G1 X205.116937 Y252.434996 Z3.270728 E19525.664001 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.079628 Y252.531686 Z3.262228 E19525.760919 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.021148 Y252.683242 Z3.330129 E19525.925018 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.262228 matz1=3.330129 note=collision lift
G1 X204.667865 Y253.391601 Z3.665716 E19526.564964 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.330129 matz1=3.665716 note=collision lift
G1 X204.599926 Y253.527823 Z3.731126 E19526.740004 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.665716 matz1=3.731126 note=collision lift
G1 X204.599267 Y253.529146 Z3.730283 E19526.741802 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.731126 matz1=3.730283 note=collision lift
G1 X204.592645 Y253.542424 Z3.732477 E19526.757647 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.730283 matz1=3.732477 note=collision lift
G1 X204.58642 Y253.554905 Z3.73847 E19526.773685 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.732477 matz1=3.73847 note=collision lift
G1 X204.394735 Y253.853333 Z3.761106 E19526.980463 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.73847 matz1=3.761106 note=collision lift
G1 X204.393687 Y253.854965 Z3.760024 E19526.981755 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.761106 matz1=3.760024 note=collision lift
G1 X204.375738 Y253.88291 Z3.760845 E19527.001084 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.760024 matz1=3.760845 note=collision lift
G1 X204.155275 Y254.226143 Z3.941158 E19527.260574 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.760845 matz1=3.941158 note=collision lift
G1 X204.154803 Y254.226878 Z3.940671 E19527.261156 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.941158 matz1=3.940671 note=collision lift
G1 X203.996098 Y254.473962 Z3.977788 E19527.433369 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.940671 matz1=3.977788 note=collision lift
G1 X203.996061 Y254.474019 Z3.97775 E19527.433414 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.977788 matz1=3.97775 note=collision lift
G1 X203.995829 Y254.474381 Z3.97794 E19527.433688 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.97775 matz1=3.97794 note=collision lift
G1 X203.640595 Y255.027435 Z3.97794 E19527.816114 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.97794 matz1=3.97794 note=collision lift
G1 X203.132164 Y255.635003 Z3.97794 E19528.157382 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.97794 matz1=3.97794 note=collision lift
G1 X202.052468 Y256.611869 Z3.97794 E19528.541253 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.97794 matz1=3.97794 note=collision lift
G1 X201.484077 Y256.986888 Z3.97794 E19528.70189 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.97794 matz1=3.97794 note=collision lift
G1 X200.602283 Y257.392367 Z3.97794 E19528.967505 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.97794 matz1=3.97794 note=collision lift
G1 X200.296599 Y257.53293 Z4.142354 E19529.069989 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.97794 matz1=4.142354 note=collision lift
G1 X200.294201 Y257.533616 Z4.141159 E19529.070918 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.142354 matz1=4.141159 note=collision lift
G1 X200.084081 Y257.593737 Z4.226067 E19529.149593 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.141159 matz1=4.226067 note=collision lift
G1 X200.073964 Y257.596632 Z4.231546 E19529.153574 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.226067 matz1=4.231546 note=collision lift
G1 X199.687737 Y257.70714 Z4.375165 E19529.29673 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.231546 matz1=4.375165 note=collision lift
G1 X199.687658 Y257.707163 Z4.375126 E19529.29676 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.375165 matz1=4.375126 note=collision lift
G1 X199.681572 Y257.708904 Z4.378422 E19529.299155 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.375126 matz1=4.378422 note=collision lift
G1 X199.184242 Y257.779733 Z4.442039 E19529.574096 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.378422 matz1=4.442039 note=collision lift
G1 X199.178357 Y257.780572 Z4.439272 E19529.577656 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.442039 matz1=4.439272 note=collision lift
G1 X198.690626 Y257.850034 Z4.446727 E19529.845185 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.439272 matz1=4.446727 note=collision lift
G1 X198.688548 Y257.85033 Z4.445751 E19529.846441 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.446727 matz1=4.445751 note=collision lift
G1 X198.414357 Y257.88938 Z4.443987 E19529.996825 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.445751 matz1=4.443987 note=collision lift
G1 X198.41311 Y257.889353 Z4.443428 E19529.998007 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.443987 matz1=4.443428 note=collision lift
G1 X198.303698 Y257.886999 Z4.438235 E19530.092729 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.443428 matz1=4.438235 note=collision lift
G1 X198.297641 Y257.886869 Z4.441583 E19530.098713 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.438235 matz1=4.441583 note=collision lift
G1 X198.035655 Y257.881234 Z4.377558 E19530.331933 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.441583 matz1=4.377558 note=collision lift
G1 X197.108664 Y257.861297 Z3.962769 E19531.210118 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.377558 matz1=3.962769 note=collision lift
G1 X196.332998 Y257.741657 Z3.622351 E19532.157807 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.962769 matz1=3.622351 note=collision lift
G1 X195.776276 Y257.655787 Z3.382625 E19532.68996 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.622351 matz1=3.382625 note=collision lift
G1 X195.479382 Y257.574946 Z3.253649 E19533.027354 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.382625 matz1=3.253649 note=collision lift
G1 X195.232758 Y257.507793 Z3.274313 E19533.286677 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X194.47549 Y257.301599 Z3.343351 E19534.736185 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.271257 Y256.79618 Z3.470947 E19537.933495 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X192.187005 Y256.115885 Z3.608519 E19541.898642 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.696725 Y255.704971 Z3.680809 E19544.099171 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.063214 Y254.983998 Z3.792569 E19547.976527 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X191.028597 Y254.944603 Z3.824897 E19548.223742 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.792569 matz1=3.824897 note=collision lift
G1 X191.002312 Y254.914688 Z3.838135 E19548.39214 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.824897 matz1=3.838135 note=collision lift
G1 X191.001343 Y254.913586 Z3.837572 E19548.398446 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.838135 matz1=3.837572 note=collision lift
G1 X190.978206 Y254.887254 Z3.843787 E19548.5413 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.837572 matz1=3.843787 note=collision lift
G1 X190.976026 Y254.884773 Z3.845823 E19548.556868 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.843787 matz1=3.845823 note=collision lift
G1 X191.642935 Y254.691965 Z3.899978 E19551.970669 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.845823 matz1=3.899978 note=collision lift
G1 X191.644997 Y254.691369 Z3.89916 E19551.981932 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.899978 matz1=3.89916 note=collision lift
G1 X192.511296 Y254.440915 Z3.998182 E19556.429525 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.89916 matz1=3.998182 note=collision lift
G1 X194.482517 Y254.272788 Z4.230154 E19568.356305 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X195.955972 Y254.437411 Z4.393454 E19578.426519 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X196.448662 Y254.492458 Z4.4449 E19580.749794 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X196.921146 Y254.642565 Z4.494426 E19583.1491 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X198.334172 Y255.091482 Z4.629214 E19594.841692 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X199.037091 Y255.479114 Z4.687053 E19601.699184 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X200.066589 Y256.046842 Z5.359595 E19613.240009 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.687053 matz1=5.359595 note=collision lift
G1 X200.24264 Y256.195221 Z5.485424 E19615.588617 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.359595 matz1=5.485424 note=collision lift
G1 X200.307794 Y256.250135 Z5.446783 E19616.426099 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.485424 matz1=5.446783 note=collision lift
G1 X200.81999 Y256.681827 Z5.47794 E19622.428548 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.446783 matz1=5.47794 note=collision lift
G1 X201.288595 Y257.076778 Z5.506445 E19627.920136 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.47794 matz1=5.506445 note=collision lift
G1 X201.305715 Y257.091207 Z5.485096 E19628.197061 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.506445 matz1=5.485096 note=collision lift
G1 X201.317781 Y257.101377 Z5.47794 E19628.352158 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.485096 matz1=5.47794 note=collision lift
G1 X201.329848 Y257.111547 Z5.470784 E19628.507254 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.47794 matz1=5.470784 note=collision lift
G1 X201.447489 Y257.210697 Z5.47794 E19629.885895 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.470784 matz1=5.47794 note=collision lift
G1 X201.579336 Y257.321822 Z5.48596 E19631.431023 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.47794 matz1=5.48596 note=collision lift
G1 X201.589349 Y257.334353 Z5.470279 E19631.635103 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.48596 matz1=5.470279 note=collision lift
G1 X202.346073 Y258.281437 Z4.891321 E19643.85728 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.470279 matz1=4.891321 note=collision lift
G1 X202.452106 Y258.414144 Z4.895129 E19645.403062 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X202.814281 Y258.867426 Z4.899617 E19650.693945 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X203.723963 Y260.624257 Z4.877058 E19668.526715 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X203.926374 Y261.324379 Z4.854194 E19675.020772 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X204.273426 Y262.524802 Z4.797494 E19685.829679 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X204.318455 Y263.052758 Z4.767056 E19690.340358 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X204.83838 Y261.416227 Z4.644331 E19703.982916 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.793739 Y259.683811 Z4.463444 E19718.045657 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.672262 Y258.641455 Z4.319675 E19726.827076 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.068719 Y258.171063 Z4.250986 E19729.338158 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X207.199306 Y258.066724 Z4.231472 E19729.899639 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.614323 Y256.936119 Z4.925633 E19736.371362 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.231472 matz1=4.925633 note=collision lift
G1 X210.371155 Y256.026436 Z5.679551 E19741.882038 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.925633 matz1=5.284749 note=collision lift
G1 X211.783688 Y255.618062 Z6.247434 E19744.878358 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.284749 matz1=5.117441 note=collision lift
G1 X211.905691 Y255.58279 Z6.270178 E19745.123617 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.117441 matz1=5.10299 note=collision lift
G1 X211.906969 Y255.58242 Z6.269362 E19745.126584 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.10299 matz1=5.102839 note=collision lift
G1 X212.026214 Y255.547946 Z6.284283 E19745.364242 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.102839 matz1=5.088715 note=collision lift
G1 X212.027694 Y255.547518 Z6.284878 E19745.367382 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.088715 matz1=5.08854 note=collision lift
G1 X212.2717 Y255.476974 Z6.309084 E19745.852405 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.08854 matz1=5.059638 note=collision lift
G1 X212.272261 Y255.476926 Z6.308746 E19745.853241 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.059638 matz1=5.059581 note=collision lift
G1 X212.532367 Y255.454741 Z6.328789 E19746.186762 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.059581 matz1=5.033045 note=collision lift
G1 X212.532493 Y255.454731 Z6.328839 E19746.186935 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.033045 matz1=5.033032 note=collision lift
G1 X213.601056 Y255.363592 Z6.366668 E19747.553923 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.033032 matz1=4.924016 note=collision lift
G1 X213.601274 Y255.363574 Z6.366536 E19747.554249 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.924016 matz1=4.923993 note=collision lift
G1 X214.20254 Y255.312291 Z6.362651 E19748.322973 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.923993 matz1=4.862651 note=collision lift
G1 X214.202626 Y255.312284 Z6.362642 E19748.323084 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.862651 matz1=4.862642 note=collision lift
G1 X214.242837 Y255.308854 Z6.35854 E19748.374758 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.862642 matz1=4.85854 note=collision lift
G1 X214.242921 Y255.308847 Z6.358531 E19748.374865 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.85854 matz1=4.858531 note=collision lift
G1 X215.396463 Y255.437728 Z6.261879 E19749.260277 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.858531 matz1=4.761879 note=collision lift
G1 X215.396521 Y255.437734 Z6.261874 E19749.260321 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.761879 matz1=4.761874 note=collision lift
G1 X215.463743 Y255.445245 Z6.256242 E19749.311918 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.761874 matz1=4.756242 note=collision lift
G1 X215.463771 Y255.445248 Z6.25624 E19749.31194 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.756242 matz1=4.75624 note=collision lift
G1 X216.107951 Y255.51722 Z6.202266 E19749.806386 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.75624 matz1=4.702266 note=collision lift
G1 X216.107972 Y255.517222 Z6.202264 E19749.806402 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.702266 matz1=4.702264 note=collision lift
G1 X216.209065 Y255.528517 Z6.193793 E19749.883997 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.702264 matz1=4.693793 note=collision lift
G1 X217.823245 Y256.04134 Z6.092569 E19750.548249 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.693793 matz1=4.592569 note=collision lift
G1 X217.824001 Y256.04158 Z6.092522 E19750.548561 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.592569 matz1=4.592522 note=collision lift
G1 X217.876899 Y256.058386 Z6.089205 E19750.570329 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.592522 matz1=4.589205 note=collision lift
G1 X218.094576 Y256.127542 Z6.075554 E19750.659905 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.589205 matz1=4.575554 note=collision lift
G1 X219.826992 Y257.082901 Z5.212172 E19751.071044 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.575554 matz1=4.511084 note=collision lift
G1 X220.055193 Y257.275234 Z5.058186 E19751.130018 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.511084 matz1=4.506319 note=collision lift
G1 X220.09173 Y257.306028 Z5.034238 E19751.143605 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506319 matz1=4.506263 note=collision lift
G1 X221.33974 Y258.357881 Z5.848399 E19751.60724 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.506263 matz1=4.504347 note=collision lift
G1 X221.985041 Y259.165513 Z6.031211 E19752.126532 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.504347 matz1=4.531211 note=collision lift
G1 X222.574684 Y259.903485 Z6.055758 E19752.593942 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.531211 matz1=4.555758 note=collision lift
G1 X222.575942 Y259.905915 Z6.055905 E19752.596661 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.555758 matz1=4.555905 note=collision lift
G1 X222.673605 Y260.094527 Z6.067328 E19752.807726 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.555905 matz1=4.567328 note=collision lift
G1 X222.67361 Y260.094538 Z6.067329 E19752.807738 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.567328 matz1=4.567329 note=collision lift
G1 X222.791363 Y260.321948 Z6.081101 E19753.06222 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.567329 matz1=4.581101 note=collision lift
G1 X222.791768 Y260.322731 Z6.081148 E19753.063096 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.581101 matz1=4.581148 note=collision lift
G1 X223.338654 Y261.378909 Z6.145113 E19754.245005 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.581148 matz1=4.645113 note=collision lift
G1 X223.339179 Y261.379923 Z6.145174 E19754.246139 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.645113 matz1=4.645174 note=collision lift
G1 X223.484367 Y261.660317 Z6.162155 E19754.559912 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.645174 matz1=4.662155 note=collision lift
G1 X223.484388 Y261.660389 Z6.162161 E19754.560042 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.662155 matz1=4.662161 note=collision lift
G1 X223.608758 Y262.090577 Z6.19721 E19755.33106 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.662161 matz1=4.69721 note=collision lift
G1 X223.60885 Y262.090895 Z6.197235 E19755.331629 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.69721 matz1=4.697235 note=collision lift
G1 X223.928971 Y263.198166 Z6.287447 E19757.316169 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.697235 matz1=4.787447 note=collision lift
G1 X223.929171 Y263.198857 Z6.287503 E19757.317408 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.787447 matz1=4.787503 note=collision lift
G1 X224.033811 Y263.560798 Z6.270868 E19757.964759 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.787503 matz1=4.816991 note=collision lift
G1 X224.033829 Y263.560861 Z6.270906 E19757.964891 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.816991 matz1=4.816997 note=collision lift
G1 X224.06745 Y263.955047 Z6.246074 E19759.004555 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.816997 matz1=4.855744 note=collision lift
G1 X224.06746 Y263.95517 Z6.246024 E19759.004905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.855744 matz1=4.855756 note=collision lift
G1 X224.071137 Y263.998279 Z6.243288 E19759.118608 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.855756 matz1=4.859993 note=collision lift
G1 X224.071187 Y263.99887 Z6.243642 E19759.12042 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.859993 matz1=4.860051 note=collision lift
G1 X224.17574 Y265.224708 Z6.164196 E19762.353935 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.860051 matz1=4.980547 note=collision lift
G1 X224.175808 Y265.225512 Z6.163872 E19762.356215 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.980547 matz1=4.980626 note=collision lift
G1 X224.201851 Y265.530846 Z6.13584 E19763.163308 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.980626 matz1=5.010639 note=collision lift
G1 X224.201956 Y265.532083 Z6.136582 E19763.1671 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.010639 matz1=5.010761 note=collision lift
G1 X224.142854 Y266.061073 Z6.084767 E19764.713053 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.010761 matz1=5.068045 note=collision lift
G1 X224.142409 Y266.065051 Z6.083218 E19764.723514 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.068045 matz1=5.068498 note=collision lift
G1 X224.139444 Y266.091593 Z6.080365 E19764.788966 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.068498 matz1=5.071517 note=collision lift
G1 X224.138909 Y266.09638 Z6.083318 E19764.802734 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.071517 matz1=5.072062 note=collision lift
G1 X224.059265 Y266.809234 Z5.993441 E19766.564388 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.072062 matz1=5.153155 note=collision lift
G1 X223.982286 Y267.498227 Z5.72518 E19768.375933 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.153155 matz1=5.231534 note=collision lift
G1 X223.383261 Y269.383737 Z4.970197 E19775.082644 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.231534 matz1=4.970197 note=collision lift
G1 X222.427902 Y271.116154 Z4.214246 E19783.330722 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.970197 matz1=4.214246 note=collision lift
G1 X222.408223 Y271.139503 Z4.202342 E19783.480634 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.214246 matz1=4.202342 note=collision lift
G1 X221.152922 Y272.628902 Z4.416907 E19792.44399 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X219.607318 Y273.863846 Z4.606126 E19802.707014 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X217.850486 Y274.773528 Z4.755 E19813.873281 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X215.949942 Y275.322991 Z4.854376 E19825.635909 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X213.97872 Y275.491118 Z4.898141 E19837.65665 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X212.012576 Y275.271448 Z4.883606 E19849.585108 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X210.127066 Y274.672423 Z4.811664 E19861.077037 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X208.394649 Y273.717064 Z4.686739 E19871.812068 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X206.881901 Y272.442084 Z4.516513 E19881.511363 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X205.646957 Y270.89648 Z4.311451 E19889.954954 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X204.995419 Y269.638191 Z4.148663 E19894.998991 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X204.737275 Y269.139648 Z4.36487 E19897.126557 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.148663 matz1=4.36487 note=collision lift
G1 X204.422732 Y268.051671 Z4.796385 E19900.903381 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.36487 matz1=4.796385 note=collision lift
G1 X204.187812 Y267.239103 Z5.118523 E19904.707627 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.796385 matz1=5.118523 note=collision lift
G1 X204.019685 Y265.267882 Z5.878409 E19911.342229 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.118523 matz1=5.119325 note=collision lift
G1 X204.129126 Y264.288337 Z6.267119 E19913.623561 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.119325 matz1=5.015215 note=collision lift
G1 X204.186801 Y263.772121 Z6.297538 E19914.743897 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.015215 matz1=4.960349 note=collision lift
G1 X204.186837 Y263.7718 Z6.297665 E19914.744645 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.960349 matz1=4.960315 note=collision lift
G1 X204.239355 Y263.301738 Z6.319807 E19915.764184 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.960315 matz1=4.910355 note=collision lift
G1 X204.239385 Y263.301642 Z6.319747 E19915.764422 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.910355 matz1=4.910345 note=collision lift
G1 X204.318455 Y263.052758 Z6.330536 E19916.29617 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.910345 matz1=4.884983 note=collision lift
G1 X204.318456 Y263.05277 Z6.330529 E19916.296189 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.884983 matz1=4.884982 note=collision lift
G1 X204.379653 Y263.77028 Z6.297587 E19917.328151 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.884982 matz1=4.820894 note=collision lift
G1 X204.379668 Y263.770455 Z6.297484 E19917.328442 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.820894 matz1=4.820878 note=collision lift
G1 X204.424683 Y264.298236 Z6.267056 E19918.087982 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.820878 matz1=4.773736 note=collision lift
G1 X204.441553 Y264.496023 Z6.150137 E19918.417781 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.773736 matz1=4.75607 note=collision lift
G1 X204.280717 Y265.935579 Z5.324613 E19919.725968 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.75607 matz1=4.654803 note=collision lift
G1 X204.274401 Y265.992106 Z5.349076 E19919.77455 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.654803 matz1=4.650826 note=collision lift
G1 X204.221947 Y266.46159 Z5.407149 E19920.14801 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.650826 matz1=4.6178 note=collision lift
G1 X204.221883 Y266.462168 Z5.407399 E19920.148507 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.6178 matz1=4.617759 note=collision lift
G1 X204.103764 Y266.833961 Z5.4489 E19920.317129 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.617759 matz1=4.599627 note=collision lift
G1 X204.100611 Y266.843889 Z5.453624 E19920.322045 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.599627 matz1=4.599143 note=collision lift
G1 X203.781609 Y267.847987 Z5.542646 E19920.7765 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.599143 matz1=4.550175 note=collision lift
G1 X203.77936 Y267.855069 Z5.538585 E19920.78014 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.550175 matz1=4.54983 note=collision lift
G1 X203.727917 Y268.016992 Z5.54913 E19920.853307 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.54983 matz1=4.541933 note=collision lift
G1 X203.727681 Y268.017734 Z5.549483 E19920.853674 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.541933 matz1=4.541897 note=collision lift
G1 X203.645512 Y268.276371 Z5.563326 E19920.921984 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.541897 matz1=4.533059 note=collision lift
G1 X203.645252 Y268.277189 Z5.562869 E19920.922229 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.533059 matz1=4.533031 note=collision lift
G1 X203.623903 Y268.344389 Z5.565707 E19920.939968 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.533031 matz1=4.530734 note=collision lift
G1 X203.622858 Y268.347678 Z5.56732 E19920.940926 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.530734 matz1=4.530622 note=collision lift
G1 X203.486484 Y268.594975 Z5.563264 E19920.984975 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.530622 matz1=4.526253 note=collision lift
G1 X203.485305 Y268.597113 Z5.562005 E19920.985403 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.526253 matz1=4.526215 note=collision lift
G1 X203.418297 Y268.718623 Z5.55203 E19921.0071 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.526215 matz1=4.524069 note=collision lift
G1 X203.417401 Y268.720247 Z5.551074 E19921.007426 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.524069 matz1=4.52404 note=collision lift
G1 X203.384203 Y268.780447 Z5.540909 E19921.018264 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.52404 matz1=4.522977 note=collision lift
G1 X203.383369 Y268.78196 Z5.540018 E19921.018567 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.522977 matz1=4.52295 note=collision lift
G1 X203.367156 Y268.81136 Z5.531563 E19921.023967 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.52295 matz1=4.522431 note=collision lift
G1 X203.365884 Y268.813666 Z5.530206 E19921.024429 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.522431 matz1=4.52239 note=collision lift
G1 X203.359095 Y268.825977 Z5.524631 E19921.026788 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.52239 matz1=4.522172 note=collision lift
G1 X203.358633 Y268.826816 Z5.525095 E19921.026954 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.522172 matz1=4.522157 note=collision lift
G1 X202.667499 Y270.080095 Z4.787347 E19921.278075 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.522157 matz1=4.500017 note=collision lift
G1 X201.552516 Y271.403007 Z3.946611 E19921.744871 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.500017 matz1=3.946611 note=collision lift
G1 X201.392519 Y271.592842 Z3.946611 E19921.805119 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946611 matz1=3.946611 note=collision lift
G1 X199.846914 Y272.827787 Z3.946611 E19922.806562 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946611 matz1=3.946611 note=collision lift
G1 X198.090083 Y273.737469 Z3.946611 E19924.647094 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946611 matz1=3.946611 note=collision lift
G1 X198.022408 Y273.757035 Z3.946611 E19924.751987 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946611 matz1=3.946611 note=collision lift
G1 X198.022014 Y273.757148 Z3.946853 E19924.752696 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946611 matz1=3.946853 note=collision lift
G1 X197.881277 Y273.797837 Z3.943886 E19924.970877 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.946853 matz1=3.943886 note=collision lift
G1 X196.582769 Y274.173245 Z3.390452 E19927.145677 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943886 matz1=3.390452 note=collision lift
G1 X196.189538 Y274.286932 Z3.427522 E19927.757663 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X194.218317 Y274.455059 Z3.638813 E19932.031014 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X193.019915 Y274.321166 Z3.779261 E19935.510743 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X192.756947 Y274.291785 Z3.942382 E19936.401719 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.779261 matz1=3.942382 note=collision lift
G1 X192.252208 Y274.235393 Z3.942513 E19937.857458 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942382 matz1=3.942513 note=collision lift
G1 X192.252172 Y274.235389 Z3.942535 E19937.857579 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942513 matz1=3.942535 note=collision lift
G1 X192.244642 Y274.232996 Z3.942948 E19937.886064 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942535 matz1=3.942948 note=collision lift
G1 X190.366662 Y273.636364 Z4.104629 E19945.004198 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942948 matz1=4.104629 note=collision lift
G1 X188.634245 Y272.681005 Z4.330512 E19953.575706 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.121498 Y271.406024 Z4.532998 E19963.392003 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X185.886554 Y269.86042 Z4.699635 E19974.223468 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.976871 Y268.103589 Z4.820178 E19985.781721 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.427409 Y266.203044 Z4.887214 E19997.738972 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.259282 Y264.231823 Z4.896622 E20009.747534 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.297722 Y263.887769 Z4.892245 E20011.844322 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.478952 Y262.265678 Z4.847822 E20026.337768 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X185.077976 Y260.380168 Z4.743815 E20042.95937 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X186.033336 Y258.647751 Z4.590998 E20058.18922 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X186.838639 Y257.692269 Z4.473462 E20067.132493 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.308316 Y257.135004 Z4.398766 E20072.0968 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.108208 Y256.495887 Z4.284999 E20078.018196 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.85392 Y255.90006 Z4.656196 E20083.905011 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.284999 matz1=4.656196 note=collision lift
G1 X189.369149 Y255.633276 Z4.878525 E20087.279525 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.656196 matz1=4.878525 note=collision lift
G1 X190.610752 Y254.990377 Z5.411481 E20094.243323 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.878525 matz1=5.411481 note=collision lift
G1 X190.974361 Y254.885255 Z5.456535 E20095.936412 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.411481 matz1=5.399873 note=collision lift
G1 X190.976026 Y254.884773 Z5.457195 E20095.944647 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.399873 matz1=5.399666 note=collision lift
G1 X190.842461 Y254.732769 Z5.445244 E20096.820705 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.399666 matz1=5.375564 note=collision lift
G1 X190.834005 Y254.723146 Z5.450123 E20096.879949 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.375564 matz1=5.374038 note=collision lift
G1 X190.467288 Y254.149363 Z5.391494 E20099.576057 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.374038 matz1=5.293382 note=collision lift
G1 X190.4613 Y254.135827 Z5.382387 E20099.630965 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.293382 matz1=5.291675 note=collision lift
G1 X190.39569 Y253.987505 Z5.358121 E20100.149092 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.291675 matz1=5.272976 note=collision lift
G1 X190.394402 Y253.984594 Z5.359346 E20100.159869 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.272976 matz1=5.272609 note=collision lift
G1 X190.321515 Y253.819825 Z5.31442 E20100.746545 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.272609 matz1=5.251836 note=collision lift
G1 X189.878264 Y252.8178 Z4.640249 E20104.811171 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.251836 matz1=4.640249 note=collision lift
G1 X189.660909 Y252.055961 Z4.156994 E20107.36496 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.640249 matz1=4.156994 note=collision lift
G1 X189.590807 Y251.598539 Z3.878845 E20108.404139 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.156994 matz1=3.878845 note=collision lift
G1 X189.529124 Y251.196059 Z3.869261 E20109.188045 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.878845 matz1=3.869261 note=collision lift
G1 X189.528348 Y251.190999 Z3.871303 E20109.198654 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.869261 matz1=3.871303 note=collision lift
G1 X189.395787 Y250.326036 Z3.821645 E20110.885577 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.871303 matz1=3.821645 note=collision lift
G1 X189.394989 Y250.307798 Z3.810822 E20110.924743 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.821645 matz1=3.810822 note=collision lift
G1 X189.393765 Y250.279837 Z3.807735 E20110.976704 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.810822 matz1=3.807735 note=collision lift
G1 X189.393735 Y250.279157 Z3.808012 E20110.978061 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.807735 matz1=3.808012 note=collision lift
G1 X189.387844 Y250.144622 Z3.790436 E20111.22868 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.808012 matz1=3.790436 note=collision lift
G1 X189.387805 Y250.143723 Z3.790803 E20111.230472 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.790436 matz1=3.790803 note=collision lift
G1 X189.381255 Y249.994113 Z3.76509 E20111.384381 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.790803 matz1=3.76509 note=collision lift
G1 X189.381164 Y249.992044 Z3.763872 E20111.386815 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.76509 matz1=3.763872 note=collision lift
G1 X189.377979 Y249.919308 Z3.745896 E20111.462776 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.763872 matz1=3.745896 note=collision lift
G1 X189.377891 Y249.91729 Z3.744709 E20111.465149 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.745896 matz1=3.744709 note=collision lift
G1 X189.376342 Y249.881905 Z3.732287 E20111.503168 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.744709 matz1=3.732287 note=collision lift
G1 X189.376184 Y249.87831 Z3.730171 E20111.507397 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.732287 matz1=3.730171 note=collision lift
G1 X189.375566 Y249.864195 Z3.723167 E20111.52337 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.730171 matz1=3.723167 note=collision lift
G1 X189.375523 Y249.863204 Z3.723575 E20111.524456 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.723167 matz1=3.723575 note=collision lift
G1 X189.35318 Y249.352913 Z3.423204 E20112.124667 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.723575 matz1=3.423204 note=collision lift
G1 X189.366644 Y249.087168 Z3.268195 E20112.415498 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.423204 matz1=3.268195 note=collision lift
G1 X189.368194 Y249.056582 Z3.250744 E20112.443382 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.268195 matz1=3.250744 note=collision lift
G1 X189.463561 Y247.174253 Z3.119134 E20113.937982 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X189.851659 Y244.670224 Z3.016698 E20114.729118 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X189.961563 Y244.216679 Z3.016506 E20114.872061 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X190.542442 Y241.819552 Z4.24874 E20115.716595 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.016506 matz1=4.24874 note=collision lift
G1 X190.545463 Y241.789683 Z4.264402 E20115.727071 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.24874 matz1=4.264402 note=collision lift
G1 X190.763306 Y239.635751 Z5.428063 E20117.420873 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.264402 matz1=4.597341 note=collision lift
G1 X190.845195 Y239.200167 Z5.674311 E20117.828722 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.597341 matz1=4.621981 note=collision lift
G1 X191.057518 Y238.070781 Z6.200984 E20119.509075 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.621981 matz1=4.700984 note=collision lift
G1 X191.14666 Y237.596618 Z6.234153 E20120.151924 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.700984 matz1=4.734153 note=collision lift
G1 X191.146794 Y237.595907 Z6.234203 E20120.152888 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.734153 matz1=4.734203 note=collision lift
G1 X191.341363 Y236.853435 Z6.297681 E20121.40531 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.734203 matz1=4.797681 note=collision lift
G1 X191.341782 Y236.854886 Z6.297816 E20121.408041 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.797681 matz1=4.797816 note=collision lift
G1 X191.45798 Y237.256803 Z6.335014 E20122.16445 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.797816 matz1=4.835014 note=collision lift
G1 X191.458022 Y237.256951 Z6.335027 E20122.164727 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.835014 matz1=4.835027 note=collision lift
G1 X191.529011 Y238.08927 Z6.327764 E20124.361729 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.835027 matz1=4.917636 note=collision lift
G1 X191.610356 Y239.043004 Z5.943824 E20127.074085 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.917636 matz1=5.012294 note=collision lift
G1 X191.572209 Y239.384439 Z5.808842 E20128.108404 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.012294 matz1=5.049093 note=collision lift
G1 X191.411321 Y240.824457 Z5.246938 E20133.644971 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.049093 matz1=5.211677 note=collision lift
G1 X191.086481 Y241.846934 Z4.836287 E20138.413138 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.211677 matz1=4.836287 note=collision lift
G1 X190.868566 Y242.53285 Z4.562094 E20141.918452 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.836287 matz1=4.562094 note=collision lift
G1 X190.251427 Y243.65195 Z4.074805 E20149.504761 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.562094 matz1=4.074805 note=collision lift
G1 X190.002949 Y244.102531 Z4.135885 E20152.378834 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X188.847735 Y245.473177 Z4.339276 E20164.10136 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X187.447319 Y246.592116 Z4.522999 E20177.358576 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X186.108721 Y247.285238 Z4.655428 E20189.428893 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X185.855517 Y247.416347 Z4.67777 E20190.969746 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X184.133501 Y247.914195 Z4.795769 E20201.308776 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X182.347448 Y248.066529 Z4.871034 E20212.055626 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X180.565995 Y247.867494 Z4.899763 E20222.954992 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X178.857602 Y247.324739 Z4.880504 E20233.745933 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X177.287921 Y246.459122 Z4.81423 E20244.172939 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X175.917274 Y245.303908 Z4.704289 E20253.996748 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.798336 Y243.903492 Z4.556236 E20263.005182 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.974105 Y242.31169 Z4.377553 E20271.023861 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.476257 Y240.589674 Z4.177267 E20277.926206 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.323923 Y238.803621 Z3.965498 E20283.641679 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.355599 Y238.520107 Z3.931443 E20284.520905 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.522958 Y237.022168 Z3.752945 E20290.221037 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.630787 Y236.682762 Z3.712696 E20291.227382 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X174.065713 Y235.313775 Z4.268557 E20295.552249 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.712696 matz1=4.268557 note=collision lift
G1 X174.916963 Y233.770145 Z4.970359 E20299.286182 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.268557 matz1=4.870758 note=collision lift
G1 X174.916376 Y233.770551 Z4.969936 E20299.287615 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.870758 matz1=4.870692 note=collision lift
G1 X174.455717 Y234.088529 Z4.915116 E20300.258689 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.870692 matz1=4.819207 note=collision lift
G1 X174.455192 Y234.088891 Z4.915376 E20300.259879 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.819207 matz1=4.819149 note=collision lift
G1 X173.879285 Y234.419151 Z4.848236 E20300.816938 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.819149 matz1=4.769196 note=collision lift
G1 X173.878249 Y234.419746 Z4.847549 E20300.818089 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.769196 matz1=4.769106 note=collision lift
G1 X173.856646 Y234.432134 Z4.844932 E20300.838992 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.769106 matz1=4.767232 note=collision lift
G1 X172.257078 Y235.349423 Z3.78423 E20302.614882 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.767232 matz1=3.78423 note=collision lift
G1 X171.599743 Y235.640395 Z3.385112 E20303.148666 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.78423 matz1=3.385112 note=collision lift
G1 X171.057836 Y235.880271 Z3.063857 E20303.42756 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.385112 matz1=3.063857 note=collision lift
G1 X170.50598 Y236.124552 Z3.038456 E20303.677468 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.262981 Y236.232116 Z3.030031 E20303.776992 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.624334 Y236.445931 Z3.014789 E20303.959633 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.33842 Y236.541653 Z3.158722 E20304.050214 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.014789 matz1=3.158722 note=collision lift
G1 X168.542924 Y236.715026 Z3.563902 E20304.279362 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.158722 matz1=3.563902 note=collision lift
G1 X168.52766 Y236.718352 Z3.565157 E20304.283311 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.563902 matz1=3.565157 note=collision lift
G1 X168.527449 Y236.718398 Z3.565048 E20304.283372 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.565157 matz1=3.565048 note=collision lift
G1 X167.723461 Y236.893621 Z3.565048 E20304.49071 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.565048 matz1=3.565048 note=collision lift
G1 X167.628578 Y236.9143 Z3.613376 E20304.518042 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.565048 matz1=3.613376 note=collision lift
G1 X167.562586 Y236.920119 Z3.647604 E20304.541431 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.613376 matz1=3.647604 note=collision lift
G1 X167.519719 Y236.923899 Z3.666321 E20304.556151 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.647604 matz1=3.666321 note=collision lift
G1 X167.518246 Y236.924029 Z3.665606 E20304.556666 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.666321 matz1=3.665606 note=collision lift
G1 X167.478356 Y236.927546 Z3.675474 E20304.569602 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.665606 matz1=3.675474 note=collision lift
G1 X167.476851 Y236.927679 Z3.676254 E20304.570135 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.675474 matz1=3.676254 note=collision lift
G1 X167.392856 Y236.935085 Z3.690566 E20304.596963 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.676254 matz1=3.690566 note=collision lift
G1 X167.391116 Y236.935238 Z3.691468 E20304.597579 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.690566 matz1=3.691468 note=collision lift
G1 X167.229192 Y236.949515 Z3.709991 E20304.648896 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.691468 matz1=3.709991 note=collision lift
G1 X167.219646 Y236.950357 Z3.714942 E20304.652279 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.709991 matz1=3.714942 note=collision lift
G1 X166.839885 Y236.983841 Z3.752481 E20304.772438 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.714942 matz1=3.752481 note=collision lift
G1 X166.834698 Y236.983581 Z3.750032 E20304.774848 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.752481 matz1=3.750032 note=collision lift
G1 X166.746782 Y236.979167 Z3.754738 E20304.811848 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.750032 matz1=3.754738 note=collision lift
G1 X166.736164 Y236.978634 Z3.760355 E20304.816895 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.754738 matz1=3.760355 note=collision lift
G1 X166.041561 Y236.943763 Z3.782971 E20305.108962 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.760355 matz1=3.782971 note=collision lift
G1 X166.034081 Y236.943388 Z3.779517 E20305.113408 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.782971 matz1=3.779517 note=collision lift
G1 X165.917684 Y236.937545 Z3.780713 E20305.176243 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.779517 matz1=3.780713 note=collision lift
G1 X165.917461 Y236.937533 Z3.780833 E20305.17638 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.780713 matz1=3.780833 note=collision lift
G1 X165.715611 Y236.9274 Z3.781559 E20305.285341 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.780833 matz1=3.781559 note=collision lift
G1 X165.715577 Y236.927398 Z3.781544 E20305.285361 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.781559 matz1=3.781544 note=collision lift
G1 X165.513761 Y236.917267 Z3.780802 E20305.394303 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.781544 matz1=3.780802 note=collision lift
G1 X165.51353 Y236.917255 Z3.780695 E20305.39444 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.780802 matz1=3.780695 note=collision lift
G1 X165.387614 Y236.910934 Z3.779558 E20305.462413 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.780695 matz1=3.779558 note=collision lift
G1 X165.385281 Y236.910817 Z3.780816 E20305.463844 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.779558 matz1=3.780816 note=collision lift
G1 X164.718123 Y236.774119 Z3.759274 E20305.935762 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.780816 matz1=3.759274 note=collision lift
G1 X164.715075 Y236.772991 Z3.757848 E20305.939551 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.759274 matz1=3.757848 note=collision lift
G1 X164.667583 Y236.755408 Z3.755333 E20305.993686 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.757848 matz1=3.755333 note=collision lift
G1 X164.664977 Y236.754443 Z3.756893 E20305.997089 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.755333 matz1=3.756893 note=collision lift
G1 X163.852858 Y236.453771 Z3.71201 E20306.922907 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.756893 matz1=3.71201 note=collision lift
G1 X163.849676 Y236.452593 Z3.710522 E20306.926863 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.71201 matz1=3.710522 note=collision lift
G1 X163.494407 Y236.321062 Z3.688628 E20307.332002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.710522 matz1=3.688628 note=collision lift
G1 X163.492674 Y236.32042 Z3.689666 E20307.334266 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.688628 matz1=3.689666 note=collision lift
G1 X162.932927 Y236.010264 Z3.640013 E20308.160634 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.689666 matz1=3.640013 note=collision lift
G1 X162.927538 Y236.006217 Z3.637204 E20308.173151 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.640013 matz1=3.637204 note=collision lift
G1 X162.906209 Y235.990201 Z3.63473 E20308.219074 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.637204 matz1=3.63473 note=collision lift
G1 X162.904633 Y235.989018 Z3.635879 E20308.222985 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63473 matz1=3.635879 note=collision lift
G1 X162.688838 Y235.826975 Z3.606508 E20308.688364 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.635879 matz1=3.606508 note=collision lift
G1 X162.678115 Y235.818923 Z3.600919 E20308.713268 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.606508 matz1=3.600919 note=collision lift
G1 X162.6758 Y235.817185 Z3.60016 E20308.718399 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.600919 matz1=3.60016 note=collision lift
G1 X162.119018 Y235.399091 Z3.309955 E20310.01162 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.60016 matz1=3.309955 note=collision lift
G1 X162.055752 Y235.351583 Z3.316538 E20310.147727 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.909362 Y235.241657 Z3.332992 E20310.476983 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.760893 Y235.086829 Z3.352685 E20310.882701 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.569549 Y234.887289 Z3.37881 E20311.449894 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.511736 Y234.827 Z3.428468 E20311.64838 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.37881 matz1=3.428468 note=collision lift
G1 X161.738626 Y234.852349 Z3.564794 E20312.219088 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.428468 matz1=3.564794 note=collision lift
G1 X162.232971 Y234.90758 Z3.863337 E20313.599428 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.564794 matz1=3.863337 note=collision lift
G1 X162.59739 Y234.948296 Z4.084656 E20314.694576 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.863337 matz1=4.084656 note=collision lift
G1 X162.688116 Y234.977119 Z4.142808 E20315.09426 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.084656 matz1=4.142808 note=collision lift
G1 X162.802709 Y235.013525 Z4.276376 E20315.738173 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.142808 matz1=4.276376 note=collision lift
G1 X162.964995 Y235.065083 Z4.380524 E20316.453348 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.276376 matz1=4.380524 note=collision lift
G1 X162.968251 Y235.066118 Z4.380902 E20316.465663 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.380524 matz1=4.380902 note=collision lift
G1 X162.98594 Y235.071737 Z4.391604 E20316.542427 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.380902 matz1=4.391604 note=collision lift
G1 X162.986077 Y235.071781 Z4.391765 E20316.543201 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.391604 matz1=4.391765 note=collision lift
G1 X163.0017 Y235.076745 Z4.401085 E20316.610763 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.391765 matz1=4.401085 note=collision lift
G1 X163.044658 Y235.090392 Z4.426958 E20316.796976 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.401085 matz1=4.426958 note=collision lift
G1 X163.047531 Y235.091305 Z4.430306 E20316.813117 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.426958 matz1=4.430306 note=collision lift
G1 X163.139541 Y235.120536 Z4.484106 E20317.209109 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.430306 matz1=4.484106 note=collision lift
G1 X164.422608 Y235.528165 Z5.256893 E20322.770937 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.484106 matz1=5.209034 note=collision lift
G1 X164.4829 Y235.54732 Z5.229945 E20323.017313 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.209034 matz1=5.216049 note=collision lift
G1 X166.215317 Y236.50268 Z4.474504 E20332.920243 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.216049 matz1=4.474504 note=collision lift
G1 X166.220907 Y236.507391 Z4.471721 E20332.95685 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.474504 matz1=4.471721 note=collision lift
G1 X167.017741 Y237.178982 Z4.073798 E20339.392799 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.471721 matz1=4.073798 note=collision lift
G1 X167.728065 Y237.77766 Z4.183558 E20344.78984 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X168.963009 Y239.323264 Z4.402957 E20358.316883 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.810526 Y240.960038 Z4.582554 E20372.457684 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.872691 Y241.080096 Z4.594504 E20373.153651 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.422154 Y242.98064 Z4.746421 E20384.268137 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.581963 Y244.854332 Z4.845535 E20395.398301 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.590281 Y244.951861 Z4.849367 E20396.268537 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.370611 Y246.918006 Z4.897011 E20414.290002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.771586 Y248.803516 Z4.886424 E20432.208535 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X168.816227 Y250.535933 Z4.818257 E20449.5063 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.848839 Y251.683727 Z4.726026 E20461.79285 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.541247 Y252.04868 Z4.935345 E20466.050643 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.726026 matz1=4.935345 note=collision lift
G1 X167.089844 Y252.409353 Z5.17967 E20471.044953 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.935345 matz1=5.17967 note=collision lift
G1 X167.559906 Y251.556959 Z5.583047 E20479.022861 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.17967 matz1=5.583047 note=collision lift
G1 X168.834886 Y250.044211 Z6.375847 E20493.202287 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.583047 matz1=5.872408 note=collision lift
G1 X169.082047 Y249.846728 Z6.386458 E20494.97901 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.872408 matz1=5.836849 note=collision lift
G1 X169.082459 Y249.846399 Z6.386662 E20494.982186 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.836849 matz1=5.83679 note=collision lift
G1 X170.011651 Y249.103971 Z6.391984 E20501.658006 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.83679 matz1=5.703109 note=collision lift
G1 X170.011936 Y249.103743 Z6.391761 E20501.660409 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.703109 matz1=5.703068 note=collision lift
G1 X170.212408 Y248.943565 Z6.392651 E20503.100705 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.703068 matz1=5.674226 note=collision lift
G1 X170.212412 Y248.943562 Z6.392648 E20503.100738 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.674226 matz1=5.674226 note=collision lift
G1 X170.37938 Y248.810153 Z6.393307 E20504.300323 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.674226 matz1=5.650204 note=collision lift
G1 X170.38049 Y248.809267 Z6.393857 E20504.308873 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.650204 matz1=5.650045 note=collision lift
G1 X171.219316 Y248.374925 Z6.393582 E20508.574045 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.650045 matz1=5.538001 note=collision lift
G1 X172.137322 Y247.899584 Z5.754077 E20514.062768 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.538001 matz1=5.415381 note=collision lift
G1 X173.170968 Y247.600749 Z5.089166 E20518.601581 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.415381 matz1=5.089166 note=collision lift
G1 X173.751165 Y247.433009 Z5.319902 E20520.92162 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.089166 matz1=5.217217 note=collision lift
G1 X174.037866 Y247.350122 Z5.434753 E20521.652351 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.217217 matz1=5.182847 note=collision lift
G1 X176.009087 Y247.181995 Z6.207834 E20525.074773 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.182847 matz1=4.966739 note=collision lift
G1 X176.236073 Y247.207355 Z6.300515 E20525.32867 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.966739 matz1=4.945221 note=collision lift
G1 X176.289781 Y247.213356 Z6.314887 E20525.386272 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.945221 matz1=4.940129 note=collision lift
G1 X176.291233 Y247.213518 Z6.315479 E20525.387895 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.940129 matz1=4.939991 note=collision lift
G1 X176.838161 Y247.274624 Z6.345832 E20525.955635 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.939991 matz1=4.888142 note=collision lift
G1 X176.838201 Y247.274629 Z6.345848 E20525.95568 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.888142 matz1=4.888138 note=collision lift
G1 X177.608118 Y247.360648 Z6.315149 E20526.754306 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.888138 matz1=4.815149 note=collision lift
G1 X177.609118 Y247.36076 Z6.315055 E20526.755348 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.815149 matz1=4.815055 note=collision lift
G1 X177.975232 Y247.401665 Z6.280347 E20527.136496 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.815055 matz1=4.780347 note=collision lift
G1 X177.975242 Y247.401668 Z6.280346 E20527.136502 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.780347 matz1=4.780346 note=collision lift
G1 X179.316625 Y247.827824 Z6.177037 E20527.951159 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.780346 matz1=4.677037 note=collision lift
G1 X179.860742 Y248.000689 Z6.135131 E20528.281615 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.677037 matz1=4.635131 note=collision lift
G1 X181.363866 Y248.829603 Z6.052609 E20528.763999 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.635131 matz1=4.552609 note=collision lift
G1 X181.36396 Y248.829654 Z6.052604 E20528.76403 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.552609 matz1=4.552604 note=collision lift
G1 X181.59157 Y248.955173 Z6.040108 E20528.837075 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.552604 matz1=4.540108 note=collision lift
G1 X181.593159 Y248.956049 Z6.040021 E20528.837584 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.540108 matz1=4.540021 note=collision lift
G1 X181.981594 Y249.283431 Z6.029967 E20528.918171 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.540021 matz1=4.529967 note=collision lift
G1 X183.105906 Y250.231029 Z5.615304 E20529.160477 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.529967 matz1=4.500865 note=collision lift
G1 X184.340851 Y251.776633 Z4.645321 E20529.641896 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.500865 matz1=4.520071 note=collision lift
G1 X185.112954 Y253.267764 Z3.870569 E20530.48642 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.520071 matz1=3.870569 note=collision lift
G1 X185.250533 Y253.533465 Z4.031725 E20530.64162 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.870569 matz1=4.031725 note=collision lift
G1 X185.42139 Y254.124443 Z4.374076 E20531.039439 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.031725 matz1=4.374076 note=collision lift
G1 X185.799996 Y255.434009 Z5.149784 E20533.059236 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.374076 matz1=4.725328 note=collision lift
G1 X185.920277 Y256.844265 Z5.981548 E20536.50502 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.725328 matz1=4.849404 note=collision lift
G1 X185.924213 Y256.890403 Z5.998535 E20536.608545 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.849404 matz1=4.853463 note=collision lift
G1 X185.927077 Y256.923982 Z6.01834 E20536.690592 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.853463 matz1=4.856418 note=collision lift
G1 X185.967632 Y257.399479 Z6.09534 E20537.705209 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.856418 matz1=4.898252 note=collision lift
G1 X185.968078 Y257.404711 Z6.093175 E20537.71713 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.898252 matz1=4.898713 note=collision lift
G1 X185.968123 Y257.40523 Z6.093482 E20537.718399 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.898713 matz1=4.898758 note=collision lift
G1 X185.841142 Y258.541764 Z6.187751 E20541.239614 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.898758 matz1=5.018603 note=collision lift
G1 X185.840831 Y258.544549 Z6.186643 E20541.24886 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018603 matz1=5.018897 note=collision lift
G1 X185.84083 Y258.544556 Z6.186644 E20541.248883 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018897 matz1=5.018898 note=collision lift
G1 X185.840829 Y258.544564 Z6.186645 E20541.248905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018898 matz1=5.018898 note=collision lift
G1 X185.840828 Y258.544571 Z6.186645 E20541.248928 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018898 matz1=5.018899 note=collision lift
G1 X185.840828 Y258.544578 Z6.186646 E20541.248951 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018899 matz1=5.0189 note=collision lift
G1 X185.840827 Y258.544585 Z6.186646 E20541.248973 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.0189 matz1=5.018901 note=collision lift
G1 X185.840826 Y258.544593 Z6.186647 E20541.248996 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018901 matz1=5.018901 note=collision lift
G1 X185.840825 Y258.5446 Z6.186648 E20541.249019 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018901 matz1=5.018902 note=collision lift
G1 X185.840824 Y258.544608 Z6.186648 E20541.249042 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018902 matz1=5.018903 note=collision lift
G1 X185.840823 Y258.544615 Z6.186645 E20541.249067 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018903 matz1=5.018904 note=collision lift
G1 X185.77746 Y259.111748 Z6.228856 E20543.005006 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.018904 matz1=5.078707 note=collision lift
G1 X185.777383 Y259.112432 Z6.228584 E20543.007278 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.078707 matz1=5.078779 note=collision lift
G1 X185.753268 Y259.328274 Z6.243869 E20543.675389 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.078779 matz1=5.101539 note=collision lift
G1 X185.753255 Y259.328394 Z6.243822 E20543.675786 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.101539 matz1=5.101552 note=collision lift
G1 X185.748453 Y259.371375 Z6.24593 E20543.808658 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.101552 matz1=5.106084 note=collision lift
G1 X185.748452 Y259.371376 Z6.24593 E20543.808662 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.106084 matz1=5.106084 note=collision lift
G1 X185.161608 Y261.218548 Z6.347822 E20551.838362 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.106084 matz1=5.329911 note=collision lift
G1 X185.14976 Y261.25584 Z6.34897 E20552.000315 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.329911 matz1=5.33443 note=collision lift
G1 X185.149428 Y261.256885 Z6.349645 E20552.005644 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.33443 matz1=5.334557 note=collision lift
G1 X184.586493 Y262.277694 Z6.382295 E20558.115424 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.334557 matz1=5.473364 note=collision lift
G1 X184.585842 Y262.278873 Z6.381782 E20558.122978 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.473364 matz1=5.473525 note=collision lift
G1 X184.449944 Y262.525305 Z6.388985 E20559.597836 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.473525 matz1=5.507034 note=collision lift
G1 X184.449915 Y262.525359 Z6.388961 E20559.598181 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.507034 matz1=5.507042 note=collision lift
G1 X184.386214 Y262.640872 Z6.392251 E20560.289496 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.507042 matz1=5.522749 note=collision lift
G1 X184.386196 Y262.640904 Z6.392273 E20560.289721 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.522749 matz1=5.522753 note=collision lift
G1 X184.197346 Y262.983358 Z6.39665 E20562.338716 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.522753 matz1=5.56932 note=collision lift
G1 X184.19731 Y262.983425 Z6.396622 E20562.339142 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.56932 matz1=5.569329 note=collision lift
G1 X184.194069 Y262.989302 Z6.396622 E20562.374304 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.569329 matz1=5.570128 note=collision lift
G1 X183.648958 Y263.636069 Z6.396622 E20567.198595 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.570128 matz1=5.669428 note=collision lift
G1 X183.018594 Y264.383987 Z6.396622 E20571.310878 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.669428 matz1=5.780741 note=collision lift
G1 X183.01858 Y264.384004 Z6.396635 E20571.310985 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.780741 matz1=5.780744 note=collision lift
G1 X183.017802 Y264.384927 Z6.396475 E20571.316106 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.780744 matz1=5.780881 note=collision lift
G1 X182.919088 Y264.502049 Z6.33732 E20572.006435 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.780881 matz1=5.798313 note=collision lift
G1 X181.373484 Y265.736994 Z5.554899 E20582.322476 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.798313 matz1=5.554899 note=collision lift
G1 X179.616653 Y266.646676 Z4.738345 E20593.852634 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.554899 matz1=4.738345 note=collision lift
G1 X179.500164 Y266.680354 Z4.685554 E20594.617854 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.738345 matz1=4.685554 note=collision lift
G1 X177.716108 Y267.196139 Z4.805604 E20605.385623 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X175.744887 Y267.364266 Z4.880883 E20617.305577 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X173.778742 Y267.144596 Z4.898921 E20629.32869 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.893232 Y266.545571 Z4.858612 E20641.105083 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.160815 Y265.590212 Z4.762432 E20652.298917 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X168.648068 Y264.315232 Z4.616296 E20662.606061 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.413124 Y262.769627 Z4.42919 E20671.77169 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X166.503441 Y261.012796 Z4.212619 E20679.607137 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.953979 Y259.112251 Z3.9799 E20686.004246 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.946921 Y259.029501 Z3.970054 E20686.211652 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.785852 Y257.14103 Z4.693006 E20691.242376 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.970054 matz1=4.693006 note=collision lift
G1 X166.005522 Y255.174885 Z5.460222 E20695.036058 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.693006 matz1=5.023369 note=collision lift
G1 X166.443379 Y253.796671 Z6.036894 E20697.108869 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.023369 matz1=4.876993 note=collision lift
G1 X166.52919 Y253.526568 Z6.152314 E20697.649355 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.876993 matz1=4.85071 note=collision lift
G1 X166.604546 Y253.289375 Z6.172432 E20698.090363 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.85071 matz1=4.827628 note=collision lift
G1 X166.604588 Y253.2893 Z6.172382 E20698.0905 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.827628 matz1=4.827621 note=collision lift
G1 X166.753517 Y253.019238 Z6.196819 E20698.513288 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.827621 matz1=4.8014 note=collision lift
G1 X166.75352 Y253.019231 Z6.196815 E20698.513299 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.8014 matz1=4.801399 note=collision lift
G1 X167.089844 Y252.409353 Z6.238485 E20699.466794 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.801399 matz1=4.742184 note=collision lift
G1 X167.089835 Y252.40936 Z6.238479 E20699.466806 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.742184 matz1=4.742183 note=collision lift
G1 X166.564687 Y252.828956 Z6.194183 E20700.0723 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.742183 matz1=4.694183 note=collision lift
G1 X166.564513 Y252.829095 Z6.194168 E20700.0725 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.694183 matz1=4.694168 note=collision lift
G1 X166.113283 Y253.189629 Z6.152127 E20700.593014 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.694168 matz1=4.652924 note=collision lift
G1 X165.995643 Y253.283625 Z6.066084 E20700.748897 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.652924 matz1=4.642172 note=collision lift
G1 X165.879826 Y253.343594 Z5.992789 E20700.87771 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.642172 matz1=4.634087 note=collision lift
G1 X164.238811 Y254.193307 Z4.978724 E20701.495554 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.634087 matz1=4.544001 note=collision lift
G1 X162.338266 Y254.74277 Z3.947074 E20701.854123 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.544001 matz1=3.947074 note=collision lift
G1 X162.328636 Y254.743591 Z3.942319 E20701.856387 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947074 matz1=3.942319 note=collision lift
G1 X160.367045 Y254.910897 Z3.943291 E20702.270124 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942319 matz1=3.943291 note=collision lift
G1 X160.366375 Y254.910822 Z3.942978 E20702.27045 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943291 matz1=3.942978 note=collision lift
G1 X160.097775 Y254.880812 Z3.943 E20702.388941 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942978 matz1=3.943 note=collision lift
G1 X160.09739 Y254.880769 Z3.943208 E20702.389134 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943 matz1=3.943208 note=collision lift
G1 X158.400901 Y254.691227 Z3.942398 E20703.13753 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943208 matz1=3.942398 note=collision lift
G1 X158.400423 Y254.691075 Z3.94218 E20703.137984 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942398 matz1=3.94218 note=collision lift
G1 X157.887605 Y254.528153 Z3.941413 E20703.585368 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.94218 matz1=3.941413 note=collision lift
G1 X157.885787 Y254.527576 Z3.942489 E20703.587189 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.941413 matz1=3.942489 note=collision lift
G1 X157.803075 Y254.501298 Z3.930046 E20703.660085 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942489 matz1=3.930046 note=collision lift
G1 X156.51539 Y254.092202 Z3.340575 E20704.885724 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.930046 matz1=3.340575 note=collision lift
G1 X156.298354 Y253.972515 Z3.23809 E20705.251846 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.340575 matz1=3.23809 note=collision lift
G1 X154.782974 Y253.136843 Z3.38779 E20707.622996 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.678351 Y252.20584 Z3.538003 E20710.537313 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.270226 Y251.861863 Z3.860375 E20711.788475 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.538003 matz1=3.860375 note=collision lift
G1 X153.261661 Y251.851142 Z3.868815 E20711.832235 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.860375 matz1=3.868815 note=collision lift
G1 X153.182256 Y251.751762 Z3.89041 E20712.182711 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.868815 matz1=3.89041 note=collision lift
G1 X153.181002 Y251.750193 Z3.889637 E20712.188557 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.89041 matz1=3.889637 note=collision lift
G1 X153.103331 Y251.652984 Z3.9034 E20712.528605 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.889637 matz1=3.9034 note=collision lift
G1 X153.102851 Y251.652382 Z3.903874 E20712.531059 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.9034 matz1=3.903874 note=collision lift
G1 X152.944064 Y251.453651 Z3.925822 E20713.224592 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.903874 matz1=3.925822 note=collision lift
G1 X152.944041 Y251.453623 Z3.925844 E20713.224709 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.925822 matz1=3.925844 note=collision lift
G1 X152.035282 Y250.316258 Z3.948727 E20717.179687 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.925844 matz1=3.948727 note=collision lift
G1 X152.034784 Y250.315297 Z3.948314 E20717.183684 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.948727 matz1=3.948314 note=collision lift
G1 X151.98778 Y250.224519 Z3.949814 E20717.536483 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.948314 matz1=3.949814 note=collision lift
G1 X151.987776 Y250.224512 Z3.949811 E20717.536513 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949814 matz1=3.949811 note=collision lift
G1 X151.125599 Y248.559427 Z4.056689 E20724.017495 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949811 matz1=4.056689 note=collision lift
G1 X150.576137 Y246.658882 Z4.285684 E20732.312151 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X150.40801 Y244.687661 Z4.494039 E20741.88978 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X150.62768 Y242.721516 Z4.668941 E20752.535034 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X151.226705 Y240.836006 Z4.799635 E20763.970036 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.182064 Y239.103589 Z4.878086 E20775.873469 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.757575 Y238.420753 Z4.894967 E20781.290288 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.457044 Y237.590842 Z4.89947 E20791.186782 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.002648 Y236.355898 Z4.862471 E20808.886512 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.563917 Y235.547477 Z4.782355 E20823.970055 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.75948 Y235.446215 Z4.769365 E20825.84732 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.660025 Y234.896753 Z4.625877 E20841.395414 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X160.631246 Y234.728626 Z4.440829 E20855.250691 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.511736 Y234.827 Z4.34742 E20861.0735 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.00557 Y234.299152 Z4.266556 E20865.604266 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X160.209444 Y233.210846 Z4.110973 E20872.974893 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.53904 Y232.040895 Z3.950779 E20879.33101 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.12668 Y231.030496 Z3.820899 E20883.807677 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.045625 Y230.831889 Z3.795578 E20884.661943 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.004745 Y230.653444 Z3.774057 E20885.372396 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.973927 Y230.518923 Z3.757894 E20885.897441 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.759789 Y229.584195 Z3.647444 E20889.04628 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.704117 Y228.946689 Z3.576082 E20890.931819 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.712515 Y228.816249 Z3.562305 E20891.232028 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X158.755816 Y228.143723 Z3.549922 E20892.771591 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.562305 matz1=3.549922 note=collision lift
G1 X158.769725 Y227.92768 Z3.635348 E20893.303183 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.549922 matz1=3.635348 note=collision lift
G1 X158.76978 Y227.926825 Z3.63483 E20893.305471 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.635348 matz1=3.63483 note=collision lift
G1 X158.788077 Y227.642649 Z3.63483 E20893.955902 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63483 matz1=3.63483 note=collision lift
G1 X158.934556 Y226.97757 Z3.63483 E20895.299456 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63483 matz1=3.63483 note=collision lift
G1 X159.21918 Y226.240944 Z3.63483 E20896.403309 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63483 matz1=3.63483 note=collision lift
G1 X159.438888 Y225.672328 Z3.886062 E20897.324924 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.63483 matz1=3.886062 note=collision lift
G1 X159.645013 Y226.385299 Z4.200497 E20898.238035 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.886062 matz1=4.200497 note=collision lift
G1 X159.81314 Y228.35652 Z5.072011 E20899.497208 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.200497 matz1=4.574531 note=collision lift
G1 X159.8119 Y228.367623 Z5.077226 E20899.500836 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.574531 matz1=4.574161 note=collision lift
G1 X159.760538 Y228.827333 Z5.147239 E20899.638523 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.574161 matz1=4.558832 note=collision lift
G1 X159.759773 Y228.834175 Z5.150453 E20899.640759 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.558832 matz1=4.558604 note=collision lift
G1 X159.700043 Y229.368791 Z5.240961 E20899.801301 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.558604 matz1=4.540777 note=collision lift
G1 X159.699738 Y229.371515 Z5.239499 E20899.802216 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.540777 matz1=4.540686 note=collision lift
G1 X159.686302 Y229.49178 Z5.25796 E20899.838242 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.540686 matz1=4.536676 note=collision lift
G1 X159.686298 Y229.49181 Z5.257944 E20899.838252 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.536676 matz1=4.536675 note=collision lift
G1 X159.674447 Y229.597882 Z5.274086 E20899.870021 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.536675 matz1=4.533138 note=collision lift
G1 X159.674437 Y229.597976 Z5.27413 E20899.870052 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.533138 matz1=4.533135 note=collision lift
G1 X159.658362 Y229.74185 Z5.295575 E20899.913122 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.533135 matz1=4.528337 note=collision lift
G1 X159.658308 Y229.742339 Z5.295805 E20899.913282 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.528337 matz1=4.528321 note=collision lift
G1 X159.641827 Y229.889848 Z5.320824 E20899.957581 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.528321 matz1=4.523402 note=collision lift
G1 X159.641643 Y229.891499 Z5.321599 E20899.958121 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.523402 matz1=4.523347 note=collision lift
G1 X159.606713 Y230.204134 Z5.370447 E20900.051812 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.523347 matz1=4.512923 note=collision lift
G1 X159.606624 Y230.204931 Z5.370031 E20900.052068 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.512923 matz1=4.512908 note=collision lift
G1 X159.59378 Y230.319893 Z5.386841 E20900.085248 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.512908 matz1=4.51074 note=collision lift
G1 X159.59347 Y230.322664 Z5.388183 E20900.086126 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.51074 matz1=4.510687 note=collision lift
G1 X159.482443 Y230.672138 Z5.43641 E20900.181508 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510687 matz1=4.505139 note=collision lift
G1 X159.482056 Y230.673356 Z5.43576 E20900.181849 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.505139 matz1=4.505128 note=collision lift
G1 X159.444353 Y230.792032 Z5.45056 E20900.211655 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.505128 matz1=4.504047 note=collision lift
G1 X159.443553 Y230.794548 Z5.451857 E20900.212354 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.504047 matz1=4.504024 note=collision lift
G1 X159.334263 Y231.138554 Z5.491557 E20900.298668 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.504024 matz1=4.50089 note=collision lift
G1 X159.331831 Y231.146209 Z5.495503 E20900.300795 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50089 matz1=4.50082 note=collision lift
G1 X159.092646 Y231.899076 Z5.557548 E20900.503157 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.50082 matz1=4.503501 note=collision lift
G1 X159.090807 Y231.904862 Z5.554533 E20900.504888 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.503501 matz1=4.503522 note=collision lift
G1 X158.994445 Y232.208175 Z5.569735 E20900.586258 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.503522 matz1=4.504602 note=collision lift
G1 X158.994366 Y232.208319 Z5.569657 E20900.586349 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.504602 matz1=4.504606 note=collision lift
G1 X158.878531 Y232.41837 Z5.569363 E20900.706001 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.504606 matz1=4.510917 note=collision lift
G1 X158.877717 Y232.419846 Z5.57025 E20900.706951 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510917 matz1=4.510961 note=collision lift
G1 X158.73986 Y232.669831 Z5.558883 E20900.849465 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.510961 matz1=4.518471 note=collision lift
G1 X158.73821 Y232.672823 Z5.557264 E20900.851351 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.518471 matz1=4.518561 note=collision lift
G1 X158.696557 Y232.748356 Z5.54824 E20900.894612 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.518561 matz1=4.52083 note=collision lift
G1 X158.147671 Y233.743687 Z6.050733 E20901.514522 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.52083 matz1=4.550733 note=collision lift
G1 X158.120525 Y233.792913 Z6.052212 E20901.542572 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.550733 matz1=4.552212 note=collision lift
G1 X158.119875 Y233.794091 Z6.052247 E20901.543244 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.552212 matz1=4.552247 note=collision lift
G1 X158.093934 Y233.841132 Z6.05366 E20901.570049 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.552247 matz1=4.55366 note=collision lift
G1 X158.093379 Y233.842139 Z6.05369 E20901.570623 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.55366 matz1=4.55369 note=collision lift
G1 X158.044541 Y233.930699 Z6.056351 E20901.621088 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.55369 matz1=4.556351 note=collision lift
G1 X158.039086 Y233.940591 Z6.056648 E20901.626725 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.556351 matz1=4.556648 note=collision lift
G1 X157.57125 Y234.495673 Z6.095902 E20902.353124 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.556648 matz1=4.595902 note=collision lift
G1 X157.567749 Y234.499827 Z6.096196 E20902.35856 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.595902 matz1=4.596196 note=collision lift
G1 X157.438908 Y234.652695 Z6.107007 E20902.558608 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.596196 matz1=4.607007 note=collision lift
G1 X157.437941 Y234.653842 Z6.107088 E20902.560109 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.607007 matz1=4.607088 note=collision lift
G1 X156.764106 Y235.453339 Z6.163626 E20903.606357 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.607088 matz1=4.663626 note=collision lift
G1 X156.762901 Y235.454302 Z6.163732 E20903.608023 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.663626 matz1=4.663732 note=collision lift
G1 X156.596013 Y235.587646 Z6.178363 E20903.838759 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.663732 matz1=4.678363 note=collision lift
G1 X156.595999 Y235.587657 Z6.178364 E20903.838777 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.678363 matz1=4.678364 note=collision lift
G1 X156.588022 Y235.59403 Z6.179063 E20903.849806 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.678364 matz1=4.679063 note=collision lift
G1 X156.572888 Y235.606123 Z6.18039 E20903.87073 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.679063 matz1=4.68039 note=collision lift
G1 X156.572821 Y235.606176 Z6.180396 E20903.870823 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.68039 matz1=4.680396 note=collision lift
G1 X156.175523 Y235.923619 Z6.221044 E20904.75121 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.680396 matz1=4.721044 note=collision lift
G1 X156.175442 Y235.923684 Z6.221052 E20904.75139 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.721044 matz1=4.721052 note=collision lift
G1 X155.218561 Y236.688235 Z6.318952 E20906.871777 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.721052 matz1=4.818952 note=collision lift
G1 X155.218502 Y236.688283 Z6.318958 E20906.871909 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.818952 matz1=4.818958 note=collision lift
G1 X154.570926 Y237.023596 Z6.390517 E20908.801729 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.818958 matz1=4.890517 note=collision lift
G1 X154.570834 Y237.023643 Z6.390527 E20908.802002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.890517 matz1=4.890527 note=collision lift
G1 X153.46404 Y237.596738 Z6.39947 E20912.084641 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.890527 matz1=5.01283 note=collision lift
G1 X153.462424 Y237.597575 Z6.39947 E20912.089434 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.01283 matz1=5.013009 note=collision lift
G1 X153.46167 Y237.597966 Z6.39947 E20912.091669 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.013009 matz1=5.013092 note=collision lift
G1 X153.459302 Y237.59865 Z6.39947 E20912.099533 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.013092 matz1=5.013362 note=collision lift
G1 X152.419009 Y237.899407 Z6.39947 E20915.553046 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.013362 matz1=5.131848 note=collision lift
G1 X152.258505 Y237.94581 Z6.39947 E20915.961532 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.131848 matz1=5.150977 note=collision lift
G1 X152.258504 Y237.94581 Z6.39947 E20915.961534 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.150977 matz1=5.150977 note=collision lift
G1 X152.210747 Y237.959617 Z6.399221 E20916.083079 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.150977 matz1=5.156669 note=collision lift
G1 X152.210521 Y237.959683 Z6.399366 E20916.083757 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.156669 matz1=5.156696 note=collision lift
G1 X151.561126 Y238.147428 Z6.395406 E20917.736516 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.156696 matz1=5.234091 note=collision lift
G1 X151.560489 Y238.147482 Z6.395162 E20917.738687 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.234091 matz1=5.234167 note=collision lift
G1 X151.538518 Y238.149356 Z6.394977 E20917.808709 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.234167 matz1=5.236778 note=collision lift
G1 X151.537371 Y238.149454 Z6.395689 E20917.813007 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.236778 matz1=5.236914 note=collision lift
G1 X151.337079 Y238.166537 Z6.385378 E20918.452166 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.236914 matz1=5.260719 note=collision lift
G1 X149.589904 Y238.315555 Z5.716267 E20924.411902 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.260719 matz1=5.468367 note=collision lift
G1 X147.62376 Y238.095885 Z4.960224 E20932.676845 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.468367 matz1=4.960224 note=collision lift
G1 X146.177566 Y237.636431 Z4.368475 E20940.13827 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.960224 matz1=4.368475 note=collision lift
G1 X145.73825 Y237.49686 Z4.419193 E20942.262714 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X144.005833 Y236.541501 Z4.608023 E20952.537304 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X142.493085 Y235.266521 Z4.756392 E20963.711969 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X141.258141 Y233.720917 Z4.855176 E20975.479368 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X140.348459 Y231.964085 Z4.898302 E20987.501014 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X139.798996 Y230.06354 Z4.883117 E20999.426482 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X139.630869 Y228.092319 Z4.810555 E21010.911693 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X139.850539 Y226.126175 Z4.685078 E21021.636644 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X140.449564 Y224.240665 Z4.514402 E21031.323057 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X141.404923 Y222.508248 Z4.30902 E21039.751712 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X142.679903 Y220.9955 Z4.081563 E21046.778146 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X144.123616 Y219.841968 Z3.861506 E21052.06752 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X144.225507 Y219.760556 Z3.846017 E21052.617939 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X145.982339 Y218.850874 Z3.616864 E21058.829873 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X147.882884 Y218.301411 Z3.408195 E21063.0932 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X149.854105 Y218.133284 Z3.232842 E21065.720675 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X151.820249 Y218.352954 Z3.101586 E21067.126428 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.702056 Y218.633103 Z3.064599 E21067.440419 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.70576 Y218.951979 Z3.549069 E21067.833504 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.064599 matz1=3.549069 note=collision lift
G1 X153.791474 Y218.999247 Z3.595553 E21067.869003 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.549069 matz1=3.595553 note=collision lift
G1 X154.41203 Y219.341459 Z3.942497 E21067.993108 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.595553 matz1=3.942497 note=collision lift
G1 X154.801529 Y219.556252 Z3.944014 E21068.06307 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942497 matz1=3.944014 note=collision lift
G1 X154.801709 Y219.556351 Z3.943908 E21068.063106 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.944014 matz1=3.943908 note=collision lift
G1 X155.438176 Y219.907338 Z3.943908 E21068.177428 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943908 matz1=3.943908 note=collision lift
G1 X156.950924 Y221.182318 Z3.943908 E21068.71273 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943908 matz1=3.943908 note=collision lift
G1 X157.035317 Y221.287941 Z3.943908 E21068.751242 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943908 matz1=3.943908 note=collision lift
G1 X157.500659 Y221.870343 Z3.943908 E21069.376278 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943908 matz1=3.943908 note=collision lift
G1 X157.976755 Y222.466206 Z4.325261 E21070.091241 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943908 matz1=4.325261 note=collision lift
G1 X157.976813 Y222.466277 Z4.325357 E21070.091352 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.325261 matz1=4.325357 note=collision lift
G1 X158.185334 Y222.727254 Z4.483308 E21070.401164 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.325357 matz1=4.483308 note=collision lift
G1 X158.185868 Y222.727922 Z4.484204 E21070.402203 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.483308 matz1=4.484204 note=collision lift
G1 X158.887528 Y224.083009 Z5.200898 E21072.942939 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.484204 matz1=4.739523 note=collision lift
G1 X158.88828 Y224.08446 Z5.201016 E21072.945409 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.739523 matz1=4.739641 note=collision lift
G1 X158.937227 Y224.178991 Z5.246382 E21073.119797 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.739641 matz1=4.747333 note=collision lift
G1 X158.937405 Y224.179333 Z5.246796 E21073.120651 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.747333 matz1=4.747361 note=collision lift
G1 X159.089086 Y224.47227 Z5.386062 E21073.660282 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.747361 matz1=4.771197 note=collision lift
G1 X159.094709 Y224.483129 Z5.378996 E21073.681566 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.771197 matz1=4.772081 note=collision lift
G1 X159.095551 Y224.484754 Z5.379129 E21073.684331 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.772081 matz1=4.772213 note=collision lift
G1 X159.349984 Y225.364819 Z4.846444 E21075.832327 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.772213 matz1=4.846444 note=collision lift
G1 X159.352593 Y225.373843 Z4.837895 E21075.858073 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.846444 matz1=4.837895 note=collision lift
G1 X159.374256 Y225.448774 Z4.779788 E21076.055223 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.837895 matz1=4.779788 note=collision lift
G1 X159.375542 Y225.453219 Z4.775576 E21076.067906 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.779788 matz1=4.775576 note=collision lift
G1 X159.386056 Y225.489587 Z4.744478 E21076.167211 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.775576 matz1=4.744478 note=collision lift
G1 X159.386392 Y225.490751 Z4.744587 E21076.169678 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.744478 matz1=4.744587 note=collision lift
G1 X159.438888 Y225.672328 Z4.572569 E21076.687705 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.744587 matz1=4.572569 note=collision lift
G1 X159.459485 Y225.619021 Z4.520913 E21076.845827 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.572569 matz1=4.520913 note=collision lift
G1 X159.470129 Y225.599849 Z4.501169 E21076.917286 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.520913 matz1=4.501169 note=collision lift
G1 X159.843804 Y224.926799 Z4.116257 E21079.001658 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.501169 matz1=4.116257 note=collision lift
G1 X160.413759 Y224.150756 Z3.647545 E21082.547534 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.116257 matz1=3.647545 note=collision lift
G1 X160.879689 Y223.51635 Z3.65794 E21085.154068 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.647545 matz1=3.65794 note=collision lift
G1 X161.538518 Y222.797622 Z3.770611 E21088.921187 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X161.73562 Y222.619382 Z3.801859 E21089.987285 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.622793 Y221.817104 Z3.944047 E21095.587676 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X163.155971 Y221.334947 Z4.02977 E21099.243846 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.201578 Y219.839575 Z4.322122 E21115.613527 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.70593 Y218.311875 Z4.612096 E21138.529902 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.729288 Y218.292827 Z4.614672 E21138.76543 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.406412 Y216.925121 Z4.772565 E21157.262436 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.772778 Y216.6744 Z4.797786 E21161.105385 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.119611 Y215.752695 Z4.867319 E21175.754152 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.782584 Y215.365234 Z4.886852 E21182.712783 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X171.579677 Y215.733179 Z4.893859 E21186.533555 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.424463 Y217.103825 Z4.894101 E21202.833031 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X170.156163 Y217.318198 Z4.888662 E21205.947436 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X169.024046 Y218.222764 Z4.846641 E21218.80789 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X168.071473 Y218.716004 Z4.796321 E21228.081496 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X167.432244 Y219.046995 Z4.753877 E21234.165403 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X165.710228 Y219.544843 Z4.620495 E21248.209667 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X163.924175 Y219.697177 Z4.453236 E21260.867647 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X162.142722 Y219.498142 Z4.26055 E21271.918687 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X160.706215 Y219.041765 Z4.085959 E21279.980479 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X160.434329 Y218.955387 Z4.052173 E21280.967753 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.540525 Y218.462489 Z3.93058 E21283.815998 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X159.364695 Y218.365526 Z3.930795 E21284.372371 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.93058 matz1=3.930795 note=collision lift
G1 X159.336204 Y218.349814 Z3.943187 E21284.468845 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.930795 matz1=3.943187 note=collision lift
G1 X158.927048 Y218.124181 Z3.943787 E21285.763529 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943187 matz1=3.943787 note=collision lift
G1 X158.872767 Y218.094247 Z3.947444 E21285.935589 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.943787 matz1=3.947444 note=collision lift
G1 X158.864648 Y218.08977 Z3.950975 E21285.963079 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.947444 matz1=3.950975 note=collision lift
G1 X158.179325 Y217.512163 Z3.989213 E21287.867215 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.950975 matz1=3.989213 note=collision lift
G1 X158.178594 Y217.511547 Z3.988625 E21287.869596 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.989213 matz1=3.988625 note=collision lift
G1 X157.494002 Y216.934556 Z4.005535 E21289.770312 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.988625 matz1=4.005535 note=collision lift
G1 X157.492003 Y216.932054 Z4.003591 E21289.776024 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.005535 matz1=4.003591 note=collision lift
G1 X157.289545 Y216.678666 Z4.008934 E21290.27057 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.003591 matz1=4.008934 note=collision lift
G1 X157.279084 Y216.665575 Z4.01552 E21290.298021 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.008934 matz1=4.01552 note=collision lift
G1 X156.375063 Y215.53414 Z4.008944 E21292.50601 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.01552 matz1=4.008944 note=collision lift
G1 X156.368671 Y215.521796 Z4.000706 E21292.522282 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.008944 matz1=4.000706 note=collision lift
G1 X156.181669 Y215.160647 Z3.988579 E21292.932046 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.000706 matz1=3.988579 note=collision lift
G1 X156.180819 Y215.159004 Z3.987483 E21292.934211 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.988579 matz1=3.987483 note=collision lift
G1 X156.084973 Y214.9739 Z3.973932 E21293.144581 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.987483 matz1=3.973932 note=collision lift
G1 X156.084376 Y214.972748 Z3.973163 E21293.1461 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.973932 matz1=3.973163 note=collision lift
G1 X156.036624 Y214.880527 Z3.961552 E21293.25134 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.973163 matz1=3.961552 note=collision lift
G1 X156.036162 Y214.879634 Z3.960956 E21293.252518 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.961552 matz1=3.960956 note=collision lift
G1 X156.013285 Y214.835454 Z3.952212 E21293.303391 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.960956 matz1=3.952212 note=collision lift
G1 X156.01245 Y214.83384 Z3.952952 E21293.305367 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.952212 matz1=3.952952 note=collision lift
G1 X155.988276 Y214.787153 Z3.935595 E21293.361125 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.952952 matz1=3.935595 note=collision lift
G1 X155.967346 Y214.746732 Z3.908622 E21293.414411 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.935595 matz1=3.908622 note=collision lift
G1 X155.553266 Y213.947037 Z3.880941 E21294.321778 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.908622 matz1=3.880941 note=collision lift
G1 X155.550832 Y213.942337 Z3.883097 E21294.327534 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.880941 matz1=3.883097 note=collision lift
G1 X155.131808 Y212.492967 Z3.769544 E21295.229711 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.883097 matz1=3.769544 note=collision lift
G1 X155.131026 Y212.490262 Z3.767929 E21295.231646 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.769544 matz1=3.767929 note=collision lift
G1 X155.126802 Y212.475652 Z3.764909 E21295.240892 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.767929 matz1=3.764909 note=collision lift
G1 X155.052984 Y212.220322 Z3.878267 E21295.413189 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.764909 matz1=3.878267 note=collision lift
G1 X155.052828 Y212.21849 Z3.879093 E21295.41382 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.878267 matz1=3.879093 note=collision lift
G1 X155.0491 Y212.17479 Z3.895316 E21295.428451 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.879093 matz1=3.895316 note=collision lift
G1 X155.049004 Y212.17366 Z3.894691 E21295.428857 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.895316 matz1=3.894691 note=collision lift
G1 X155.045891 Y212.137161 Z3.902753 E21295.440592 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.894691 matz1=3.902753 note=collision lift
G1 X155.045373 Y212.13109 Z3.90549 E21295.442682 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.902753 matz1=3.90549 note=collision lift
G1 X155.012386 Y211.744324 Z3.929427 E21295.564367 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.90549 matz1=3.929427 note=collision lift
G1 X155.012333 Y211.743704 Z3.929707 E21295.56458 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.929427 matz1=3.929707 note=collision lift
G1 X154.901872 Y210.448593 Z3.950542 E21295.971329 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.929707 matz1=3.950542 note=collision lift
G1 X154.901719 Y210.446801 Z3.949551 E21295.971971 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.950542 matz1=3.949551 note=collision lift
G1 X154.90065 Y210.434269 Z3.949551 E21295.975907 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949551 matz1=3.949551 note=collision lift
G1 X154.955999 Y209.938872 Z3.949551 E21296.061261 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949551 matz1=3.949551 note=collision lift
G1 X154.957089 Y209.929112 Z3.954213 E21296.063123 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949551 matz1=3.954213 note=collision lift
G1 X155.021319 Y209.354226 Z4.112559 E21296.165817 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.954213 matz1=4.112559 note=collision lift
G1 X155.021904 Y209.348993 Z4.109792 E21296.166835 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.112559 matz1=4.109792 note=collision lift
G1 X155.022112 Y209.347131 Z4.11068 E21296.16719 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.109792 matz1=4.11068 note=collision lift
G1 X155.022112 Y209.347128 Z4.110678 E21296.167191 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.11068 matz1=4.110678 note=collision lift
G1 X155.075898 Y208.86572 Z4.110678 E21296.250135 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.110678 matz1=4.110678 note=collision lift
G1 X155.076996 Y208.855894 Z4.114325 E21296.25194 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.110678 matz1=4.114325 note=collision lift
G1 X155.076997 Y208.855888 Z4.114321 E21296.251941 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114325 matz1=4.114321 note=collision lift
G1 X155.099685 Y208.652816 Z4.114321 E21296.286929 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114321 matz1=4.114321 note=collision lift
G1 X155.316504 Y207.97035 Z4.114321 E21296.414727 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114321 matz1=4.114321 note=collision lift
G1 X155.316512 Y207.970325 Z4.114335 E21296.414732 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114321 matz1=4.114335 note=collision lift
G1 X155.319748 Y207.960139 Z4.110678 E21296.416748 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.114335 matz1=4.110678 note=collision lift
G1 X155.430704 Y207.610888 Z4.110678 E21296.482148 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.110678 matz1=4.110678 note=collision lift
G1 X155.430707 Y207.61088 Z4.110682 E21296.48215 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.110678 matz1=4.110682 note=collision lift
G1 X155.431721 Y207.60769 Z4.109013 E21296.482818 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.110682 matz1=4.109013 note=collision lift
G1 X155.432171 Y207.606272 Z4.109759 E21296.483115 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.109013 matz1=4.109759 note=collision lift
G1 X155.479524 Y207.457222 Z4.045383 E21296.513298 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.109759 matz1=4.045383 note=collision lift
G1 X155.479911 Y207.456004 Z4.046023 E21296.513553 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.045383 matz1=4.046023 note=collision lift
G1 X155.538484 Y207.271639 Z3.949551 E21296.552132 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.046023 matz1=3.949551 note=collision lift
G1 X155.581206 Y207.137163 Z3.949551 E21296.577313 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949551 matz1=3.949551 note=collision lift
G1 X155.58168 Y207.135673 Z3.950335 E21296.577626 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.949551 matz1=3.950335 note=collision lift
G1 X155.64244 Y206.944422 Z3.942059 E21296.613469 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.950335 matz1=3.942059 note=collision lift
G1 X155.646688 Y206.936718 Z3.937905 E21296.616721 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.942059 matz1=3.937905 note=collision lift
G1 X155.647831 Y206.934647 Z3.937397 E21296.61753 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937905 matz1=3.937397 note=collision lift
G1 X156.508057 Y205.374742 Z3.096355 E21297.275957 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.937397 matz1=3.096355 note=collision lift
G1 X156.558535 Y205.314849 Z3.061346 E21297.330066 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.096355 matz1=3.061346 note=collision lift
G1 X157.020953 Y204.766197 Z3.099399 E21297.783225 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X157.663271 Y204.004095 Z3.650598 E21298.50152 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.099399 matz1=3.650598 note=collision lift
G1 X157.886032 Y203.826108 Z3.812158 E21298.727614 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.650598 matz1=3.812158 note=collision lift
G1 X159.063687 Y202.885157 Z4.682241 E21301.476148 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.812158 matz1=4.682241 note=collision lift
G1 X160.65549 Y202.060926 Z5.74735 E21306.415494 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.682241 matz1=4.956472 note=collision lift
G1 X161.147966 Y201.918547 Z6.059046 E21308.371014 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.956472 matz1=5.011846 note=collision lift
G1 X161.175795 Y201.910501 Z6.061696 E21308.465828 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.011846 matz1=5.014975 note=collision lift
G1 X161.176683 Y201.910245 Z6.062258 E21308.469351 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.014975 matz1=5.015075 note=collision lift
G1 X162.348789 Y201.571379 Z6.162268 E21312.459486 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.015075 matz1=5.146865 note=collision lift
G1 X162.347857 Y201.571209 Z6.161903 E21312.463099 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.146865 matz1=5.146973 note=collision lift
G1 X161.797733 Y201.470456 Z6.117035 E21314.460127 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.146973 matz1=5.210947 note=collision lift
G1 X161.797356 Y201.470387 Z6.117271 E21314.461728 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.210947 matz1=5.210991 note=collision lift
G1 X161.156297 Y201.296336 Z6.062244 E21317.769002 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.210991 matz1=5.2896 note=collision lift
G1 X161.154692 Y201.295901 Z6.06161 E21317.777835 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.2896 matz1=5.289797 note=collision lift
G1 X161.130994 Y201.289466 Z6.059049 E21317.900339 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.289797 matz1=5.292703 note=collision lift
G1 X159.351958 Y200.806451 Z5.355481 E21327.690736 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.292703 matz1=5.355481 note=collision lift
G1 X157.565004 Y200.116937 Z4.622033 E21340.018527 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.355481 matz1=4.622033 note=collision lift
G1 X157.316758 Y200.021148 Z4.519127 E21341.188527 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.622033 matz1=4.519127 note=collision lift
G1 X156.86234 Y199.794514 Z4.321321 E21343.57204 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.519127 matz1=4.321321 note=collision lift
G1 X156.608399 Y199.667865 Z4.352667 E21344.820721 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X156.445095 Y199.58642 Z4.372291 E21346.041689 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.147472 Y198.75294 Z4.526925 E21357.624802 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.972565 Y198.640595 Z4.651708 E21359.436696 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.526925 matz1=4.651708 note=collision lift
G1 X154.921694 Y198.598025 Z4.690771 E21360.037335 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.651708 matz1=4.690771 note=collision lift
G1 X154.880376 Y198.563449 Z4.690771 E21360.457706 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.690771 matz1=4.690771 note=collision lift
G1 X154.880189 Y198.563292 Z4.690771 E21360.459614 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.690771 matz1=4.690771 note=collision lift
G1 X154.880001 Y198.563135 Z4.690771 E21360.461523 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.690771 matz1=4.690771 note=collision lift
G1 X154.712236 Y198.422744 Z4.690771 E21362.168369 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.690771 matz1=4.690771 note=collision lift
G1 X154.712136 Y198.42266 Z4.69083 E21362.169489 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.690771 matz1=4.69083 note=collision lift
G1 X154.364997 Y198.132164 Z4.69083 E21365.701303 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.69083 matz1=4.69083 note=collision lift
G1 X153.388131 Y197.052468 Z4.72991 E21377.827087 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.69083 matz1=4.72991 note=collision lift
G1 X153.013112 Y196.484077 Z4.773417 E21383.646511 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.46707 Y195.296599 Z4.839805 E21395.214041 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.291096 Y194.681572 Z4.863654 E21400.943753 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.11062 Y193.414357 Z4.893543 E21412.58259 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.138703 Y192.108664 Z4.89893 E21424.487561 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.258343 Y191.332998 Z4.889881 E21431.609044 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.344213 Y190.776276 Z4.877746 E21434.99585 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.492207 Y190.232758 Z4.860965 E21438.353884 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.698401 Y189.47549 Z4.829999 E21445.260446 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.186744 Y188.311945 Z4.762074 E21455.9568 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.20382 Y188.271257 Z4.781762 E21456.365784 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.762074 matz1=4.781762 note=collision lift
G1 X153.884115 Y187.187005 Z5.331732 E21467.571242 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.781762 matz1=5.331732 note=collision lift
G1 X154.295029 Y186.696725 Z5.599463 E21472.979955 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331732 matz1=5.599463 note=collision lift
G1 X154.337663 Y186.659263 Z5.60616 E21473.399288 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.599463 matz1=5.60616 note=collision lift
G1 X154.337852 Y186.659097 Z5.606316 E21473.401464 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.60616 matz1=5.606316 note=collision lift
G1 X154.338042 Y186.65893 Z5.60619 E21473.403533 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.606316 matz1=5.60619 note=collision lift
G1 X155.115227 Y185.976026 Z5.60619 E21480.99504 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.60619 matz1=5.60619 note=collision lift
G1 X155.432184 Y187.072356 Z5.60619 E21488.497837 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.60619 matz1=5.60619 note=collision lift
G1 X155.432731 Y187.074248 Z5.606974 E21488.511771 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.60619 matz1=5.606974 note=collision lift
G1 X155.462394 Y187.176849 Z5.58183 E21489.233117 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.606974 matz1=5.58183 note=collision lift
G1 X155.559085 Y187.511296 Z5.372203 E21491.904815 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.58183 matz1=5.372203 note=collision lift
G1 X155.727212 Y189.482517 Z4.159166 E21504.731843 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.372203 matz1=4.159166 note=collision lift
G1 X155.721126 Y189.536991 Z4.125257 E21505.03508 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.159166 matz1=4.125257 note=collision lift
G1 X155.686133 Y189.850191 Z4.087874 E21506.528172 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X155.562589 Y190.955972 Z4.512221 E21512.130757 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.087874 matz1=4.512221 note=collision lift
G1 X155.507542 Y191.448662 Z4.700943 E21513.696705 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.512221 matz1=4.700943 note=collision lift
G1 X155.357435 Y191.921146 Z4.889872 E21515.165352 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.700943 matz1=4.889872 note=collision lift
G1 X154.908518 Y193.334172 Z5.458383 E21520.475453 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.889872 matz1=5.164986 note=collision lift
G1 X153.953158 Y195.066589 Z6.233348 E21525.451968 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.164986 matz1=4.950762 note=collision lift
G1 X153.813384 Y195.232429 Z6.321672 E21525.799442 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.950762 matz1=4.930642 note=collision lift
G1 X153.764699 Y195.290193 Z6.334582 E21525.913158 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.930642 matz1=4.923635 note=collision lift
G1 X153.76389 Y195.291153 Z6.333838 E21525.915323 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.923635 matz1=4.923518 note=collision lift
G1 X153.73014 Y195.331197 Z6.338277 E21525.993307 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.923518 matz1=4.91866 note=collision lift
G1 X153.716014 Y195.347957 Z6.347203 E21526.028423 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.91866 matz1=4.916627 note=collision lift
G1 X153.222604 Y195.933382 Z6.345603 E21527.164438 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.916627 matz1=4.845603 note=collision lift
G1 X153.221015 Y195.935268 Z6.345374 E21527.168113 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.845603 matz1=4.845374 note=collision lift
G1 X152.729195 Y196.518806 Z6.27458 E21528.305328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.845374 matz1=4.77458 note=collision lift
G1 X152.727456 Y196.520869 Z6.274329 E21528.309348 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.77458 matz1=4.774329 note=collision lift
G1 X152.678547 Y196.578899 Z6.267289 E21528.422439 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.774329 matz1=4.767289 note=collision lift
G1 X152.678178 Y196.579336 Z6.267236 E21528.423291 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.767289 matz1=4.767236 note=collision lift
G1 X152.506111 Y196.716819 Z6.251479 E21528.604742 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.767236 matz1=4.751479 note=collision lift
G1 X152.504951 Y196.717746 Z6.251372 E21528.605965 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.751479 matz1=4.751372 note=collision lift
G1 X152.231566 Y196.936181 Z6.226336 E21528.894259 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.751372 matz1=4.726336 note=collision lift
G1 X152.23045 Y196.937073 Z6.226234 E21528.895436 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.726336 matz1=4.726234 note=collision lift
G1 X152.096612 Y197.04401 Z6.213978 E21529.036573 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.726234 matz1=4.713978 note=collision lift
G1 X152.094874 Y197.045399 Z6.213819 E21529.038406 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.713978 matz1=4.713819 note=collision lift
G1 X151.958182 Y197.154616 Z6.201301 E21529.182552 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.713819 matz1=4.701301 note=collision lift
G1 X151.132574 Y197.814281 Z5.67496 E21530.152715 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.701301 matz1=4.625693 note=collision lift
G1 X149.375743 Y198.723963 Z4.594914 E21531.047091 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.625693 matz1=4.534836 note=collision lift
G1 X148.675621 Y198.926374 Z4.211041 E21531.298899 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.534836 matz1=4.211041 note=collision lift
G1 X148.287765 Y199.038506 Z4.001745 E21531.38105 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.211041 matz1=4.001745 note=collision lift
G1 X147.475198 Y199.273426 Z3.571141 E21531.604136 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.001745 matz1=3.571141 note=collision lift
G1 X146.33755 Y199.370457 Z3.013996 E21532.044259 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.571141 matz1=3.013996 note=collision lift
G1 X145.503977 Y199.441553 Z3.024067 E21532.334102 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X143.537832 Y199.221883 Z3.104818 E21533.767867 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X143.288853 Y199.142782 Z3.119511 E21533.975317 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X144.439221 Y199.044667 Z3.197004 E21535.418935 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X144.732118 Y199.019685 Z3.363715 E21535.840543 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.197004 matz1=3.363715 note=collision lift
G1 X145.42943 Y199.097593 Z3.775245 E21537.506566 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.363715 matz1=3.775245 note=collision lift
G1 X146.698262 Y199.239355 Z5.162431 E21541.367903 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.775245 matz1=4.887898 note=collision lift
G1 X146.739582 Y199.252482 Z5.184108 E21541.505216 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.887898 matz1=4.892354 note=collision lift
G1 X146.739596 Y199.252487 Z5.184124 E21541.505275 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.892354 matz1=4.892356 note=collision lift
G1 X146.947164 Y199.318431 Z5.290631 E21542.192063 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.892356 matz1=4.914742 note=collision lift
G1 X146.947242 Y199.318455 Z5.290721 E21542.192406 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.914742 matz1=4.91475 note=collision lift
G1 X147.493749 Y199.49208 Z5.570823 E21544.000249 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.91475 matz1=4.97369 note=collision lift
G1 X147.49385 Y199.492112 Z5.57094 E21544.000696 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.97369 matz1=4.973701 note=collision lift
G1 X148.253829 Y199.733557 Z5.959631 E21546.513683 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.973701 matz1=5.055664 note=collision lift
G1 X148.40402 Y199.781273 Z5.976911 E21546.831846 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.055664 matz1=5.072944 note=collision lift
G1 X148.583773 Y199.83838 Z5.808987 E21547.338649 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.072944 matz1=5.093625 note=collision lift
G1 X149.943548 Y200.588242 Z4.434832 E21552.971899 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.093625 matz1=4.434832 note=collision lift
G1 X150.316189 Y200.793739 Z4.271023 E21554.210691 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.434832 matz1=4.271023 note=collision lift
G1 X151.003995 Y201.373439 Z3.928367 E21557.532736 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.271023 matz1=3.928367 note=collision lift
G1 X151.828937 Y202.068719 Z4.056822 E21561.282429 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.063881 Y203.614323 Z4.285809 E21569.577858 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.973564 Y205.371155 Z4.494148 E21579.156158 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.523026 Y207.2717 Z4.669028 E21589.801942 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.691153 Y209.242921 Z4.799695 E21601.237303 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X154.471483 Y211.209065 Z4.878115 E21613.140904 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X153.872458 Y213.094576 Z4.899465 E21625.167574 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.917099 Y214.826992 Z4.862434 E21636.967168 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X152.724766 Y215.055193 Z4.851875 E21638.738129 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X151.642119 Y216.33974 Z4.769297 E21653.050349 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X150.380419 Y217.347843 Z4.652144 E21665.741793 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X150.096515 Y217.574684 Z4.807482 E21668.839414 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.652144 matz1=4.807482 note=collision lift
G1 X149.820865 Y217.717415 Z4.837238 E21671.013641 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.807482 matz1=4.837238 note=collision lift
G1 X149.818729 Y217.718521 Z4.838216 E21671.031738 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.837238 matz1=4.838216 note=collision lift
G1 X149.113753 Y218.083555 Z4.909052 E21676.588949 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.838216 matz1=4.909052 note=collision lift
G1 X149.112471 Y218.084219 Z4.908195 E21676.60065 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.909052 matz1=4.908195 note=collision lift
G1 X148.339683 Y218.484367 Z4.908195 E21682.668303 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.908195 matz1=4.908195 note=collision lift
G1 X147.893857 Y218.613258 Z4.625662 E21685.90957 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.908195 matz1=4.625662 note=collision lift
G1 X146.439139 Y219.033829 Z5.218058 E21695.609983 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.625662 matz1=5.218058 note=collision lift
G1 X146.094113 Y219.063257 Z5.258989 E21697.311479 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.218058 matz1=5.258989 note=collision lift
G1 X146.092387 Y219.063404 Z5.259651 E21697.32053 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.258989 matz1=5.259651 note=collision lift
G1 X145.469245 Y219.116552 Z5.329243 E21700.391144 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.259651 matz1=5.329243 note=collision lift
G1 X145.468389 Y219.116625 Z5.328712 E21700.396076 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.329243 matz1=5.328712 note=collision lift
G1 X145.305133 Y219.130549 Z5.346063 E21701.200075 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.328712 matz1=5.346063 note=collision lift
G1 X145.305059 Y219.130556 Z5.346017 E21701.200504 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.346063 matz1=5.346017 note=collision lift
G1 X144.467917 Y219.201956 Z5.346017 E21705.300328 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.346017 matz1=5.346017 note=collision lift
G1 X144.374928 Y219.191567 Z5.288066 E21705.804685 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.346017 matz1=5.288066 note=collision lift
G1 X143.938927 Y219.142854 Z5.455062 E21707.955845 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.288066 matz1=5.429765 note=collision lift
G1 X143.528371 Y219.096984 Z5.460408 E21708.997327 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.429765 matz1=5.380825 note=collision lift
G1 X143.525942 Y219.096713 Z5.458896 E21709.004571 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.380825 matz1=5.380535 note=collision lift
G1 X143.320067 Y219.073711 Z5.451148 E21709.527146 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.380535 matz1=5.355994 note=collision lift
G1 X143.318377 Y219.073522 Z5.450096 E21709.532187 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.355994 matz1=5.355793 note=collision lift
G1 X143.215916 Y219.062075 Z5.439591 E21709.79343 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.355793 matz1=5.343579 note=collision lift
G1 X143.214596 Y219.061927 Z5.43877 E21709.797365 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.343579 matz1=5.343421 note=collision lift
G1 X143.16384 Y219.056256 Z5.429135 E21709.928382 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.343421 matz1=5.337371 note=collision lift
G1 X143.162599 Y219.056118 Z5.428362 E21709.932084 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.337371 matz1=5.337223 note=collision lift
G1 X143.139285 Y219.053513 Z5.421127 E21709.99397 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.337223 matz1=5.334444 note=collision lift
G1 X143.137802 Y219.053347 Z5.421696 E21709.997995 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.334444 matz1=5.334267 note=collision lift
G1 X143.111764 Y219.050438 Z5.405882 E21710.075141 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.334267 matz1=5.331163 note=collision lift
G1 X142.501773 Y218.982286 Z5.026275 E21711.894417 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.331163 matz1=5.026275 note=collision lift
G1 X140.616263 Y218.383261 Z3.814021 E21716.129591 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=5.026275 matz1=3.814021 note=collision lift
G1 X140.132085 Y218.116257 Z3.482345 E21716.909287 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.814021 matz1=3.482345 note=collision lift
G1 X140.089934 Y218.093012 Z3.477751 E21716.967761 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.482345 matz1=3.477751 note=collision lift
G1 X139.651664 Y217.851324 Z3.498489 E21717.573508 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.477751 matz1=3.498489 note=collision lift
G1 X139.646559 Y217.848508 Z3.500822 E21717.581102 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.498489 matz1=3.500822 note=collision lift
G1 X138.883846 Y217.427902 Z3.522196 E21718.634687 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.500822 matz1=3.522196 note=collision lift
G1 X138.880538 Y217.425114 Z3.519683 E21718.638242 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.522196 matz1=3.519683 note=collision lift
G1 X138.435192 Y217.049766 Z3.526766 E21719.052137 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.519683 matz1=3.526766 note=collision lift
G1 X138.424892 Y217.041085 Z3.532412 E21719.062516 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.526766 matz1=3.532412 note=collision lift
G1 X137.521572 Y216.279744 Z3.503892 E21719.902226 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.532412 matz1=3.503892 note=collision lift
G1 X137.509779 Y216.269805 Z3.494934 E21719.9149 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.503892 matz1=3.494934 note=collision lift
G1 X137.375363 Y216.156516 Z3.48365 E21720.040071 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.494934 matz1=3.48365 note=collision lift
G1 X137.371098 Y216.152922 Z3.485988 E21720.044369 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.48365 matz1=3.485988 note=collision lift
G1 X137.043195 Y215.742532 Z3.448728 E21720.233927 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.485988 matz1=3.448728 note=collision lift
G1 X137.039942 Y215.738461 Z3.445826 E21720.236074 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.448728 matz1=3.445826 note=collision lift
G1 X136.882042 Y215.54084 Z3.413638 E21720.32786 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.445826 matz1=3.413638 note=collision lift
G1 X136.879244 Y215.537337 Z3.415625 E21720.329626 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.413638 matz1=3.415625 note=collision lift
G1 X136.715292 Y215.332142 Z3.355927 E21720.426579 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.415625 matz1=3.355927 note=collision lift
G1 X136.41847 Y214.960652 Z3.091145 E21720.622486 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.355927 matz1=3.091145 note=collision lift
G1 X136.136154 Y214.607318 Z3.065438 E21720.785545 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X135.226472 Y212.850486 Z3.007379 E21721.139661 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X134.969927 Y211.96312 Z3.007333 E21721.304645 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X134.677009 Y210.949942 Z3.534617 E21721.515251 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.007333 matz1=3.534617 note=collision lift
G1 X134.643956 Y210.562412 Z3.740462 E21721.673253 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.534617 matz1=3.740462 note=collision lift
G1 X134.640331 Y210.519909 Z3.756562 E21721.689624 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.740462 matz1=3.756562 note=collision lift
G1 X134.640193 Y210.518293 Z3.755799 E21721.690268 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.756562 matz1=3.755799 note=collision lift
G1 X134.636805 Y210.47857 Z3.763346 E21721.704836 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.755799 matz1=3.763346 note=collision lift
G1 X134.636706 Y210.477405 Z3.763965 E21721.705311 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.763346 matz1=3.763965 note=collision lift
G1 X134.629574 Y210.393782 Z3.773478 E21721.735639 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.763965 matz1=3.773478 note=collision lift
G1 X134.629456 Y210.392399 Z3.774213 E21721.736203 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.773478 matz1=3.774213 note=collision lift
G1 X134.615111 Y210.224211 Z3.784137 E21721.796915 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.774213 matz1=3.784137 note=collision lift
G1 X134.614955 Y210.222385 Z3.785107 E21721.79766 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.784137 matz1=3.785107 note=collision lift
G1 X134.586181 Y209.885022 Z3.791529 E21721.919253 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.785107 matz1=3.791529 note=collision lift
G1 X134.585954 Y209.882358 Z3.792944 E21721.920339 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.791529 matz1=3.792944 note=collision lift
G1 X134.527952 Y209.202304 Z3.785356 E21722.165418 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.792944 matz1=3.785356 note=collision lift
G1 X134.527615 Y209.198357 Z3.783492 E21722.16699 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.785356 matz1=3.783492 note=collision lift
G1 X134.509392 Y208.984696 Z3.778234 E21722.244007 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.783492 matz1=3.778234 note=collision lift
G1 X134.508882 Y208.97872 Z3.781408 E21722.246444 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.778234 matz1=3.781408 note=collision lift
G1 X134.621788 Y207.96816 Z3.758725 E21722.967724 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.781408 matz1=3.758725 note=collision lift
G1 X134.622018 Y207.966105 Z3.757808 E21722.969328 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.758725 matz1=3.757808 note=collision lift
G1 X134.72796 Y207.01787 Z3.718011 E21723.646544 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.757808 matz1=3.718011 note=collision lift
G1 X134.728552 Y207.012576 Z3.720977 E21723.650868 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.718011 matz1=3.720977 note=collision lift
G1 X135.141371 Y205.713171 Z3.650139 E21725.299234 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.720977 matz1=3.650139 note=collision lift
G1 X135.145437 Y205.700373 Z3.64451 E21725.316814 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.650139 matz1=3.64451 note=collision lift
G1 X135.327287 Y205.127978 Z3.59156 E21726.044763 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.64451 matz1=3.59156 note=collision lift
G1 X135.327577 Y205.127066 Z3.592116 E21726.0461 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.59156 matz1=3.592116 note=collision lift
G1 X135.362251 Y205.064189 Z3.585185 E21726.177613 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.592116 matz1=3.585185 note=collision lift
G1 X135.681545 Y204.485191 Z3.981781 E21727.583262 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.585185 matz1=3.981781 note=collision lift
G1 X136.282936 Y203.394649 Z3.981781 E21729.853695 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.981781 matz1=3.981781 note=collision lift
G1 X136.610179 Y203.00638 Z3.981781 E21731.132511 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.981781 matz1=3.981781 note=collision lift
G1 X137.112688 Y202.410159 Z3.679803 E21733.238366 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=3.981781 matz1=3.679803 note=collision lift
G1 X137.557916 Y201.881901 Z3.757675 E21734.98927 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X138.650239 Y201.009131 Z3.923255 E21739.262027 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X139.10352 Y200.646957 Z3.992503 E21742.111171 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X140.860352 Y199.737275 Z4.224716 E21753.987454 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X142.323205 Y199.314352 Z4.390449 E21764.662574 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X142.760897 Y199.187812 Z4.667846 E21768.38008 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.390449 matz1=4.667846 note=collision lift
G1 X143.2859 Y199.143034 Z4.703212 E21772.191562 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.667846 matz1=4.703212 note=collision lift
G1 X143.288853 Y199.142782 Z4.70499 E21772.216503 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.703212 matz1=4.70499 note=collision lift
G1 X143.191468 Y199.111843 Z4.698142 E21773.029551 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.70499 matz1=4.698142 note=collision lift
G1 X143.19102 Y199.111701 Z4.698346 E21773.033618 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.698142 matz1=4.698346 note=collision lift
G1 X143.190571 Y199.111558 Z4.698079 E21773.037909 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.698346 matz1=4.698079 note=collision lift
G1 X142.097529 Y198.7643 Z4.621218 E21782.163482 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.698079 matz1=4.621218 note=collision lift
G1 X142.067421 Y198.754735 Z4.608261 E21782.434568 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 matz0=4.621218 matz1=4.608261 note=collision lift
G1 X141.652322 Y198.622858 Z4.647396 E21785.906313 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X139.919905 Y197.667499 Z4.784684 E21802.923986 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X138.877549 Y196.788976 Z4.8498 E21815.05084 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X138.489823 Y196.462191 Z4.867378 E21818.084257 F2400 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X138.407158 Y196.392519 Z4.870647 E21819.055883 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X137.172213 Y194.846914 Z4.9 E21837.101768 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X136.262531 Y193.090083 Z4.870938 E21854.878666 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X135.998959 Y192.178409 Z4.829833 E21863.03245 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000
G1 X135.713068 Y191.189538 Z4.785248 E21871.876658 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=attached-tail
G1 X135.544941 Y189.218317 Z4.648199 E21887.628236 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=attached-tail
G1 X135.764611 Y187.252172 Z4.468219 E21901.734758 F1600 ; clayline kind=print page=1 layer=0 stroke=stroke-0000 note=attached-tail
; CLAYLINE_STROKE_END page=1 layer=0 id=stroke-0000
G1 X135.764611 Y187.252172 Z6.468219 E21915.936805 F1600 ; clayline kind=thread_release page=1 layer=0 stroke=stroke-0000 note=thread release
; CLAYLINE_BODY_END
; CLAYLINE_PROFILE_END_BEGIN
M83 ;Set to Relative Extrusion Mode
G91 ;Set to Relative Positioning
G1 Z150 E-100 F40000 ;Move Z Axis up and relieve Extruder pressure (v1.3.0: was E-3000, which left the next job dry)
G90 ;Set to Absolute Positioning
G28 Z ;Home Z
G1 X207.5 Y0 F500 ;Move X and Y slow to home position
M82 ;absolute extrusion mode
; CLAYLINE_PROFILE_END_END
